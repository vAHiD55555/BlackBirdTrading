'use strict';
/**
 * v16 — two-model security review.
 *
 * Sends the security-critical surface to TWO different models and records what
 * each one says. This is a REVIEW, not a test: a model's opinion is not a
 * passing assertion, so nothing here can fail the build. What it can do is find
 * something the hand-written tests did not think of, and that is the point.
 *
 * The models are reached through the project's own provider layer, so the same
 * free-only rule applies: no paid provider, no key required.
 *
 *   node scripts/security-review.js
 *
 * Output: reports/security-review.json + a readable summary on stdout.
 */
const fs = require('node:fs');
const path = require('node:path');
const { createProvider } = require('../src/jev/providers');

const ROOT = path.resolve(__dirname, '..');

/** The files a reviewer must see to judge the attack surface. */
const TARGETS = [
  'src/web/status.js',
  'src/web/auth.js',
  'src/web/ratelimit.js',
  'src/plugins/registry.js',
  'src/profiles-live.js',
  'src/intel/news.js',
];

/** Two different models, so a blind spot in one is not a blind spot in both. */
const MODELS = [
  { provider: 'pollinations', model: 'openai', label: 'model-A (openai)' },
  { provider: 'pollinations', model: 'openai-fast', label: 'model-B (openai-fast)' },
];

const PROMPT = `You are a security reviewer for a Node.js crypto trading bot.

Read the code below and report ONLY concrete, exploitable problems. For each:
  - severity: blocker | major | minor
  - file and the exact function or line
  - the attack: what an attacker sends, and what happens
  - the fix, in one or two sentences

You MUST check each of these attack classes explicitly, and say which ones you
checked:
  1. authentication bypass (a route reachable without a valid token)
  2. path traversal / arbitrary file read
  3. reflected or stored injection (HTML, script, header)
  4. prototype pollution via a JSON body
  5. unbounded body or memory growth (a request that can exhaust the process)
  6. rate-limit bypass (a route that should be limited but is not)
  7. secret leakage (a key, token or env value reaching a response or a log)
  8. a plugin or profile escaping its sandbox (reaching the broker, raising risk)

Rules for your answer:
  - No praise, no summary of what the code does, no style comments.
  - "none" is a valid answer for a file, but only after you checked all eight.
  - Do not invent a vulnerability to seem useful.
  - Answer in English, as a JSON array of objects with keys:
    severity, file, where, attack, fix.
  - If you find nothing at all, return exactly: []

CODE:
`;

function readTargets() {
  const parts = [];
  for (const rel of TARGETS) {
    const abs = path.join(ROOT, rel);
    if (!fs.existsSync(abs)) continue;
    const body = fs.readFileSync(abs, 'utf8');
    // Cap each file so the prompt stays inside a free-tier context window.
    parts.push(`\n===== ${rel} =====\n${body.slice(0, 12000)}`);
  }
  return parts.join('\n');
}

/** Pull a JSON array out of a model reply that may be wrapped in prose. */
function extractJson(text) {
  if (!text) return null;
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf('[');
  const end = candidate.lastIndexOf(']');
  if (start < 0 || end <= start) return null;
  try {
    const parsed = JSON.parse(candidate.slice(start, end + 1));
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

async function askOne({ provider, model, label }, code, attempt = 1) {
  const started = Date.now();
  try {
    const p = createProvider({ provider, model, timeoutMs: 90000 });
    const text = await p.complete({
      messages: [
        { role: 'system', content: 'You are a precise security reviewer. You answer with JSON only.' },
        { role: 'user', content: PROMPT + code },
      ],
      timeoutMs: 90000,
    });
    const findings = extractJson(text);
    return {
      label,
      provider,
      model,
      ok: true,
      attempt,
      elapsedMs: Date.now() - started,
      parsed: Boolean(findings),
      findings: findings || [],
      rawHead: findings ? null : String(text).slice(0, 600),
    };
  } catch (e) {
    // Pollinations allows one reply per 45 s per IP. A 402 is a wait, not a
    // failure: retry once after the window it names, then give up honestly.
    const m = /Retry after (\d+)s/.exec(e.message || '');
    if (m && attempt < 3) {
      const waitMs = (Number(m[1]) + 3) * 1000;
      process.stdout.write(`\n    rate limited, waiting ${Math.round(waitMs / 1000)}s … `);
      await new Promise((r) => setTimeout(r, waitMs));
      return askOne({ provider, model, label }, code, attempt + 1);
    }
    return {
      label, provider, model, ok: false, attempt,
      elapsedMs: Date.now() - started,
      error: e.message,
    };
  }
}

(async () => {
  const code = readTargets();
  console.log(`\n  security review — ${TARGETS.length} files, ${Math.round(code.length / 1024)} KB of code`);
  console.log(`  models: ${MODELS.map((m) => m.label).join(', ')}\n`);

  const results = [];
  for (const m of MODELS) {
    process.stdout.write(`  asking ${m.label} … `);
    const r = await askOne(m, code);
    results.push(r);
    if (!r.ok) console.log(`FAILED (${r.error})`);
    else if (!r.parsed) console.log(`answered in ${r.elapsedMs}ms but not as JSON`);
    else console.log(`${r.findings.length} finding(s) in ${r.elapsedMs}ms`);
  }

  const outDir = path.join(ROOT, 'reports');
  fs.mkdirSync(outDir, { recursive: true });
  const outFile = path.join(outDir, 'security-review.json');
  fs.writeFileSync(outFile, JSON.stringify({ at: new Date().toISOString(), targets: TARGETS, results }, null, 2));

  console.log('\n  ── findings ──');
  let total = 0;
  for (const r of results) {
    if (!r.ok || !r.parsed) continue;
    for (const f of r.findings) {
      total++;
      console.log(`  [${r.label}] ${String(f.severity || '?').toUpperCase()} ${f.file || '?'} — ${f.where || ''}`);
      console.log(`      attack: ${String(f.attack || '').slice(0, 200)}`);
      console.log(`      fix:    ${String(f.fix || '').slice(0, 200)}`);
    }
  }
  if (!total) console.log('  (no findings returned)');
  console.log(`\n  written to ${path.relative(ROOT, outFile)}\n`);
})();
