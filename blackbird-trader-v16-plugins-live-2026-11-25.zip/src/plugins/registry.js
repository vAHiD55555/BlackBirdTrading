'use strict';
/**
 * BlackBird — plugin registry.
 *
 * WHY THIS EXISTS
 * ---------------
 * The engine is already modular (sleeves, providers, brokers, agents), but every
 * new capability meant editing engine.js. That is fine for the core and wrong
 * for everything else: a strategy variant, an extra data source, a notifier or a
 * risk overlay should be addable without touching the boot path.
 *
 * WHAT A PLUGIN IS
 * ----------------
 * A plugin is a plain object with a `manifest` and a `register(ctx)` function.
 * It is loaded from a directory, never from a URL, and it is validated before
 * it is allowed to run. There is no `eval`, no dynamic `require` of a path that
 * came from the network, and no way for a plugin to reach the broker directly.
 *
 * THE SECURITY MODEL (this is the important part)
 * -----------------------------------------------
 * A plugin is UNTRUSTED CODE that runs in the same process. Node has no sandbox,
 * so "untrusted" cannot mean "cannot do damage" — it means the registry refuses
 * to hand it the tools to do damage:
 *
 *   1. CAPABILITIES, NOT THE ENGINE. `register(ctx)` receives a frozen context
 *      with a small, named set of hooks. It never receives `engine`, `broker`,
 *      `risk` or `portfolio`. A plugin that wants to influence risk must go
 *      through `ctx.riskOverlay`, which is capped and can only REDUCE risk.
 *
 *   2. NO ORDER PATH. There is no hook that submits, cancels or sizes an order.
 *      A plugin cannot trade. That is not a policy, it is an absent API.
 *
 *   3. DECLARED PERMISSIONS. A manifest must list what it needs
 *      (`permissions: ['data', 'notify', 'risk-overlay', 'strategy']`). The
 *      registry only wires the hooks whose permission was declared, so a plugin
 *      that forgot to declare `notify` gets no notifier — it fails loudly at
 *      register time instead of silently doing nothing.
 *
 *   4. FAILURE IS CONTAINED. Every hook call is wrapped: a plugin that throws,
 *      hangs or returns garbage is disabled for the rest of the run and the
 *      engine continues. A broken plugin must never stop trading.
 *
 *   5. DETERMINISTIC ORDER. Plugins run in manifest `priority` order, then by
 *      name, so two runs with the same set behave identically.
 *
 * WHAT A PLUGIN MAY NOT DO
 * ------------------------
 *   - raise a risk limit, open a position, or bypass the kill switch;
 *   - read a secret (the context has no env, no keys);
 *   - write outside its own data directory;
 *   - register a second plugin (no recursion, no supply chain).
 *
 * Those are enforced by what is absent from the context, plus the checks below.
 */

const fs = require('node:fs');
const path = require('node:path');

/** The only permissions that exist. Anything else is a manifest error. */
const PERMISSIONS = Object.freeze([
  'data',          // may contribute a read-only data source
  'notify',        // may receive report/alert text
  'risk-overlay',  // may return a multiplier in (0, 1] — reduce only
  'strategy',      // may contribute a signal, never an order
]);

/** Hooks a plugin may implement, and the permission each one requires. */
const HOOKS = Object.freeze({
  onBoot: null,               // no permission: setup only
  onTick: 'data',             // observe a ticker
  onBar: 'data',              // observe a closed bar
  onReport: 'notify',         // add a section to the report
  riskMultiplier: 'risk-overlay', // return a number in (0, 1]
  signal: 'strategy',         // return {symbol, side, confidence} or null
  onShutdown: null,           // no permission: cleanup only
});

const NAME_RE = /^[a-z0-9][a-z0-9._-]{1,63}$/;
const MAX_PLUGINS = 32;
const HOOK_TIMEOUT_MS = 2000;

/**
 * Static gate on the plugin SOURCE, before it is ever required.
 *
 * WHY THIS EXISTS
 * ---------------
 * Node has no sandbox. A plugin that reaches `require('fs')` or
 * `process.env` can read a key and send it anywhere — the capability model in
 * buildContext() cannot stop that, because it only decides what we HAND to the
 * plugin, not what the plugin can fetch for itself. So the loader reads the
 * source and refuses the patterns below.
 *
 * WHAT THIS IS AND IS NOT
 * -----------------------
 * This is a GATE, not a CAGE. A determined author can get around a regex
 * (`global.process`, `this.constructor.constructor('return process')()`). It
 * stops the ordinary case — a plugin that imports fs because it did not think
 * about it — and it makes the intent explicit at the point of loading.
 *
 * For real isolation the plugin must run in a separate process under a
 * separate user, with no environment and a read-only root. That is the
 * recommendation in PLUGINS-FA.md, and it is NOT what this build does.
 *
 * `manifest.allowUnsafe: true` opts out and is logged at warn level on every
 * boot, so nobody can leave it on by accident.
 */
const UNSAFE_PATTERNS = [
  { re: /\brequire\s*\(\s*['"`]/, why: 'dynamic require (use the provided ctx instead)' },
  { re: /\bchild_process\b/, why: 'child_process' },
  { re: /\bprocess\s*\.\s*(env|exit|binding|dlopen|kill)/, why: 'process.env / process.exit / binding' },
  { re: /\beval\s*\(/, why: 'eval()' },
  { re: /\bnew\s+Function\s*\(/, why: 'new Function()' },
  { re: /\bimport\s*\(/, why: 'dynamic import()' },
  { re: /\bglobalThis\s*\.\s*(process|require|module)/, why: 'globalThis escape' },
  { re: /\bconstructor\s*\.\s*constructor\b/, why: 'Function constructor escape' },
  { re: /\b__proto__\b/, why: '__proto__ (prototype pollution)' },
];

/** Return the first unsafe pattern found, or null. Comments are stripped first. */
function scanSource(src) {
  // Strip line and block comments so a URL or a note in a comment does not trip
  // the gate, and so a commented-out require does not silently disable it.
  const cleaned = String(src)
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/(^|[^:])\/\/[^\n]*/g, '$1 ');
  for (const p of UNSAFE_PATTERNS) {
    if (p.re.test(cleaned)) return p.why;
  }
  return null;
}

/** A manifest is valid or it is not; there is no "best effort". */
function validateManifest(m, source) {
  const problems = [];
  if (!m || typeof m !== 'object' || Array.isArray(m)) return { ok: false, problems: ['manifest must be an object'] };
  if (typeof m.name !== 'string' || !NAME_RE.test(m.name)) {
    problems.push(`manifest.name must match ${NAME_RE} (got ${JSON.stringify(m.name)})`);
  }
  if (typeof m.version !== 'string' || !/^\d+\.\d+\.\d+/.test(m.version)) {
    problems.push('manifest.version must be semver-like (e.g. "1.0.0")');
  }
  if (m.permissions !== undefined) {
    if (!Array.isArray(m.permissions)) problems.push('manifest.permissions must be an array');
    else {
      for (const p of m.permissions) {
        if (!PERMISSIONS.includes(p)) problems.push(`unknown permission "${p}" (allowed: ${PERMISSIONS.join(', ')})`);
      }
    }
  }
  if (m.priority !== undefined && !Number.isFinite(m.priority)) problems.push('manifest.priority must be a number');
  if (m.apiVersion !== undefined && m.apiVersion !== 1) {
    problems.push(`unsupported apiVersion ${m.apiVersion} (this build speaks 1)`);
  }
  return { ok: problems.length === 0, problems, source };
}

/**
 * The context handed to a plugin. Frozen, and deliberately small.
 *
 * `log` is a namespaced logger. `dataDir` is a directory the registry created
 * for this plugin alone. `riskOverlay` is a registration function, not a value:
 * the plugin proposes, the registry clamps.
 */
function buildContext({ name, dataDir, log, registry }) {
  const ctx = {
    name,
    apiVersion: 1,
    dataDir,
    log: {
      info: (msg, meta) => log.info(`[plugin:${name}] ${msg}`, meta),
      warn: (msg, meta) => log.warn(`[plugin:${name}] ${msg}`, meta),
      error: (msg, meta) => log.error(`[plugin:${name}] ${msg}`, meta),
    },
    /**
     * Propose a risk multiplier. The registry clamps it to (0, 1] and takes the
     * MINIMUM across all plugins, so no combination of plugins can ever raise
     * risk above what the core decided. Returns nothing: the plugin cannot read
     * back or influence the aggregate.
     */
    riskOverlay: (fn) => {
      if (typeof fn !== 'function') throw new Error('riskOverlay expects a function');
      registry._overlays.push({ name, fn });
    },
    /** Contribute a read-only data source. The registry calls it, never the plugin. */
    dataSource: (fn) => {
      if (typeof fn !== 'function') throw new Error('dataSource expects a function');
      registry._sources.push({ name, fn });
    },
  };
  return Object.freeze(ctx);
}

/** Run one hook with a timeout and full containment. */
async function callHook(entry, hook, args) {
  const fn = entry.impl[hook];
  if (typeof fn !== 'function') return { ok: true, value: undefined };
  let timer = null;
  try {
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`hook ${hook} exceeded ${HOOK_TIMEOUT_MS}ms`)), HOOK_TIMEOUT_MS);
    });
    const value = await Promise.race([Promise.resolve(fn.apply(entry.impl, args)), timeout]);
    return { ok: true, value };
  } catch (e) {
    entry.failures++;
    entry.lastError = e.message;
    // Three strikes: a plugin that keeps throwing is switched off, not retried
    // forever. The engine keeps running either way.
    if (entry.failures >= 3) entry.disabled = true;
    return { ok: false, error: e.message };
  } finally {
    if (timer) clearTimeout(timer);
  }
}

class PluginRegistry {
  constructor({ log, dataRoot, enabled = true } = {}) {
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.dataRoot = dataRoot || path.join(process.cwd(), 'data', 'plugins');
    this.enabled = enabled !== false;
    this.entries = [];
    this._overlays = [];
    this._sources = [];
    this.loaded = false;
  }

  /**
   * Load every plugin from a directory. A directory that does not exist is not
   * an error: the feature is optional and the default install has no plugins.
   *
   * Each plugin is a subdirectory containing `plugin.js` (or a single
   * `*.plugin.js` file). Anything else is ignored, so a README or a test file
   * sitting in the folder cannot be executed by accident.
   */
  loadFrom(dir) {
    if (!this.enabled) return { loaded: 0, skipped: 0, errors: [] };
    const root = dir || path.join(process.cwd(), 'plugins');
    const errors = [];
    let skipped = 0;
    if (!fs.existsSync(root)) {
      this.loaded = true;
      return { loaded: 0, skipped: 0, errors: [], note: `no plugin directory at ${root}` };
    }

    let names = [];
    try {
      names = fs.readdirSync(root, { withFileTypes: true });
    } catch (e) {
      return { loaded: 0, skipped: 0, errors: [`cannot read ${root}: ${e.code || e.message}`] };
    }

    const candidates = [];
    for (const d of names) {
      if (d.isDirectory()) {
        const f = path.join(root, d.name, 'plugin.js');
        if (fs.existsSync(f)) candidates.push(f);
        else skipped++;
      } else if (d.isFile() && d.name.endsWith('.plugin.js')) {
        candidates.push(path.join(root, d.name));
      } else {
        skipped++;
      }
    }

    if (candidates.length > MAX_PLUGINS) {
      errors.push(`too many plugins (${candidates.length} > ${MAX_PLUGINS}); none loaded`);
      this.loaded = true;
      return { loaded: 0, skipped, errors };
    }

    for (const file of candidates) {
      const res = this._loadOne(file);
      if (res.ok) this.entries.push(res.entry);
      else errors.push(`${path.basename(path.dirname(file))}: ${res.problems.join('; ')}`);
    }

    // Deterministic order: priority, then name. Two runs, same behaviour.
    this.entries.sort((a, b) => (a.manifest.priority - b.manifest.priority) || a.manifest.name.localeCompare(b.manifest.name));
    this.loaded = true;
    return { loaded: this.entries.length, skipped, errors };
  }

  _loadOne(file) {
    let src;
    try {
      src = fs.readFileSync(path.resolve(file), 'utf8');
    } catch (e) {
      return { ok: false, problems: [`cannot read plugin source: ${e.code || e.message}`] };
    }

    // The source gate runs BEFORE require(): a plugin that imports fs is never
    // executed at all, so it cannot do anything on the way in.
    const unsafe = scanSource(src);
    if (unsafe) {
      // The opt-out is read from the manifest only if it parses; a plugin that
      // cannot even declare a manifest gets no opt-out.
      let allowUnsafe = false;
      if (/allowUnsafe\s*:\s*true/.test(src)) allowUnsafe = true;
      if (!allowUnsafe) return { ok: false, problems: [`refused by the source gate: ${unsafe}`] };
      this.log.warn(`plugin ${path.basename(path.dirname(file))} set allowUnsafe:true — the source gate is OFF for it`);
    }

    let mod;
    try {
      // `require` resolves a relative specifier against THIS file, not against
      // the caller's cwd, so a plugin directory given as "./plugins" would fail
      // with "Cannot find module 'plugins/...'". Resolve to an absolute path
      // first; that is also what makes the error message name a real file.
      const abs = path.resolve(file);
      // eslint-disable-next-line global-require, import/no-dynamic-require
      mod = require(abs);
    } catch (e) {
      return { ok: false, problems: [`require failed: ${e.message}`] };
    }
    const impl = mod && mod.default ? mod.default : mod;
    if (!impl || typeof impl !== 'object') return { ok: false, problems: ['module must export an object'] };
    if (typeof impl.register !== 'function') return { ok: false, problems: ['module must export register(ctx)'] };

    const v = validateManifest(impl.manifest, file);
    if (!v.ok) return { ok: false, problems: v.problems };

    const manifest = impl.manifest;
    const perms = new Set(manifest.permissions || []);

    // A hook whose permission was not declared is a manifest bug, not a runtime
    // surprise: refuse the plugin so the operator sees it at boot.
    const missing = [];
    for (const [hook, perm] of Object.entries(HOOKS)) {
      if (perm && typeof impl[hook] === 'function' && !perms.has(perm)) {
        missing.push(`${hook} needs permission "${perm}"`);
      }
    }
    if (missing.length) return { ok: false, problems: missing };

    const entry = {
      manifest,
      impl,
      file,
      permissions: perms,
      failures: 0,
      lastError: null,
      disabled: false,
    };

    const dataDir = path.join(this.dataRoot, manifest.name);
    try {
      fs.mkdirSync(dataDir, { recursive: true });
    } catch (e) {
      return { ok: false, problems: [`cannot create data dir: ${e.code || e.message}`] };
    }

    const ctx = buildContext({ name: manifest.name, dataDir, log: this.log, registry: this });
    try {
      impl.register(ctx);
    } catch (e) {
      return { ok: false, problems: [`register() threw: ${e.message}`] };
    }
    return { ok: true, entry };
  }

  /** Active entries, in deterministic order. */
  active() {
    return this.entries.filter((e) => !e.disabled);
  }

  /**
   * The aggregate risk multiplier. Starts at 1 and can only go DOWN: the result
   * is the minimum of every proposal, clamped to (0, 1]. A plugin that returns
   * 5, NaN, a string or a negative number is ignored (and counted as a failure)
   * rather than trusted.
   *
   * TWO WAYS TO PROPOSE, ONE PLACE TO ENFORCE
   * -----------------------------------------
   * A plugin may either implement the `riskMultiplier` hook directly, or call
   * `ctx.riskOverlay(fn)` in register(). Both end up here, and both are clamped
   * identically. (An earlier version only read the hook, so a plugin that used
   * the documented `riskOverlay()` helper was silently ignored — the brake
   * loaded, reported itself armed, and never moved the multiplier.)
   */
  async riskMultiplier(context) {
    let m = 1;
    const consider = (name, v, entry) => {
      if (typeof v !== 'number' || !Number.isFinite(v)) {
        if (entry) {
          entry.failures++;
          entry.lastError = `riskMultiplier returned ${typeof v}`;
          if (entry.failures >= 3) entry.disabled = true;
        }
        return;
      }
      const clamped = Math.min(1, Math.max(0.0001, v));
      if (clamped < m) m = clamped;
    };

    for (const e of this.active()) {
      if (typeof e.impl.riskMultiplier !== 'function') continue;
      const r = await callHook(e, 'riskMultiplier', [context]);
      if (!r.ok) continue;
      consider(e.manifest.name, r.value, e);
    }

    // Overlays registered through ctx.riskOverlay(). An overlay whose plugin was
    // disabled is skipped, so a broken plugin cannot keep influencing risk.
    for (const o of this._overlays) {
      const owner = this.entries.find((e) => e.manifest.name === o.name);
      if (owner && owner.disabled) continue;
      let v;
      try {
        v = await Promise.race([
          Promise.resolve(o.fn(context)),
          new Promise((_, rej) => setTimeout(() => rej(new Error('overlay timeout')), HOOK_TIMEOUT_MS)),
        ]);
      } catch (e) {
        if (owner) {
          owner.failures++;
          owner.lastError = e.message;
          if (owner.failures >= 3) owner.disabled = true;
        }
        continue;
      }
      consider(o.name, v, owner);
    }
    return m;
  }

  /** Broadcast a hook to every active plugin. Never throws. */
  async broadcast(hook, args) {
    const out = [];
    for (const e of this.active()) {
      if (typeof e.impl[hook] !== 'function') continue;
      const r = await callHook(e, hook, args);
      if (r.ok && r.value !== undefined) out.push({ name: e.manifest.name, value: r.value });
    }
    return out;
  }

  /** Report sections contributed by plugins, in order. */
  async reportSections(context) {
    const out = [];
    for (const e of this.active()) {
      if (typeof e.impl.onReport !== 'function') continue;
      const r = await callHook(e, 'onReport', [context]);
      if (r.ok && typeof r.value === 'string' && r.value.trim()) out.push({ name: e.manifest.name, text: r.value });
    }
    return out;
  }

  /** Public, secret-free description for the dashboard and /status. */
  snapshot() {
    return {
      enabled: this.enabled,
      loaded: this.entries.length,
      active: this.active().length,
      plugins: this.entries.map((e) => ({
        name: e.manifest.name,
        version: e.manifest.version,
        description: e.manifest.description || '',
        permissions: [...e.permissions],
        priority: e.manifest.priority ?? 100,
        disabled: e.disabled,
        failures: e.failures,
        lastError: e.lastError,
      })),
    };
  }
}

module.exports = {
  PluginRegistry,
  PERMISSIONS,
  HOOKS,
  NAME_RE,
  MAX_PLUGINS,
  HOOK_TIMEOUT_MS,
  UNSAFE_PATTERNS,
  scanSource,
  validateManifest,
};
