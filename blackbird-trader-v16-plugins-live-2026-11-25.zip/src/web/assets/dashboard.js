/*
 * Public dashboard client. Read-only: it only ever GETs /api/public/*.
 * Every piece of server data is written with textContent only.
 * It starts fetching only after the entrance (gesture / button / keyboard).
 *
 * Visual rule: colour is never the only signal — each level also carries an
 * icon and a word, so the page still reads correctly in monochrome.
 */
(function () {
  'use strict';
  var STALE_AFTER_MS = 30000;
  var view = document.getElementById('view');
  var freshPill = document.getElementById('freshPill');
  var timer = null, lastOk = 0, skew = 0, latest = null;

  var WORD = { ok: 'سالم', watch: 'نیازمند توجه', alert: 'خطر', unknown: 'نامشخص' };
  var ICON = { ok: '✓', watch: '▲', alert: '✖', unknown: '?' };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = String(text);
    return e;
  }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
  function fmt(v, suffix) {
    if (v === null || v === undefined) return '—';
    if (typeof v === 'number') return v.toLocaleString('fa-IR', { maximumFractionDigits: 2 }) + (suffix || '');
    return String(v);
  }
  function pct(v) {
    var n = num(v);
    if (n === null) return '—';
    return (n > 0 ? '+' : '') + n.toLocaleString('fa-IR', { maximumFractionDigits: 2 }) + '٪';
  }
  function badge(level, text) {
    var b = el('span', 'badge l-' + level);
    b.appendChild(el('span', null, ICON[level] || '?'));
    b.appendChild(el('span', null, text || WORD[level] || level));
    return b;
  }

  /** One stat tile: label above, value below. No chart, no noise. */
  function stat(label, value, tone, unit) {
    var s = el('div', 'stat');
    s.appendChild(el('span', 'k', label));
    var v = el('span', 'v' + (tone ? ' ' + tone : ''), value);
    if (unit) v.appendChild(el('small', null, unit));
    s.appendChild(v);
    return s;
  }

  function freshness() {
    if (!latest) return;
    var ageMs = Date.now() - skew - latest.generatedAt;
    var state = latest.freshness && latest.freshness.state;
    var stale = ageMs > STALE_AFTER_MS || state === 'stale' || state === 'unknown';
    var secs = Math.max(0, Math.round(ageMs / 1000));
    freshPill.className = 'pill ' + (stale ? (state === 'unknown' ? 'unknown' : 'stale') : 'fresh');
    freshPill.textContent = '';
    freshPill.appendChild(el('span', 'dot'));
    freshPill.appendChild(el('span', null,
      stale
        ? (state === 'unknown' ? 'وضعیت نامشخص' : 'داده قدیمی') + ' · ' + secs.toLocaleString('fa-IR') + ' ثانیه'
        : 'به‌روز · ' + secs.toLocaleString('fa-IR') + ' ثانیه'
    ));
  }

  function renderHome(s) {
    view.textContent = '';
    var level = (s.overall && s.overall.level) || 'unknown';
    var headline = (s.overall && s.overall.headline) || 'وضعیت در دسترس نیست';

    var hero = el('section', 'hero');
    hero.appendChild(el('p', 'eyebrow', 'وضعیت کلی سیستم'));
    var big = el('div', 'big l-' + level);
    big.appendChild(el('span', 'status-icon', ICON[level] || '?'));
    big.appendChild(el('span', null, headline));
    big.appendChild(badge(level));
    hero.appendChild(big);

    var f = s.figures || {};
    var stats = el('div', 'stats');
    stats.appendChild(stat('ارزش پرتفوی', fmt(f.equity), null, 'دلار'));
    var daily = num(f.dailyPnlPct);
    stats.appendChild(stat('بازده امروز', pct(f.dailyPnlPct), daily === null ? '' : daily < 0 ? 'neg' : daily > 0 ? 'pos' : ''));
    stats.appendChild(stat('افت از اوج', fmt(f.drawdownPct, '٪')));
    stats.appendChild(stat('معاملات', fmt(f.trades)));
    stats.appendChild(stat('نرخ برد', f.winRatePct === null || f.winRatePct === undefined ? '—' : fmt(f.winRatePct, '٪')));
    hero.appendChild(stats);
    view.appendChild(hero);

    var cards = s.cards || [];
    if (cards.length) {
      var grid = el('div', 'grid');
      cards.forEach(function (c) {
        var card = el('article', 'card lv-' + c.level);
        card.appendChild(el('h2', null, c.title));
        card.appendChild(badge(c.level, c.word));
        card.appendChild(el('p', null, c.message));
        if (c.detail) {
          var a = el('a', 'more', 'جزئیات');
          a.href = '#/detail/' + encodeURIComponent(c.detail);
          card.appendChild(a);
        }
        grid.appendChild(card);
      });
      view.appendChild(grid);
    }
  }

  function renderDetail(d) {
    view.textContent = '';
    var back = el('a', 'btn back', 'بازگشت');
    back.href = '#/';
    view.appendChild(back);

    var card = el('section', 'card');
    var wrap = el('div', 'wrap'), table = el('table');
    if (d.columns) {
      var head = el('thead'), hr = el('tr');
      d.columns.forEach(function (c) { hr.appendChild(el('th', null, c)); });
      head.appendChild(hr); table.appendChild(head);
    }
    var body = el('tbody');
    (d.rows || []).forEach(function (r) {
      var tr = el('tr');
      r.forEach(function (v) { tr.appendChild(el('td', null, fmt(v))); });
      body.appendChild(tr);
    });
    if (!(d.rows || []).length) {
      var empty = el('tr'), td = el('td', null, d.state === 'unknown' ? 'داده‌ی معتبر در دسترس نیست.' : 'موردی برای نمایش نیست.');
      td.colSpan = (d.columns || []).length || 3;
      empty.appendChild(td); body.appendChild(empty);
    }
    table.appendChild(body);
    wrap.appendChild(table);
    card.appendChild(wrap);
    view.appendChild(card);

    view.appendChild(el('p', 'eyebrow table-note', 'فقط‌خواندنی · داده‌ی زنده'));
  }

  function get(path) {
    // same-origin، نه omit: پشت پراکسی‌های احراز‌هویت‌دار (پیش‌نمایش ابری، تونل
    // شخصی) کوکی نشست فقط با همین حالت فرستاده می‌شود؛ با omit پاسخ ۴۰۳ بود
    // و داشبورد تا ابد «در انتظار داده» می‌ماند.
    return fetch(path, { method: 'GET', cache: 'no-store', credentials: 'same-origin' }).then(function (r) {
      var d = r.headers.get('date');
      if (d) skew = Date.now() - new Date(d).getTime();
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  function route() {
    var m = /^#\/detail\/([a-z]+)$/.exec(location.hash || '');
    if (m) return get('/api/public/detail/' + m[1]).then(renderDetail);
    return Promise.resolve(latest && renderHome(latest));
  }

  function refresh() {
    return get('/api/public/summary').then(function (s) {
      latest = s; lastOk = Date.now();
      document.getElementById('brandName').textContent = (s.profile && s.profile.label) || 'BlackBird';
      document.getElementById('modePill').textContent = s.profile && s.profile.mode === 'live' ? 'LIVE' : 'PAPER';
      if (!/^#\/detail\//.test(location.hash)) renderHome(s);
    }).catch(function () {
      // A failed fetch must not leave the last "healthy" picture looking current.
      if (latest) { latest.freshness = { state: 'stale' }; }
      // و اگر هیچ داده‌ای نداریم، صفحه‌ی خالی و بی‌توضیح نماند.
      else {
        var host = document.getElementById('view');
        if (host && !host.childNodes.length) {
          var box = el('section', 'card lv-watch');
          box.appendChild(el('h2', null, 'ارتباط با سرور برقرار نشد'));
          box.appendChild(el('p', null, 'داده‌ای نرسید؛ هر پنج ثانیه خودکار دوباره تلاش می‌شود.'));
          host.appendChild(box);
        }
      }
    }).then(freshness);
  }

  function start() {
    if (timer) return;
    refresh();
    timer = setInterval(function () { if (!document.hidden) refresh(); freshness(); }, 5000);
    window.addEventListener('hashchange', route);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
  }
  if (document.body.classList.contains('entered')) start();
  document.addEventListener('bb:enter', start);
})();
