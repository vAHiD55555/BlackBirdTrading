'use strict';
/**
 * BlackBird — engine.
 * Wires the layers together and owns the clock.
 *
 *   feed ──bar──▶ scout ──proposal──▶ board ──decision──▶ trader ──fill──▶ portfolio
 *                    ▲                 │                                  │
 *                    │                 └── veto ──────────────────────────┘
 *                    └── learner ◀── trade closed ◀── witness.verifyTrade
 *   auditor ◀── clock ──▶ risk (kill switch)
 *   reporter ◀── every 6h ──▶ witness.scoreReport
 */
const { loadConfig, validateConfig, summarise } = require('./config');
const path = require('node:path');
const { Logger } = require('./core/logger');
const { Store } = require('./core/store');
const { Bus } = require('./core/bus');
const { now, iso } = require('./core/util');
const { createExchange } = require('./data/exchanges');
const { MarketHub } = require('./data/market');
const { WorkerBridge } = require('./worker/bridge');
const { classify, findHistoricalAnalog } = require('./data/regime');
const { RiskManager } = require('./risk/risk');
const { Portfolio } = require('./exec/portfolio');
const { PaperBroker } = require('./exec/paper');
const { Jev: JevExec } = require('./exec/jev');
const { Scout } = require('./agents/scout');
const { Board } = require('./agents/board');
const { Watch } = require('./agents/watch');
const { Trader } = require('./agents/trader');
const { Witness } = require('./agents/witness');
const { Auditor } = require('./agents/auditor');
const { Learner } = require('./agents/learner');
const { Apprentice } = require('./agents/apprentice');
const { Intel } = require('./intel/news');
const { Reporter } = require('./agents/reporter');
const { startServer } = require('./web/status');
const { Rotator } = require('./strategy/rotator');
const { riskXray } = require('./risk/xray');
const { AdaptiveSupervisor } = require('./supervisor/adaptive');
const { Healer } = require('./supervisor/heal');
const { AngryReporter } = require('./notify/angry-report');
const { Jev } = require('./jev/jev');
const { Lawyer } = require('./lawyer/lawyer');
const { EquityCurve } = require('./core/equity-curve');
const { TrialRegistry } = require('./jev/trials');
const { readLatest: readBacktestLatest } = require('./backtest/latest');
const { sendConfiguredTelegram } = require('./notify/telegram');
const { Strategist } = require('./strategist/strategist');
const crypto = require('node:crypto');
const nodePath = require('node:path');
const { claimDataDir } = require('./profiles');
const { EvidenceChain } = require('./audit/chain');
const { buildCourt, courtStagedExit } = require('./court/wire');
const { RoleBook } = require('./roles');
const { PluginRegistry } = require('./plugins/registry');
const { checkLiveGates, claimLiveDir } = require('./profiles-live');

function effectiveConfigView(cfg) {
  return {
    mode: cfg.mode,
    market: cfg.market,
    exchange: cfg.exchange,
    witnessExchange: cfg.witnessExchange,
    symbols: cfg.symbols,
    timeframe: cfg.data?.timeframe,
    data: cfg.data,
    strategy: cfg.strategy,
    risk: cfg.risk,
    fees: cfg.fees,
    futures: cfg.futures,
    jev: cfg.jev,
    board: cfg.board,
    serverPort: cfg.server?.port,
  };
}

function configFingerprint(cfg) {
  return crypto.createHash('sha256').update(JSON.stringify(effectiveConfigView(cfg))).digest('hex').slice(0, 16);
}

class Engine {
  constructor(overrides = {}) {
    this.cfg = loadConfig(overrides);
    const v = validateConfig(this.cfg);
    if (!v.ok) {
      const err = new Error(`configuration invalid:\n - ${v.problems.join('\n - ')}`);
      err.problems = v.problems;
      throw err;
    }
    this.warnings = v.warnings;
    this.configFingerprint = null;
    // Profiles never share a data directory: refuse to start on someone else's state.
    const dataDir = this.cfg.runtime.dataDir || nodePath.dirname(this.cfg.runtime.stateFile);
    const claim = claimDataDir(dataDir, this.cfg.profile.name);
    if (!claim.ok) throw new Error(`profile isolation: ${claim.reason}`);
    this.log = new Logger({ dir: this.cfg.runtime.logDir, level: this.cfg.runtime.logLevel, name: 'engine' });
    this.bus = new Bus(this.log);
    this.store = new Store(this.cfg, this.log);
    this.store.loadState();
    // Append-only, hash-linked evidence. Nothing that calls it can delete or edit a record.
    this.evidence = new EvidenceChain({ file: nodePath.join(dataDir, 'evidence.jsonl') });
    this.roles = new RoleBook({ profile: this.cfg.profile.name });
    this.court = null;
    this._courtExit = false;
    this._courtContinue = false;
    this.startedAt = now();
    this.timers = [];
    this.running = false;
    this.reportTimer = null;
    this.supervisor = null;
    this._telegramAlertAt = new Map();
  }

  async init() {
    const cfg = this.cfg;
    if (cfg.mode === 'live') {
      // v1.0 ships paper execution only. Refusing loudly beats pretending.
      throw new Error(
        'MODE=live is not implemented in this build: BlackBird v1.0 executes against a simulated book only. ' +
          'Run MODE=paper (the default) for the experimental phase.'
      );
    }
    // The live PROFILE is a different thing from MODE=live. The profile exists
    // so every gate, limit and credential slot is in place before the last mile
    // is switched on; it still refuses to trade, and it says exactly why.
    if (cfg.profile && cfg.profile.name === 'live') {
      const gates = checkLiveGates(process.env);
      const claim = claimLiveDir(cfg.runtime.dataDir);
      if (!claim.ok) throw new Error(`live profile refused: ${claim.reason}`);
      if (!gates.ready) {
        throw new Error(
          'live profile is configured but not armed. Blockers: ' + gates.blockers.join(' | ') +
            '. This build never places a real order; see src/profiles-live.js for the gate list.'
        );
      }
      // Even with every gate open, execution is still paper in this build. Say
      // so once, loudly, instead of letting the operator believe otherwise.
      this.log.warn(
        'live profile gates are OPEN, but this build still executes against the simulated book. ' +
          'No real order will be sent. See src/exec/live-broker.js.'
      );
      for (const w of gates.warnings) this.log.warn(`live: ${w}`);
    }
    // the rotator reads weekly momentum on hourly bars: force a compatible feed
    if (cfg.strategy.mode === 'rotator' || cfg.strategy.mode === 'hybrid') {
      // The rotator's lookbacks are expressed in HOURS, so the feed must be
      // hourly. Say what this does, and warn when it overrides.
      if (cfg.data.timeframe !== '1h') {
        this.log.warn(`strategy=${cfg.strategy.mode} needs hourly bars; overriding timeframe ${cfg.data.timeframe} -> 1h`);
      }
      cfg.data.timeframe = '1h';
      cfg.data.intervalMs = 3600000;
      cfg.data.bootstrapBars = Math.max(cfg.data.bootstrapBars, 400);
      cfg.data.staleQuoteMs = Math.max(cfg.data.staleQuoteMs, 20000);
    }
    this.configFingerprint = configFingerprint(cfg);
    this.log.info('BlackBird booting', { mode: cfg.mode, node: process.version, strategy: cfg.strategy.mode });
    this.log.info('\n' + summarise(cfg));
    for (const w of this.warnings) this.log.warn(`config: ${w}`);

    // The status server comes up BEFORE the market bootstrap. On a hosted plan
    // the platform probes /healthz within seconds of boot; if the port is not
    // listening yet it declares the deploy dead and restarts it. A slow or
    // blocked exchange must never cost us the health check.
    if (cfg.server.enabled) {
      this.server = startServer(this);
    }

    // Probe the optional model endpoint NOW, before the market bootstrap.
    // The bootstrap can take a minute on a blocked exchange, and the operator
    // needs to know within seconds whether the reviewer is on or off — not after
    // eight symbols have timed out. Never awaited: boot must not depend on a
    // third-party service being up.
    this.supervisor = new AdaptiveSupervisor({
      cfg, engine: this, log: this.log.child('supervisor'), store: this.store,
    });
    this.supervisor.probe().catch(() => { /* probe never rejects */ });

    // Plugins load AFTER the supervisor and BEFORE the market bootstrap: a
    // plugin that contributes a data source must be in place before the first
    // bar, and a plugin that fails to load must not delay the health check.
    // Loading is contained: a broken plugin is reported and skipped.
    this.plugins = new PluginRegistry({
      log: this.log.child('plugins'),
      dataRoot: nodePath.join(cfg.runtime.dataDir, 'plugins'),
      enabled: cfg.plugins ? cfg.plugins.enabled !== false : true,
    });
    const pluginDir = (cfg.plugins && cfg.plugins.dir) || nodePath.join(process.cwd(), 'plugins');
    const pluginLoad = this.plugins.loadFrom(pluginDir);
    if (pluginLoad.loaded) {
      this.log.info(`plugins: ${pluginLoad.loaded} loaded from ${pluginDir}`);
    }
    for (const err of pluginLoad.errors || []) this.log.warn(`plugin skipped: ${err}`);
    if (this.plugins.entries.length) {
      // onBoot is fire-and-forget: a slow plugin must not hold up the boot.
      this.plugins.broadcast('onBoot', [{ cfg: { mode: cfg.mode, profile: cfg.profile && cfg.profile.name } }])
        .catch(() => { /* broadcast never rejects */ });
    }

    this.primary = createExchange(cfg.exchange);
    this.witnessExchange = cfg.witnessExchange ? createExchange(cfg.witnessExchange) : null;

    // کارگر میانی اختیاری. اگر BB_WORKER_URL خالی باشد، این شیء خاموش است و
    // هیچ تماسی زده نمی‌شود؛ موتور دقیقاً مثل قبل کار می‌کند.
    this.worker = new WorkerBridge({ cfg, log: this.log.child('worker') });
    if (this.worker.enabled) {
      this.log.info(`edge worker on: data=${this.worker.dataEnabled} model=${this.worker.llmEnabled} token=${Boolean(this.worker.token)}`);
    }

    this.hub = new MarketHub({ exchanges: { primary: this.primary, witness: this.witnessExchange }, cfg, log: this.log.child('market'), worker: this.worker });
    await this.hub.start();

    // JEV prewarm with live prices
    this.jevExec = new JevExec(cfg, this.log.child('jev'));
    const prices = {};
    for (const f of this.hub.all()) prices[f.symbol] = f.ticker?.last || 1;
    this.jevExec.prewarm(cfg.symbols, prices);

    this.risk = new RiskManager({ cfg, store: this.store, log: this.log.child('risk') });
    // The AngryBird gate reads the tape through this one lazy hook. Computing it
    // only when the profile asks keeps BlackBird's hot path untouched.
    this.risk.marketContext = () => this._angryContext();
    this.court = buildCourt(this);
    if (this.court) {
      this.risk.courtState = () => ({ yellowCards: this.court.yellowCards, redCard: this.court.redCardActive });
    }
    this.portfolio = new Portfolio(this.log.child('portfolio'));
    this.broker = new PaperBroker({
      cfg,
      log: this.log.child('broker'),
      getBook: (s) => this.hub.get(s)?.book(),
      getFeed: (s) => this.hub.get(s),
    });

    this.rotator = (cfg.strategy.mode === 'rotator' || cfg.strategy.mode === 'hybrid')
      ? new Rotator({
          cfg, log: this.log.child('rotator'), store: this.store, risk: this.risk,
          portfolio: this.portfolio, broker: this.broker, hub: this.hub, bus: this.bus,
        })
      : null;
    try { this.rotator?.restore(); } catch (e) { this.log.warn('rotator restore failed: ' + e.message); }
    // The strategist's crisis overlay feeds the rotator's size scale. It is a
    // function, not a value, so an expiring overlay takes effect immediately
    // without touching the rotator's own state.
    if (this.rotator) {
      this.rotator.externalScale = () =>
        (this.strategist ? this.strategist.riskMultiplier() : 1) * (this.healer ? this.healer.scale : 1);
    }

    this.witness = new Witness({ cfg, log: this.log.child('witness'), store: this.store, exchange: this.witnessExchange });
    await this.witness.start();

    this.learner = new Learner({ cfg, log: this.log.child('learner'), store: this.store });

    // The apprentice (کارآموز): a permanent learner that asks every actor why.
    // Constructed before the agents so it can subscribe to the bus first and
    // never miss an event. It never blocks a trade and never throws.
    this.apprentice = new Apprentice({
      cfg: cfg.apprentice,
      log: this.log.child('apprentice'),
      store: this.store,
      dir: cfg.runtime.dataDir || nodePath.dirname(cfg.runtime.stateFile),
      bus: this.bus,
    });

    // Market intel (اخبار و هوش بازار). Off unless at least one feed URL is
    // configured; it can only reduce risk, never raise it.
    this.intel = new Intel({ cfg: cfg.intel, log: this.log.child('intel') });

    this.scout = new Scout({ cfg, log: this.log.child('scout'), store: this.store, hub: this.hub, risk: this.risk, learner: this.learner });
    this.board = new Board({ cfg, log: this.log.child('board'), store: this.store, risk: this.risk, witness: this.witness, hub: this.hub, jev: this.jevExec });
    // The watch (دیده‌بان): looks OUTSIDE the current book for better
    // opportunities and proposes replacing a stagnant holding. It is wired to
    // the same board, so a swap needs the same approval as any other trade.
    // The executor is the ONLY bridge from the watch to the book. It is a lazy
    // object because the trader is constructed a few lines below; every method
    // resolves `this.trader` at call time.
    //
    // close() reports ok only when the position is actually gone. A close that
    // is still pending at the venue returns ok:false, so the watch never opens
    // the candidate on top of a position that has not left yet.
    const watchExecutor = {
      close: (symbol, reason) => {
        const pos = this.portfolio.get(symbol);
        if (!pos) return { ok: false, reason: 'not_open' };
        try {
          this.trader._exit(pos, reason, 'market');
        } catch (e) {
          return { ok: false, reason: e.message };
        }
        return this.portfolio.get(symbol) ? { ok: false, reason: 'close_pending' } : { ok: true };
      },
      open: (swap, decision) => {
        const feed = this.hub.get(swap.in.symbol);
        const book = feed?.book();
        if (!book || feed.isStale) return { ok: false, reason: 'stale_book' };
        const price = book.ask;
        const notional = Number(swap.notional) || 0;
        const qty = price > 0 ? notional / price : 0;
        if (!(qty > 0)) return { ok: false, reason: 'zero_qty' };
        const proposal = {
          id: swap.id,
          ts: now(),
          symbol: swap.in.symbol,
          side: 'buy',
          strategy: 'WATCH_SWAP',
          entryType: 'taker',
          price,
          tpBps: Math.max(Number(this.cfg.strategy?.minTpBps) || 30, Number(swap.edgeBps) || 0),
          slBps: Number(this.cfg.strategy?.maxSlBps) || 250,
          confidence: Math.max(0, Math.min(1, Number(swap.in.score) || 0)),
          expectedEdgeBps: Number(swap.edgeBps) || 0,
          features: { watch: true, from: swap.out.symbol },
          rationale: [`watch swap from ${swap.out.symbol}`],
        };
        const res = this.trader.enter(proposal, { ...decision, qty, notional });
        return res && res.ok ? { ok: true } : { ok: false, reason: res?.reason || 'entry_refused' };
      },
    };

    this.watch = new Watch({
      cfg, log: this.log.child('watch'), store: this.store, hub: this.hub,
      exchange: this.primary, portfolio: this.portfolio, board: this.board, risk: this.risk,
      executor: watchExecutor,
    });
    this.trader = new Trader({ cfg, log: this.log.child('trader'), store: this.store, broker: this.broker, portfolio: this.portfolio, risk: this.risk, jev: this.jevExec, hub: this.hub, bus: this.bus });
    this.auditor = new Auditor({
      cfg, log: this.log.child('auditor'), store: this.store, risk: this.risk,
      portfolio: this.portfolio, trader: this.trader, jev: this.jevExec, hub: this.hub,
      witness: this.witness, broker: this.broker, bus: this.bus,
    });
    this.reporter = new Reporter({
      cfg, log: this.log.child('reporter'), store: this.store, trader: this.trader,
      portfolio: this.portfolio, risk: this.risk, scout: this.scout, board: this.board,
      auditor: this.auditor, witness: this.witness, learner: this.learner, jev: this.jevExec, hub: this.hub,
      rotator: this.rotator,
      // Market intel is handed to the reporter so the hourly report (and the
      // Telegram copy of it) carries a news summary. Without this the module
      // ran, gated entries, and never appeared in a single report.
      intel: this.intel,
    });
    // (the supervisor was constructed and probed earlier, before the bootstrap)

    // jev — the central layer: brain, mediator, manager. Constructed even when
    // disabled so /status can report why it is off; it never throws and never
    // blocks boot.
    this.jev = new Jev({ cfg: cfg.jev, log: this.log.child('jev'), worker: this.worker });
    this._registerModules();
    if (this.jev.enabled) {
      this.log.info(`jev enabled: provider=${cfg.jev.provider} model=${cfg.jev.model} ready=${this.jev.ready}`);
      if (!this.jev.ready) {
        // Say which variable is missing. "missing credentials" alone sent the
        // operator hunting through the panel with no name to look for.
        const names = [cfg.jev.apiKeyEnv || 'JEV_API_KEY', 'GROQ_API_KEY', 'GEMINI_API_KEY'].join(' or ');
        this.log.warn(`jev is enabled but not ready: ${this.jev.lastError || `missing credentials — set ${names} as a Secret`}`);
      }
    }

    // The lawyer — independent of jev by design. It audits whether the system is
    // at maximum productivity and files findings on behalf of the capital owner.
    // Constructed even when disabled so /status can say why it is off.
    this.lawyer = new Lawyer({
      cfg: {
        ...cfg.lawyer,
        // The strategist's own cadence and limits, so the lawyer judges its
        // report against the numbers the strategist actually runs with.
        strategistIntervalMs: cfg.strategist?.intervalMs,
        strategistMaxActionsPerHour: cfg.strategist?.authority?.maxActionsPerHour,
        strategistOverlayTtlMs: cfg.strategist?.authority?.overlayTtlMs,
        killSwitchDrawdownPct: cfg.risk.killSwitchDrawdownPct,
      },
      log: this.log.child('lawyer'),
      ledger: this.jev.ledger,
      jev: this.jev,
    });
    if (this.lawyer.enabled) {
      this.log.info(`lawyer enabled: audit every ${Math.round((cfg.lawyer.auditIntervalMs || 900000) / 1000)}s`);
    }

    // Trial registry (K) and the equity curve that feeds the Deflated Sharpe.
    // Both are constructed unconditionally: K must be readable even when the
    // lawyer is off, and the curve must accumulate from the first cycle or the
    // DSR will never have enough observations.
    this.trials = new TrialRegistry({
      file: cfg.trials?.file,
      log: this.log.child('trials'),
    });
    this.equityCurve = new EquityCurve({
      file: path.join(cfg.runtime.dataDir || path.join(__dirname, '..', 'data'), 'equity.jsonl'),
      log: this.log.child('equity'),
    });
    this._initTrials();

    // The live strategist. Constructed unconditionally so /status can say why it
    // is off; it does nothing until cfg.strategist.enabled is true.
    this.strategist = this._buildStrategist();

    // Self-healing supervisor. Constructed after the hub and the risk manager so
    // it can read both; it acts only through the bounded hooks below.
    this.healer = new Healer({ cfg, log: this.log.child('heal'), engine: this, store: this.store });
    // AngryBird's separate Telegram report. Silent unless the profile is
    // angrybird and a chat id is configured.
    this.angryReport = new AngryReporter({ cfg, log: this.log.child('angry'), store: this.store });

    this._wire();
    return this;
  }

  /**
   * Build the strategist and give it the two things it needs to be useful:
   * a read of the world, and hands that can only reduce risk.
   */
  _buildStrategist() {
    const cfg = this.cfg.strategist || {};
    const s = new Strategist({
      cfg,
      engineCfg: this.cfg,
      log: this.log.child('strategist'),
      store: this.store,
      getStatus: () => this.status(),
      // The committee: jev in its mediator role, plus the lawyer's veto.
      requestAction: (request) => this._strategistRequest(request),
      applyAction: (action, params) => this._strategistApply(action, params),
    });
    return s;
  }

  /**
   * Hand a strategist request to the committee and wait for a verdict.
   *
   * A committee that is off, broken or slow has NOT answered — the caller's
   * response window is what turns that into self-execution. Answering "yes"
   * for a committee that never ran would silently disarm the whole mechanism.
   */
  async _strategistRequest(request) {
    if (request.action === 'notify') return { approved: false, reason: 'notification only' };

    // The lawyer's veto is an answer, and it is always "no" to anything that
    // would undo its objection.
    if (this.lawyer && this.lawyer.vetoActive && request.kind === 'opportunity') {
      return { approved: false, reason: `lawyer veto active: ${this.lawyer.vetoReason}` };
    }

    if (!this.jev || !this.jev.enabled || !this.jev.ready) {
      throw new Error('committee unavailable: jev is off or not ready');
    }

    const opinions = [{ module: 'strategist', stance: request.action === 'review_method' ? 'reduce' : 'block', reason: request.reason }];
    const verdict = await this.jev.mediate({ topic: `strategist:${request.action}`, opinions, context: { request } });
    const resolution = String(verdict?.resolution || 'allow');
    const approved = request.action === 'review_method' ? resolution !== 'block' : resolution === 'block' || resolution === 'reduce';
    return {
      approved,
      reason: `committee ${resolution} ×${verdict?.riskMultiplier ?? 1}${verdict?.winner ? ` (${verdict.winner})` : ''}`,
      verdict,
    };
  }

  /**
   * The strategist's hands. Every branch here can only reduce risk — there is
   * deliberately no code path that opens a position, raises a limit, or lifts
   * a halt. A crisis is not an opportunity.
   */
  _strategistApply(action, params = {}) {
    const applied = [];
    try {
      switch (action) {
        case 'block_entries':
          this._strategistBlock = true;
          applied.push('entries blocked');
          break;

        case 'pause_strategy':
          this._strategistBlock = true;
          if (this.rotator && typeof this.rotator.pause === 'function') {
            this.rotator.pause('strategist crisis');
            applied.push('rotator paused');
          }
          applied.push('entries blocked');
          break;

        case 'reduce_risk': {
          const m = Number(params.multiplier);
          if (!Number.isFinite(m) || m < 0 || m > 1) return { applied: false, reason: `invalid multiplier ${params.multiplier}` };
          this._strategistRiskMultiplier = m;
          applied.push(`risk multiplier → ${m}`);
          break;
        }

        case 'flatten': {
          if (!this.rotator) return { applied: false, reason: 'no rotator book to flatten' };
          const open = this.portfolio.openPositions();
          let closed = 0;
          for (const p of open) {
            try { if (this.rotator._close(p.symbol, 'strategist_crisis')) closed++; } catch { /* keep going */ }
          }
          applied.push(`flattened ${closed}/${open.length}`);
          break;
        }

        case 'clear_overlay':
          this._strategistBlock = false;
          this._strategistRiskMultiplier = 1;
          applied.push('overlay cleared');
          break;

        case 'notify':
          applied.push('notified');
          break;

        default:
          // Not reachable through the authority (it whitelists), but a guard
          // here means a future refactor cannot smuggle in a new power.
          return { applied: false, reason: `action "${action}" has no engine handler` };
      }
    } catch (e) {
      return { applied: false, reason: `apply threw: ${e.message}`, applied_parts: applied };
    }

    this.log.error(`strategist applied ${action}: ${applied.join(', ')} — ${params.reason || 'no reason'}`);
    try {
      this.store.append('strategist_overlay', { action, params: { reason: params.reason, multiplier: params.multiplier }, applied });
    } catch { /* the journal is a bonus */ }
    return { applied: true, reason: applied.join(', '), parts: applied };
  }

  /**
   * Boot the trial registry.
   *
   * Two jobs, both about honesty:
   *   1. If the config changed since the last recorded fingerprint, that change
   *      was a trial nobody logged. Record it as `unregistered` so K stops
   *      under-counting — a hand-edited config is still a test.
   *   2. Otherwise, record a baseline so the NEXT change has something to
   *      compare against.
   *
   * Never throws: a broken registry must not stop the engine.
   */
  _initTrials() {
    try {
      if (!this.cfg.trials?.enabled) return;
      const drift = this.cfg.trials.detectDrift ? this.trials.detectDrift(this.cfg) : null;
      if (drift && drift.unregistered) {
        this.trials.recordDrift(drift);
        this.log.warn(
          `trial registry: config changed outside the registry (${drift.changed.map((c) => c.field).join(', ')}); ` +
          `recorded as an unregistered trial. K is now ${this.trials.K}.`
        );
      } else if (this.cfg.trials.recordBaselineOnBoot) {
        this.trials.recordBaseline(this.cfg);
      }
      this.log.info(`trial registry: K=${this.trials.K} (${this.trials.file})`);
    } catch (e) {
      this.log.warn(`trial registry init failed: ${e.message}`);
    }
  }

  /**
   * Record a parameter change as a trial.
   * Called by the panel/CLI when a setting is changed through the app, so the
   * change is counted rather than silently inflating the next Sharpe.
   */
  recordTrial({ kind = 'param_change', field, from, to, note, source = 'engine', metrics } = {}) {
    try {
      return this.trials.record({ kind, field, from, to, note, source, metrics });
    } catch (e) {
      this.log.warn(`trial record failed: ${e.message}`);
      return null;
    }
  }

  /**
   * Variance of Sharpe ratios across recorded trials.
   *
   * Returns null unless at least two trials carry a `metrics.sharpe`. That is
   * the honest answer: with one trial there is no spread, and with none there
   * is nothing to spread. The lawyer then reports DSR as "not computable"
   * instead of substituting a made-up variance.
   */
  _varSharpeAcrossTrials() {
    try {
      if (!this.trials) return null;
      const sharpes = this.trials.trials
        .filter((t) => t && t.metrics && Number.isFinite(Number(t.metrics.sharpe)))
        .map((t) => Number(t.metrics.sharpe));
      if (sharpes.length < 2) return null;
      const mean = sharpes.reduce((a, b) => a + b, 0) / sharpes.length;
      return sharpes.reduce((a, b) => a + (b - mean) ** 2, 0) / (sharpes.length - 1);
    } catch {
      return null;
    }
  }

  /** Attach the market listeners. Re-run after a venue switch (new hub object). */
  _wireHub() {
    this.hub.on('tick', (t) => {
      // A tick is liveness too: with an hourly timeframe the next closed candle
      // is up to an hour away, and the healer's clock is shorter than that. It
      // used to watch bars only, so a quiet hour read as a dead engine and every
      // entry was paused after 20 minutes — the bot could never open anything.
      this.healer?.noteProgress();
      const feed = this.hub.get(t.symbol);
      if (!feed) return;
      if (this.rotator) {
        this.rotator.onTick(t);
        if (this.cfg.strategy.mode === 'hybrid') this.trader.onTick(t, feed);
        this._markPosition(t);
        return;
      }
      this.trader.onTick(t, feed);
      this._markPosition(t);
    });

    this.hub.on('bar', (evt) => {
      this.healer?.noteProgress();
      if (this.rotator) {
        // record the observation too, so the 6h report can describe the market
        const s = evt.symbol || evt.bar?.symbol;
        const f = evt.feed || this.hub.get(s);
        const sn = f?.snapshot();
        if (sn) {
          try { this.trader.observe(s, sn, classify(sn, f.book(), this.cfg.strategy)); } catch { /* ignore */ }
        }
        // onBar is async (the carry sleeve fetches funding): a try/catch cannot
        // see a rejected promise, so the rejection is handled explicitly.
        Promise.resolve(this.rotator.onBar(evt)).catch((e) => this.log.error(`rotator bar error: ${e.message}`));
        if (this.cfg.strategy.mode === 'hybrid') {
          const symbol = evt.symbol || evt.bar?.symbol;
          const feed = evt.feed || this.hub.get(symbol);
          if (feed) {
            const snap = feed.snapshot();
            if (snap) {
              try { this.trader.onBar(symbol, snap); } catch (e) { this.log.error(`tactical bar error: ${e.message}`); }
              try { this._tryEnter(symbol, snap, feed.book(), classify(snap, feed.book(), this.cfg.strategy)); } catch (e) { this.log.error(`tactical entry error: ${e.message}`); }
            }
          }
        }
        return;
      }
      const symbol = evt.symbol || evt.bar?.symbol;
      const feed = evt.feed || this.hub.get(symbol);
      if (!feed) return;
      const snap = feed.snapshot();
      if (!snap) return;
      const book = feed.book();
      const reg = classify(snap, book, this.cfg.strategy);
      this.trader.observe(symbol, snap, reg);
      this.trader.onBar(symbol, snap);
      this._tryEnter(symbol, snap, book, reg);
    });

  }

  _wire() {
    this._wireHub();

    // --- trade lifecycle ------------------------------------------------
    this.bus.on('trade:closed', (trade) => {
      try {
        this.witness.verifyTrade(trade);
      } catch (e) {
        this.log.warn(`witness verify failed: ${e.message}`);
      }
      this.learner.observe(trade);
      // Feed the analog reference set: the shape this trade was entered on, and
      // what it actually returned. Without this the analog gate has no memory.
      try { this._recordAnalog(trade); } catch (e) { this.log.debug(`analog record failed: ${e.message}`); }
      this.angryReport?.onTradeClosed(trade);
      this.store.saveState();
    });
    this.bus.on('audit:alert', (finding) => {
      if (!this.cfg.notifications?.telegram?.enabled || !['warn', 'critical'].includes(finding.level)) return;
      const key = `${finding.level}:${finding.code}:${finding.message}`;
      const cooldown = finding.level === 'critical' ? 10 * 60 * 1000 : 60 * 60 * 1000;
      const last = this._telegramAlertAt.get(key) || 0;
      if (now() - last < cooldown) return;
      this._telegramAlertAt.set(key, now());
      const icon = finding.level === 'critical' ? '🚨' : '⚠️';
      sendConfiguredTelegram(this.cfg, 'alert', `${icon} BlackBird ${finding.level.toUpperCase()}\nکد: ${finding.code}\n${finding.message}\n${JSON.stringify(finding.metrics || {})}`)
        .catch((e) => this.log.warn(`telegram alert failed: ${e.message}`));
    });
  }

  /**
   * Mark an open position at the price it could actually be closed at.
   * A long exits into the bid, a short exits into the ask.
   */
  _markPosition(t) {
    const pos = this.portfolio.get(t.symbol);
    if (!pos) return;
    const px = pos.dir > 0 ? t.bid : t.ask;
    if (px > 0) this.portfolio.mark(t.symbol, px);
  }

  /**
   * Historical analog for the current market shape.
   *
   * The reference set is built from closed trades: each one stored the snapshot
   * it was entered on, plus its realised outcome. That is the only honest
   * source — a shape is only "known" once we have seen what followed it.
   *
   * Returns null when there is not enough history, which the caller treats as
   * "no opinion" rather than "safe".
   */
  _analogFor(snap) {
    if (!snap) return null;
    const hist = this.store.state.analogHistory;
    if (!Array.isArray(hist) || hist.length < (this.cfg.analog?.minSamples || 20)) return null;
    try {
      return findHistoricalAnalog(snap, hist, {
        k: this.cfg.analog.k,
        minSamples: this.cfg.analog.minSamples,
        maxDistance: this.cfg.analog.maxDistance,
      });
    } catch (e) {
      this.log.debug(`analog failed: ${e.message}`);
      return null;
    }
  }

  /** Record a closed trade's entry shape + outcome for future analog matching. */
  _recordAnalog(trade) {
    if (!this.cfg.analog?.enabled) return;
    // The trader stores `proposal.features` as the trade context, and those
    // features already carry the five analog fields. Accept either shape so a
    // future change to the context does not silently empty the reference set.
    const snap = trade?.context?.snapshot || trade?.context;
    if (!snap || !Number.isFinite(trade?.pnlBps)) return;
    if (!Number.isFinite(snap.atrPercentile) && !Number.isFinite(snap.rsi)) return;
    const hist = Array.isArray(this.store.state.analogHistory) ? this.store.state.analogHistory : [];
    hist.push({
      ts: trade.exit?.ts || now(),
      symbol: trade.symbol,
      snap: {
        atrPercentile: snap.atrPercentile,
        trendStrength: snap.trendStrength,
        rsi: snap.rsi,
        vwapDevAtr: snap.vwapDevAtr,
        atrPct: snap.atrPct,
      },
      outcomePct: trade.pnlBps / 100,
    });
    const cap = this.cfg.analog.maxHistory || 500;
    this.store.state.analogHistory = hist.slice(-cap);
  }

  /** scout -> board -> trader, for one symbol. Synchronous by design. */
  _tryEnter(symbol, snap, book, reg) {
    if (this.risk.halted) return;
    // A self-heal pause stops NEW entries only; it never touches what is open.
    if (this.healer && this.healer.entriesPaused) return;
    if (this.portfolio.hasPosition(symbol)) return;
    if (this.trader.pendingEntries.size >= this.cfg.risk.maxOpenPositions) return;
    // jev may veto NEW entries. It never closes what is already open.
    if (this.jev && this.jev.blocksEntries()) {
      this.log.debug(`entry ${symbol} blocked by jev veto`);
      return;
    }
    // The strategist's crisis overlay may block new entries. Like jev, it can
    // only stop an entry; it never opens one and never closes a position here.
    if (this.strategist && this.strategist.blocksEntries()) {
      this.log.debug(`entry ${symbol} blocked by strategist crisis overlay`);
      return;
    }
    // Market intel: a scheduled high-impact event inside the blackout window
    // blocks NEW entries. It never predicts direction and never opens a trade.
    if (this.intel && this.intel.enabled) {
      const b = this.intel.bias();
      if (b.blackout) {
        this.log.debug(`entry ${symbol} blocked by intel blackout: ${b.reason}`);
        this.apprentice?.observe('intel', `blackout ${symbol}`, `high-impact event window: ${b.reason}`, { symbol });
        return;
      }
    }
    // Historical analog: if this exact market shape has repeatedly failed, do
    // not take it again. A weak match is not a veto — only a matched analog
    // with a poor win rate is.
    if (this.cfg.analog?.enabled) {
      const analog = this._analogFor(snap);
      if (analog && analog.matched && analog.winRate !== null && analog.winRate < this.cfg.analog.minWinRate) {
        this.log.debug(`entry ${symbol} blocked by analog: winRate ${analog.winRate} over ${analog.samples} analogs`);
        this.apprentice?.observe(
          'analog',
          `block ${symbol}`,
          `historical analog win rate ${analog.winRate} < ${this.cfg.analog.minWinRate} over ${analog.samples} similar setups`,
          { symbol, analog }
        );
        return;
      }
    }

    const t0 = now();
    const proposal = this.scout.evaluate(symbol);
    if (!proposal) return;

    const bias = this.learner.bias(symbol, proposal.strategy, proposal.regime);
    const decision = this.board.review(proposal, this.portfolio, bias);
    this.scout.markDecision(proposal.id, decision.approved ? 'approved' : 'rejected');

    if (!decision.approved) return;

    const res = this.trader.enter(proposal, decision);
    this.bus.emit('entry:submitted', { proposal, decision, res });
    this.log.debug(`pipeline ${symbol} took ${now() - t0}ms`, { ok: res.ok, status: res.status });
  }

  start() {
    if (this.running) return this;
    this.running = true;

    this.auditor.start();

    // The strategist runs on its own 3m30s clock. Off unless enabled; when on
    // it takes its first look immediately rather than waiting a full interval.
    //
    // Started BEFORE the lawyer on purpose: the lawyer audits once at boot, and
    // if it runs first it inspects a strategist that has not had the chance to
    // report yet — a false "never ran" warning on every single restart.
    if (this.strategist) {
      try { this.strategist.start(); } catch (e) { this.log.warn(`strategist start failed: ${e.message}`); }
    }

    // The lawyer audits on its own clock, independent of jev. It reads the
    // engine status directly, so it works even when jev is off or broken.
    if (this.lawyer && this.lawyer.enabled) {
      this.lawyer.start(() => this.status());
    }

    // housekeeping clock (1s)
    const clock = setInterval(() => {
      try {
        this.trader.onClock();
        this.rotator?.tick();
        this.risk.maybeAutoResume();
        this.risk.rollDay();
        this._rotatorGuard();
        if (this.court && this.court.redCardActive) courtStagedExit(this);
        this._maybeReport();
        this.supervisor?.run();
        this.healer?.tick();
        this.angryReport?.tick({
          context: this._angryContext(),
          positions: this.portfolio.openPositions(),
          equity: this.risk.state.equity,
        });
        this._maybeAnalyse();
        this._maybeIntel();
        this._maybeSupervise();
        this._heartbeat();
      } catch (e) {
        this.log.error(`clock error: ${e.message}`);
      }
    }, 1000);
    this.timers.push(clock);

    // The watch (دیده‌بان) runs on its own slow clock: discovery is a
    // background research job, not part of the 1s trading loop. It is
    // deliberately NOT awaited and its failures are swallowed inside run(),
    // so a slow or unreachable exchange can never stall trading.
    if (this.watch && this.watch.enabled) {
      const every = Math.max(60000, Number(this.cfg.watch?.intervalMs) || 6 * 3600000);
      const watchTimer = setInterval(() => {
        this.watch.runCycle().catch((e) => this.log.warn(`watch: ${e.message}`));
      }, every);
      if (typeof watchTimer.unref === 'function') watchTimer.unref();
      this.timers.push(watchTimer);
      // one early pass, after the book has had time to open its first positions
      const first = setTimeout(() => {
        this.watch.runCycle().catch((e) => this.log.warn(`watch: ${e.message}`));
      }, 60000);
      if (typeof first.unref === 'function') first.unref();
      this.timers.push(first);
    }

    // (the status server was started in init(), before the market bootstrap)

    // give the rotator a moment to build its first book, otherwise the boot
    // report would describe an empty portfolio
    if (this.cfg.runtime.reportOnBoot) setTimeout(() => { try { this._report(); } catch { /* logged inside */ } }, 20000);
    if (this.court) {
      const r = this.court.startSeason({ id: `season-${new Date().toISOString().slice(0, 10)}` });
      if (!r.ok) this.log.warn(`court season not started: ${r.reason} ${(r.violations || []).join('; ')}`);
    }
    this.log.info('engine running', { symbols: this.cfg.symbols.length, mode: this.cfg.mode });
    return this;
  }

  /** If risk ever halts the book, a momentum portfolio must be flattened. */
  _rotatorGuard() {
    if (!this.rotator) return;
    // a daily pause keeps the book; only a hard halt is flattened
    if (this.risk.halted && this.risk.haltKind !== 'daily' && !(this.court && this.court.redCardActive) && this.portfolio.openPositions().length) {
      // Log once per halt episode, not once per second.
      //
      // This guard runs on the 1s housekeeping clock. When the book cannot be
      // closed — a stale feed, a dead venue — the positions stay open, the
      // condition stays true, and the old code wrote an ERROR line every
      // second. Fifteen identical errors a second is not a louder alarm, it is
      // a log nobody can read, and it buries the one line that matters.
      if (!this._haltFlattenLogged) {
        this._haltFlattenLogged = true;
        this.log.error('risk halted -> flattening the rotator book');
      }
      let closed = 0;
      for (const p of [...this.portfolio.openPositions()]) {
        if (p.strategy === 'ORBITAL') {
          try { if (this.rotator._close(p.symbol, 'halt')) closed++; } catch { /* keep going */ }
        }
      }
      // If nothing could be closed, say so once — the book is stuck, and that
      // is a different fact from "the book was flattened".
      if (closed === 0 && !this._haltFlattenStuckLogged) {
        this._haltFlattenStuckLogged = true;
        this.log.warn('risk halted but no position could be closed (stale book or dead venue) — will keep trying');
      }
    } else {
      // The halt cleared: re-arm both one-shot logs for the next episode.
      this._haltFlattenLogged = false;
      this._haltFlattenStuckLogged = false;
    }
  }

  /**
   * Swap the primary data venue without restarting the process.
   *
   * Triggered by the self-healing supervisor when the primary exchange has
   * been unreachable long enough that a fallback is better than waiting. The
   * witness stays on its own venue on purpose: a failover must never collapse
   * the two independent price sources into one (§16).
   *
   * Never throws. Every failure is returned, logged and journaled so a bad
   * fallback cannot take the process down.
   */
  async switchVenue(id, reason = 'self-heal') {
    const venue = String(id || '').toLowerCase();
    const prev = String(this.cfg.exchange || '').toLowerCase();
    if (!venue) return { ok: false, reason: 'no venue given' };
    if (venue === prev) return { ok: false, reason: 'already on this venue' };
    if (this.witnessExchange && venue === String(this.witnessExchange.id || '').toLowerCase()) {
      return { ok: false, reason: 'venue is the witness; the two sources must stay independent' };
    }

    let adapter;
    try {
      adapter = createExchange(venue);
    } catch (e) {
      return { ok: false, reason: `unknown venue: ${e.message}` };
    }

    const previousHub = this.hub;
    const hub = new MarketHub({
      exchanges: { primary: adapter, witness: this.witnessExchange },
      cfg: this.cfg,
      log: this.log.child('market'),
      worker: this.worker,
    });

    try {
      await hub.start();
    } catch (e) {
      try { hub.stop(); } catch { /* ignore */ }
      return { ok: false, reason: `new venue failed to start: ${e.message}` };
    }

    this.hub = hub;
    this.primary = adapter;
    this.cfg.exchange = venue;
    // Modules hold the hub by reference; a stale reference would read a dead feed.
    for (const m of [this.scout, this.board, this.trader, this.auditor, this.rotator, this.reporter]) {
      if (m) m.hub = hub;
    }
    this._wireHub();
    try { previousHub.stop(); } catch { /* ignore */ }

    this.log.warn(`venue switched ${prev} -> ${venue}`, { reason });
    try {
      this.store.append('venue_switch', { from: prev, to: venue, reason, ts: now() });
    } catch { /* journal is best-effort here */ }
    return { ok: true, from: prev, to: venue };
  }

  _heartbeat() {
    const every = this.cfg.runtime.heartbeatMs;
    if (!every || now() - (this._lastBeat || 0) < every) return;
    this._lastBeat = now();
    const pos = this.portfolio.openPositions();
    this.log.info('heartbeat', {
      equity: Math.round(this.risk.state.equity * 100) / 100,
      positions: pos.length,
      tradesToday: this.risk.state.counters.tradesToday,
      unrealised: Math.round(this.portfolio.unrealisedTotal() * 100) / 100,
      halted: this.risk.halted,
    });
    this.store.saveState({ lastHeartbeat: now() });
    this.store.append('heartbeat', {
      equity: this.risk.state.equity,
      positions: pos.length,
      trades: this.risk.state.counters.trades,
      halted: this.risk.halted,
    });
  }

  /**
   * Register every module jev is expected to watch. Explicit registration is
   * what makes "missing" distinguishable from "healthy".
   */
  _registerModules() {
    const r = this.jev.registry;
    const add = (name, ref, version) => {
      try { r.register(name, { ref, version: version || '4.0.0' }); } catch (e) { this.log.warn(`registry: ${name} failed: ${e.message}`); }
    };
    add('strategy.rotator', this.rotator);
    add('risk', this.risk);
    add('portfolio', this.portfolio);
    add('broker', this.broker);
    add('witness', this.witness);
    add('auditor', this.auditor);
    add('reporter', this.reporter);
    add('scout', this.scout);
    add('board', this.board);
    add('watch', this.watch);
    add('trader', this.trader);
    add('learner', this.learner);
    add('strategist', this.strategist);
    add('panel', this.server || null);
  }

  /**
   * Ask jev for a fresh market read, at most once per decideIntervalMs.
   * Fire-and-forget: decide() never rejects, and a slow model must never
   * stall the 1s clock.
   */
  _maybeAnalyse() {
    const j = this.jev;
    if (!j || !j.enabled || !j.ready) return;
    const every = Number(this.cfg.jev?.decideIntervalMs) || 300000;
    if (now() - (j.lastDecideAt || 0) < every) return;
    if (j.inFlight.decide) return;
    j.decide(this.status()).catch(() => { /* decide never rejects; belt and braces */ });
  }

  /**
   * Refresh the news feeds on their own slow clock.
   *
   * Deliberately outside the 1s loop: a feed is a network call, and a slow feed
   * must never delay a trade. Failures are swallowed inside refresh(), so an
   * unreachable news source leaves the last known view in place.
   */
  _maybeIntel() {
    if (!this.intel || !this.intel.enabled) return;
    const every = Math.max(60000, Number(this.cfg.intel?.refreshMs) || 900000);
    if (now() - (this.intel.lastRunAt || 0) < every) return;
    this.intel.refresh().catch((e) => this.log.debug(`intel refresh failed: ${e.message}`));
  }

  /** Ask jev to audit the modules, at most once per superviseIntervalMs. */
  _maybeSupervise() {
    const j = this.jev;
    if (!j) return;
    const every = Number(this.cfg.jev?.superviseIntervalMs) || 600000;
    if (now() - (j.lastSuperviseAt || 0) < every) return;
    if (j.inFlight.supervise) return;
    // Heartbeat every registered module first, so "stale" means something.
    for (const name of j.registry.names()) j.registry.beat(name);
    j.supervise().catch(() => { /* supervise never rejects */ });
  }

  _maybeReport() {
    const due = this.reporter.lastReportAt + this.cfg.reporter.intervalMs;
    if (now() >= due) this._report();
  }

  _report() {
    try {
      const { report, markdownPath } = this.reporter.run();
      this.store.saveState();
      this.bus.emit('report:ready', { report, markdownPath });
      return report;
    } catch (e) {
      this.log.error(`report generation failed: ${e.message}`, { stack: e.stack });
      return null;
    }
  }

  forceReport() {
    return this._report();
  }

  /**
   * "Muddy water" measurements for the AngryBird activation gate: how volatile
   * the tape is, how much of the universe is being sold, and how much of it is
   * already turning back up. Every value is optional; the gate fails closed
   * when one is missing, so a dead feed can never open it.
   */
  _angryContext() {
    const feeds = this.hub && typeof this.hub.all === 'function' ? this.hub.all() : [];
    const snapshots = [];
    const moves = [];
    const turns = [];
    let books = 0;
    let spreadOk = true;
    let depthOk = true;
    let btcTurn = null;
    const gateSymbol = (this.cfg.strategy.rotator && this.cfg.strategy.rotator.gateSymbol) || 'BTCUSDT';
    const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;

    for (const f of feeds) {
      const bars = f.bars && typeof f.bars.toArray === 'function' ? f.bars.toArray() : [];
      const snap = typeof f.snapshot === 'function' ? f.snapshot() : null;
      const book = typeof f.book === 'function' ? f.book() : null;
      if (snap && Number.isFinite(snap.atrPercentile)) snapshots.push(snap.atrPercentile);
      if (book) {
        books++;
        if (!(book.spreadBps <= this.cfg.strategy.maxSpreadBps)) spreadOk = false;
        if (!(book.depthUsd >= this.cfg.strategy.minDepthUsd)) depthOk = false;
      }
      if (bars.length >= 25) {
        const last = bars[bars.length - 1].c;
        const past = bars[bars.length - 25].c; // ~24 hourly bars
        if (past > 0) moves.push((last - past) / past);
        const shortNow = avg(bars.slice(-9).map((b) => b.c));
        const shortBefore = avg(bars.slice(-10, -1).map((b) => b.c));
        turns.push(last > shortNow && shortNow >= shortBefore ? 1 : 0);
        if (f.symbol === gateSymbol) btcTurn = last > bars[bars.length - 7].c; // ~6h direction
      }
    }

    const median = (arr) => {
      if (!arr.length) return null;
      const s = [...arr].sort((a, b) => a - b);
      const m = Math.floor(s.length / 2);
      return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
    };

    const atrPercentile = median(snapshots);
    const exodusBreadth = moves.length ? moves.filter((r) => r <= -0.01).length / moves.length : null;
    let recoveryScore = turns.length ? turns.reduce((a, b) => a + b, 0) / turns.length : null;
    // A rebound in alts that the market itself has not confirmed is not evidence.
    if (recoveryScore !== null && btcTurn === false) recoveryScore = Math.max(0, recoveryScore - 0.34);

    return {
      atrPercentile,
      exodusBreadth,
      recoveryScore,
      spreadOk: books > 0 ? spreadOk : false,
      depthOk: books > 0 ? depthOk : false,
      btcTurn,
      symbolsMeasured: feeds.length,
    };
  }

  /** Cheap, side-effect-free health view. Used by /readyz and the panel. */
  health() {
    const booting = !this.risk || !this.portfolio || !this.hub;
    return {
      booting,
      feedsTotal: this.cfg.symbols.length,
      feedsDegraded: this.hub ? this.hub.degraded.size : 0,
      degradedSymbols: this.hub ? [...this.hub.degraded] : [],
      dataOk: this.hub ? this.hub.healthy : false,
      exchange: this.cfg.exchange,
      worker: this.worker ? this.worker.status() : null,
      uptimeSec: Math.round((now() - this.startedAt) / 1000),
    };
  }

  status() {
    // The status server is up before init() finishes, so /status can be hit
    // while the engine is still booting. Answer with a booting payload instead
    // of a 500: a platform health check that sees an exception may kill us.
    if (!this.risk || !this.portfolio) {
      return {
        ok: true,
        booting: true,
        mode: this.cfg.mode,
        startedAt: this.startedAt,
        uptimeSec: Math.round((now() - this.startedAt) / 1000),
        time: iso(),
        symbols: this.cfg.symbols,
        health: {
          booting: true,
          feedsTotal: this.cfg.symbols.length,
          feedsDegraded: 0,
          degradedSymbols: [],
          dataOk: false,
          exchange: this.cfg.exchange,
          uptimeSec: Math.round((now() - this.startedAt) / 1000),
        },
        message: 'engine is still booting',
      };
    }
    const risk = this.risk.snapshot();
    const unrealised = Math.round(this.portfolio.unrealisedTotal() * 100) / 100;
    risk.unrealised = unrealised;
    risk.equityMtm = Math.round((risk.equity + unrealised) * 100) / 100;

    // The kill switch must see the marked equity, not only the realised one.
    // Without this a book 16% underwater on open positions reads as 0% and the
    // switch never fires until the loss is already past the limit.
    try {
      if (typeof this.risk.markToMarket === 'function') this.risk.markToMarket(risk.equityMtm);
      // Charter §8: a halt lifts only after health and the resume conditions are
      // re-evaluated — never because time passed. Without this call a drawdown
      // halt was permanent, and a 12-month replay showed the bot idle for five
      // months after one bad stretch.
      if (typeof this.risk.evaluateResume === 'function') {
        this.risk.evaluateResume({
          equityMtm: risk.equityMtm,
          openPositions: this.portfolio.openPositions().length,
          dataOk: this.dataHealthy !== false,
        });
      }
    } catch (e) {
      this.log.warn(`mark-to-market risk check failed: ${e.message}`);
    }

    // Sample the equity curve on the status path: /status is polled by the panel
    // and by the lawyer's own clock, so this is the natural heartbeat. The curve
    // enforces its own cadence, so a fast poller does not create fake periods.
    let performance = null;
    if (this.equityCurve) {
      try {
        this.equityCurve.sample(risk.equityMtm);
        const p = this.equityCurve.performance();
        // K comes from the registry, not from the curve: they answer different
        // questions (how many tests vs how many observations).
        performance = {
          returns: p.returns,
          T: p.T,
          K: this.trials ? this.trials.K : null,
          // Variance of Sharpe across trials. We do not have per-trial Sharpes
          // stored, so this is null and DSR reports "not computable" rather
          // than inventing a variance. See LAWYER.md.
          varSharpe: this._varSharpeAcrossTrials(),
          enough: p.enough,
        };
      } catch (e) {
        this.log.warn(`equity curve sample failed: ${e.message}`);
      }
    }
    return {
      ok: true,
      mode: this.cfg.mode,
      exchange: this.cfg.exchange,
      witnessExchange: this.cfg.witnessExchange,
      startedAt: this.startedAt,
      uptimeSec: Math.round((now() - this.startedAt) / 1000),
      time: iso(),
      symbols: this.cfg.symbols,
      risk,
      performance,
      // Plugins are reported as a count and a list of names, never as code.
      // A plugin that failed to load is visible here, not silently absent.
      plugins: this.plugins ? this.plugins.snapshot() : { enabled: false, loaded: 0, active: 0, plugins: [] },
      // Real health, not a decoration. The panel used to print "SYSTEM HEALTHY"
      // unconditionally, which is a lie the moment an exchange feed is blocked
      // (HTTP 451) and the engine is running on zero candles. These fields let
      // the UI say what is actually true.
      health: {
        booting: false,
        feedsTotal: this.cfg.symbols.length,
        feedsDegraded: this.hub ? this.hub.degraded.size : 0,
        degradedSymbols: this.hub ? [...this.hub.degraded] : [],
        dataOk: this.hub ? this.hub.healthy : false,
        exchange: this.cfg.exchange,
        uptimeSec: Math.round((now() - this.startedAt) / 1000),
      },
      riskXray: riskXray(this.portfolio, risk.equity),
      // The charter's limits, so the lawyer can measure compliance against the
      // same numbers the risk engine enforces.
      limits: {
        maxPositionPct: this.cfg.risk.maxPositionPct,
        maxOpenPositions: this.cfg.risk.maxOpenPositions,
        maxSymbolExposurePct: this.cfg.risk.maxSymbolExposurePct,
        maxNetExposurePct: this.cfg.risk.maxNetExposurePct,
        killSwitchDrawdownPct: this.cfg.risk.killSwitchDrawdownPct,
        maxDailyLossPct: this.cfg.risk.maxDailyLossPct,
      },
      deployment: {
        node: process.version,
        strategy: this.cfg.strategy.mode,
        timeframe: this.cfg.data.timeframe,
        symbols: this.cfg.symbols,
        configFingerprint: this.configFingerprint,
      },
      trader: this.trader.snapshot(),
      market: this.hub.all().map((f) => {
        const snap = f.snapshot();
        const book = f.book();
        const reg = snap ? classify(snap, book, this.cfg.strategy) : null;
        return {
          symbol: f.symbol,
          price: snap?.price ?? null,
          regime: reg?.regime ?? 'n/a',
          regimeScore: reg?.score ?? null,
          atrPct: snap ? Math.round(snap.atrPct * 100) / 100 : null,
          volPercentile: snap ? Math.round(snap.atrPercentile * 1000) / 1000 : null,
          rsi: snap ? Math.round(snap.rsi * 10) / 10 : null,
          spreadBps: book ? Math.round(book.spreadBps * 10) / 10 : null,
          depthUsd: book ? Math.round(book.depthUsd) : null,
          quoteAgeMs: book ? Math.round(book.quoteAgeMs) : null,
          source: f.quoteSource,
        };
      }),
      strategy: this.cfg.strategy.mode,
      rotator: this.rotator ? this.rotator.snapshot() : null,
      supervisor: this.supervisor ? this.supervisor.snapshot() : null,
      heal: this.healer ? this.healer.snapshot() : null,
      angryReport: this.angryReport ? this.angryReport.snapshot() : null,
      jev: this.jev ? this.jev.snapshot() : null,
      lawyer: this.lawyer ? this.lawyer.snapshot() : null,
      strategist: this.strategist ? this.strategist.snapshot() : null,
      trials: this.trials ? this.trials.snapshot() : null,
      equityCurve: this.equityCurve ? this.equityCurve.snapshot() : null,
      // The last offline backtest, read from disk. Null when none has run —
      // the panel shows "none yet" rather than inventing a number.
      backtest: readBacktestLatest(this.cfg.runtime?.dataDir),
      scout: this.scout.snapshot(),
      board: this.board.snapshot(5),
      watch: this.watch ? this.watch.snapshot() : null,
      intel: this.intel ? this.intel.snapshot() : null,
      apprentice: this.apprentice ? this.apprentice.snapshot() : null,
      jevExec: this.jevExec.stats(),
      auditors: this.auditor.summary(),
      witness: this.witness.snapshot(),
      learner: this.learner.snapshot(),
      lastReport: this.reporter.lastReport
        ? { round: this.reporter.lastReport.round, summary: this.reporter.lastReport.summary, witness: this.reporter.lastReport.witness?.score ?? null }
        : null,
    };
  }

  async stop(reason = 'shutdown') {
    if (!this.running) return;
    this.running = false;
    this.log.info(`shutting down (${reason})`);
    for (const t of this.timers) clearInterval(t);
    this.timers = [];
    this.auditor.stop();
    this.witness.stop();
    try { this.lawyer?.stop(); } catch { /* ignore */ }
    try { this.strategist?.stop(); } catch { /* ignore */ }
    try { this.rotator?.stop(); } catch { /* ignore */ }
    this.hub.stop();
    try { this.server?.close(); } catch { /* ignore */ }
    this.store.saveState({ stoppedAt: now(), stopReason: reason });
    this.store.append('shutdown', { reason, equity: this.risk.state.equity });
    this.log.close();
  }
}

module.exports = { Engine };
