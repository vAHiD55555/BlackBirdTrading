'use strict';
/**
 * BlackBird — the LIVE trading profile.
 *
 * WHY A PROFILE AND NOT A REWRITE
 * -------------------------------
 * The user's requirement was explicit: prepare the system for real money now, so
 * that going live later does not mean deleting and re-uploading the app. So this
 * file adds a THIRD profile next to `blackbird` and `angrybird`, and it changes
 * nothing about how the existing two behave.
 *
 * WHAT "READY" MEANS HERE — AND WHAT IT DOES NOT
 * ----------------------------------------------
 * This build does NOT place a real order. It cannot: `LiveBroker` in
 * src/exec/live-broker.js refuses, and the engine refuses `MODE=live`. What this
 * profile does is make every gate, every limit and every credential slot exist
 * and be testable NOW, so that switching on the last mile is a config change
 * rather than a code change.
 *
 * The gates, in the order they are checked:
 *
 *   1. PROFILE      BB_PROFILE=live must be chosen explicitly. It is never the
 *                   default, and a typo falls back to refusing, not to trading.
 *   2. INTENT       BB_I_UNDERSTAND_REAL_MONEY=YES — a literal string, not a
 *                   boolean, so it cannot be set by accident with "1" or "true".
 *   3. VENUE        an allow-listed venue with a TRADE-only key. A key with
 *                   withdraw permission is refused, not warned about.
 *   4. CAPITAL      a hard notional ceiling that the risk module cannot raise.
 *   5. CANARY       the first N days run at a fraction of the ceiling, and the
 *                   fraction only grows on measured agreement with the paper book.
 *   6. KILL SWITCH  the same drawdown switch as paper, plus a live-only daily
 *                   loss stop that halts the process rather than the strategy.
 *
 * Every one of those is a value in this file, so it can be reviewed, diffed and
 * tested without reading the engine.
 *
 * WHAT IS DELIBERATELY NOT HERE
 * -----------------------------
 * No wallet keys, no seed phrases, no exchange secrets. Those live in the
 * environment only (rule six of AGENTS.md). This file names the variables; it
 * never holds a value.
 */

const fs = require('node:fs');
const path = require('node:path');

/**
 * Venues this profile is allowed to talk to. Each entry says how the key is
 * scoped and whether the venue supports the two things a live book needs:
 * a reduce-only order and a server-side stop.
 *
 * `keyScope` is what the adapter will VERIFY, not what it hopes for. A key that
 * can withdraw is refused at boot with a readable message.
 */
const VENUES = Object.freeze({
  hyperliquid: Object.freeze({
    label: 'Hyperliquid',
    keyEnv: 'HL_API_WALLET_KEY',
    accountEnv: 'HL_ACCOUNT_ADDRESS',
    keyScope: 'trade-only',        // API wallet: signs orders, cannot withdraw
    supportsReduceOnly: true,
    supportsServerStop: false,     // stops are client-side; the engine must stay up
    minNotionalUsd: 10,
    makerBps: 1.5,
    takerBps: 4.5,
    notes: 'API wallet is the only accepted key. The master key is never read.',
  }),
  binance: Object.freeze({
    label: 'Binance Futures',
    keyEnv: 'BINANCE_API_KEY',
    accountEnv: 'BINANCE_API_SECRET',
    keyScope: 'trade-only',
    supportsReduceOnly: true,
    supportsServerStop: true,
    minNotionalUsd: 5,
    makerBps: 2,
    takerBps: 5,
    notes: 'Disable withdrawals on the API key. IP allow-list is required.',
  }),
  bybit: Object.freeze({
    label: 'Bybit',
    keyEnv: 'BYBIT_API_KEY',
    accountEnv: 'BYBIT_API_SECRET',
    keyScope: 'trade-only',
    supportsReduceOnly: true,
    supportsServerStop: true,
    minNotionalUsd: 5,
    makerBps: 2,
    takerBps: 5.5,
    notes: 'Use a sub-account with a fixed balance, not the main account.',
  }),
});

/**
 * The live overlay. Numbers are deliberately conservative: this is the profile
 * that can lose real money, so every default is the cautious end of the range.
 */
const LIVE_OVERLAY = Object.freeze({
  risk: {
    // A live book starts small on purpose. The canary stage below scales it.
    startEquity: 200,
    maxPositionPct: 0.10,          // 10% of equity per position, not 20%
    maxOpenPositions: 3,
    maxSymbolExposurePct: 0.10,
    maxNetExposurePct: 0.30,       // never more than 30% of the book at risk
    maxDailyLossPct: 0.02,         // 2% a day, then stop for the day
    maxDailyTrades: 10,
    maxConsecutiveLosses: 2,
    cooldownAfterLossMs: 30 * 60 * 1000,
    killSwitchDrawdownPct: 0.08,   // 8% from peak: halt, do not "wait it out"
    minNotionalUsd: 10,
    useRiskSizing: true,
    riskPerTradePct: 0.0025,       // 0.25% of equity risked per trade
  },
  strategy: {
    // Live uses the same strategy as paper. Changing the strategy AND the venue
    // at the same time makes a bad result unattributable.
    mode: 'hybrid',
    timeStopMs: 3 * 60 * 60 * 1000,
    entryType: 'maker',            // maker first: taker fees eat a small book
    makerTimeoutMs: 5 * 60 * 1000,
  },
  live: {
    // ---- gate 2: intent -----------------------------------------------------
    // A literal string. "true", "1", "yes" and "on" are all refused, because a
    // boolean-looking value is exactly what gets set by accident.
    intentEnv: 'BB_I_UNDERSTAND_REAL_MONEY',
    intentValue: 'YES',

    // ---- gate 3: venue ------------------------------------------------------
    venue: 'hyperliquid',
    requireTradeOnlyKey: true,
    refuseWithdrawScope: true,

    // ---- gate 4: capital ----------------------------------------------------
    // The hard ceiling. The risk module may size BELOW this; nothing may size
    // above it, and this number is not reachable from the panel.
    maxNotionalUsd: 50,
    maxTotalExposureUsd: 150,

    // ---- gate 5: canary -----------------------------------------------------
    // Stage 1 runs at 25% of the ceiling for 7 days. Promotion needs the live
    // book to agree with the paper book within a tolerance, measured, not felt.
    canary: {
      enabled: true,
      stage1Days: 7,
      stage1Scale: 0.25,
      stage2Scale: 0.5,
      stage3Scale: 1.0,
      // Promotion is refused when the live book diverges from paper by more
      // than this on realised PnL over the stage.
      maxDivergencePct: 15,
      minTradesPerStage: 20,
    },

    // ---- gate 6: stops ------------------------------------------------------
    // A live-only hard stop: if the process cannot reach the venue for this
    // long while positions are open, it flattens rather than hoping.
    flattenIfBlindMs: 5 * 60 * 1000,
    // Daily loss that halts the PROCESS, not just the strategy. A strategy halt
    // can be overridden by a restart; a process halt cannot.
    dailyLossHaltPct: 0.03,

    // ---- reconciliation -----------------------------------------------------
    // After a restart the local book is a guess. It is reconciled against the
    // venue before the first order, and a mismatch blocks trading.
    reconcileOnBoot: true,
    blockOnMismatch: true,
  },
  reporter: {
    // Live reports go out more often: a real position needs a real heartbeat.
    intervalMs: 15 * 60 * 1000,
  },
});

/** The profile's own data directory, so a live book can never mix with paper. */
function livePaths(base) {
  const dir = path.join(base, 'profiles', 'live');
  return {
    dataDir: dir,
    stateFile: path.join(dir, 'state.json'),
    journalFile: path.join(dir, 'journal.jsonl'),
    logDir: path.join(dir, 'logs'),
    reportDir: path.join(dir, 'reports'),
    trialsFile: path.join(dir, 'trials.jsonl'),
  };
}

/**
 * Check every gate and return a readable verdict. Pure: it reads the env it is
 * given and nothing else, so it is testable without a venue.
 *
 * @returns {{ready: boolean, blockers: string[], warnings: string[], venue: object|null}}
 */
function checkLiveGates(env = process.env, overlay = LIVE_OVERLAY) {
  const blockers = [];
  const warnings = [];
  const L = overlay.live;

  // gate 2 — intent
  const intent = String(env[L.intentEnv] || '').trim();
  if (intent !== L.intentValue) {
    blockers.push(
      `${L.intentEnv} must be exactly "${L.intentValue}" (got ${intent ? `"${intent}"` : 'nothing'}). ` +
        'A boolean-looking value is refused on purpose.'
    );
  }

  // gate 3 — venue
  const venueName = String(env.BB_LIVE_VENUE || L.venue).trim().toLowerCase();
  const venue = VENUES[venueName] || null;
  if (!venue) {
    blockers.push(`unknown live venue "${venueName}" (allowed: ${Object.keys(VENUES).join(', ')})`);
  } else {
    const key = String(env[venue.keyEnv] || '').trim();
    const account = String(env[venue.accountEnv] || '').trim();
    if (!key) blockers.push(`${venue.keyEnv} is not set`);
    if (!account) blockers.push(`${venue.accountEnv} is not set`);
    // A key that looks like a master/withdraw key is refused, not warned about.
    if (L.refuseWithdrawScope && /withdraw/i.test(String(env.BB_LIVE_KEY_SCOPE || ''))) {
      blockers.push('the configured key has withdraw scope; a trade-only key is required');
    }
  }

  // gate 4 — capital
  const ceiling = Number(env.BB_LIVE_MAX_NOTIONAL_USD || L.maxNotionalUsd);
  if (!Number.isFinite(ceiling) || ceiling <= 0) blockers.push('BB_LIVE_MAX_NOTIONAL_USD must be a positive number');
  else if (ceiling > L.maxNotionalUsd) {
    // Raising the ceiling above the reviewed default is allowed only by editing
    // this file, never by an environment variable.
    blockers.push(
      `BB_LIVE_MAX_NOTIONAL_USD=${ceiling} exceeds the reviewed ceiling ${L.maxNotionalUsd}; ` +
        'raise it in src/profiles-live.js, not in the panel'
    );
  }

  // gate 5 — canary
  if (L.canary.enabled) {
    const stage = Number(env.BB_LIVE_CANARY_STAGE || 1);
    if (![1, 2, 3].includes(stage)) blockers.push('BB_LIVE_CANARY_STAGE must be 1, 2 or 3');
    else if (stage > 1) {
      warnings.push(`canary stage ${stage} skips the measured promotion; stage 1 is the reviewed start`);
    }
  }

  // gate 6 — stops
  if (!Number.isFinite(Number(env.BB_LIVE_FLATTEN_IF_BLIND_MS || L.flattenIfBlindMs))) {
    blockers.push('BB_LIVE_FLATTEN_IF_BLIND_MS must be a number');
  }

  return { ready: blockers.length === 0, blockers, warnings, venue };
}

/**
 * The canary scale for the current stage. This is the number the risk module
 * multiplies its ceiling by, so stage 1 can never reach the full ceiling even if
 * every other gate is open.
 */
function canaryScale(env = process.env, overlay = LIVE_OVERLAY) {
  const c = overlay.live.canary;
  if (!c.enabled) return 1;
  const stage = Number(env.BB_LIVE_CANARY_STAGE || 1);
  if (stage === 1) return c.stage1Scale;
  if (stage === 2) return c.stage2Scale;
  return c.stage3Scale;
}

/**
 * Apply the live overlay to a config object. Mirrors applyProfile() in
 * profiles.js: explicit operator values win, the overlay only fills defaults.
 */
function applyLiveProfile(cfg, { env = process.env, root } = {}) {
  const base = env.DATA_DIR || path.join(root || process.cwd(), 'data');
  const p = livePaths(base);
  cfg.profile = {
    name: 'live',
    label: 'BlackBird Live',
    version: `${require('../package.json').version}+live`,
    isolatedDir: true,
  };
  // Deep copy so the frozen overlay is never mutated by the engine.
  const overlay = JSON.parse(JSON.stringify(LIVE_OVERLAY));
  for (const [k, v] of Object.entries(overlay)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      cfg[k] = { ...(cfg[k] || {}), ...v };
    } else cfg[k] = v;
  }
  cfg.runtime = cfg.runtime || {};
  cfg.runtime.dataDir = p.dataDir;
  cfg.runtime.stateFile = p.stateFile;
  cfg.runtime.journalFile = p.journalFile;
  cfg.runtime.logDir = p.logDir;
  cfg.reporter = { ...(cfg.reporter || {}), dir: p.reportDir };
  cfg.trials = { ...(cfg.trials || {}), file: p.trialsFile };
  // The canary scale is carried on the config so the risk module can read it
  // without knowing about environments.
  cfg.live = { ...(cfg.live || {}), canaryScale: canaryScale(env) };
  return cfg;
}

/**
 * Refuse to boot a live profile on a directory that belongs to another profile.
 * Same contract as claimDataDir() in profiles.js, kept separate so the live
 * marker can never be confused with the paper one.
 */
function claimLiveDir(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const marker = path.join(dir, 'PROFILE');
    if (fs.existsSync(marker)) {
      const owner = fs.readFileSync(marker, 'utf8').trim();
      if (owner !== 'live') return { ok: false, reason: `data directory belongs to "${owner}", refusing to start "live" on it` };
      return { ok: true, reason: 'owned' };
    }
    // A live book must never adopt an unmarked directory: that directory may
    // hold a paper book, and mixing them would report paper PnL as real.
    if (fs.existsSync(path.join(dir, 'state.json'))) {
      return { ok: false, reason: 'data directory holds unmarked state; a live book refuses to adopt it' };
    }
    fs.writeFileSync(marker, 'live\n');
    return { ok: true, reason: 'claimed' };
  } catch (e) {
    return { ok: false, reason: `cannot verify data directory: ${e.code || e.message}` };
  }
}

module.exports = {
  VENUES,
  LIVE_OVERLAY,
  livePaths,
  checkLiveGates,
  canaryScale,
  applyLiveProfile,
  claimLiveDir,
};
