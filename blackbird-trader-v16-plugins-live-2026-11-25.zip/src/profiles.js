'use strict';
/**
 * Profiles — BlackBird (conventional) and AngryBird are two separate products.
 *
 * A profile is a thin, explicit overlay on the config plus a state namespace.
 * The two must never share state, journal, logs, reports or positions, so:
 *   - each profile gets its own data directory (AngryBird: <base>/profiles/angrybird);
 *   - a PROFILE marker file is written into the data directory and checked on
 *     every boot: pointing AngryBird at BlackBird's directory (or vice versa)
 *     is refused instead of silently mixing positions;
 *   - the profile carries its own version id.
 *
 * BlackBird (the default) is NOT modified: with BB_PROFILE unset, every path and
 * every rule is exactly what it was before this file existed.
 */
const fs = require('node:fs');
const path = require('node:path');

const PROFILES = Object.freeze({
  blackbird: Object.freeze({ name: 'blackbird', label: 'BlackBird', isolatedDir: false }),
  angrybird: Object.freeze({ name: 'angrybird', label: 'AngryBird', isolatedDir: true }),
  // The live profile is a THIRD product, not a mode of the first two. It is
  // never the default and it is never reachable by a typo: an unknown name is
  // refused by resolveProfileName() below.
  live: Object.freeze({ name: 'live', label: 'BlackBird Live', isolatedDir: true }),
});

/** The AngryBird scenario. Numbers live here, enforcement lives in risk code. */
const ANGRYBIRD_OVERLAY = Object.freeze({
  risk: {
    startEquity: 100, // USDT (paper) — the $100 starting-capital scenario
    maxPositionPct: 0.25, // $25 nominal on $100 — an upper bound, never a target
    maxOpenPositions: 2,
    maxSymbolExposurePct: 0.25,
    maxNetExposurePct: 0.5,
    killSwitchDrawdownPct: 0.15,
    maxDailyLossPct: 0.05,
    minNotionalUsd: 5,
    // The scenario's own market window: "muddy water". Turbulent, most
    // participants leaving, and the evidence already turning positive. Any
    // missing measurement closes the gate rather than opening it.
    // Thresholds are deliberately explicit so they can be argued with.
    angry: {
      enabled: true,
      maxTradeNotionalUsd: 25, // hard ceiling, even if a strategy asks for more
      reducedTradeNotionalUsd: 10, // what is allowed when full size is not earned
      // Two losses in a row end the episode. Re-entry waits for a genuinely
      // new window (the gate closed and re-opened) plus a cooling period.
      lockout: {
        enabled: true,
        maxConsecutiveLosses: 2,
        minLockMs: 12 * 3600 * 1000,
        requireFreshSetup: true,
      },
      activation: {
        enabled: true,
        // Deliberately above the project's own volatility gate (0.55): AngryBird
        // only trades the extreme end of the same scale, not a different one.
        minAtrPercentile: 0.70,
        minExodusBreadth: 0.6, // 60% of the universe falling: people are leaving
        minRecoveryScore: 0.5, // half the universe already turning back up
      },
      // $25 is allowed ONLY while every one of these holds. Any miss -> reduced size.
      fullSizeRequires: {
        minEquityPctOfStart: 90,
        maxDrawdownPct: 5,
        maxDailyLossPct: 2,
        maxConsecutiveLosses: 1,
        noYellowCard: true,
      },
    },
  },
  // Short-horizon by design: this scenario trades a turn, not a trend. Weekly
  // rotation and a 3-hour time stop belong to BlackBird; AngryBird uses a
  // one-day rotation, shorter momentum windows and a tighter time stop.
  strategy: {
    timeStopMs: 6 * 3600 * 1000,
    entryType: 'maker',
    rotator: {
      rebalanceHours: 24,
      perPositionPct: 25,
      maxGrossPct: 50,
      maxPositions: 2,
      disasterStopAtr: 3.5,
      volTargetPct: 25,
      variants: [
        { lookHours: 24, top: 2, neutral: true, gate: false },
        { lookHours: 48, top: 2, neutral: true, gate: false },
      ],
    },
  },

  court: {
    enabled: true,
    maxInvisibleInterventionsPerSeason: 3,
    maxYellowCardsPerSeason: 2,
    userTakeoverWindowMs: 30 * 1000,
    minAlertChannels: 2,
    alertChannels: ['dashboard', 'telegram', 'email'],
    councilQuorum: 3,
    // Logical party ids (not secrets). Which model plays which id lives in ROLE_MAP_JSON.
    roster: {
      actor: 'primary_model',
      overseer: 'overseer_model',
      approver: 'risk_engine',
      evaluator: 'standby_council',
      council: ['council_1', 'council_2', 'council_3'],
    },
  },
});

function resolveProfileName(env = process.env) {
  const raw = String(env.BB_PROFILE || 'blackbird').trim().toLowerCase();
  return PROFILES[raw] ? raw : null;
}

function deepAssign(target, src) {
  for (const [k, v] of Object.entries(src)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      target[k] = deepAssign(target[k] && typeof target[k] === 'object' ? target[k] : {}, v);
    } else target[k] = v;
  }
  return target;
}

/**
 * Apply a profile to a config object (mutates and returns it).
 * Explicit operator overrides win: an env/config value for START_EQUITY etc.
 * is NOT silently replaced, because the overlay is applied only to keys that
 * are still at their default value (see `defaults`).
 */
function applyProfile(cfg, { env = process.env, defaults, pkgVersion = '0.0.0', root } = {}) {
  const name = resolveProfileName(env);
  if (!name) {
    throw new Error(`BB_PROFILE="${env.BB_PROFILE}" is not a known profile (use: ${Object.keys(PROFILES).join(' | ')})`);
  }
  const prof = PROFILES[name];
  cfg.profile = {
    name,
    label: prof.label,
    version: `${pkgVersion}+${name}`,
    isolatedDir: prof.isolatedDir,
  };
  if (name === 'angrybird') {
    deepAssign(cfg, JSON.parse(JSON.stringify(ANGRYBIRD_OVERLAY)));
    const base = env.DATA_DIR || (defaults && defaults.runtime && defaults.runtime.dataDir) || path.join(root || process.cwd(), 'data');
    cfg.runtime.dataDir = path.join(base, 'profiles', 'angrybird');
    cfg.runtime.stateFile = path.join(cfg.runtime.dataDir, 'state.json');
    cfg.runtime.journalFile = path.join(cfg.runtime.dataDir, 'journal.jsonl');
    cfg.runtime.logDir = path.join(cfg.runtime.dataDir, 'logs');
    cfg.reporter.dir = path.join(cfg.runtime.dataDir, 'reports');
    cfg.trials.file = path.join(cfg.runtime.dataDir, 'trials.jsonl');
  }
  if (name === 'live') {
    // Kept in its own module so the live gates can be reviewed and tested
    // without reading the engine. It mutates the same cfg object.
    require('./profiles-live').applyLiveProfile(cfg, { env, root });
  }
  return cfg;
}

/**
 * Refuse to boot a profile on a data directory that belongs to another one.
 * Writes the marker on first use. Returns { ok, reason }.
 */
function claimDataDir(dir, profileName) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const marker = path.join(dir, 'PROFILE');
    if (fs.existsSync(marker)) {
      const owner = fs.readFileSync(marker, 'utf8').trim();
      if (owner !== profileName) {
        return { ok: false, reason: `data directory belongs to profile "${owner}", refusing to start "${profileName}" on it` };
      }
      return { ok: true, reason: 'owned' };
    }
    // An existing state file with no marker predates profiles: only BlackBird may adopt it.
    const hasLegacyState = fs.existsSync(path.join(dir, 'state.json'));
    if (hasLegacyState && profileName !== 'blackbird') {
      return { ok: false, reason: `data directory holds unmarked legacy state; only "blackbird" may adopt it` };
    }
    fs.writeFileSync(marker, profileName + '\n');
    return { ok: true, reason: 'claimed' };
  } catch (e) {
    return { ok: false, reason: `cannot verify data directory: ${e.code || e.message}` };
  }
}

module.exports = { PROFILES, ANGRYBIRD_OVERLAY, resolveProfileName, applyProfile, claimDataDir };
