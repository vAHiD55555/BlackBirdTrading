'use strict';
/**
 * EXAMPLE PLUGIN — a volatility brake.
 *
 * This is a working example, not a demo stub: it is loaded by the registry like
 * any other plugin, and it does exactly one thing — when realised volatility is
 * far above its own recent norm, it asks the engine to trade smaller.
 *
 * WHAT IT CANNOT DO (and this is the point of the example)
 * -------------------------------------------------------
 *   - it cannot open, close, size or cancel an order: there is no such hook;
 *   - it cannot raise risk: `riskMultiplier` is clamped to (0, 1] and the
 *     registry takes the MINIMUM across plugins;
 *   - it cannot read a key, an env var or the engine object: the context has
 *     none of them.
 *
 * Copy this directory, rename the manifest, and you have a plugin.
 */

const manifest = {
  name: 'vol-brake',
  version: '1.0.0',
  apiVersion: 1,
  description: 'Trades smaller when realised volatility is far above its norm.',
  permissions: ['risk-overlay', 'data', 'notify'],
  priority: 50,
};

/** A tiny ring of recent returns, kept per symbol. */
const state = new Map();

function pushReturn(symbol, r) {
  let s = state.get(symbol);
  if (!s) { s = { ring: [], i: 0 }; state.set(symbol, s); }
  s.ring.push(r);
  if (s.ring.length > 200) s.ring.shift();
  return s.ring;
}

function stdev(xs) {
  if (xs.length < 20) return null;
  const mean = xs.reduce((a, b) => a + b, 0) / xs.length;
  const v = xs.reduce((a, b) => a + (b - mean) ** 2, 0) / xs.length;
  return Math.sqrt(v);
}

module.exports = {
  manifest,

  register(ctx) {
    ctx.log.info('vol-brake armed');
    // The plugin proposes a multiplier; it never sees the aggregate.
    ctx.riskOverlay(({ symbol, price } = {}) => {
      if (!symbol || !Number.isFinite(price)) return 1;
      const s = state.get(symbol);
      if (!s || s.ring.length < 40) return 1;
      const recent = stdev(s.ring.slice(-20));
      const norm = stdev(s.ring);
      if (recent === null || norm === null || norm === 0) return 1;
      const ratio = recent / norm;
      // 1.0x normally; down to 0.5x when volatility is 2x its own norm.
      if (ratio <= 1.2) return 1;
      return Math.max(0.5, 1 - (ratio - 1.2) * 0.5);
    });
  },

  /** Observe a tick. Read-only: the return value is ignored. */
  onTick({ symbol, price } = {}) {
    if (!symbol || !Number.isFinite(price)) return;
    const s = state.get(symbol);
    if (s && Number.isFinite(s.last) && s.last > 0) {
      pushReturn(symbol, (price - s.last) / s.last);
    }
    const cur = state.get(symbol) || { ring: [], i: 0 };
    cur.last = price;
    state.set(symbol, cur);
  },

  /** One line in the report. */
  onReport() {
    const symbols = [...state.keys()];
    if (!symbols.length) return null;
    return `vol-brake: watching ${symbols.length} symbol(s)`;
  },
};
