# BlackBird / AngryBird final package

Source: Cloud merged snapshot, with UTC-safe timestamp parsing fix.

Validation:
- Node.js v22.23.5
- npm test: 429 passed, 0 failed
- mode: paper only
- no .env, secrets, node_modules, runtime state or reports included

Profiles:
- BlackBird: BB_PROFILE=blackbird
- AngryBird: BB_PROFILE=angrybird; paper start equity $100; deterministic $25 hard ceiling

Run:
```sh
npm install --ignore-scripts
npm test
BB_PROFILE=blackbird MODE=paper PORT=8787 npm start
```
