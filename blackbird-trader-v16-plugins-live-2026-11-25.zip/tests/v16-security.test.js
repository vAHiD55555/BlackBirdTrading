'use strict';
/**
 * v16 — security suite: several attack shapes, plus load and overload.
 *
 * WHAT THIS IS
 * ------------
 * A real HTTP server is started (the same startServer() the engine uses) and
 * attacked over a real socket. Nothing is mocked at the transport layer, because
 * the bugs that matter here live in the transport layer: a header that is not
 * checked, a path that is not normalised, a body that is not bounded.
 *
 * THE SHAPES
 * ----------
 *   1. AUTH        — every operations route refuses without a token, and a
 *                    wrong token is not distinguishable from a missing one.
 *   2. PATH        — traversal, encoded traversal, null byte, absolute path.
 *   3. INJECTION   — HTML/script in a query string and in a JSON body.
 *   4. METHOD      — a write verb on a read-only route.
 *   5. SIZE        — a body past the limit is refused, not buffered forever.
 *   6. RATE        — the public limiter and the auth-failure limiter both fire.
 *   7. HEADERS     — CSP, nosniff, frame-deny on every response.
 *   8. LOAD        — N concurrent requests, all answered, none 5xx.
 *   9. OVERLOAD    — far past the limiter, the server still answers (429), it
 *                    does not crash, hang or leak a socket.
 *
 * The load numbers are printed, not asserted as a performance claim: this is a
 * 1-core sandbox, so a throughput figure here says nothing about production.
 */
const assert = require('node:assert');
const http = require('node:http');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { startServer } = require(path.join(SRC, 'web/status'));

const TOKEN = 'test-token-0123456789abcdef';

/** A minimal engine stub: enough for the routes, no market, no disk writes. */
function makeEngine() {
  const cfg = {
    mode: 'paper',
    exchange: 'mexc',
    witnessExchange: 'bitget',
    symbols: ['BTCUSDT', 'ETHUSDT'],
    reporter: { dir: path.join(require('node:os').tmpdir(), 'bb-sec-reports') },
    server: { enabled: true, host: '127.0.0.1', port: 0, token: TOKEN },
    notifications: { telegram: { botToken: '', controlUserIds: [] } },
    strategy: { mode: 'hybrid' },
    risk: {},
  };
  const log = { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
  return {
    cfg,
    log,
    evidence: null,
    supervisor: null,
    health: () => ({ booting: false, dataOk: true, degradedSymbols: [] }),
    status: () => ({ ok: true, mode: 'paper', symbols: cfg.symbols }),
  };
}

/** One HTTP request, with a hard timeout so a hang fails the test, not the run. */
function request(port, { method = 'GET', path: p = '/', headers = {}, body = null, timeoutMs = 5000 } = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, method, path: p, headers }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.setTimeout(timeoutMs, () => { req.destroy(new Error(`timeout after ${timeoutMs}ms`)); });
    req.on('error', reject);
    if (body !== null) req.write(body);
    req.end();
  });
}

(async () => {
  process.env.SERVER_TOKEN = TOKEN;
  const engine = makeEngine();
  const server = startServer(engine);
  await new Promise((resolve, reject) => {
    server.once('listening', resolve);
    server.once('error', reject);
  });
  const port = server.address().port;
  console.log(`\n  (test server on 127.0.0.1:${port})`);

  // ================================================================ 1. AUTH
  console.log('\n▸ v16 security — authentication');

  await t('every operations route refuses without a token', async () => {
    const routes = ['/status', '/ops/status', '/report/latest', '/report/latest.md', '/ops/evidence', '/control/state'];
    for (const r of routes) {
      const res = await request(port, { path: r });
      assert.strictEqual(res.status, 401, `${r} answered ${res.status} without a token`);
    }
  });

  await t('a wrong token is refused exactly like a missing one', async () => {
    const a = await request(port, { path: '/status' });
    const b = await request(port, { path: '/status', headers: { 'x-admin-token': 'wrong' } });
    assert.strictEqual(b.status, 401);
    assert.strictEqual(a.body, b.body, 'the response must not reveal which part was wrong');
  });

  await t('a token of the right length but wrong bytes is refused', async () => {
    const same = 'X'.repeat(TOKEN.length);
    const res = await request(port, { path: '/status', headers: { 'x-admin-token': same } });
    assert.strictEqual(res.status, 401);
  });

  await t('the correct token is accepted', async () => {
    const res = await request(port, { path: '/status', headers: { 'x-admin-token': TOKEN } });
    assert.strictEqual(res.status, 200);
    assert.ok(JSON.parse(res.body).ok);
  });

  await t('a Bearer header works the same as x-admin-token', async () => {
    const res = await request(port, { path: '/status', headers: { authorization: `Bearer ${TOKEN}` } });
    assert.strictEqual(res.status, 200);
  });

  await t('a forged Telegram initData is refused', async () => {
    const res = await request(port, { path: '/status', headers: { 'x-telegram-init-data': 'hash=deadbeef&auth_date=1&user=%7B%22id%22%3A1%7D' } });
    assert.strictEqual(res.status, 401);
  });

  // ================================================================ 2. PATH
  console.log('\n▸ v16 security — path traversal');

  await t('plain traversal is not served', async () => {
    for (const p of ['/assets/../../package.json', '/assets/../status.js', '/assets/..%2f..%2fpackage.json']) {
      const res = await request(port, { path: p });
      assert.ok(res.status === 404 || res.status === 400, `${p} answered ${res.status}`);
      assert.ok(!res.body.includes('"name": "blackbird'), `${p} leaked package.json`);
    }
  });

  await t('an encoded traversal is not served', async () => {
    const res = await request(port, { path: '/assets/%2e%2e%2f%2e%2e%2fpackage.json' });
    assert.ok(res.status === 404 || res.status === 400, `answered ${res.status}`);
  });

  await t('a null byte in the path is not served', async () => {
    const res = await request(port, { path: '/assets/base.css%00.png' });
    assert.ok(res.status === 404 || res.status === 400, `answered ${res.status}`);
  });

  await t('an absolute path is not served', async () => {
    const res = await request(port, { path: '/assets//etc/passwd' });
    assert.ok(res.status === 404 || res.status === 400, `answered ${res.status}`);
  });

  // REGRESSION (v16.1): two independent models flagged readStatic() as a
  // traversal sink. The allow-list already blocked it at the router, but the
  // reader itself had no guard — so a future caller could bypass it. This
  // asserts the guard lives in the reader, not only in the route.
  await t('REGRESSION: the static reader itself refuses to escape the web root', async () => {
    const { readStaticForTest } = require('../src/web/status.js');
    assert.strictEqual(typeof readStaticForTest, 'function', 'the reader must expose a test hook');
    for (const bad of ['../../package.json', '../status.js', '/etc/passwd', 'assets/../../../etc/passwd']) {
      assert.throws(() => readStaticForTest(bad), /outside the web root/, `${bad} was not refused`);
    }
    // and a legitimate asset still reads
    assert.ok(readStaticForTest('assets/base.css').length > 0);
  });

  await t('only allow-listed assets are served', async () => {
    const ok = await request(port, { path: '/assets/base.css' });
    assert.strictEqual(ok.status, 200);
    const bad = await request(port, { path: '/assets/status.js' });
    assert.strictEqual(bad.status, 404, 'a server-side file must never be served as an asset');
  });

  // ================================================================ 3. INJECTION
  console.log('\n▸ v16 security — injection');

  await t('a script tag in a query string is not reflected', async () => {
    const res = await request(port, { path: '/api/public/detail/%3Cscript%3Ealert(1)%3C%2Fscript%3E' });
    assert.ok(!res.body.includes('<script>'), 'the payload was reflected');
    assert.strictEqual(res.status, 404);
  });

  await t('a script tag in a JSON body is not reflected', async () => {
    const res = await request(port, {
      method: 'POST', path: '/ops/probe',
      headers: { 'x-admin-token': TOKEN, 'content-type': 'application/json' },
      body: JSON.stringify({ target: '<script>alert(1)</script>' }),
    });
    assert.ok(!res.body.includes('<script>'), 'the payload was reflected');
  });

  await t('a prototype-pollution body does not change Object.prototype', async () => {
    const res = await request(port, {
      method: 'POST', path: '/control/propose',
      headers: { 'x-admin-token': TOKEN, 'content-type': 'application/json' },
      body: JSON.stringify({ __proto__: { polluted: true }, path: 'risk.maxPositionPct', value: 1 }),
    });
    assert.ok(res.status === 400 || res.status === 409 || res.status === 500, `answered ${res.status}`);
    assert.strictEqual({}.polluted, undefined, 'Object.prototype was polluted');
  });

  // REGRESSION (v16): found by BOTH external review models, on readBody().
  // They were half right and it mattered: JSON.parse alone is safe (it makes
  // __proto__ an own property), but the very next deep walk is not. The body is
  // now scrubbed at the boundary, so no downstream merge can be poisoned.
  await t('REGRESSION: a nested __proto__ in the body never reaches an object', async () => {
    let captured = null;
    const e = makeEngine();
    // Capture what readBody hands to a route by pointing probe at a local sink.
    const s = startServer(e);
    await new Promise((r) => s.once('listening', r));
    const p = s.address().port;
    const res = await request(p, {
      method: 'POST', path: '/control/propose',
      headers: { 'x-admin-token': TOKEN, 'content-type': 'application/json' },
      body: JSON.stringify({ a: { __proto__: { deep: true } }, b: [{ constructor: { x: 1 } }] }),
    });
    // Whatever the route decides, the global prototype must be untouched.
    assert.strictEqual({}.deep, undefined, 'a nested __proto__ polluted Object.prototype');
    assert.strictEqual({}.x, undefined, 'constructor in an array element polluted Object.prototype');
    void captured;
    s.close();
  });

  await t('REGRESSION: setPath refuses a prototype segment', () => {
    const { setPath } = require(path.join(SRC, 'config'));
    assert.throws(() => setPath({}, '__proto__.polluted', 'x'), /prototype chain/);
    assert.throws(() => setPath({}, 'a.constructor.prototype.x', 1), /prototype chain/);
    assert.strictEqual({}.polluted, undefined);
    // A normal path still works.
    const o = {};
    setPath(o, 'risk.maxPositionPct', 0.1);
    assert.strictEqual(o.risk.maxPositionPct, 0.1);
  });

  await t('/healthz is exempt from the public limiter (a probe must never 429)', async () => {
    // REGRESSION from the same suite: /healthz sat behind the public budget, so a
    // burst of real traffic made the platform's liveness probe answer 429 and
    // restart a healthy process — a restart loop caused by our own limiter.
    const el = makeEngine();
    const sl = startServer(el);
    await new Promise((r) => sl.once('listening', r));
    const pl = sl.address().port;
    // Burn the public budget on a real route first.
    for (let i = 0; i < 200; i++) {
      const r = await request(pl, { path: '/api/public/summary' });
      if (r.status === 429) break;
    }
    const probe = await request(pl, { path: '/healthz' });
    assert.strictEqual(probe.status, 200, '/healthz must answer even when the public budget is gone');
    sl.close();
  });

  // ================================================================ 4. METHOD
  console.log('\n▸ v16 security — method');

  await t('a write verb on a public route is refused with 405', async () => {
    for (const m of ['POST', 'PUT', 'DELETE', 'PATCH']) {
      const res = await request(port, { method: m, path: '/api/public/summary' });
      assert.strictEqual(res.status, 405, `${m} answered ${res.status}`);
      assert.ok(String(res.headers.allow || '').includes('GET'));
    }
  });

  await t('a write verb on an ops route still needs auth first', async () => {
    const res = await request(port, { method: 'POST', path: '/ops/probe' });
    assert.strictEqual(res.status, 401, 'auth must be checked before the method');
  });

  // ================================================================ 5. SIZE
  console.log('\n▸ v16 security — body size');

  await t('a body past the limit is refused, not buffered', async () => {
    // A fresh server: the shared one has already spent its public budget on the
    // traversal and injection tests, and a 429 would mask the real answer.
    const eb = makeEngine();
    const sb = startServer(eb);
    await new Promise((r) => sb.once('listening', r));
    const pb = sb.address().port;
    const big = JSON.stringify({ target: 'x'.repeat(200 * 1024) });
    const res = await request(pb, {
      method: 'POST', path: '/ops/probe',
      headers: { 'x-admin-token': TOKEN, 'content-type': 'application/json' },
      body: big,
    });
    assert.strictEqual(res.status, 400, `answered ${res.status}`);
    assert.match(res.body, /too large/);
    sb.close();
  });

  await t('invalid JSON is a 400, not a 500', async () => {
    const ej = makeEngine();
    const sj = startServer(ej);
    await new Promise((r) => sj.once('listening', r));
    const pj = sj.address().port;
    const res = await request(pj, {
      method: 'POST', path: '/ops/probe',
      headers: { 'x-admin-token': TOKEN, 'content-type': 'application/json' },
      body: '{not json',
    });
    assert.strictEqual(res.status, 400);
    sj.close();
  });

  // ================================================================ 6. RATE
  console.log('\n▸ v16 security — rate limiting');

  await t('the auth-failure limiter fires after 10 bad attempts', async () => {
    // A fresh server so the earlier tests do not consume this budget.
    const e2 = makeEngine();
    const s2 = startServer(e2);
    await new Promise((r) => s2.once('listening', r));
    const p2 = s2.address().port;
    let saw429 = false;
    for (let i = 0; i < 14; i++) {
      const res = await request(p2, { path: '/status', headers: { 'x-admin-token': 'bad' } });
      if (res.status === 429) { saw429 = true; break; }
    }
    assert.ok(saw429, 'the auth-failure limiter never fired');
    s2.close();
  });

  await t('the public limiter fires under a burst', async () => {
    const e3 = makeEngine();
    const s3 = startServer(e3);
    await new Promise((r) => s3.once('listening', r));
    const p3 = s3.address().port;
    let saw429 = false;
    for (let i = 0; i < 300; i++) {
      // /api/public/summary is a real public route and IS limited; /health and
      // /healthz are deliberately exempt so a platform probe never gets a 429.
      const res = await request(p3, { path: '/api/public/summary' });
      if (res.status === 429) { saw429 = true; break; }
    }
    assert.ok(saw429, 'the public limiter never fired in 300 requests');
    s3.close();
  });

  // ================================================================ 7. HEADERS
  console.log('\n▸ v16 security — response headers');

  await t('every response carries CSP, nosniff and frame-deny', async () => {
    for (const p of ['/', '/health', '/api/public/summary', '/status']) {
      const res = await request(port, { path: p, headers: { 'x-admin-token': TOKEN } });
      assert.ok(res.headers['content-security-policy'], `${p} has no CSP`);
      assert.strictEqual(res.headers['x-content-type-options'], 'nosniff', `${p} has no nosniff`);
      assert.strictEqual(res.headers['x-frame-options'], 'DENY', `${p} can be framed`);
      assert.strictEqual(res.headers['referrer-policy'], 'no-referrer', `${p} leaks the referrer`);
    }
  });

  await t('the CSP forbids inline script and third-party hosts', async () => {
    const res = await request(port, { path: '/' });
    const csp = String(res.headers['content-security-policy']);
    assert.ok(csp.includes("default-src 'none'"), csp);
    assert.ok(!csp.includes("script-src 'unsafe-inline'"), 'inline script must not be allowed');
    assert.ok(csp.includes("frame-ancestors 'none'"), csp);
  });

  // ================================================================ 8. LOAD
  console.log('\n▸ v16 security — load');

  await t('200 concurrent public requests all get an answer, none 5xx', async () => {
    const e4 = makeEngine();
    const s4 = startServer(e4);
    await new Promise((r) => s4.once('listening', r));
    const p4 = s4.address().port;
    const started = Date.now();
    const results = await Promise.all(
      Array.from({ length: 200 }, () => request(p4, { path: '/health', timeoutMs: 15000 }).catch((e) => ({ status: 0, error: e.message })))
    );
    const elapsed = Date.now() - started;
    const fivexx = results.filter((r) => r.status >= 500);
    const zero = results.filter((r) => r.status === 0);
    assert.strictEqual(fivexx.length, 0, `${fivexx.length} responses were 5xx`);
    assert.strictEqual(zero.length, 0, `${zero.length} requests never got a response`);
    console.log(`      (200 requests in ${elapsed}ms, ${Math.round(200 / (elapsed / 1000))} req/s on 1 core)`);
    s4.close();
  });

  await t('50 concurrent authenticated requests all succeed', async () => {
    // Ops routes are not behind the public limiter, but the shared server has
    // already spent its auth-failure budget; a fresh one keeps this a load test.
    const ea = makeEngine();
    const sa = startServer(ea);
    await new Promise((r) => sa.once('listening', r));
    const pa = sa.address().port;
    const started = Date.now();
    const results = await Promise.all(
      Array.from({ length: 50 }, () => request(pa, { path: '/status', headers: { 'x-admin-token': TOKEN }, timeoutMs: 15000 }))
    );
    const elapsed = Date.now() - started;
    assert.ok(results.every((r) => r.status === 200), `statuses: ${[...new Set(results.map((r) => r.status))].join(',')}`);
    console.log(`      (50 authenticated requests in ${elapsed}ms)`);
    sa.close();
  });

  // ================================================================ 9. OVERLOAD
  console.log('\n▸ v16 security — overload');

  await t('600 requests past the limiter: the server answers 429 and stays up', async () => {
    const e5 = makeEngine();
    const s5 = startServer(e5);
    await new Promise((r) => s5.once('listening', r));
    const p5 = s5.address().port;
    const started = Date.now();
    const results = await Promise.all(
      Array.from({ length: 600 }, () => request(p5, { path: '/api/public/summary', timeoutMs: 20000 }).catch((e) => ({ status: 0, error: e.message })))
    );
    const elapsed = Date.now() - started;
    const zero = results.filter((r) => r.status === 0);
    const fivexx = results.filter((r) => r.status >= 500);
    const limited = results.filter((r) => r.status === 429);
    assert.strictEqual(zero.length, 0, `${zero.length} requests hung or were dropped`);
    assert.strictEqual(fivexx.length, 0, `${fivexx.length} responses were 5xx`);
    assert.ok(limited.length > 0, 'the limiter never engaged under overload');
    // The server must still be alive and answering after the burst. /healthz is
    // deliberately exempt from the limiter, so it is the honest liveness check.
    const after = await request(p5, { path: '/healthz' });
    assert.strictEqual(after.status, 200, 'the server died under overload');
    console.log(`      (600 requests in ${elapsed}ms: ${limited.length} limited, 0 dropped, 0 5xx)`);
    s5.close();
  });

  await t('a slow-loris style partial request does not wedge the server', async () => {
    const e6 = makeEngine();
    const s6 = startServer(e6);
    await new Promise((r) => s6.once('listening', r));
    const p6 = s6.address().port;
    // Open a socket, send half a request, never finish it.
    const net = require('node:net');
    const sock = net.connect(p6, '127.0.0.1');
    await new Promise((r) => sock.once('connect', r));
    sock.write('GET /health HTTP/1.1\r\nHost: x\r\n');
    // The server must still answer a normal request while that one hangs.
    const res = await request(p6, { path: '/healthz', timeoutMs: 5000 });
    assert.strictEqual(res.status, 200, 'a half-open request blocked the server');
    sock.destroy();
    s6.close();
  });

  await t('a malformed request line gets a 400, not a crash', async () => {
    const net = require('node:net');
    const e7 = makeEngine();
    const s7 = startServer(e7);
    await new Promise((r) => s7.once('listening', r));
    const p7 = s7.address().port;
    const raw = await new Promise((resolve) => {
      const sock = net.connect(p7, '127.0.0.1', () => {
        sock.write('NOT-A-METHOD / HTTP/1.1\r\nHost: x\r\n\r\n');
      });
      let buf = '';
      sock.on('data', (d) => { buf += d; });
      sock.on('close', () => resolve(buf));
      sock.on('error', () => resolve(buf));
      setTimeout(() => { sock.destroy(); resolve(buf); }, 3000);
    });
    assert.ok(raw.includes('400') || raw.includes('405'), `got: ${raw.slice(0, 80)}`);
    const after = await request(p7, { path: '/healthz' });
    assert.strictEqual(after.status, 200, 'the server died on a malformed request');
    s7.close();
  });

  server.close();
  done('v16-security');
})();
