'use strict';
/**
 * v16 — FOMC calendar, plugin registry, live profile.
 *
 * Every assertion here is about a RULE, not about a number that happens to be
 * in the file. The calendar test checks the shape and the source, the plugin
 * test checks that a plugin cannot trade or raise risk, and the live test checks
 * that every gate refuses by default.
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const {
  HistoricalIntel, buildEvents, dayToMs, FOMC_2025, FOMC_2026, FOMC_2027,
} = require(path.join(SRC, 'intel/historical'));
const {
  PluginRegistry, PERMISSIONS, HOOKS, validateManifest, MAX_PLUGINS,
} = require(path.join(SRC, 'plugins/registry'));
const {
  VENUES, LIVE_OVERLAY, checkLiveGates, canaryScale, applyLiveProfile, claimLiveDir,
} = require(path.join(SRC, 'profiles-live'));
const { PROFILES, resolveProfileName, applyProfile } = require(path.join(SRC, 'profiles'));

const quietLog = () => ({ info() {}, warn() {}, error() {}, debug() {} });

(async () => {
  // ============================================================ FOMC calendar
  console.log('\n▸ v16 — FOMC calendar verified against the Federal Reserve');

  await t('2027 calendar has 7 rate-decision meetings', () => {
    assert.strictEqual(FOMC_2027.length, 7, `expected 7, got ${FOMC_2027.length}`);
  });

  await t('2027 dates match the Fed page exactly', () => {
    // Transcribed from federalreserve.gov/monetarypolicy/fomccalendars.htm
    // (page last updated 2026-11-18). Second day of each two-day meeting.
    const expected = [
      '2027-01-27', '2027-03-17', '2027-04-28', '2027-06-09',
      '2027-07-28', '2027-09-15', '2027-11-17',
    ];
    assert.deepStrictEqual([...FOMC_2027], expected);
  });

  await t('the October 2027 strategy meeting is NOT a blackout date', () => {
    // The Fed labels 2027-10-26/27 a "Monetary Policy Strategy Meeting": no
    // statement, no press conference. Blocking entries for it would be a false
    // positive that costs trades for no reason.
    assert.ok(!FOMC_2027.includes('2027-10-27'), 'strategy meeting must not be in the list');
    assert.ok(!FOMC_2027.includes('2027-10-26'), 'strategy meeting must not be in the list');
  });

  await t('every date is a valid ISO day and parses to 18:00 UTC', () => {
    for (const d of [...FOMC_2025, ...FOMC_2026, ...FOMC_2027]) {
      assert.match(d, /^\d{4}-\d{2}-\d{2}$/, `bad format: ${d}`);
      const ms = dayToMs(d);
      assert.ok(Number.isFinite(ms), `unparseable: ${d}`);
      assert.strictEqual(new Date(ms).getUTCHours(), 18, `${d} is not 18:00 UTC`);
    }
  });

  await t('the calendar is strictly increasing and has no duplicates', () => {
    const all = [...FOMC_2025, ...FOMC_2026, ...FOMC_2027];
    assert.strictEqual(new Set(all).size, all.length, 'duplicate date in the calendar');
    const sorted = [...all].sort();
    assert.deepStrictEqual(all, sorted, 'calendar is not in chronological order');
  });

  await t('buildEvents() includes 2027 and sorts by timestamp', () => {
    const ev = buildEvents();
    assert.strictEqual(ev.length, FOMC_2025.length + FOMC_2026.length + FOMC_2027.length);
    for (let i = 1; i < ev.length; i++) assert.ok(ev[i].ts > ev[i - 1].ts, 'events not sorted');
    assert.ok(ev.some((e) => e.label.includes('2027-01-27')), '2027 event missing');
  });

  await t('a 2027 FOMC date actually blocks entries inside the window', () => {
    const intel = new HistoricalIntel();
    const ts = dayToMs('2027-03-17');
    const v = intel.at(ts - 10 * 60 * 1000); // 10 minutes before
    assert.strictEqual(v.blackout, true);
    assert.match(v.reason, /2027-03-17/);
  });

  await t('a 2027 date outside the window does not block', () => {
    const intel = new HistoricalIntel();
    const ts = dayToMs('2027-03-17');
    assert.strictEqual(intel.at(ts - 3 * 3600 * 1000).blackout, false);
    assert.strictEqual(intel.at(ts + 20 * 60 * 1000).blackout, false);
  });

  await t('the historical intel never raises risk, even on a blackout', () => {
    const intel = new HistoricalIntel();
    for (const d of FOMC_2027) {
      const v = intel.at(dayToMs(d));
      assert.strictEqual(v.riskMultiplier, 1, 'riskMultiplier must always be exactly 1');
    }
  });

  // ============================================================ plugin registry
  console.log('\n▸ v16 — plugin registry: capabilities, containment, no order path');

  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-plugins-'));

  function writePlugin(name, source) {
    const dir = path.join(tmpRoot, name);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'plugin.js'), source);
    return dir;
  }

  await t('an empty directory loads zero plugins and does not throw', () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(path.join(tmpRoot, 'does-not-exist'));
    assert.strictEqual(res.loaded, 0);
    assert.deepStrictEqual(res.errors, []);
  });

  await t('a valid plugin loads and appears in the snapshot', () => {
    writePlugin('good', `
      module.exports = {
        manifest: { name: 'good', version: '1.0.0', permissions: ['notify'], priority: 10 },
        register(ctx) { ctx.log.info('registered'); },
        onReport() { return 'hello from good'; },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(tmpRoot);
    assert.strictEqual(res.loaded, 1, JSON.stringify(res.errors));
    const snap = r.snapshot();
    assert.strictEqual(snap.plugins[0].name, 'good');
    assert.deepStrictEqual(snap.plugins[0].permissions, ['notify']);
  });

  await t('a plugin that declares no permission for a hook is REFUSED', () => {
    writePlugin('sneaky', `
      module.exports = {
        manifest: { name: 'sneaky', version: '1.0.0', permissions: [] },
        register() {},
        onReport() { return 'I did not declare notify'; },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(tmpRoot);
    assert.strictEqual(res.loaded, 1, 'only "good" should load');
    assert.ok(res.errors.some((e) => e.includes('sneaky') && e.includes('notify')), JSON.stringify(res.errors));
  });

  await t('a plugin with an invalid name is refused', () => {
    writePlugin('badname', `
      module.exports = {
        manifest: { name: 'Bad Name!', version: '1.0.0' },
        register() {},
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(tmpRoot);
    assert.ok(res.errors.some((e) => e.includes('badname')), JSON.stringify(res.errors));
  });

  await t('a plugin with an unknown permission is refused', () => {
    writePlugin('root', `
      module.exports = {
        manifest: { name: 'root', version: '1.0.0', permissions: ['admin', 'shell'] },
        register() {},
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(tmpRoot);
    assert.ok(res.errors.some((e) => e.includes('root') && e.includes('admin')), JSON.stringify(res.errors));
  });

  await t('a plugin that throws in register() is refused, not crashed', () => {
    writePlugin('thrower', `
      module.exports = {
        manifest: { name: 'thrower', version: '1.0.0' },
        register() { throw new Error('boom'); },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    const res = r.loadFrom(tmpRoot);
    assert.ok(res.errors.some((e) => e.includes('thrower') && e.includes('boom')), JSON.stringify(res.errors));
  });

  await t('the context has NO broker, risk, portfolio or env', () => {
    let seen = null;
    writePlugin('spy', `
      module.exports = {
        manifest: { name: 'spy', version: '1.0.0' },
        register(ctx) { global.__spyCtx = ctx; },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data') });
    r.loadFrom(tmpRoot);
    seen = global.__spyCtx;
    assert.ok(seen, 'context was not captured');
    for (const forbidden of ['broker', 'risk', 'portfolio', 'engine', 'env', 'process', 'require']) {
      assert.strictEqual(seen[forbidden], undefined, `context must not expose ${forbidden}`);
    }
    assert.ok(Object.isFrozen(seen), 'context must be frozen');
    delete global.__spyCtx;
  });

  await t('riskMultiplier can only REDUCE: a value above 1 is clamped to 1', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data2') });
    r.entries.push({
      manifest: { name: 'greedy', version: '1.0.0', priority: 1 },
      impl: { riskMultiplier: () => 5 },
      permissions: new Set(['risk-overlay']), failures: 0, disabled: false,
    });
    const m = await r.riskMultiplier({});
    assert.strictEqual(m, 1, 'a plugin must never raise risk above 1');
  });

  await t('riskMultiplier takes the MINIMUM across plugins', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data3') });
    r.entries.push(
      { manifest: { name: 'a', version: '1.0.0', priority: 1 }, impl: { riskMultiplier: () => 0.8 }, permissions: new Set(), failures: 0, disabled: false },
      { manifest: { name: 'b', version: '1.0.0', priority: 2 }, impl: { riskMultiplier: () => 0.5 }, permissions: new Set(), failures: 0, disabled: false },
    );
    assert.strictEqual(await r.riskMultiplier({}), 0.5);
  });

  await t('a plugin returning NaN or a string is ignored, not trusted', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data4') });
    r.entries.push(
      { manifest: { name: 'nan', version: '1.0.0', priority: 1 }, impl: { riskMultiplier: () => NaN }, permissions: new Set(), failures: 0, disabled: false },
      { manifest: { name: 'str', version: '1.0.0', priority: 2 }, impl: { riskMultiplier: () => '0.1' }, permissions: new Set(), failures: 0, disabled: false },
    );
    assert.strictEqual(await r.riskMultiplier({}), 1, 'garbage must not lower or raise risk');
  });

  // REGRESSION (v16): a plugin that used the documented ctx.riskOverlay() helper
  // was silently ignored, because riskMultiplier() only read the impl hook. The
  // brake loaded, logged "armed", and never moved the multiplier — a safety
  // feature that reported itself working and did nothing.
  await t('REGRESSION: ctx.riskOverlay() actually moves the multiplier', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-overlay') });
    const entry = {
      manifest: { name: 'brake', version: '1.0.0', priority: 1 },
      impl: { register(ctx) { ctx.riskOverlay(() => 0.4); } },
      permissions: new Set(['risk-overlay']), failures: 0, disabled: false,
    };
    r.entries.push(entry);
    entry.impl.register({
      riskOverlay: (fn) => r._overlays.push({ name: 'brake', fn }),
      log: quietLog(),
    });
    assert.strictEqual(await r.riskMultiplier({}), 0.4, 'the overlay was ignored');
  });

  await t('REGRESSION: an overlay above 1 is still clamped to 1', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-overlay2') });
    r.entries.push({
      manifest: { name: 'greedy2', version: '1.0.0', priority: 1 },
      impl: {}, permissions: new Set(), failures: 0, disabled: false,
    });
    r._overlays.push({ name: 'greedy2', fn: () => 9 });
    assert.strictEqual(await r.riskMultiplier({}), 1);
  });

  await t('REGRESSION: a disabled plugin\'s overlay stops applying', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-overlay3') });
    const entry = {
      manifest: { name: 'dead', version: '1.0.0', priority: 1 },
      impl: {}, permissions: new Set(), failures: 0, disabled: true,
    };
    r.entries.push(entry);
    r._overlays.push({ name: 'dead', fn: () => 0.1 });
    assert.strictEqual(await r.riskMultiplier({}), 1, 'a disabled plugin must not influence risk');
  });

  await t('REGRESSION: a relative plugin path resolves (require is cwd-independent)', () => {
    // `require('./plugins/x/plugin.js')` from inside src/plugins/registry.js
    // resolved against the registry's own directory and failed. The loader now
    // resolves to an absolute path first.
    const dir = path.join(tmpRoot, 'reltest');
    fs.mkdirSync(path.join(dir, 'p1'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'p1', 'plugin.js'), `
      module.exports = { manifest: { name: 'p1', version: '1.0.0' }, register() {} };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-rel') });
    const res = r.loadFrom(dir);
    assert.strictEqual(res.loaded, 1, JSON.stringify(res.errors));
  });

  // ------------------------------------------------ the source gate (model-found)
  // Found by the external security review, not by my own tests: a plugin is
  // loaded with require(), so a plugin that calls require('fs') can read a key
  // and send it out. The capability model cannot stop that, because it decides
  // what we HAND the plugin, not what the plugin can fetch for itself.
  await t('a plugin that requires fs is refused BEFORE it runs', () => {
    // loadFrom() takes a PARENT directory and reads <parent>/<name>/plugin.js,
    // so this needs its own parent: tmpRoot already holds other plugins.
    const parent = path.join(tmpRoot, 'root-stealer');
    const dir = path.join(parent, 'stealer');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'plugin.js'), `
      const fs = require('node:fs');
      module.exports = {
        manifest: { name: 'stealer', version: '1.0.0' },
        register() { global.__stolen = fs.readFileSync('/etc/passwd', 'utf8').slice(0, 10); },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-steal') });
    const res = r.loadFrom(parent);
    assert.strictEqual(res.loaded, 0, 'the plugin must not load');
    assert.ok(res.errors.some((e) => e.includes('source gate')), JSON.stringify(res.errors));
    assert.strictEqual(global.__stolen, undefined, 'the plugin body executed despite the gate');
  });

  await t('the gate catches process.env, eval, child_process and __proto__', () => {
    const { scanSource } = require(path.join(SRC, 'plugins/registry'));
    const cases = [
      "const k = process.env.SERVER_TOKEN;",
      "eval('1+1');",
      "require('node:child_process').exec('id');",
      "const x = { __proto__: { admin: true } };",
      "new Function('return process')();",
      "import('node:fs');",
      "globalThis.process.env;",
      "obj.constructor.constructor('return process')();",
    ];
    for (const src of cases) assert.ok(scanSource(src), `not caught: ${src}`);
  });

  await t('the gate does NOT trip on a comment or a plain string', () => {
    const { scanSource } = require(path.join(SRC, 'plugins/registry'));
    assert.strictEqual(scanSource("// I do not require('fs') here\nmodule.exports={};"), null);
    assert.strictEqual(scanSource('/* eval( is bad */ module.exports={};'), null);
    assert.strictEqual(scanSource("const url = 'https://example.com/a'; module.exports={};"), null,
      'a URL must not be mistaken for a line comment');
  });

  await t('allowUnsafe:true is the only opt-out and it is explicit', () => {
    const parent = path.join(tmpRoot, 'root-trusted');
    const dir = path.join(parent, 'trusted');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'plugin.js'), `
      const os = require('node:os');
      module.exports = {
        manifest: { name: 'trusted', version: '1.0.0', allowUnsafe: true },
        register() { return os.platform(); },
      };
    `);
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data-trust') });
    const res = r.loadFrom(parent);
    assert.strictEqual(res.loaded, 1, JSON.stringify(res.errors));
  });

  await t('a plugin that throws three times is disabled and the engine continues', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data5') });
    const entry = {
      manifest: { name: 'flaky', version: '1.0.0', priority: 1 },
      impl: { onReport: () => { throw new Error('nope'); } },
      permissions: new Set(['notify']), failures: 0, disabled: false,
    };
    r.entries.push(entry);
    for (let i = 0; i < 3; i++) await r.reportSections({});
    assert.strictEqual(entry.disabled, true, 'three failures must disable the plugin');
    assert.strictEqual(r.active().length, 0);
  });

  await t('a hanging hook is cut off by the timeout, not left to block', async () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data6') });
    r.entries.push({
      manifest: { name: 'hang', version: '1.0.0', priority: 1 },
      impl: { onReport: () => new Promise(() => {}) },
      permissions: new Set(['notify']), failures: 0, disabled: false,
    });
    const started = Date.now();
    const out = await r.reportSections({});
    const elapsed = Date.now() - started;
    assert.deepStrictEqual(out, []);
    assert.ok(elapsed < 4000, `hook should time out near 2s, took ${elapsed}ms`);
  });

  await t('plugins run in priority order, then by name', () => {
    const r = new PluginRegistry({ log: quietLog(), dataRoot: path.join(tmpRoot, 'data7') });
    r.entries.push(
      { manifest: { name: 'z', version: '1.0.0', priority: 5 }, impl: {}, permissions: new Set(), failures: 0, disabled: false },
      { manifest: { name: 'a', version: '1.0.0', priority: 5 }, impl: {}, permissions: new Set(), failures: 0, disabled: false },
      { manifest: { name: 'first', version: '1.0.0', priority: 1 }, impl: {}, permissions: new Set(), failures: 0, disabled: false },
    );
    r.entries.sort((a, b) => (a.manifest.priority - b.manifest.priority) || a.manifest.name.localeCompare(b.manifest.name));
    assert.deepStrictEqual(r.entries.map((e) => e.manifest.name), ['first', 'a', 'z']);
  });

  await t('there is no hook that can submit, cancel or size an order', () => {
    for (const hook of Object.keys(HOOKS)) {
      assert.ok(!/submit|cancel|order|size|trade/i.test(hook), `hook "${hook}" looks like an order path`);
    }
  });

  await t('validateManifest rejects a non-object and a bad version', () => {
    assert.strictEqual(validateManifest(null).ok, false);
    assert.strictEqual(validateManifest({ name: 'xx', version: 'one' }).ok, false);
    assert.strictEqual(validateManifest({ name: 'xx', version: '1.0.0' }).ok, true);
    // A one-character name is refused: it is too easy to collide with a typo.
    assert.strictEqual(validateManifest({ name: 'x', version: '1.0.0' }).ok, false);
  });

  await t('MAX_PLUGINS is a real cap, not a comment', () => {
    assert.ok(Number.isInteger(MAX_PLUGINS) && MAX_PLUGINS > 0 && MAX_PLUGINS <= 64);
  });

  // ============================================================ live profile
  console.log('\n▸ v16 — live profile: every gate refuses by default');

  await t('live is a known profile but never the default', () => {
    assert.ok(PROFILES.live, 'live profile must exist');
    assert.strictEqual(resolveProfileName({}), 'blackbird', 'default must stay blackbird');
    assert.strictEqual(resolveProfileName({ BB_PROFILE: 'live' }), 'live');
    assert.strictEqual(resolveProfileName({ BB_PROFILE: 'lvie' }), null, 'a typo must not resolve');
  });

  await t('an empty environment is NOT ready to trade', () => {
    const g = checkLiveGates({});
    assert.strictEqual(g.ready, false);
    assert.ok(g.blockers.length >= 3, `expected several blockers, got ${g.blockers.length}`);
  });

  await t('the intent gate refuses "true", "1" and "yes"', () => {
    for (const v of ['true', '1', 'yes', 'on', 'TRUE']) {
      const g = checkLiveGates({ BB_I_UNDERSTAND_REAL_MONEY: v });
      assert.ok(g.blockers.some((b) => b.includes('BB_I_UNDERSTAND_REAL_MONEY')), `"${v}" must be refused`);
    }
  });

  await t('the intent gate accepts only the literal "YES"', () => {
    const g = checkLiveGates({ BB_I_UNDERSTAND_REAL_MONEY: 'YES' });
    assert.ok(!g.blockers.some((b) => b.includes('BB_I_UNDERSTAND_REAL_MONEY')));
  });

  await t('a withdraw-scoped key is refused, not warned about', () => {
    const g = checkLiveGates({
      BB_I_UNDERSTAND_REAL_MONEY: 'YES',
      HL_API_WALLET_KEY: 'k', HL_ACCOUNT_ADDRESS: '0xabc',
      BB_LIVE_KEY_SCOPE: 'trade+withdraw',
    });
    assert.ok(g.blockers.some((b) => b.includes('withdraw')), JSON.stringify(g.blockers));
  });

  await t('a notional ceiling above the reviewed default is refused', () => {
    const g = checkLiveGates({
      BB_I_UNDERSTAND_REAL_MONEY: 'YES',
      HL_API_WALLET_KEY: 'k', HL_ACCOUNT_ADDRESS: '0xabc',
      BB_LIVE_MAX_NOTIONAL_USD: '100000',
    });
    assert.ok(g.blockers.some((b) => b.includes('exceeds the reviewed ceiling')), JSON.stringify(g.blockers));
  });

  await t('an unknown venue is refused', () => {
    const g = checkLiveGates({ BB_I_UNDERSTAND_REAL_MONEY: 'YES', BB_LIVE_VENUE: 'my-friend-exchange' });
    assert.ok(g.blockers.some((b) => b.includes('unknown live venue')));
  });

  await t('every gate open still reports ready=true (and the engine still refuses)', () => {
    const g = checkLiveGates({
      BB_I_UNDERSTAND_REAL_MONEY: 'YES',
      HL_API_WALLET_KEY: 'k', HL_ACCOUNT_ADDRESS: '0xabc',
      BB_LIVE_MAX_NOTIONAL_USD: '50',
      BB_LIVE_CANARY_STAGE: '1',
    });
    assert.strictEqual(g.ready, true, JSON.stringify(g.blockers));
    assert.ok(g.venue && g.venue.keyScope === 'trade-only');
  });

  await t('canary stage 1 scales the ceiling to 25%', () => {
    assert.strictEqual(canaryScale({ BB_LIVE_CANARY_STAGE: '1' }), 0.25);
    assert.strictEqual(canaryScale({ BB_LIVE_CANARY_STAGE: '2' }), 0.5);
    assert.strictEqual(canaryScale({ BB_LIVE_CANARY_STAGE: '3' }), 1);
    assert.strictEqual(canaryScale({}), 0.25, 'default stage must be the cautious one');
  });

  await t('the live overlay is more conservative than the paper defaults', () => {
    const paper = { maxPositionPct: 0.2, maxNetExposurePct: 0.7, killSwitchDrawdownPct: 0.12, maxDailyLossPct: 0.04 };
    assert.ok(LIVE_OVERLAY.risk.maxPositionPct < paper.maxPositionPct);
    assert.ok(LIVE_OVERLAY.risk.maxNetExposurePct < paper.maxNetExposurePct);
    assert.ok(LIVE_OVERLAY.risk.killSwitchDrawdownPct < paper.killSwitchDrawdownPct);
    assert.ok(LIVE_OVERLAY.risk.maxDailyLossPct < paper.maxDailyLossPct);
  });

  await t('applyLiveProfile isolates the data directory', () => {
    const cfg = { runtime: {}, reporter: {}, trials: {} };
    applyLiveProfile(cfg, { env: { DATA_DIR: '/tmp/bb-live-test' }, root: '/tmp' });
    assert.strictEqual(cfg.profile.name, 'live');
    assert.ok(cfg.runtime.dataDir.includes('profiles/live'), cfg.runtime.dataDir);
    assert.ok(cfg.runtime.stateFile.endsWith('state.json'));
    assert.strictEqual(cfg.live.canaryScale, 0.25);
  });

  await t('a live book refuses to adopt an unmarked directory with state', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-live-dir-'));
    fs.writeFileSync(path.join(dir, 'state.json'), '{}');
    const r = claimLiveDir(dir);
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /unmarked state/);
  });

  await t('a live book refuses a directory owned by another profile', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-live-dir2-'));
    fs.writeFileSync(path.join(dir, 'PROFILE'), 'angrybird\n');
    const r = claimLiveDir(dir);
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /angrybird/);
  });

  await t('a fresh directory is claimed and then owned', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-live-dir3-'));
    assert.strictEqual(claimLiveDir(dir).reason, 'claimed');
    assert.strictEqual(claimLiveDir(dir).reason, 'owned');
  });

  await t('no venue entry holds a secret, only the name of an env var', () => {
    for (const [name, v] of Object.entries(VENUES)) {
      assert.match(v.keyEnv, /^[A-Z0-9_]+$/, `${name}.keyEnv must be a variable name`);
      assert.ok(!/^[A-Za-z0-9+/=]{20,}$/.test(v.keyEnv), `${name}.keyEnv looks like a value`);
    }
  });

  await t('the live profile does not change the paper profile', () => {
    const cfg = { runtime: {}, reporter: {}, trials: {}, risk: { maxPositionPct: 0.2 } };
    applyProfile(cfg, { env: {}, defaults: {}, pkgVersion: '4.0.0', root: '/tmp' });
    assert.strictEqual(cfg.profile.name, 'blackbird');
    assert.strictEqual(cfg.risk.maxPositionPct, 0.2, 'paper risk must be untouched');
  });

  done('v16');
})();
