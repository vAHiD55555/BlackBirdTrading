# BlackBird Trader — code review, fixes, and three added methods

Reviewed the whole `blackbird-trader-deploy` tree (Node.js, no dependencies,
`node tests/run.js`). Every finding below was reproduced with a script before
being fixed, and every fix is covered by a test.

Baseline before the changes: **60/60 tests passing**.
After the changes: **315/315 passing** (the suite grew by the new sleeve and
regression tests).

---

## 1. Bugs found and fixed

### BLOCKER — the kill switch could never fire again after a restart
`src/risk/risk.js`

`peakEquity` was initialised from the *live* equity on every boot:

```js
this.peakEquity = store.state.equity;   // before
```

A bot that had run up to 6000 and fallen to 5400 came back believing its peak
was 5400. Drawdown read **0%**, so the kill switch and the drawdown throttle
were both permanently disarmed — the exact moment they matter most.

**Fix:** the peak is persisted in state and restored on boot, with the live
equity only as a floor. `settle()` now writes it back.

```js
this.peakEquity = Math.max(
  Number(store.state.peakEquity) || 0,
  Number(store.state.equity) || 0,
  Number(cfg.risk.startEquity) || 0
);
```

### BLOCKER — a restart mid-day faked a −20% daily loss and halted the bot
`src/risk/risk.js`, `src/core/store.js`

`dayStartEquity` is only written on a day roll. A restart inside the same UTC
day left it unset, and `dailyPnlPct()` fell back to `startEquity`:

```js
const start = s.dayStartEquity ?? this.cfg.risk.startEquity;   // before
```

A bot merely down 20% *since inception* therefore reported a −20% **daily**
loss and halted itself on the first boot. Reproduced: `dailyPnlPct() = -20.00`.

**Fix:** no anchor means no daily P&L (return 0), `rollDay()` anchors the day
to the current equity the first time it sees a day with no anchor, and
`loadState()` migrates old state files that predate the key.

### MAJOR — the rotator bypassed the risk officer entirely
`src/strategy/rotator.js`

`_openTarget()` never called `risk.check()`. The hard limits (halted, daily
loss cap, net exposure, equity floor) applied only to the tactical path, so the
rotator could keep opening positions while the bot was halted.

**Fix:** every rotator entry now passes `risk.check()` and is vetoed like any
other order. (The replay harness injects a minimal risk stub with no `check()`,
so the gate is applied only when the method exists.)

### MAJOR — the gross cap ignored `maxGrossPct`
`src/strategy/rotator.js`

```js
const maxTotal = this.cfg.risk.maxOpenPositions * this.cfg.risk.maxPositionPct * equity;  // before
```

That is 8 × 20% = **160% of equity**, regardless of what `maxGrossPct` said. A
config asking for 70% gross could still reach 160%.

**Fix:** the cap is the rotator's own limit, `equity * maxGrossPct / 100`.

### MAJOR — partial resizes skipped the risk officer and dropped the entry fee
`src/strategy/rotator.js`

The resize branch wrote `this.risk.state.equity += pnl` directly. That skipped
the peak-equity update, the trade counters, the loss streak and the kill
switch — a book could bleed out through resizes and never trip a single limit.
It also charged only the exit fee, so every partial resize booked a slightly
better P&L than the book earned.

**Fix:** resizes route through `risk.settle()` and charge the entry fee
attributable to the closed slice.

### MAJOR — `.env` values with an inline comment were silently discarded
`src/config.js`

`.env.example` documents every key with a trailing `# ...`. Copying it to
`.env` made every such value unparseable, and the risk limit silently fell back
to the default:

```
MAX_DAILY_LOSS_PCT=0.08        # stop at 8%   ->  "not a number, ignoring"
```

**Fix:** strip an inline comment, but only when the `#` is preceded by
whitespace, so a `#` inside a token or URL survives.

### MINOR — `validateConfig()` validated nothing
`src/config.js`

```js
if (s.tpAtrMult <= 0 || s.slAtrMult <= 0)   // before
```

Neither key exists in this build (geometry is in bps). `undefined <= 0` is
always false, so the check never fired. **Fix:** validate the keys that are
actually used, plus the rotator's sizing bounds.

### MINOR — a no-op timeframe guard that looked like a guard
`src/engine.js`

```js
cfg.data.timeframe = cfg.data.timeframe === '1h' ? '1h' : '1h';   // before
```

Both branches are identical. **Fix:** assign `'1h'` and warn when it overrides
a different configured value.

### MINOR — shorts were marked at the bid
`src/engine.js`

Every position was marked with `t.bid`. A short exits into the **ask**, so
short P&L was overstated by the spread on every tick — small per tick, but it
is the number the drawdown throttle and the kill switch read. **Fix:** a
direction-aware `_markPosition()`.

### MINOR — the daily equity sample used the wall clock
`src/strategy/rotator.js`

`_sampleEquity()` used `new Date()` instead of the injected clock, so a
historical replay collapsed every simulated day into today's date and the
volatility estimator saw one sample. **Fix:** use `this.now()`.

---

## 2. Three added methods

All three are **off by default** (`strategy.rotator.sleeves.*.enabled`), so an
existing deployment keeps the exact book it had. When enabled they contribute
to the *same* target book, under the same gross cap and the same risk officer —
they are not a parallel book, so a Donchian long and a momentum short on the
same symbol cancel instead of stacking leverage.

### `src/strategy/sleeves/donchian.js` — channel breakout with ATR trailing
The trend-capture sleeve. Long when the close exceeds the highest high of the
previous `lookback` bars, short on the mirror. The channel **excludes the
current bar** — including it makes the condition true by construction, which is
the classic bug in this family. An EMA filter and an ATR-expansion floor keep
it out of dead volatility, and size scales with `targetVol / realisedVol`.

### `src/strategy/sleeves/meanrev.js` — volatility-regime mean reversion
The complement to momentum: it earns in chop, where momentum bleeds. Bollinger
+ RSI + z-score entry, gated by **ADX below a ceiling** so it never fades a
trend, and a hard z-stop so it never fades a crash. Size shrinks as the stretch
grows — a 3σ move is a worse bet than a 1.8σ one, not a better one.

### `src/strategy/sleeves/carry.js` — funding / basis carry (delta-neutral)
The only edge here that does not depend on price direction. Perpetual funding
is annualised, both legs' fees and basis slippage are subtracted, and only
clearly positive net carry is returned. It computes the target book and the
exact hedge ratio (`hedgeQty`, `netDelta`) but deliberately does **not** place
the hedge — execution stays with the broker, so a carry sleeve can never
silently open a naked perp short.

Supporting change: `funding()` was added to the Binance and Bybit adapters
(public endpoints, no key). A venue that does not expose funding yields no
carry candidates rather than a fabricated rate.

---

## 3. Verification

```
node tests/run.js
  315 passed, 0 failed
```

New coverage in `tests/sleeves.test.js` (22 tests, offline and deterministic):
breakout detection, the no-look-ahead channel, the EMA and volatility filters,
the ADX gate, the runaway-move guard, size scaling, funding annualisation,
hedge neutrality, and a regression test for each bug above.

## 4. How to enable the sleeves

```json
"strategy": {
  "rotator": {
    "sleeves": {
      "donchian": { "enabled": true, "lookback": 55, "basePct": 8, "atrMult": 2.5 },
      "meanrev":  { "enabled": true, "zEntry": 1.8, "adxMax": 22, "basePct": 6 },
      "carry":    { "enabled": true, "minCarryPct": 8, "basePct": 10 }
    }
  }
}
```

Start with one sleeve at a time and watch `stats.skipped` and the risk vetoes
before adding the next.
