#!/usr/bin/env node
'use strict';
/**
 * Research data downloader — real Binance klines, cached on disk.
 *
 *   node research/fetch.js --days=730 --tf=15m --symbols=BTCUSDT,ETHUSDT,...
 *
 * Cache layout: data/research/<SYM>-<TF>.json  -> [[t,o,h,l,c,v], ...]
 * Also: data/research/funding-<SYM>.json -> [[t,fundingRate], ...]
 */
const fs = require('node:fs');
const path = require('node:path');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};

const DAYS = Number(arg('days', 730));
const TF = arg('tf', '15m');
const SYMBOLS = arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT')
  .split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
const OUT = path.join(__dirname, '..', 'data', 'research');
fs.mkdirSync(OUT, { recursive: true });

const TF_MIN = { '1m': 1, '3m': 3, '5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240 };
const tfMs = (TF_MIN[TF] || 15) * 60000;
const need = Math.floor((DAYS * 86400000) / tfMs);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJson(url, tries = 5) {
  for (let a = 0; a < tries; a++) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 20000);
      const r = await fetch(url, { signal: ctrl.signal });
      clearTimeout(to);
      if (r.status === 429 || r.status === 418) { await sleep(2000 * (a + 1)); continue; }
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return await r.json();
    } catch (e) {
      if (a === tries - 1) throw e;
      await sleep(600 * (a + 1));
    }
  }
}

async function fetchKlines(symbol) {
  const out = [];
  let endTime = Date.now();
  while (out.length < need) {
    const limit = Math.min(1000, need - out.length);
    const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${TF}&limit=${limit}&endTime=${endTime}`;
    const rows = await getJson(url);
    if (!rows || !rows.length) break;
    for (const r of rows) out.push([+r[0], +r[1], +r[2], +r[3], +r[4], +r[5]]);
    endTime = rows[0][0] - 1;
    if (rows.length < limit) break;
    await sleep(120);
  }
  const seen = new Set();
  const bars = out.filter((b) => (seen.has(b[0]) ? false : (seen.add(b[0]), true)));
  bars.sort((a, b) => a[0] - b[0]);
  return bars;
}

async function fetchFunding(symbol) {
  // futures funding history (8h cadence) — used to model carry honestly
  const out = [];
  let startTime = Date.now() - DAYS * 86400000;
  for (let i = 0; i < 40; i++) {
    const url = `https://fapi.binance.com/fapi/v1/fundingRate?symbol=${symbol}&startTime=${startTime}&limit=1000`;
    const rows = await getJson(url);
    if (!rows || !rows.length) break;
    for (const r of rows) out.push([+r.fundingTime, +r.fundingRate]);
    const last = rows[rows.length - 1].fundingTime;
    if (last <= startTime) break;
    startTime = last + 1;
    if (rows.length < 1000) break;
    await sleep(150);
  }
  return out.sort((a, b) => a[0] - b[0]);
}

(async () => {
  console.log(`fetching ${DAYS}d ${TF} for ${SYMBOLS.length} symbols (${need} bars each)`);
  for (const sym of SYMBOLS) {
    const file = path.join(OUT, `${sym}-${TF}.json`);
    let bars = null;
    try {
      const st = fs.statSync(file);
      const old = JSON.parse(fs.readFileSync(file, 'utf8'));
      // refresh if cache is older than 6h and nearly complete
      if (Date.now() - st.mtimeMs < 6 * 3600 * 1000 && old.length >= need * 0.99) {
        console.log(`  ${sym}: cache ok (${old.length} bars)`);
        continue;
      }
    } catch { /* download */ }
    const t0 = Date.now();
    bars = await fetchKlines(sym);
    fs.writeFileSync(file, JSON.stringify(bars));
    console.log(`  ${sym}: ${bars.length} bars in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    if (TF === '15m' || TF === '1h') {
      try {
        const f = await fetchFunding(sym);
        if (f.length) fs.writeFileSync(path.join(OUT, `funding-${sym}.json`), JSON.stringify(f));
        console.log(`    funding points: ${f.length}`);
      } catch (e) { console.log(`    funding failed: ${e.message}`); }
    }
  }
  console.log('done');
})().catch((e) => { console.error(e); process.exit(1); });
