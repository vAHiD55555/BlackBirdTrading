#!/usr/bin/env node
'use strict';
/**
 * Parameter search with a strict train/test split.
 *
 *   node research/search.js --tf=1h --train=0.7
 *
 * Selection is made ONLY on the training half; the reported test-half numbers
 * are what the strategy would have done out of sample. A configuration that
 * looks great in-sample and collapses out-of-sample is exactly what we are
 * trying to avoid, so it is filtered out explicitly.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '1h');
const TRAIN = Number(arg('train', 0.7));
const SYMS = 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'.split(',');
const TFMS = { '15m': 900000, '1h': 3600000, '4h': 14400000 }[TF];
const BARS_PER_DAY = 86400000 / TFMS;

function load(sym) {
  return JSON.parse(fs.readFileSync(path.join(DIR, `${sym}-${TF}.json`), 'utf8'));
}
const raw = Object.fromEntries(SYMS.map((s) => [s, load(s)]));
const n = Math.min(...SYMS.map((s) => raw[s].length));
const split = Math.floor(n * TRAIN);

// ---- data slices (raw arrays) ------------------------------------------------
const usable = SYMS.filter((s) => raw[s].length >= n * 0.99);
const fullData = Object.fromEntries(usable.map((s) => [s, S.prep(raw[s].slice(0, n))]));
const trainData = Object.fromEntries(usable.map((s) => [s, S.prep(raw[s].slice(0, split))]));
const testData = Object.fromEntries(usable.map((s) => [s, S.prep(raw[s].slice(split))]));

const fund = {};
for (const s of usable) {
  try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ }
}

const COSTS = { maker: 2, taker: 5, slip: 1.5 };
const START = 5000;
const RISK = 0.6;

// ---- candidate space ---------------------------------------------------------
function candidates() {
  const out = [];
  for (const lookDays of [3, 7, 14, 30]) {
    for (const top of [1, 2, 3]) {
      for (const neutral of [false, true]) {
        for (const rebDays of [1, 3, 7]) {
          out.push({
            kind: 'xs', lookDays, top, neutral, rebDays,
            stopAtr: 6,
          });
        }
      }
    }
  }
  return out;
}

function build(c) {
  const every = Math.max(1, Math.round(c.rebDays * BARS_PER_DAY));
  return Z.xsMomentum({
    look: Math.round(c.lookDays * BARS_PER_DAY),
    every,
    top: c.top,
    neutral: c.neutral,
    stopAtr: c.stopAtr,
    risk: RISK,
  });
}

const rows = [];
for (const c of candidates()) {
  const strat = build(c);
  const tr = S.run({ data: trainData, strat, start: START, costs: COSTS, funding: fund });
  const te = S.run({ data: testData, strat, start: START, costs: COSTS, funding: fund });
  rows.push({
    label: `xs look${c.lookDays}d top${c.top} ${c.neutral ? 'LS' : 'L'} reb${c.rebDays}d`,
    train: tr, test: te,
  });
}
rows.sort((a, b) => (b.train.calmar || 0) - (a.train.calmar || 0));

const f = (v, w = 7, d = 1) => String(typeof v === 'number' ? v.toFixed(d) : v).padStart(w);
console.log(`\nTF ${TF}  train ${new Date(raw[usable[0]][0][0]).toISOString().slice(0, 10)}→${new Date(raw[usable[0]][split][0]).toISOString().slice(0, 10)}  test →${new Date(raw[usable[0]][n - 1][0]).toISOString().slice(0, 10)}\n`);
console.log('config'.padEnd(34) + 'TRAIN ret%  cagr%  dd%  sharpe  calmar | TEST ret%  cagr%  dd%  sharpe  calmar  trades');
console.log('-'.repeat(118));
for (const r of rows.slice(0, 25)) {
  const a = r.train, b = r.test;
  console.log(r.label.padEnd(34) + f(a.totalReturnPct) + f(a.cagrPct) + f(a.maxDrawdownPct) + f(a.sharpe) + f(a.calmar) +
    ' |' + f(b.totalReturnPct) + f(b.cagrPct) + f(b.maxDrawdownPct) + f(b.sharpe) + f(b.calmar) + f(b.trades, 8, 0));
}

// out-of-sample winners among configs that were also decent in-sample
const robust = rows.filter((r) => r.train.calmar > 0.3 && r.train.sharpe > 0.3);
robust.sort((a, b) => (b.test.calmar || 0) - (a.test.calmar || 0));
console.log('\nmost robust out-of-sample (train calmar>0.3 & sharpe>0.3):');
for (const r of robust.slice(0, 8)) {
  console.log(`  ${r.label.padEnd(34)} test ret ${f(r.test.totalReturnPct, 7)}%  dd ${f(r.test.maxDrawdownPct, 6)}%  sharpe ${f(r.test.sharpe, 5)}  trades ${r.test.trades}`);
}

const out = path.join(__dirname, '..', 'reports', `search-${TF}.json`);
fs.writeFileSync(out, JSON.stringify(rows.map((r) => ({
  label: r.label,
  train: strip(r.train), test: strip(r.test),
})), null, 1));
console.log(`\nsaved ${out}`);

function strip(r) {
  const { equityCurve, _trades, bySymbol, byReason, ...rest } = r;
  return rest;
}
