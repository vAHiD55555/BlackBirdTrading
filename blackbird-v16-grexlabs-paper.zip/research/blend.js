#!/usr/bin/env node
'use strict';
/**
 * Ensemble / portfolio blend.
 *
 * Runs several strategy variants over the same history, converts each to a
 * daily return stream and blends them with fixed weights. Ensembling is the
 * cheapest defence against parameter overfitting: the blend does not need any
 * single variant to be the best, it only needs them to be different.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '1h');
const TFMS = { '15m': 900000, '1h': 3600000, '4h': 14400000 }[TF];
const BPD = 86400000 / TFMS;
const SYMS = (arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT')).split(',');
const WINDOW = Number(arg('window', 120));
const START = 5000;
const COSTS = { maker: 2, taker: 5, slip: 1.5 };

const raw = Object.fromEntries(SYMS.map((s) => [s, JSON.parse(fs.readFileSync(path.join(DIR, `${s}-${TF}.json`), 'utf8'))]));
const n = Math.min(...SYMS.map((s) => raw[s].length));
const data = Object.fromEntries(SYMS.map((s) => [s, S.prep(raw[s].slice(0, n))]));
const fund = {};
for (const s of SYMS) {
  try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ }
}

// ---- the committee: deliberately different windows, sizes and rebalance rates
function committee(notionalPerVariant) {
  return [
    Z.xsMomentum({ look: Math.round(3 * BPD), every: Math.round(7 * BPD), top: 2, neutral: true, stopAtr: 6, gate: 'none', volWeight: false, notionalPct: notionalPerVariant, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(7 * BPD), every: Math.round(7 * BPD), top: 2, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: notionalPerVariant, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(7 * BPD), skip: Math.round(1 * BPD), every: Math.round(7 * BPD), top: 3, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: notionalPerVariant, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(14 * BPD), every: Math.round(14 * BPD), top: 2, neutral: true, stopAtr: 6, gate: 'none', volWeight: true, notionalPct: notionalPerVariant, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(30 * BPD), every: Math.round(14 * BPD), top: 1, neutral: true, stopAtr: 6, gate: 'none', volWeight: false, notionalPct: notionalPerVariant, leverage: 2, tfPerDay: BPD }),
  ];
}

const N = Number(arg('variants', 5));
const perVariant = Number(arg('notional', Math.round(100 / N)));
const list = committee(perVariant).slice(0, N);

const runs = list.map((strat) => {
  const r = S.run({ data, strat, start: START, costs: COSTS, funding: fund });
  return { strat, r, rets: dailyRets(r.equityCurve) };
});

function dailyRets(curve) {
  const out = [];
  for (let i = 1; i < curve.length; i++) out.push(curve[i] / curve[i - 1] - 1);
  return out;
}

// equal-weight blend of daily returns
const L = Math.min(...runs.map((r) => r.rets.length));
const blend = new Array(L).fill(0);
for (const run of runs) for (let i = 0; i < L; i++) blend[i] += run.rets[i] / runs.length;

const curve = [START];
for (const r of blend) curve.push(curve[curve.length - 1] * (1 + r));

const m = S.metrics(curve, START);
const days = curve.length;
console.log(`\nTF ${TF} · ${SYMS.length} symbols · ${days} days · ${runs.length} variants, ${perVariant}% notional each\n`);
console.log('variants:');
for (const run of runs) {
  console.log(`  ${run.strat.name.padEnd(44)} ret ${String(run.r.totalReturnPct).padStart(8)}%  dd ${String(run.r.maxDrawdownPct).padStart(6)}%  sharpe ${String(run.r.sharpe).padStart(5)}  trades ${run.r.trades}`);
}
console.log('\nBLEND:');
console.log(`  total ${m.totalReturnPct}%  CAGR ${m.cagrPct}%  maxDD ${m.maxDrawdownPct}%  sharpe ${m.sharpe}  sortino ${m.sortino}  calmar ${m.calmar}`);

// per-window consistency of the blend
const step = Math.round(WINDOW * BPD);
const wl = [];
for (let s = 0; s + step <= n; s += step) {
  const from = Math.round((s / n) * (days - 1));
  const to = Math.round(((s + step) / n) * (days - 1));
  if (to <= from) continue;
  let eq = START;
  for (let i = from + 1; i <= to; i++) eq *= 1 + blend[i - 1];
  const t0 = new Date(raw[SYMS[0]][s][0]).toISOString().slice(0, 10);
  const t1 = new Date(raw[SYMS[0]][s + step - 1][0]).toISOString().slice(0, 10);
  wl.push({ t0, t1, ret: (eq / START - 1) * 100 });
}
console.log('\nwindows:');
for (const w of wl) console.log(`  ${w.t0}→${w.t1}  ${w.ret >= 0 ? '+' : ''}${w.ret.toFixed(1)}%`);
console.log(`  positive: ${wl.filter((w) => w.ret > 0).length}/${wl.length}`);
