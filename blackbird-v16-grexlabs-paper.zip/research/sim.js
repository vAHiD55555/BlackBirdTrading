'use strict';
/**
 * Research simulator — vectorised indicators + an honest portfolio backtester.
 *
 * Honesty rules (all configurable, defaults = Binance USDⓈ-M futures):
 *   - entry at the NEXT bar's open (a signal on a close cannot fill at that close)
 *   - taker fee on market entries/exits, maker fee on limit exits
 *   - slippage in bps on every market order
 *   - stop and target inside the SAME bar: the STOP wins (never assume the good one)
 *   - funding charged at 00/08/16 UTC from real funding history when supplied
 *   - equity is marked to market every bar, so drawdowns include open risk
 */

const K = {
  maker: 2,      // bps
  taker: 5,      // bps
  slip: 1.5,     // bps per side on market orders
};

// ---------------------------------------------------------------- indicators
function sma(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  let s = 0;
  for (let i = 0; i < src.length; i++) {
    s += src[i];
    if (i >= n) s -= src[i - n];
    if (i >= n - 1) out[i] = s / n;
  }
  return out;
}

function ema(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  const a = 2 / (n + 1);
  let prev = NaN;
  for (let i = 0; i < src.length; i++) {
    if (i === n - 1) {
      let s = 0;
      for (let k = 0; k < n; k++) s += src[i - k];
      prev = s / n;
    } else if (i >= n) {
      prev = src[i] * a + prev * (1 - a);
    }
    out[i] = prev;
  }
  return out;
}

function rsi(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  let avgG = 0, avgL = 0;
  for (let i = 1; i < src.length; i++) {
    const d = src[i] - src[i - 1];
    const g = d > 0 ? d : 0, l = d < 0 ? -d : 0;
    if (i <= n) {
      avgG += g; avgL += l;
      if (i === n) {
        avgG /= n; avgL /= n;
        out[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
      }
    } else {
      avgG = (avgG * (n - 1) + g) / n;
      avgL = (avgL * (n - 1) + l) / n;
      out[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
    }
  }
  return out;
}

function atr(h, l, c, n) {
  const out = new Float64Array(c.length).fill(NaN);
  const tr = new Float64Array(c.length);
  for (let i = 1; i < c.length; i++) {
    tr[i] = Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1]));
  }
  let s = 0;
  for (let i = 1; i < c.length; i++) {
    s += tr[i];
    if (i >= n) s -= tr[i - n];
    if (i >= n) out[i] = s / n;
  }
  return out;
}

function stdev(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  let s = 0, s2 = 0;
  for (let i = 0; i < src.length; i++) {
    s += src[i]; s2 += src[i] * src[i];
    if (i >= n) { s -= src[i - n]; s2 -= src[i - n] * src[i - n]; }
    if (i >= n - 1) {
      const m = s / n;
      out[i] = Math.sqrt(Math.max(0, s2 / n - m * m));
    }
  }
  return out;
}

function highest(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  for (let i = n - 1; i < src.length; i++) {
    let m = -Infinity;
    for (let k = i - n + 1; k <= i; k++) if (src[k] > m) m = src[k];
    out[i] = m;
  }
  return out;
}

function lowest(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  for (let i = n - 1; i < src.length; i++) {
    let m = Infinity;
    for (let k = i - n + 1; k <= i; k++) if (src[k] < m) m = src[k];
    out[i] = m;
  }
  return out;
}

function roc(src, n) {
  const out = new Float64Array(src.length).fill(NaN);
  for (let i = n; i < src.length; i++) out[i] = (src[i] / src[i - n] - 1) * 100;
  return out;
}

/** Pack a raw bar list into typed arrays once — the simulator runs millions of times. */
function prep(raw) {
  const n = raw.length;
  const t = new Float64Array(n), o = new Float64Array(n), h = new Float64Array(n),
    l = new Float64Array(n), c = new Float64Array(n), v = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const b = raw[i];
    t[i] = b[0]; o[i] = b[1]; h[i] = b[2]; l[i] = b[3]; c[i] = b[4]; v[i] = b[5];
  }
  return { n, t, o, h, l, c, v };
}

// ------------------------------------------------------------------ metrics
function metrics(dailyEquity, startEquity) {
  const n = dailyEquity.length;
  if (n < 2) return {};
  const rets = [];
  for (let i = 1; i < n; i++) rets.push(dailyEquity[i] / dailyEquity[i - 1] - 1);
  const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
  const varN = rets.reduce((a, b) => a + (b - mean) ** 2, 0) / rets.length;
  const sd = Math.sqrt(varN);
  const downside = Math.sqrt(rets.filter((r) => r < 0).reduce((a, b) => a + b * b, 0) / Math.max(1, rets.length));
  const ann = Math.sqrt(365);
  const endEq = dailyEquity[n - 1];
  const totalRet = endEq / startEquity - 1;
  let peak = dailyEquity[0], dd = 0;
  for (const e of dailyEquity) { peak = Math.max(peak, e); dd = Math.max(dd, 1 - e / peak); }
  const years = n / 365;
  return {
    totalReturnPct: +(totalRet * 100).toFixed(2),
    cagrPct: +(((1 + totalRet) ** (1 / Math.max(years, 1e-9)) - 1) * 100).toFixed(2),
    sharpe: +(sd > 0 ? (mean / sd) * ann : 0).toFixed(2),
    sortino: +(downside > 0 ? (mean / downside) * ann : 0).toFixed(2),
    maxDrawdownPct: +(dd * 100).toFixed(2),
    calmar: +(dd > 0 ? ((1 + totalRet) ** (1 / Math.max(years, 1e-9)) - 1) / dd : 0).toFixed(2),
    finalEquity: +endEq.toFixed(2),
    days: n,
  };
}

// --------------------------------------------------------------- simulator
/**
 * @param {object} opts
 *   data:   { SYM: prep() }
 *   strat:  { name, warmup, signal(ctx) -> {long, short} | {exit}, stopAtr, tpAtr|tpR, trailAtr,
 *             maxHoldBars, allowShort, sizeRiskPct, maxLeverage, maxPositions, rebalanceBars }
 *   costs:  { maker, taker, slip }
 *   start:  starting equity
 */
function run(opts) {
  const { data, strat, start = 5000 } = opts;
  const costs = Object.assign({}, K, opts.costs || {});
  const syms = Object.keys(data);
  const n = Math.min(...syms.map((s) => data[s].n));
  const warmup = strat.warmup | 0;

  const feats = {};
  for (const s of syms) feats[s] = strat.features(data[s]);

  let equity = start;
  const dailyEquity = [start];
  const trades = [];
  const open = new Map(); // sym -> position
  let lastDay = -1;

  const ctx = { feats, data, i: 0, now: 0 };

  for (let i = warmup; i < n - 1; i++) {
    const barT = data[syms[0]].t[i];

    // ---- 1) manage open positions on this bar
    for (const sym of syms) {
      const p = open.get(sym);
      if (!p) continue;
      const d = data[sym];
      const hi = d.h[i], lo = d.l[i], cl = d.c[i];

      // funding (futures): every 8h
      if (p.nextFunding <= d.t[i]) {
        const rate = fundingAt(opts.funding, sym, d.t[i]);
        // long pays positive funding, short receives it
        p.funding += p.qty * cl * rate * p.dir * -1;
        p.nextFunding = (Math.floor(d.t[i] / 28800000) + 1) * 28800000;
      }

      // trail the stop on the PREVIOUS close (no look-ahead inside the bar)
      if (strat.trailAtr && p.trailOn) {
        const a = p.atrRef * strat.trailAtr;
        if (p.dir > 0) p.stop = Math.max(p.stop, cl - a);
        else p.stop = Math.min(p.stop, cl + a);
      }

      let exitPrice = null, reason = null;
      if (p.dir > 0) {
        if (lo <= p.stop) { exitPrice = Math.min(p.stop, d.o[i]); reason = 'stop'; }
        else if (strat.tpAtr && hi >= p.target) { exitPrice = Math.max(p.target, d.o[i]); reason = 'target'; }
      } else {
        if (hi >= p.stop) { exitPrice = Math.max(p.stop, d.o[i]); reason = 'stop'; }
        else if (strat.tpAtr && lo <= p.target) { exitPrice = Math.min(p.target, d.o[i]); reason = 'target'; }
      }
      if (!exitPrice && strat.maxHoldBars && (i - p.i0) >= strat.maxHoldBars) {
        exitPrice = cl; reason = 'time';
      }
      if (!exitPrice) continue;

      const isMakerExit = reason === 'target';
      const feeBps = isMakerExit ? costs.maker : costs.taker;
      const slipBps = isMakerExit ? 0 : costs.slip;
      const px = exitPrice * (1 - p.dir * slipBps / 10000);
      const gross = (px - p.entry) * p.qty * p.dir;
      const fees = (p.qty * p.entry * p.entryFeeBps + p.qty * px * feeBps) / 10000;
      const pnl = gross - fees - p.funding;
      equity += pnl;
      trades.push({
        sym, dir: p.dir, strat: strat.name, reason,
        entryI: p.i0, exitI: i,
        bars: i - p.i0,
        entry: p.entry, exit: px, qty: p.qty,
        pnl: +pnl.toFixed(2), pnlPct: +(pnl / p.notional * 100).toFixed(3),
        fees: +fees.toFixed(2), funding: +p.funding.toFixed(2),
        rMultiple: p.riskUnit ? +(pnl / p.riskUnit).toFixed(2) : null,
      });
      open.delete(sym);
    }

    // ---- 1b) strategy-directed exits (rotation / regime flips)
    if (strat.manage) {
      const want = strat.manage(ctx, i, open);
      if (want && want.length) {
        for (const w of want) {
          const p = open.get(w.sym);
          if (!p) continue;
          const d = data[w.sym];
          const px = d.c[i];
          const gross = (px - p.entry) * p.qty * p.dir;
          const fees = (p.qty * p.entry * p.entryFeeBps + p.qty * px * costs.taker) / 10000;
          const pnl = gross - fees - p.funding;
          equity += pnl;
          trades.push({ sym: w.sym, dir: p.dir, strat: strat.name, reason: w.reason || 'rebalance',
            entryI: p.i0, exitI: i, bars: i - p.i0, entry: p.entry, exit: px, qty: p.qty,
            pnl: +pnl.toFixed(2), pnlPct: +(pnl / p.notional * 100).toFixed(3),
            fees: +fees.toFixed(2), funding: +p.funding.toFixed(2),
            rMultiple: p.riskUnit ? +(pnl / p.riskUnit).toFixed(2) : null });
          open.delete(w.sym);
        }
      }
    }

    // ---- 2) new entries at the NEXT bar open
    ctx.i = i; ctx.open = open;
    const sig = strat.signal(ctx, i);
    if (sig && sig.length) {
      for (const s of sig) {
        if (open.size >= (strat.maxPositions || 4)) break;
        if (open.has(s.sym)) continue;
        const d = data[s.sym];
        const f = feats[s.sym];
        const a = f.atr[i];
        if (!(a > 0)) continue;
        const nextOpen = d.o[i + 1];
        const dir = s.dir;
        const stopDist = a * strat.stopAtr;
        const riskUsd = equity * (strat.sizeRiskPct / 100);
        // two explicit sizing modes: fixed-fractional risk, or fixed notional slice
        const wFrac = strat.weightMode ? (s.weight || 0) : 1;
        let qty = strat.notionalPct
          ? (equity * (strat.notionalPct / 100) * wFrac) / nextOpen
          : (riskUsd * wFrac) / stopDist;
        const maxNotional = equity * (strat.maxLeverage || 1) / (strat.maxPositions || 4);
        if (qty * nextOpen > maxNotional) qty = maxNotional / nextOpen;
        if (qty * nextOpen < 10) continue;
        const slip = costs.slip / 10000;
        const entry = nextOpen * (1 + dir * slip);
        const notional = qty * entry;
        open.set(s.sym, {
          dir, qty, entry, notional, i0: i, atrRef: a,
          stop: dir > 0 ? entry - stopDist : entry + stopDist,
          target: dir > 0 ? entry + stopDist * (strat.tpAtr || 99) : entry - stopDist * (strat.tpAtr || 99),
          entryFeeBps: costs.taker,
          funding: 0,
          nextFunding: (Math.floor(barT / 28800000) + 1) * 28800000,
          riskUnit: riskUsd,
          trailOn: true,
        });
      }
    }

    // ---- 3) mark to market (daily)
    const day = Math.floor(barT / 86400000);
    if (day !== lastDay && lastDay >= 0) {
      let mtm = equity;
      for (const [sym, p] of open) mtm += (data[sym].c[i] - p.entry) * p.qty * p.dir;
      dailyEquity.push(mtm);
    }
    lastDay = day;
  }

  // close leftovers at the last close
  for (const [sym, p] of open) {
    const d = data[sym];
    const px = d.c[n - 1];
    const gross = (px - p.entry) * p.qty * p.dir;
    const fees = (p.qty * p.entry * p.entryFeeBps + p.qty * px * costs.taker) / 10000;
    equity += gross - fees - p.funding;
  }

  const wins = trades.filter((t) => t.pnl > 0);
  const gp = wins.reduce((a, t) => a + t.pnl, 0);
  const gl = Math.abs(trades.filter((t) => t.pnl <= 0).reduce((a, t) => a + t.pnl, 0));
  const first = data[syms[0]], years = (first.t[n - 1] - first.t[0]) / (365 * 86400000);
  const m = metrics(dailyEquity, start);
  return {
    strat: strat.name,
    ...m,
    trades: trades.length,
    tradesPerDay: +(trades.length / Math.max(1, dailyEquity.length)).toFixed(2),
    winRatePct: +(trades.length ? (wins.length / trades.length) * 100 : 0).toFixed(1),
    profitFactor: +(gl > 0 ? gp / gl : gp > 0 ? 99 : 0).toFixed(2),
    avgR: +(trades.length ? trades.reduce((a, t) => a + (t.rMultiple || 0), 0) / trades.length : 0).toFixed(2),
    feesPaid: +trades.reduce((a, t) => a + t.fees, 0).toFixed(2),
    fundingPaid: +trades.reduce((a, t) => a + t.funding, 0).toFixed(2),
    bySymbol: countBy(trades, 'sym'),
    byReason: countBy(trades, 'reason'),
    equityCurve: dailyEquity.map((e) => +e.toFixed(2)),
    _trades: trades,
  };
}

function countBy(arr, key) {
  const out = {};
  for (const a of arr) out[a[key]] = (out[a[key]] || 0) + 1;
  return out;
}

function fundingAt(fundingMap, sym, ts) {
  if (!fundingMap || !fundingMap[sym]) return 0;
  const f = fundingMap[sym];
  // funding rows are [time, rate]; linear scan with a cursor is fine at daily scale
  let lo = 0, hi = f.length - 1, best = 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (f[mid][0] <= ts) { best = mid; lo = mid + 1; } else hi = mid - 1;
  }
  return f[best] ? f[best][1] : 0;
}

/** Buy & hold benchmark on the first symbol for reference. */
function buyHold(data, sym, start = 5000) {
  const d = data[sym];
  return +(start * (d.c[d.n - 1] / d.c[0])).toFixed(2);
}

module.exports = { sma, ema, rsi, atr, stdev, highest, lowest, roc, prep, run, metrics, buyHold, K };
