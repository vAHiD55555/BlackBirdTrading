#!/usr/bin/env node
'use strict';
/**
 * Rolling walk-forward evaluation for one configuration.
 *
 *   node research/walk.js --tf=1h --look=3 --top=2 --neutral=1 --reb=7 --notional=25
 *
 * Splits the whole history into consecutive windows (default ~4 months) and
 * reports each one separately. A strategy is only believable if MOST windows
 * are positive — a single lucky half is how people blow up.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '1h');
const TFMS = { '15m': 900000, '1h': 3600000, '4h': 14400000 }[TF];
const BPD = 86400000 / TFMS;
const SYMS = 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'.split(',');
const WINDOW_DAYS = Number(arg('window', 120));
const NOTIONAL = Number(arg('notional', 25));
const LEV = Number(arg('lev', 1));
const STOP_ATR = Number(arg('stopatr', 6));

function load(sym) {
  return JSON.parse(fs.readFileSync(path.join(DIR, `${sym}-${TF}.json`), 'utf8'));
}
const raw = Object.fromEntries(SYMS.map((s) => [s, load(s)]));
const n = Math.min(...SYMS.map((s) => raw[s].length));
const fund = {};
for (const s of SYMS) {
  try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ }
}

function strat() {
  return Z.xsMomentum({
    look: Math.round(Number(arg('look', 3)) * BPD),
    every: Math.max(1, Math.round(Number(arg('reb', 7)) * BPD)),
    top: Number(arg('top', 2)),
    neutral: arg('neutral', '1') === '1',
    stopAtr: STOP_ATR,
    notionalPct: NOTIONAL,
    leverage: LEV,
  });
}

const COSTS = { maker: 2, taker: 5, slip: 1.5 };
const START = 5000;
const step = Math.round(WINDOW_DAYS * BPD);

console.log(`\nconfig: xs look${arg('look', 3)}d top${arg('top', 2)} ${arg('neutral', '1') === '1' ? 'long/short' : 'long-only'} reb${arg('reb', 7)}d stop${STOP_ATR}ATR notional ${NOTIONAL}%/pos lev ${LEV}`);
console.log(`data: ${TF}, ${n} bars, ${SYMS.length} symbols\n`);
const head = 'window'.padEnd(26) + 'ret%'.padStart(8) + 'cagr%'.padStart(8) + 'maxDD%'.padStart(8) + 'sharpe'.padStart(8) + 'calmar'.padStart(8) + 'PF'.padStart(7) + 'trades'.padStart(7) + 'win%'.padStart(7);
console.log(head);
console.log('-'.repeat(head.length));

let pos = 0;
const all = [];
for (let start = 0; start + step <= n; start += step) {
  const slice = {};
  for (const s of SYMS) slice[s] = S.prep(raw[s].slice(start, start + step));
  const r = S.run({ data: slice, strat: strat(), start: START, costs: COSTS, funding: fund });
  all.push(r);
  const t0 = new Date(raw[SYMS[0]][start][0]).toISOString().slice(0, 10);
  const t1 = new Date(raw[SYMS[0]][start + step - 1][0]).toISOString().slice(0, 10);
  if (r.totalReturnPct > 0) pos++;
  const f = (v, w = 8, d = 2) => String(typeof v === 'number' ? v.toFixed(d) : v).padStart(w);
  console.log(`${(t0 + '→' + t1).padEnd(26)}${f(r.totalReturnPct)}${f(r.cagrPct)}${f(r.maxDrawdownPct)}${f(r.sharpe)}${f(r.calmar)}${f(r.profitFactor)}${f(r.trades, 7, 0)}${f(r.winRatePct, 7, 1)}`);
}

// compounded across the whole period
let eq = START;
for (const r of all) eq *= 1 + r.totalReturnPct / 100;
const ddWorst = Math.max(...all.map((r) => r.maxDrawdownPct));
console.log('-'.repeat(head.length));
console.log(`windows positive: ${pos}/${all.length}   compounded: ${(eq / START * 100 - 100).toFixed(1)}%  worst window DD: ${ddWorst.toFixed(1)}%`);
const avgSharpe = all.reduce((a, r) => a + r.sharpe, 0) / all.length;
const avgTrades = all.reduce((a, r) => a + r.trades, 0) / all.length;
console.log(`avg sharpe: ${avgSharpe.toFixed(2)}  avg trades/window: ${avgTrades.toFixed(0)}`);
