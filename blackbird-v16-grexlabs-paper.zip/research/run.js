#!/usr/bin/env node
'use strict';
/**
 * Strategy comparison harness.
 *   node research/run.js                      # full history
 *   node research/run.js --from=2024-11-01 --to=2025-05-01
 *   node research/run.js --only=donchian,pullback
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};

const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '15m');
const SYMS = (arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'))
  .split(',').map((s) => s.trim()).filter(Boolean);
const FROM = arg('from', '');
const TO = arg('to', '');
const START = Number(arg('start', 5000));
const RISK = Number(arg('risk', 0.5));
const ONLY = arg('only', '');

function load(sym) {
  const raw = JSON.parse(fs.readFileSync(path.join(DIR, `${sym}-${TF}.json`), 'utf8'));
  let bars = raw;
  if (FROM) { const t = Date.parse(FROM); bars = bars.filter((b) => b[0] >= t); }
  if (TO) { const t = Date.parse(TO); bars = bars.filter((b) => b[0] <= t); }
  return S.prep(bars);
}

function loadFunding(sym) {
  try { return JSON.parse(fs.readFileSync(path.join(DIR, `funding-${sym}.json`), 'utf8')); } catch { return null; }
}

const data = {};
for (const s of SYMS) {
  try { data[s] = load(s); } catch (e) { console.error(`skip ${s}: ${e.message}`); }
}
const syms = Object.keys(data);
if (!syms.length) { console.error('no data'); process.exit(1); }
const n = Math.min(...syms.map((s) => data[s].n));
const t0 = data[syms[0]].t[0], t1 = data[syms[0]].t[n - 1];
console.log(`\ndata: ${syms.length} symbols × ${n} bars  ${new Date(t0).toISOString().slice(0, 10)} → ${new Date(t1).toISOString().slice(0, 10)}`);

const funding = {};
for (const s of syms) funding[s] = loadFunding(s);
const fundMap = Object.fromEntries(syms.map((s) => [s, funding[s]]).filter(([, v]) => v));

const catalogue = [
  Z.trendDonchian({ risk: RISK }),
  Z.trendDonchian({ ch: 55, trend: 200, risk: RISK, name: 'donchian55' }),
  Z.pullbackTrend({ risk: RISK }),
  Z.meanRev({ risk: RISK }),
  Z.xsMomentum({ risk: RISK }),
  Z.volBreakout({ risk: RISK }),
];

const rows = [];
for (const strat of catalogue) {
  if (ONLY && !strat.name.includes(ONLY)) continue;
  const t = Date.now();
  const r = S.run({ data, strat, start: START, costs: { maker: 2, taker: 5, slip: 1.5 }, funding: fundMap });
  r.ms = Date.now() - t;
  rows.push(r);
}

const pad = (v, w, d = 2) => String(typeof v === 'number' ? v.toFixed(d) : v).padStart(w);
console.log('\n' + 'strategy'.padEnd(26) + 'ret%'.padStart(9) + 'cagr%'.padStart(9) + 'sharpe'.padStart(8) +
  'sortino'.padStart(9) + 'maxDD%'.padStart(9) + 'calmar'.padStart(8) + 'PF'.padStart(7) + 'trades'.padStart(8) + 'win%'.padStart(7) + 'fund$'.padStart(9));
console.log('-'.repeat(116));
for (const r of rows) {
  console.log(
    r.strat.padEnd(26) + pad(r.totalReturnPct, 9) + pad(r.cagrPct, 9) + pad(r.sharpe, 8) +
    pad(r.sortino, 9) + pad(r.maxDrawdownPct, 9) + pad(r.calmar, 8) + pad(r.profitFactor, 7) +
    pad(r.trades, 8, 0) + pad(r.winRatePct, 7, 1) + pad(r.fundingPaid, 9)
  );
}

// buy & hold reference
const bh = syms.map((s) => ((data[s].c[n - 1] / data[s].c[0] - 1) * 100));
console.log('\nbuy&hold per symbol: ' + syms.map((s, k) => `${s} ${bh[k].toFixed(0)}%`).join('  '));
console.log(`average buy&hold: ${(bh.reduce((a, b) => a + b, 0) / bh.length).toFixed(1)}% over the window`);

const best = rows.slice().sort((a, b) => (b.calmar || 0) - (a.calmar || 0))[0];
if (best) {
  console.log(`\nbest by calmar: ${best.strat}`);
  console.log('  exits: ' + JSON.stringify(best.byReason));
  console.log('  symbols: ' + JSON.stringify(best.bySymbol));
}

const out = path.join(__dirname, '..', 'reports', `research-${Date.now()}.json`);
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(rows.map(({ _trades, equityCurve, ...r }) => ({ ...r, trades: r.trades })), null, 1));
console.log(`\nsaved ${out}`);
