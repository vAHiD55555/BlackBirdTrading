#!/usr/bin/env node
'use strict';
/**
 * Multi-configuration sweep across rolling windows, loaded once.
 *
 *   node research/sweep.js --tf=1h --set=momentum
 *
 * Prints, per configuration: compounded return over all windows, how many
 * windows were positive, average Sharpe and the worst window drawdown.
 * Consistency across windows matters more than any single big number.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '1h');
const TFMS = { '15m': 900000, '1h': 3600000, '4h': 14400000 }[TF];
const BPD = 86400000 / TFMS;
const SET = arg('set', 'momentum');
const WINDOW_DAYS = Number(arg('window', 120));
const NOTIONAL = Number(arg('notional', 25));
const SYMS = 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'.split(',');

const raw = Object.fromEntries(SYMS.map((s) => [s, JSON.parse(fs.readFileSync(path.join(DIR, `${s}-${TF}.json`), 'utf8'))]));
const n = Math.min(...SYMS.map((s) => raw[s].length));
const fund = {};
for (const s of SYMS) {
  try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ }
}
const COSTS = { maker: 2, taker: 5, slip: 1.5 };
const START = 5000;
const step = Math.round(WINDOW_DAYS * BPD);

// pre-slice windows once (prep is the expensive part)
const wins = [];
for (let start = 0; start + step <= n; start += step) {
  const slice = {};
  for (const s of SYMS) slice[s] = S.prep(raw[s].slice(start, start + step));
  wins.push({ slice, label: new Date(raw[SYMS[0]][start][0]).toISOString().slice(0, 7) });
}

function evaluate(strat) {
  let eq = START, pos = 0, worstDD = 0, sharpe = 0, trades = 0;
  const rets = [];
  for (const w of wins) {
    const r = S.run({ data: w.slice, strat, start: START, costs: COSTS, funding: fund });
    eq *= 1 + r.totalReturnPct / 100;
    rets.push(r.totalReturnPct);
    if (r.totalReturnPct > 0) pos++;
    worstDD = Math.max(worstDD, r.maxDrawdownPct);
    sharpe += r.sharpe;
    trades += r.trades;
  }
  return {
    label: strat.name,
    total: +(eq / START * 100 - 100).toFixed(1),
    pos, windows: wins.length,
    worstDD: +worstDD.toFixed(1),
    sharpe: +(sharpe / wins.length).toFixed(2),
    trades,
    rets,
  };
}

function configs() {
  const out = [];
  if (SET === 'momentum') {
    for (const look of [3, 7]) {
      for (const top of [1, 2, 3]) {
        for (const neutral of [false, true]) {
          for (const reb of [7, 14]) {
            out.push(Z.xsMomentum({ look: Math.round(look * BPD), every: Math.round(reb * BPD), top, neutral, stopAtr: 6, notionalPct: NOTIONAL, leverage: 2, tfPerDay: BPD }));
          }
        }
      }
    }
  } else if (SET === 'mom2') {
    for (const skip of [0, 1]) {
      for (const top of [2, 3]) {
        for (const gate of ['none', 'btc']) {
          for (const volW of [true, false]) {
            out.push(Z.xsMomentum({
              look: Math.round(7 * BPD), skip: Math.round(skip * BPD), every: Math.round(7 * BPD),
              top, neutral: true, stopAtr: 6, gate, volWeight: volW,
              notionalPct: volW ? 100 : 25, leverage: 2, tfPerDay: BPD,
            }));
          }
        }
      }
    }
  } else if (SET === 'trend') {
    for (const ch of [20, 55]) {
      for (const tr of [0.8, 1.5, 2.5]) out.push(Z.trendDonchian({ ch, stopAtr: tr, trailAtr: tr * 1.5, notionalPct: NOTIONAL, leverage: 1 }));
    }
    for (const ch of [55]) for (const tr of [1.5, 2.5]) out.push(Z.volBreakout({ ch, stopAtr: tr, trailAtr: tr * 1.6, notionalPct: NOTIONAL, leverage: 1 }));
  } else if (SET === 'trend2') {
    for (const ch of [20, 55]) {
      for (const st of [3, 5]) {
        out.push(Z.trendDonchian({ ch, stopAtr: st, trailAtr: st * 2, notionalPct: NOTIONAL, leverage: 2 }));
        out.push(Z.volBreakout({ ch, stopAtr: st, trailAtr: st * 2, notionalPct: NOTIONAL, leverage: 2 }));
      }
    }
  } else if (SET === 'meanrev') {
    for (const k of [2.0, 2.4, 2.8]) {
      for (const tp of [1.0, 1.5]) out.push(Z.meanRev({ k, tpR: tp, notionalPct: NOTIONAL, leverage: 1 }));
    }
  } else if (SET === 'pullback') {
    for (const tp of [1.5, 2.5, 3.5]) out.push(Z.pullbackTrend({ tpR: tp, notionalPct: NOTIONAL, leverage: 1 }));
  }
  return out;
}

const rows = configs().map(evaluate);
rows.sort((a, b) => (b.pos - a.pos) || (b.total - a.total));
console.log(`\nTF ${TF} · ${wins.length} windows of ${WINDOW_DAYS}d · ${rows.length} configs · set=${SET}\n`);
console.log('config'.padEnd(30) + 'total%'.padStart(9) + 'pos'.padStart(7) + 'worstDD%'.padStart(10) + 'avgSharpe'.padStart(11) + 'trades'.padStart(8) + '  per-window ret%');
console.log('-'.repeat(120));
for (const r of rows) {
  console.log(r.label.padEnd(30) + String(r.total).padStart(9) + `${r.pos}/${r.windows}`.padStart(7) +
    String(r.worstDD).padStart(10) + String(r.sharpe).padStart(11) + String(r.trades).padStart(8) +
    '  ' + r.rets.map((x) => x.toFixed(0)).join(' '));
}
