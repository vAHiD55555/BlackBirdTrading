'use strict';
/**
 * Strategy zoo for the research phase.
 * Each strategy exposes: name, warmup, features(d), signal(ctx, i) [, manage(ctx, i, open)]
 * `signal` returns [{ sym, dir: +1|-1 }] to open on the NEXT bar's open.
 */
const { sma, ema, rsi, atr, stdev, highest, lowest, roc } = require('./sim');

const SYMS = () => Object.keys;

// ---------------------------------------------------------------- 1. Donchian
function trendDonchian(p = {}) {
  const ch = p.ch || 20;          // breakout lookback
  const trend = p.trend || 200;   // regime filter EMA
  const useTrend = p.useTrend !== false;
  return {
    name: `donchian(${ch},${trend})`,
    warmup: 260,
    stopAtr: p.stopAtr || 2.0,
    tpAtr: p.tpAtr || 0,
    trailAtr: p.trailAtr || 3.0,
    allowShort: p.allowShort !== false,
    maxPositions: p.maxPositions || 3,
    sizeRiskPct: p.risk || 0.5,
    maxLeverage: p.leverage || 3,
    features(d) {
      return {
        atr: atr(d.h, d.l, d.c, 14),
        hh: highest(d.h, ch),
        ll: lowest(d.l, ch),
        ema: ema(d.c, trend),
        ema50: ema(d.c, 50),
      };
    },
    signal(ctx, i) {
      const out = [];
      for (const s of Object.keys(ctx.feats)) {
        const f = ctx.feats[s], d = ctx.data[s];
        if (!(f.atr[i] > 0) || !(f.hh[i - 1] > 0)) continue;
        const up = !useTrend || d.c[i] > f.ema[i];
        const dn = !useTrend || d.c[i] < f.ema[i];
        if (up && d.c[i] > f.hh[i - 1]) out.push({ sym: s, dir: 1 });
        else if (this.allowShort && dn && d.c[i] < f.ll[i - 1]) out.push({ sym: s, dir: -1 });
      }
      return out;
    },
  };
}

// ------------------------------------------------- 2. Trend pullback (v2 core)
function pullbackTrend(p = {}) {
  const fast = p.fast || 20, slow = p.slow || 50, base = p.base || 200;
  return {
    name: `pullback(${fast}/${slow}/${base})`,
    warmup: 260,
    stopAtr: p.stopAtr || 2.0,
    tpAtr: p.tpR || 2.5,
    trailAtr: 0,
    allowShort: p.allowShort !== false,
    maxPositions: p.maxPositions || 3,
    sizeRiskPct: p.risk || 0.5,
    maxLeverage: p.leverage || 3,
    features(d) {
      return {
        atr: atr(d.h, d.l, d.c, 14),
        ef: ema(d.c, fast), es: ema(d.c, slow), eb: ema(d.c, base),
        rs: rsi(d.c, 14),
      };
    },
    signal(ctx, i) {
      const out = [];
      for (const s of Object.keys(ctx.feats)) {
        const f = ctx.feats[s], d = ctx.data[s];
        if (!(f.atr[i] > 0) || !(f.eb[i] > 0)) continue;
        const r = f.rs[i], rPrev = f.rs[i - 1];
        const upTrend = f.ef[i] > f.es[i] && d.c[i] > f.eb[i];
        const dnTrend = f.ef[i] < f.es[i] && d.c[i] < f.eb[i];
        // pullback: price dips to/below the fast EMA, RSI cools, then turns back up
        const dipUp = d.l[i] <= f.ef[i] * 1.0005 && d.c[i] > f.ef[i] && r > 45 && r < 68 && r > rPrev;
        const dipDn = d.h[i] >= f.ef[i] * 0.9995 && d.c[i] < f.ef[i] && r < 55 && r > 32 && r < rPrev;
        if (upTrend && dipUp) out.push({ sym: s, dir: 1 });
        else if (this.allowShort && dnTrend && dipDn) out.push({ sym: s, dir: -1 });
      }
      return out;
    },
  };
}

// ------------------------------------------------------- 3. Mean reversion BB
function meanRev(p = {}) {
  const n = p.n || 20, k = p.k || 2.2;
  return {
    name: `meanrev(${n},${k})`,
    warmup: 260,
    stopAtr: p.stopAtr || 1.8,
    tpAtr: p.tpR || 1.5,
    trailAtr: 0,
    allowShort: p.allowShort !== false,
    maxPositions: p.maxPositions || 3,
    sizeRiskPct: p.risk || 0.4,
    maxLeverage: p.leverage || 2,
    features(d) {
      return {
        atr: atr(d.h, d.l, d.c, 14),
        mid: sma(d.c, n), sd: stdev(d.c, n),
        rs: rsi(d.c, 14),
        eb: ema(d.c, 200),
      };
    },
    signal(ctx, i) {
      const out = [];
      for (const s of Object.keys(ctx.feats)) {
        const f = ctx.feats[s], d = ctx.data[s];
        if (!(f.sd[i] > 0) || !(f.atr[i] > 0)) continue;
        const lo = f.mid[i] - k * f.sd[i], hi = f.mid[i] + k * f.sd[i];
        const uptrend = d.c[i] > f.eb[i];
        const downtrend = d.c[i] < f.eb[i];
        if (uptrend && d.c[i] < lo && f.rs[i] < 32) out.push({ sym: s, dir: 1 });
        else if (this.allowShort && downtrend && d.c[i] > hi && f.rs[i] > 68) out.push({ sym: s, dir: -1 });
      }
      return out;
    },
  };
}

// ------------------------------------------------- 4. Cross-sectional momentum
function xsMomentum(p = {}) {
  const look = p.look || 672;
  const skip = p.skip || 0;         // skip-period momentum (avoid 1-week reversal)
  const every = p.every || 96;
  const top = p.top || 2;
  const neutral = p.neutral !== false;
  const volW = p.volWeight !== false;
  const gate = p.gate || 'none';    // 'none' | 'btc' (longs need BTC uptrend) | 'btcAll'
  const tfPerDay = p.tfPerDay || 96;
  return {
    name: `xs-mom(${Math.round(look / tfPerDay)}d${skip ? '-skip' + Math.round(skip / tfPerDay) : ''},top${top}${neutral ? ',LS' : ''},reb${Math.round(every / tfPerDay)}d${volW ? ',volw' : ''}${gate !== 'none' ? ',' + gate : ''})`,
    warmup: look + skip + 60,
    stopAtr: p.stopAtr || 6.0, tpAtr: 0, trailAtr: 0,
    maxPositions: p.maxPositions || (neutral ? top * 2 : top),
    sizeRiskPct: p.risk || 0.9,
    notionalPct: p.notionalPct || 0,
    weightMode: volW,
    maxLeverage: p.leverage || 2,
    features(d) {
      const n = d.n;
      const r = new Float64Array(n).fill(NaN);
      for (let i = look + skip; i < n; i++) r[i] = (d.c[i - skip] / d.c[i - skip - look] - 1) * 100;
      return { atr: atr(d.h, d.l, d.c, 14), r, ema200: ema(d.c, 200), c: d.c };
    },
    _gateOk(ctx, i, dir) {
      if (gate === 'none') return true;
      const b = ctx.feats.BTCUSDT;
      if (!b || !(b.ema200[i] > 0)) return true;
      const up = b.c[i] > b.ema200[i];
      if (gate === 'btcAll') return up;
      return dir > 0 ? up : true;
    },
    target(ctx, i) {
      const rank = [];
      for (const s of Object.keys(ctx.feats)) {
        const f = ctx.feats[s];
        if (!isFinite(f.r[i]) || !(f.atr[i] > 0)) continue;
        rank.push({ sym: s, r: f.r[i], atrPct: f.atr[i] / ctx.data[s].c[i] });
      }
      rank.sort((a, b) => b.r - a.r);
      const picks = [];
      for (let k = 0; k < top && k < rank.length; k++) if (this._gateOk(ctx, i, 1)) picks.push({ sym: rank[k].sym, dir: 1, atrPct: rank[k].atrPct });
      if (neutral) {
        for (let k = 0; k < top && k < rank.length; k++) {
          const x = rank[rank.length - 1 - k];
          if (this._gateOk(ctx, i, -1)) picks.push({ sym: x.sym, dir: -1, atrPct: x.atrPct });
        }
      }
      if (volW && picks.length) {
        const inv = picks.map((x) => 1 / Math.max(x.atrPct, 1e-6));
        const tot = inv.reduce((a, b) => a + b, 0);
        picks.forEach((x, k) => { x.weight = inv[k] / tot; });
      }
      return picks;
    },
    manage(ctx, i, open) {
      if ((i - this.warmup) % every !== 0) return null;
      const want = this.target(ctx, i);
      const wantMap = new Map(want.map((w) => [w.sym, w.dir]));
      const close = [];
      for (const [sym, p] of open) if (wantMap.get(sym) !== p.dir) close.push({ sym, reason: 'rebalance' });
      return close;
    },
    signal(ctx, i) {
      if ((i - this.warmup) % every !== 0) return null;
      const want = this.target(ctx, i);
      const out = [];
      for (const w of want) {
        const cur = ctx.open ? ctx.open.get(w.sym) : null;
        if (cur && cur.dir === w.dir) continue;
        const a = ctx.feats[w.sym].atr[i];
        if (a > 0) out.push({ sym: w.sym, dir: w.dir, weight: w.weight });
      }
      return out;
    },
  };
}

// ---------------------------------------------- 5. Volume breakout with trail
function volBreakout(p = {}) {
  const ch = p.ch || 55;
  return {
    name: `volbreak(${ch})`,
    warmup: ch + 210,
    stopAtr: p.stopAtr || 2.2,
    tpAtr: 0,
    trailAtr: p.trailAtr || 4.0,
    allowShort: p.allowShort !== false,
    maxPositions: 3,
    sizeRiskPct: p.risk || 0.6,
    maxLeverage: 3,
    features(d) {
      return { atr: atr(d.h, d.l, d.c, 14), hh: highest(d.h, ch), ll: lowest(d.l, ch), vma: sma(d.v, 20) };
    },
    signal(ctx, i) {
      const out = [];
      for (const s of Object.keys(ctx.feats)) {
        const f = ctx.feats[s], d = ctx.data[s];
        if (!(f.atr[i] > 0) || !(f.vma[i] > 0)) continue;
        const volOk = d.v[i] > 1.4 * f.vma[i];
        if (!volOk) continue;
        if (d.c[i] > f.hh[i - 1]) out.push({ sym: s, dir: 1 });
        else if (this.allowShort && d.c[i] < f.ll[i - 1]) out.push({ sym: s, dir: -1 });
      }
      return out;
    },
  };
}

module.exports = { trendDonchian, pullbackTrend, meanRev, xsMomentum, volBreakout };
