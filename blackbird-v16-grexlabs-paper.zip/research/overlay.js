#!/usr/bin/env node
'use strict';
/**
 * Portfolio-level risk overlays on top of a raw daily return stream:
 *
 *   1. volatility targeting  — exposure ∝ target vol / realised vol (capped)
 *   2. drawdown throttle     — exposure steps down as the equity curve falls
 *   3. both
 *
 * Evaluated on two universes (the eight symbols used for tuning, and eight
 * symbols never used) so an overlay that only helps in-sample is obvious.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('./sim');
const Z = require('./strategies');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const TF = arg('tf', '1h');
const TFMS = { '15m': 900000, '1h': 3600000, '4h': 14400000 }[TF];
const BPD = 86400000 / TFMS;
const TARGET_VOL = Number(arg('vol', 0.45));   // annualised
const START = 5000;
const COSTS = { maker: 2, taker: 5, slip: 1.5 };

const UNIVERSE_A = 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'.split(',');
const UNIVERSE_B = 'DOTUSDT,BCHUSDT,ATOMUSDT,XLMUSDT,ETCUSDT,LINKUSDT,LTCUSDT,TRXUSDT'.split(',');

function committee(notional) {
  return [
    Z.xsMomentum({ look: Math.round(3 * BPD), every: Math.round(7 * BPD), top: 2, neutral: true, stopAtr: 6, gate: 'none', volWeight: false, notionalPct: notional, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(7 * BPD), every: Math.round(7 * BPD), top: 2, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: notional, leverage: 2, tfPerDay: BPD }),
    Z.xsMomentum({ look: Math.round(7 * BPD), skip: Math.round(1 * BPD), every: Math.round(7 * BPD), top: 3, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: notional, leverage: 2, tfPerDay: BPD }),
  ];
}

function blendRets(symbols) {
  const raw = Object.fromEntries(symbols.map((s) => [s, JSON.parse(fs.readFileSync(path.join(DIR, `${s}-${TF}.json`), 'utf8'))]));
  const n = Math.min(...symbols.map((s) => raw[s].length));
  const data = Object.fromEntries(symbols.map((s) => [s, S.prep(raw[s].slice(0, n))]));
  const fund = {};
  for (const s of symbols) { try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ } }
  const per = 100 / 3;
  const runs = committee(per).map((strat) => {
    const r = S.run({ data, strat, start: START, costs: COSTS, funding: fund });
    return r.equityCurve;
  });
  const L = Math.min(...runs.map((c) => c.length - 1));
  const rets = [];
  for (let i = 0; i < L; i++) {
    let x = 0;
    for (const c of runs) x += (c[i + 1] / c[i] - 1) / runs.length;
    rets.push(x);
  }
  return { rets, days: L, t0: raw[symbols[0]][0][0], tEnd: raw[symbols[0]][n - 1][0] };
}

function applyOverlay(rets, { vt, dd }) {
  const out = [];
  let eq = START, peak = START;
  const hist = [];
  for (let i = 0; i < rets.length; i++) {
    let scale = 1;
    if (vt) {
      const w = Math.min(60, hist.length);
      if (w >= 20) {
        const m = hist.slice(-w).reduce((a, b) => a + b, 0) / w;
        const v = Math.sqrt(hist.slice(-w).reduce((a, b) => a + (b - m) ** 2, 0) / w) * Math.sqrt(365);
        scale *= Math.max(0.3, Math.min(1.6, TARGET_VOL / Math.max(v, 1e-6)));
      }
    }
    if (dd) {
      const cur = 1 - eq / peak;
      const f = cur < 0.08 ? 1 : cur < 0.15 ? 0.6 : cur < 0.22 ? 0.35 : 0.2;
      scale *= f;
    }
    const r = rets[i] * scale;
    eq *= 1 + r;
    peak = Math.max(peak, eq);
    hist.push(r);
    out.push(r);
  }
  return out;
}

function curveOf(rets) {
  const c = [START];
  for (const r of rets) c.push(c[c.length - 1] * (1 + r));
  return c;
}

function report(name, rets, t0, tEnd, step) {
  const m = S.metrics(curveOf(rets), START);
  // windows
  const per = Math.max(1, Math.floor(rets.length / 6));
  const wins = [];
  for (let i = 0; i + per <= rets.length; i += per) {
    let eq = START;
    for (let k = i; k < i + per; k++) eq *= 1 + rets[k];
    wins.push((eq / START - 1) * 100);
  }
  return { name, ...m, wins };
}

const f = (v, w = 8, d = 1) => String(typeof v === 'number' ? v.toFixed(d) : v).padStart(w);
for (const [label, uni] of [['TUNING UNIVERSE', UNIVERSE_A], ['UNSEEN UNIVERSE', UNIVERSE_B]]) {
  const { rets } = blendRets(uni);
  const rows = [
    report('raw', rets),
    report('vol-target', applyOverlay(rets, { vt: true })),
    report('dd-throttle', applyOverlay(rets, { dd: true })),
    report('both', applyOverlay(rets, { vt: true, dd: true })),
  ];
  console.log(`\n=== ${label} (${TF}) ===`);
  console.log('overlay'.padEnd(14) + 'total%'.padStart(9) + 'cagr%'.padStart(8) + 'maxDD%'.padStart(8) + 'sharpe'.padStart(8) + 'sortino'.padStart(9) + 'calmar'.padStart(8) + '  windows%');
  for (const r of rows) {
    console.log(r.name.padEnd(14) + f(r.totalReturnPct) + f(r.cagrPct) + f(r.maxDrawdownPct) + f(r.sharpe, 8, 2) + f(r.sortino, 9, 2) + f(r.calmar, 8, 2) + '  ' + r.wins.map((x) => x.toFixed(0)).join(' '));
  }
}
