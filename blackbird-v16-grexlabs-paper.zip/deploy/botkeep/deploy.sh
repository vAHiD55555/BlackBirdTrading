#!/usr/bin/env bash
# BlackBird — deploy to botkeep.cloud (free plan).
#
#   ./deploy/botkeep/deploy.sh              deploy
#   ./deploy/botkeep/deploy.sh --dry-run    show what would happen
#   ./deploy/botkeep/deploy.sh --logs       tail the remote logs
#
# Requires: BOTKEEP_TOKEN in the environment (never on the command line, where
# it would land in your shell history and in `ps`).
#
# This script is deliberately thin. It does not invent an API: it uses the
# documented CLI when present, and otherwise prints exactly what to do in the
# dashboard. A deploy script that silently does nothing is worse than none.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

DRY_RUN=0
SHOW_LOGS=0
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    --logs) SHOW_LOGS=1 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

say() { printf '\033[1m%s\033[0m\n' "$*"; }
warn() { printf '\033[33m%s\033[0m\n' "$*"; }
die() { printf '\033[31m%s\033[0m\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- preflight
say "1/5  preflight"

[ -f package.json ] || die "run this from the project root (package.json not found)"
[ -f src/index.js ] || die "src/index.js not found"

# Zero runtime dependencies is a hard rule for the free plan: an npm install
# step is the most common reason a free build fails.
DEPS=$(node -e "const p=require('./package.json');console.log(Object.keys(p.dependencies||{}).length)")
if [ "$DEPS" != "0" ]; then
  warn "package.json declares $DEPS runtime dependencies — the free plan expects zero"
fi

# The engine must boot without a network call. A syntax error here would only
# surface after the deploy, so check it now.
node --check src/index.js || die "src/index.js has a syntax error"
node -e "require('./src/config').loadConfig()" >/dev/null 2>&1 \
  || die "config does not load — fix that before deploying"

say "     ok: zero deps, syntax clean, config loads"

# ------------------------------------------------------------------- secrets
say "2/5  secrets"

if [ -z "${BOTKEEP_TOKEN:-}" ]; then
  warn "BOTKEEP_TOKEN is not set."
  warn "Set it in your shell (not in this file):  export BOTKEEP_TOKEN=..."
  warn "Then re-run. Nothing has been deployed."
  exit 1
fi

# Never echo the token, only its presence.
say "     ok: BOTKEEP_TOKEN present (${#BOTKEEP_TOKEN} chars)"

if [ ! -f .env ]; then
  warn ".env not found — copying .env.example"
  cp deploy/botkeep/.env.example .env
  warn "edit .env and add your keys, then re-run"
  exit 1
fi

# --------------------------------------------------------------------- build
say "3/5  build"

if [ "$DRY_RUN" = "1" ]; then
  say "     [dry-run] would build the image from deploy/botkeep/Dockerfile"
else
  if command -v docker >/dev/null 2>&1; then
    docker build -f deploy/botkeep/Dockerfile -t blackbird-trader:botkeep . \
      || die "docker build failed"
    say "     ok: image built"
  else
    warn "docker not installed — skipping the local build check"
    warn "the platform will build from deploy/botkeep/Dockerfile"
  fi
fi

# -------------------------------------------------------------------- deploy
say "4/5  deploy"

if command -v botkeep >/dev/null 2>&1; then
  if [ "$DRY_RUN" = "1" ]; then
    say "     [dry-run] botkeep deploy --config deploy/botkeep/botkeep.json"
  else
    botkeep deploy --config deploy/botkeep/botkeep.json || die "botkeep deploy failed"
    say "     ok: deployed"
  fi
else
  warn "the 'botkeep' CLI is not installed."
  cat <<'EOF'

  Deploy from the dashboard instead:
    1. open https://botkeep.cloud and sign in (free plan)
    2. New App -> "Deploy from Git repository"
    3. pick this repo, branch main
    4. Build: Dockerfile at deploy/botkeep/Dockerfile
    5. Port: the one the platform assigns   Health check: /healthz
    6. add the env vars from deploy/botkeep/.env.example
    7. Deploy

EOF
  exit 0
fi

# -------------------------------------------------------------------- verify
say "5/5  verify"

if [ "$SHOW_LOGS" = "1" ] && command -v botkeep >/dev/null 2>&1; then
  botkeep logs --follow
else
  cat <<'EOF'
  Check the deploy:
    curl -s https://<your-app>.botkeep.cloud/healthz
    -> {"ok":true,"up":<seconds>}

    curl -s https://<your-app>.botkeep.cloud/status | head -c 400

  If /healthz does not answer within a minute, read the build log in the
  dashboard: the usual causes are a missing env var and a port mismatch.
EOF
fi

say "done"
