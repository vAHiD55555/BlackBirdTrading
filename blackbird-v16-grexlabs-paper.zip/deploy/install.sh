#!/usr/bin/env bash
# BlackBird Trader — one-shot installer for a fresh Debian/Ubuntu server.
#
#   sudo ./deploy/install.sh
#
# What it does, in order:
#   1. checks Node >= 18 (installs Node 20 from NodeSource if missing)
#   2. creates the `blackbird` system user and the data directory
#   3. copies the app to /opt/blackbird
#   4. writes /etc/blackbird/blackbird.env from .env.example (no secrets)
#   5. installs and starts the systemd unit
#   6. verifies the dashboard actually answers
#
# It is idempotent: running it twice is safe.
#
# It does NOT open a firewall port for you — see DEPLOY.md step 6.

set -euo pipefail

APP_DIR=/opt/blackbird
DATA_DIR=/var/lib/blackbird
ENV_DIR=/etc/blackbird
ENV_FILE="$ENV_DIR/blackbird.env"
SERVICE=blackbird
PORT="${PORT:?set PORT to the free port this host should expose, e.g. PORT=3000 sudo -E bash deploy/install.sh}"

say()  { printf '\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '\033[32m  ✓ %s\033[0m\n' "$*"; }
warn() { printf '\033[33m  ! %s\033[0m\n' "$*"; }
die()  { printf '\033[31m  ✗ %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" = "0" ] || die "run with sudo"

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[ -f "$SRC/src/index.js" ] || die "src/index.js not found — run this from the project root"

# ---------------------------------------------------------------- 1. node
say "1/6  Node.js"
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
else
  NODE_MAJOR=0
fi

if [ "$NODE_MAJOR" -lt 18 ]; then
  warn "Node ${NODE_MAJOR:-none} found; installing Node 20 from NodeSource"
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq
    apt-get install -y -qq curl ca-certificates gnupg >/dev/null
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null
    apt-get install -y -qq nodejs >/dev/null
  else
    die "no apt-get — install Node >= 18 manually, then re-run"
  fi
fi
ok "node $(node -v)"

# ---------------------------------------------------------------- 2. user
say "2/6  system user and directories"
if ! id -u blackbird >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin blackbird
  ok "created user blackbird"
else
  ok "user blackbird exists"
fi
mkdir -p "$APP_DIR" "$DATA_DIR" "$ENV_DIR"
chown -R blackbird:blackbird "$DATA_DIR"
chmod 750 "$DATA_DIR"

# ---------------------------------------------------------------- 3. files
say "3/6  application files"
# Copy the tree but never the runtime data or a local .env with secrets.
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude 'data/' --exclude 'reports/' --exclude '.env' \
    --exclude 'node_modules/' --exclude '*.log' \
    "$SRC"/ "$APP_DIR"/
else
  tar -C "$SRC" --exclude=./data --exclude=./reports --exclude=./.env \
      --exclude=./node_modules --exclude='*.log' -cf - . | tar -C "$APP_DIR" -xf -
fi
chown -R root:root "$APP_DIR"
chmod -R a+rX "$APP_DIR"
ok "installed to $APP_DIR"

# ---------------------------------------------------------------- 4. env
say "4/6  environment file"
if [ -f "$ENV_FILE" ]; then
  ok "$ENV_FILE already exists — left untouched"
else
  cat > "$ENV_FILE" <<EOF
# BlackBird Trader — runtime configuration
# Read by systemd. Keep this file 0640 root:blackbird.
# NEVER commit it. There are no real secrets in it by default.

NODE_ENV=production
PORT=$PORT
DATA_DIR=$DATA_DIR
MODE=paper
EXCHANGE=binance
SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT
LOG_LEVEL=info

# Dashboard control routes. Leave empty for a read-only panel.
# Generate one with:  openssl rand -hex 24
ADMIN_TOKEN=

# --- optional: LLM layer (off by default) ---
JEV_ENABLED=false
JEV_PROVIDER=openai
JEV_MODEL=gpt-4o-mini
# JEV_API_KEY=

# --- optional: notifications ---
TELEGRAM_ENABLED=false
# TELEGRAM_BOT_TOKEN=
# TELEGRAM_REPORT_CHAT_ID=
EOF
  chown root:blackbird "$ENV_FILE"
  chmod 640 "$ENV_FILE"
  ok "wrote $ENV_FILE"
fi

# ---------------------------------------------------------------- 5. systemd
say "5/6  systemd unit"
install -m 644 "$SRC/deploy/blackbird.service" "/etc/systemd/system/$SERVICE.service"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1 || true
systemctl restart "$SERVICE"
ok "service installed and started"

# ---------------------------------------------------------------- 6. verify
say "6/6  verification"
for i in $(seq 1 30); do
  if curl -fsS -m 2 "http://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then
    ok "/healthz answers on port $PORT"
    break
  fi
  if [ "$i" = "30" ]; then
    warn "the service did not answer within 30s"
    echo
    echo "  Look here:"
    echo "    systemctl status $SERVICE --no-pager -l"
    echo "    journalctl -u $SERVICE -n 80 --no-pager"
    echo
    exit 1
  fi
  sleep 1
done

echo
curl -s "http://127.0.0.1:$PORT/readyz" | head -c 400 || true
echo
echo
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
say "done"
echo "  dashboard:  http://${IP:-<server-ip>}:$PORT/"
echo "  liveness:   http://${IP:-<server-ip>}:$PORT/healthz"
echo "  readiness:  http://${IP:-<server-ip>}:$PORT/readyz"
echo
echo "  If it is not reachable from outside, open the port:"
echo "    ufw allow $PORT/tcp        # or your cloud provider's firewall"
