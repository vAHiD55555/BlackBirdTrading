# استقرار روی Botkeep (رایگان)

مشخصات پلن Standard Free (طبق سایت رسمی، هنگام نگارش این راهنما):

| مورد | مقدار |
|---|---|
| RAM | ۵۱۲ مگابایت |
| CPU | ۵۰٪ (نیم هسته) |
| دیسک | ۱ گیگابایت |
| اجرا | ۲۴/۷ بدون تایمر تجدید |
| آپلود | GitHub یا ZIP |
| دستور شروع | `npm start` |

این گزینه برای اجرای بلندمدت راحت‌تر از KataBump است، چون تجدید دستی ندارد.

---

## گام ۱ — آماده‌سازی مخزن/فایل

دو راه دارید:

**الف) GitHub (توصیه‌شده)**

```bash
cd blackbird-trader
git init && git add -A
git commit -m "BlackBird Trader v1.0"
git remote add origin git@github.com:<user>/blackbird-trader.git
git push -u origin main
```

**ب) ZIP** — همان `dist/blackbird-trader.zip`.

## گام ۲ — ساخت Workload

1. وارد `botkeep.cloud` شوید → **Start free**.
2. **Create** → نوع: Application / Bot → Runtime: **Node.js 20+**.
3. منبع: GitHub (repo + branch) یا آپلود ZIP.
4. **Start command**: `npm start`
5. منابع: همان پلن رایگان (۵۱۲MB) کافی است.

## گام ۳ — Secrets

در بخش Environment این‌ها را تعریف کنید (مقادیر محرمانه جدا از کد ذخیره می‌شوند):

```
MODE=paper
EXCHANGE=binance
WITNESS_EXCHANGE=bybit
SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT
BB_INTERVAL=5m
START_EQUITY=5000
REPORT_INTERVAL_MS=21600000
# BB_PORT=<port assigned by the host> (usually injected as PORT or SERVER_PORT)
```

## گام ۴ — اجرا و پایش

- **Start** را بزنید؛ خروجی زنده (Live output) را ببینید.
- `http://<your-app>:<PORT>/api/public/summary` وضعیت عمومی (فقط‌خواندنی). وضعیت کامل `/ops/status` است و توکن مدیر می‌خواهد.
- `/ops/report/latest.md` آخرین گزارش (نیازمند توکن مدیر).

> پورت ۸۷۸۷ را خود برنامه باز می‌کند. اگر پلتفرم `PORT` تزریق می‌کند و
> می‌خواهید از آن استفاده شود: `BB_PORT=$PORT` را ست نکنید — برنامه عمداً
> فقط `BB_PORT` را می‌خواند تا هرگز پورت پنل را اشغال نکند.

## گام ۵ — پایداری

- برنامه در برابر ری‌استارت مقاوم است: `data/state.json` و زنجیره‌ی هش
  `data/journal.jsonl` دوباره خوانده می‌شوند.
- اگر خواستید هر بار از صفر شروع شود، پوشه‌ی `data` را پاک کنید.
- برای بکاپ: پوشه‌های `data/` و `reports/` را دوره‌ای دانلود کنید.

## تفاوت با KataBump

| | KataBump | Botkeep |
|---|---|---|
| تجدید دستی | هر ۴ روز | ندارد |
| RAM | ۳۰۸MB | ۵۱۲MB |
| دیسک | ۷۱۶MB | ۱GB |
| مناسب برای | تست سریع | اجرای مداوم |
