> ## ⚡ خلاصه در ۴ خط (برای همین الان) — نسخه ۳ «Orbital»
>
> 1. فایل **`blackbird-trader.zip`** را در پنل آپلود و Extract کنید (باید `package.json` و `src` مستقیم در `/home/container` باشند).
> 2. نوع سرور: **Node.js** — نسخه **20** یا **22**.
> 3. **فایل اجرایی / Main file: `src/index.js`**
>    ⚠️ هرگز `package.json` را به‌عنوان فایل اجرایی انتخاب نکنید — Node سعی می‌کند آن را به‌عنوان کد اجرا کند و بلافاصله کرش می‌کند.
>    (اگر پنل فقط فایل‌های ریشه را نشان می‌دهد، `index.js` را انتخاب کنید — همان کار را می‌کند.)
> 4. Start بزنید. همین. تنظیمات از قبل در `config.json` آماده است و هیچ متغیر محیطی لازم نیست.
>
> **در لاگ چه می‌بینید:** ابتدا `bootstrapped 420 bars` برای هر ۸ نماد، سپس یک `rebalance complete {"targets":N,"opened":M}` — یعنی کتاب اولیه ساخته شد. بعد از آن هر ساعت یک heartbeat و هر ۶ ساعت یک گزارش در `reports/latest.md`.
> اگر کمتر از ۱۰ دقیقه بعد از Start، پوزیشن‌ها باز نشدند، `doctor.js` را اجرا کنید.
>
> اگر پنل به‌جای فایل، «دستور اجرا» می‌خواهد: `npm start`

# استقرار روی KataBump (رایگان)

مشخصات پلن رایگان (طبق مستندات رسمی، هنگام نگارش این راهنما):

| مورد | مقدار |
|---|---|
| RAM | ۳۰۸ مگابایت |
| دیسک | ۷۱۶ مگابایت |
| CPU | ۲۵٪ |
| تجدید | هر **۴ روز** (فقط در ۲ روز آخر قابل تمدید) |
| زبان | Node.js و Python |
| آپلود | پنل وب (ZIP) یا SFTP |
| مسیر کار | `/home/container` |

BlackBird بدون هیچ وابستگی npm است، پس `npm install` عملاً کاری نمی‌کند و
مصرف حافظه‌اش حدود ۶۰–۹۰ مگابایت است — راحت جا می‌شود.

---

## گام ۱ — ساخت بسته

روی دستگاه خودتان:

```bash
cd blackbird-trader
zip -r blackbird-trader.zip . -x "data/*" -x "reports/*" -x ".env" -x "dist/*"
```

یا از فایل آماده‌ی `dist/blackbird-trader.zip` استفاده کنید.

## گام ۲ — ساخت سرور

1. وارد `dashboard.katabump.com` شوید و یک سرور بسازید.
2. نوع سرور: **Node.js**، نسخه: **20** یا بالاتر.
3. فایل اجرا (Startup / Main file): `src/index.js`
4. در تب **Files** فایل ZIP را آپلود و extract کنید (یا با SFTP در
   `/home/container` بریزید).

> فایل‌ها باید مستقیم در `/home/container` باشند؛ یعنی `package.json` و پوشه‌ی
> `src` کنار هم، نه داخل یک پوشه‌ی اضافه.

## گام ۳ — متغیرهای محیطی

یک فایل `.env` در ریشه بسازید (یا از تب Environment استفاده کنید):

```env
MODE=paper
EXCHANGE=binance
WITNESS_EXCHANGE=bybit
SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT
BB_INTERVAL=5m
START_EQUITY=5000
REPORT_INTERVAL_MS=21600000
# BB_PORT=<port assigned by the host> (usually injected as PORT or SERVER_PORT)
```

اگر پورت را اشغال نکنید هم برنامه کار می‌کند؛ پنل وضعیت اختیاری است.

## گام ۴ — اجرا

دکمه‌ی Start را بزنید و کنسول را ببینید. خروجی سالم چنین است:

```
INFO [engine] BlackBird booting {"mode":"paper","node":"v20.x"}
INFO [BTCUSDT] bootstrapped 300 bars
INFO [jev] JEV prewarmed {"symbols":4}
INFO [engine] engine running
```

## گام ۵ — بررسی خروجی

- گزارش‌ها: `reports/latest.md` (از File Manager دانلود کنید)
- لاگ‌ها: `data/logs/engine-YYYY-MM-DD.jsonl`
- وضعیت: `data/state.json`

## نکات مهم

- **تمدید را فراموش نکنید**: هر ۴ روز. اگر انجام نشود سرور معلق و بعد از یک
  روز پاک می‌شود. یک یادآور در گوشی بگذارید.
- خروجی کنسول در پنل محدود است؛ برای تاریخچه‌ی کامل به فایل‌های JSONL تکیه کنید.
- اگر سرور به‌دلیل مصرف حافظه ری‌استارت شد، برنامه با `data/state.json` ادامه
  می‌دهد (پوزیشن‌های باز paper بازیابی نمی‌شوند — مستند شده است).
- **هیچ‌وقت** کلید API واقعی را در این پلن رایگان نگذارید؛ این مرحله فقط paper است.
