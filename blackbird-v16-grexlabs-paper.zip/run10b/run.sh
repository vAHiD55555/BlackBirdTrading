#!/usr/bin/env bash
cd /workspace/work/bb_strategist_v2
export DATA_DIR=/workspace/work/bb_strategist_v2/run10b/data
export STRATEGIST_ENABLED=true
export STRATEGIST_CRISIS_AUTHORITY=false
export EXCHANGE=hyperliquid
export PORT=61257
export BB_PUBLIC_URL=http://203.0.113.10:61257
export MODE=paper
node src/index.js --exit-after=660
