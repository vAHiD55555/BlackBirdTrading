'use strict';
/**
 * BlackBird — پل ارتباطی با کارگر میانی.
 *
 * قاعده‌ی طراحی: این کلاس هرگز خطا پرتاب نمی‌کند و هرگز بوت را متوقف نمی‌کند.
 * اگر کارگر جواب نداد، «هیچ» برمی‌گرداند و صداکننده مسیر قبلی خودش را می‌رود.
 *
 * بعد از هر خطا، کارگر برای مدتی «افتاده» فرض می‌شود تا در هر چرخه دوباره
 * تلاش نکنیم؛ هر خطای پیاپی این مدت را بیشتر می‌کند تا سقف.
 */

const DEFAULTS = {
  enabled: null, // null = خودکار: اگر baseUrl ست شده باشد روشن است
  baseUrl: '',
  tokenEnv: 'BB_WORKER_TOKEN',
  useForModel: true,
  useForData: true,
  timeoutMs: 1500,
  cooldownMs: 60000,
  maxCooldownMs: 300000,
};

class WorkerBridge {
  constructor({ cfg = {}, log, env, fetchImpl } = {}) {
    const w = { ...DEFAULTS, ...((cfg && cfg.worker) || {}) };
    this.log = log || { info() {}, warn() {}, debug() {} };
    this.env = env || process.env;
    this._fetch = fetchImpl || (typeof fetch === 'function' ? fetch : null);

    this.baseUrl = String(w.baseUrl || '').replace(/\/+$/, '');
    // null یعنی «تصمیم با وجود نشانی»: فقط ست‌کردن نشانی، کارگر را روشن می‌کند.
    const on = w.enabled === null || w.enabled === undefined ? Boolean(this.baseUrl) : Boolean(w.enabled);
    this.enabled = Boolean(on && this.baseUrl && this._fetch);
    this.llmEnabled = Boolean(this.enabled && w.useForModel);
    this.dataEnabled = Boolean(this.enabled && w.useForData);
    this.timeoutMs = Math.max(200, Number(w.timeoutMs) || DEFAULTS.timeoutMs);
    this.cooldownMs = Math.max(1000, Number(w.cooldownMs) || DEFAULTS.cooldownMs);
    this.maxCooldownMs = Math.max(this.cooldownMs, Number(w.maxCooldownMs) || DEFAULTS.maxCooldownMs);

    const tokenName = w.tokenEnv || DEFAULTS.tokenEnv;
    this.token = typeof this.env[tokenName] === 'string' ? this.env[tokenName].trim() : '';

    this._downUntil = 0;
    this._failures = 0;
    this.stats = {
      enabled: this.enabled,
      requests: 0,
      ok: 0,
      failed: 0,
      modelCalls: 0,
      modelHits: 0,
      dataCalls: 0,
      dataHits: 0,
      lastError: null,
      lastOkAt: 0,
      downUntil: 0,
    };
  }

  /** آماده به کار است؟ (روشن، نشانی دارد، و در دوره‌ی افتادن نیست) */
  get available() {
    return Boolean(this.enabled && Date.now() >= this._downUntil);
  }

  _headers() {
    const h = { accept: 'application/json' };
    if (this.token) h['x-bb-token'] = this.token;
    return h;
  }

  async _request(path, init = {}) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(new Error('worker timeout')), this.timeoutMs);
    try {
      this.stats.requests++;
      const res = await this._fetch(`${this.baseUrl}${path}`, {
        ...init,
        headers: { ...this._headers(), ...(init.headers || {}) },
        signal: ctl.signal,
      });
      if (!res.ok) throw new Error(`worker HTTP ${res.status}`);
      const body = await res.json();
      if (!body || body.ok === false) throw new Error((body && body.error) || 'worker returned not-ok');
      this._succeed();
      return body;
    } catch (e) {
      this._fail(e);
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  _succeed() {
    this.stats.ok++;
    this.stats.lastOkAt = Date.now();
    this._failures = 0;
    this._downUntil = 0;
    this.stats.downUntil = 0;
  }

  _fail(e) {
    this.stats.failed++;
    this.stats.lastError = e && e.message ? e.message : String(e);
    this._failures++;
    const wait = Math.min(this.maxCooldownMs, this.cooldownMs * Math.min(this._failures, 5));
    this._downUntil = Date.now() + wait;
    this.stats.downUntil = this._downUntil;
    this.log.debug(`worker unavailable for ${wait}ms: ${this.stats.lastError}`);
  }

  /**
   * یک پاسخ مدل از درگاه لبه. در صورت هر شکستی null برمی‌گرداند.
   * @returns {Promise<string|null>}
   */
  async complete({ messages, model, provider, cache = true } = {}) {
    if (!this.llmEnabled || !this.available) return null;
    if (!Array.isArray(messages) || !messages.length) return null;
    this.stats.modelCalls++;
    const body = await this._request('/v1/llm', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ messages, model, provider, cache, temperature: 0 }),
    });
    if (!body || typeof body.text !== 'string' || !body.text.trim()) return null;
    this.stats.modelHits++;
    return body.text;
  }

  /**
   * آخرین قیمت چند نماد از کش لبه.
   * @returns {Promise<Record<string,{bid:number,ask:number,last:number,ts:number}>|null>}
   */
  async snapshot(symbols) {
    if (!this.dataEnabled || !this.available) return null;
    const list = (Array.isArray(symbols) ? symbols : [])
      .map((s) => String(s).trim().toUpperCase())
      .filter(Boolean)
      .slice(0, 20);
    if (!list.length) return null;
    this.stats.dataCalls++;
    const body = await this._request(`/v1/snapshot?symbols=${encodeURIComponent(list.join(','))}`, { method: 'GET' });
    if (!body || !body.symbols) return null;
    const out = {};
    for (const [sym, q] of Object.entries(body.symbols)) {
      if (!q || q.error) continue;
      const bid = Number(q.bid);
      const ask = Number(q.ask);
      if (!(bid > 0) || !(ask > 0)) continue;
      out[sym] = { bid, ask, last: Number(q.last) || (bid + ask) / 2, ts: Number(q.ts) || Date.now() };
    }
    if (!Object.keys(out).length) return null;
    this.stats.dataHits++;
    return out;
  }

  status() {
    return {
      ...this.stats,
      available: this.available,
      llmEnabled: this.llmEnabled,
      dataEnabled: this.dataEnabled,
      hasToken: Boolean(this.token),
    };
  }
}

module.exports = { WorkerBridge, DEFAULTS };
