'use strict';
/**
 * BlackBird — providerی که اول از درگاه لبه می‌پرسد، بعد مستقیم.
 *
 * چرا این ترتیب: درگاه لبه پاسخ تکراری را کش می‌کند و سهمیه‌ی مدل را کم‌مصرف
 * می‌کند. اما اگر کارگر خاموش، کند یا خطادار بود، همان provider اصلی بی‌درنگ
 * جواب می‌دهد. هیچ‌وقت هر دو مسیر هم‌زمان صدا زده نمی‌شوند.
 */

class WorkerFirstProvider {
  /**
   * @param {object} opts
   * @param {object} opts.inner   provider اصلی (مستقیم به سرویس مدل)
   * @param {object} opts.bridge  نمونه‌ی WorkerBridge
   */
  constructor({ inner, bridge } = {}) {
    if (!inner) throw new Error('WorkerFirstProvider needs an inner provider');
    this.inner = inner;
    this.bridge = bridge || null;
    this.name = (inner && inner.name) || 'worker-first';
    this.model = inner && inner.model;
    this.lastVia = null;
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    if (this.bridge && this.bridge.llmEnabled) {
      const viaEdge = await this.bridge.complete({ messages, model: model || this.model });
      if (viaEdge) {
        this.lastVia = 'edge';
        return viaEdge;
      }
    }
    this.lastVia = 'direct';
    return this.inner.complete({ messages, model, timeoutMs, signal });
  }
}

module.exports = { WorkerFirstProvider };
