'use strict';
/**
 * AngryBird nominal-size limit — deterministic, pure, no model in the loop.
 *
 * The scenario allows up to `maxTradeNotionalUsd` ($25 of $100) per trade, but
 * only while every condition in `fullSizeRequires` holds. Otherwise the cap
 * falls to `reducedTradeNotionalUsd`. A halted book, or an open red card, gets
 * a cap of zero.
 *
 * ctx = { equity, startEquity, drawdownPct, dailyPnlPct, lossStreak,
 *         yellowCards, redCard, halted }
 * Percent inputs are in percent units (5 means 5%).
 */
function angryNotionalCap(angryCfg, ctx) {
  const reasons = [];
  if (!angryCfg || !angryCfg.enabled) return { cap: Infinity, full: true, reasons };
  const hard = Number(angryCfg.maxTradeNotionalUsd);
  const reduced = Math.min(Number(angryCfg.reducedTradeNotionalUsd), hard);
  if (!(hard > 0)) return { cap: 0, full: false, reasons: ['misconfigured_cap'] };
  if (ctx.halted) return { cap: 0, full: false, reasons: ['halted'] };
  if (ctx.redCard) return { cap: 0, full: false, reasons: ['red_card'] };

  const req = angryCfg.fullSizeRequires || {};
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : NaN);
  const equityPct = (num(ctx.equity) / num(ctx.startEquity)) * 100;

  if (!(equityPct >= req.minEquityPctOfStart)) reasons.push(`equity_below_${req.minEquityPctOfStart}pct_of_start`);
  if (!(num(ctx.drawdownPct) <= req.maxDrawdownPct)) reasons.push(`drawdown_above_${req.maxDrawdownPct}pct`);
  // A daily loss deeper than the allowance (dailyPnlPct is negative when losing).
  if (!(num(ctx.dailyPnlPct) >= -req.maxDailyLossPct)) reasons.push(`daily_loss_above_${req.maxDailyLossPct}pct`);
  if (!(num(ctx.lossStreak) <= req.maxConsecutiveLosses)) reasons.push('loss_streak');
  if (req.noYellowCard && Number(ctx.yellowCards) > 0) reasons.push('yellow_card_active');

  // NaN anywhere makes the comparisons above false, so unknown inputs fail closed.
  const full = reasons.length === 0;
  return { cap: full ? hard : reduced, full, reasons };
}

/**
 * AngryBird activation gate — "muddy water": the market must be turbulent,
 * most participants must be leaving, and the evidence must already be turning
 * positive. Pure and deterministic; no model in the loop.
 *
 * ctx (all optional; anything missing fails CLOSED):
 *   atrPercentile   0..1   how volatile the tape is versus its own history
 *   exodusBreadth   0..1   fraction of the universe down over the window
 *   recoveryScore   0..1   fraction already turning back up
 *   spreadOk        bool   every book inside the spread limit
 *   depthOk         bool   every book above the depth floor
 */
function angryActivation(actCfg, ctx = {}) {
  if (!actCfg || !actCfg.enabled) return { active: true, score: null, reasons: ['gate_disabled'] };
  // Number(null) is 0, which would silently read a dead feed as a calm market.
  // Treat null/undefined/'' as "not measured" so the gate fails closed.
  const num = (v) => (v === null || v === undefined || v === '' ? NaN : Number.isFinite(Number(v)) ? Number(v) : NaN);
  const atr = num(ctx.atrPercentile);
  const exodus = num(ctx.exodusBreadth);
  const recovery = num(ctx.recoveryScore);
  if (Number.isNaN(atr) || Number.isNaN(exodus) || Number.isNaN(recovery)) {
    // Unknown conditions are not permission to trade someone's last $100.
    return { active: false, score: null, reasons: ['missing_context'] };
  }

  const reasons = [];
  if (!(atr >= num(actCfg.minAtrPercentile))) reasons.push(`calm_market(${atr.toFixed(2)})`);
  if (!(exodus >= num(actCfg.minExodusBreadth))) reasons.push(`no_capitulation(${exodus.toFixed(2)})`);
  if (!(recovery >= num(actCfg.minRecoveryScore))) reasons.push(`no_recovery_evidence(${recovery.toFixed(2)})`);
  if (ctx.gateEnabled !== false && ctx.spreadOk === false) reasons.push('spread_too_wide');
  if (ctx.gateEnabled !== false && ctx.depthOk === false) reasons.push('book_too_thin');

  const score = Math.round(
    (Math.min(1, Math.max(0, atr)) * 0.35 +
      Math.min(1, Math.max(0, exodus)) * 0.35 +
      Math.min(1, Math.max(0, recovery)) * 0.3) * 100,
  ) / 100;
  return { active: reasons.length === 0, score, reasons };
}

/**
 * AngryBird lockout after repeated losses.
 *
 * Two consecutive losses end the episode. The lock does NOT lift because time
 * passed and it does not lift on a lucky tick: it lifts only once the market
 * profile has changed — the muddy-water window closed and a new one opened —
 * and a cooling period has elapsed. That is what "until the profile improves"
 * means operationally, and it is measurable.
 *
 * ctx = { lossStreak, now, lock: { at, losses, gateClosedSince } | null }
 */
function angryLockout(lockCfg, ctx = {}) {
  if (!lockCfg || !lockCfg.enabled) return { locked: false, reasons: [] };
  const max = Number(lockCfg.maxConsecutiveLosses) || 2;
  const streak = Number(ctx.lossStreak) || 0;
  const rec = ctx.lock || null;
  if (!rec) {
    return streak >= max
      ? { locked: true, reasons: [`${streak}_consecutive_losses`], unlockAt: null }
      : { locked: false, reasons: [] };
  }

  const minLockMs = Number(lockCfg.minLockMs) || 0;
  const elapsed = Math.max(0, Number(ctx.now || 0) - Number(rec.at || 0));
  // The loss note is context for the operator; only the blockers keep the lock.
  const blockers = [];
  if (elapsed < minLockMs) {
    blockers.push(`cooling(${Math.round(elapsed / 60000)}m/${Math.round(minLockMs / 60000)}m)`);
  }
  if (lockCfg.requireFreshSetup !== false && !rec.gateClosedSince) {
    blockers.push('no_fresh_setup');
  }
  return {
    locked: blockers.length > 0,
    reasons: [`${rec.losses || max}_consecutive_losses`, ...blockers],
    unlockAt: Number(rec.at || 0) + minLockMs || null,
  };
}

module.exports = { angryNotionalCap, angryActivation, angryLockout };
