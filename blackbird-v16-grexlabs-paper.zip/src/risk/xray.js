'use strict';

/**
 * Portfolio risk x-ray. This is deliberately descriptive: it never changes
 * position sizes or risk state. It makes long/short, gross/net and
 * concentration visible so a paper/live comparison cannot hide exposure.
 */
function riskXray(portfolio, equity) {
  const positions = portfolio?.openPositions?.() || [];
  const safeEquity = Number(equity) > 0 ? Number(equity) : 0;
  let longNotional = 0;
  let shortNotional = 0;
  let unrealised = 0;
  const bySymbol = {};

  for (const p of positions) {
    const notional = Math.max(0, Number(p.notional) || 0);
    const pnl = Number(p.unrealisedPnl?.() || 0);
    if (p.dir > 0) longNotional += notional;
    else shortNotional += notional;
    unrealised += pnl;
    bySymbol[p.symbol] = Math.round(((bySymbol[p.symbol] || 0) + notional) * 100) / 100;
  }

  const gross = longNotional + shortNotional;
  const net = longNotional - shortNotional;
  const ranked = Object.entries(bySymbol).sort((a, b) => b[1] - a[1]);
  const largest = ranked[0] || [null, 0];
  return {
    positions: positions.length,
    longNotional: Math.round(longNotional * 100) / 100,
    shortNotional: Math.round(shortNotional * 100) / 100,
    grossNotional: Math.round(gross * 100) / 100,
    netNotional: Math.round(net * 100) / 100,
    grossPct: safeEquity ? Math.round((gross / safeEquity) * 10000) / 100 : 0,
    netPct: safeEquity ? Math.round((net / safeEquity) * 10000) / 100 : 0,
    unrealisedPnl: Math.round(unrealised * 100) / 100,
    equityMtm: Math.round((safeEquity + unrealised) * 100) / 100,
    largestSymbol: largest[0],
    largestNotional: Math.round(Number(largest[1]) * 100) / 100,
    largestPct: safeEquity ? Math.round((Number(largest[1]) / safeEquity) * 10000) / 100 : 0,
    bySymbol: Object.fromEntries(ranked),
  };
}

module.exports = { riskXray };
