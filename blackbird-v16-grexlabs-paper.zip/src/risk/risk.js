'use strict';
/**
 * BlackBird — risk officer (hard limits, not opinions).
 *
 * Every rule here is a veto, not a vote: if risk says no, the board cannot
 * approve the trade. It is deliberately dumb and deterministic so that its
 * behaviour can be audited line by line.
 */
const { clamp, now, dayKey } = require('../core/util');
const { angryNotionalCap, angryActivation, angryLockout } = require('./angry-limits');

class RiskManager {
  constructor({ cfg, store, log }) {
    this.cfg = cfg;
    this.store = store;
    this.log = log;
    // The peak must survive a restart. Reading it from the live equity meant a
    // bot that had run up to 6000 and fallen to 5400 came back believing its
    // peak was 5400: drawdown read 0% and the kill switch could never fire
    // again. Persisted peak wins; live equity is only the floor.
    this.peakEquity = Math.max(
      Number(store.state.peakEquity) || 0,
      Number(store.state.equity) || 0,
      Number(cfg.risk.startEquity) || 0
    );
    this.halted = false;
    this.haltReason = null;
    this.haltKind = null;   // 'daily' (auto-resumes) | 'hard' (manual)
    this.resumeAt = 0;
    this.vetoes = [];
    this.lastVeto = null;
    // Set by the engine when a court exists: () => ({ yellowCards, redCard }).
    // Read-only input to the AngryBird cap; risk never calls back into the court.
    this.courtState = null;
  }

  get state() {
    return this.store.state;
  }

  dailyPnlPct() {
    const s = this.state;
    // Never fall back to startEquity: that turns "down since inception" into
    // "down today" and halts a healthy bot. No anchor means no daily P&L yet.
    const start = Number(s.dayStartEquity);
    if (!Number.isFinite(start) || start <= 0) return 0;
    return ((s.equity - start) / start) * 100;
  }

  drawdownPct() {
    return this.peakEquity ? ((this.peakEquity - this.state.equity) / this.peakEquity) * 100 : 0;
  }

  /**
   * Drawdown measured on MARK-TO-MARKET equity, not on realised equity.
   *
   * BUG THIS FIXES
   * --------------
   * The kill switch only ever looked at `state.equity`, which moves when a
   * trade CLOSES. A book that is 16% underwater on open positions but has not
   * closed anything yet reads as 0% drawdown, so the switch never fires — and
   * the moment the positions finally close, the loss is already past the limit.
   * A 12-month replay showed exactly that: 15.86% drawdown against a 15% cap.
   *
   * `equityMtm` is the same number the dashboard already shows, so the switch
   * and the operator now agree on what "down" means.
   */
  drawdownMtmPct(equityMtm) {
    const eq = Number(equityMtm);
    if (!Number.isFinite(eq) || !(this.peakEquity > 0)) return this.drawdownPct();
    return ((this.peakEquity - eq) / this.peakEquity) * 100;
  }

  /**
   * Called from the engine clock with the marked equity. Halts on a breach.
   * Never throws: a risk check that can crash the engine is worse than none.
   * @returns {boolean} true when this call tripped the switch
   */
  markToMarket(equityMtm) {
    if (this.halted) return false;
    const eq = Number(equityMtm);
    if (!Number.isFinite(eq) || eq <= 0) return false;
    // The peak follows the marked equity too, otherwise a run-up that is still
    // open would never raise the high-water mark and the drawdown would be
    // measured from a stale peak.
    if (eq > this.peakEquity) {
      this.peakEquity = eq;
      this.state.peakEquity = eq;
    }
    const dd = this.drawdownMtmPct(eq);
    const limit = Number(this.cfg.risk.killSwitchDrawdownPct) * 100;
    if (Number.isFinite(limit) && dd >= limit) {
      // A drawdown halt is NOT permanent. Charter §8 forbids resuming on the
      // passage of time alone, but it also forbids a switch with no way back:
      // a 12-month replay showed the bot locking itself out in May and sitting
      // idle for five months, which is a dead bot, not a safe one.
      //
      // The way back is conditional, not timed:
      //   1. a cooling period must pass (resumeAt);
      //   2. the book must be flat or the drawdown must have recovered below
      //      `resumeDrawdownPct` (a partial recovery, not a full one);
      //   3. the first entries after resume are sized down (resumeScale).
      const coolMs = Number(this.cfg.risk.drawdownCooldownMs) || 24 * 3600 * 1000;
      this.halt(`drawdown(mtm) ${dd.toFixed(2)}% >= ${limit.toFixed(2)}%`, {
        kind: 'drawdown',
        resumeAt: now() + coolMs,
      });
      return true;
    }
    return false;
  }

  /**
   * Charter §8: a halt may only lift when health and the resume conditions are
   * re-evaluated — never because time passed. Called from the engine clock.
   *
   * @param {object} ctx { equityMtm, openPositions, dataOk }
   * @returns {boolean} true when trading resumed on this call
   */
  evaluateResume(ctx = {}) {
    if (!this.halted || this.haltKind !== 'drawdown') return false;
    if (!this.resumeAt || now() < this.resumeAt) return false;

    // Condition 1: the data path must be healthy. Resuming on stale data is
    // how a bot re-enters a market it cannot see.
    if (ctx.dataOk === false) return false;

    // Condition 2: the book must be flat, or the drawdown must have recovered
    // to the resume threshold. A still-underwater book does not get new risk.
    const open = Number(ctx.openPositions) || 0;
    const resumeDd = Number(this.cfg.risk.resumeDrawdownPct);
    const dd = Number.isFinite(Number(ctx.equityMtm))
      ? this.drawdownMtmPct(ctx.equityMtm)
      : this.drawdownPct();
    const recovered = Number.isFinite(resumeDd) && dd <= resumeDd * 100;
    if (open > 0 && !recovered) return false;

    const why = this.haltReason;
    this.resume();
    // Condition 3: come back small. The first entries after a drawdown halt are
    // scaled down until the book proves itself again.
    this.resumeScale = Number(this.cfg.risk.resumeScale) || 0.5;
    this.resumedAt = now();
    this.log.info(`drawdown halt lifted after re-evaluation (dd ${dd.toFixed(2)}%, open ${open})`, { previous: why });
    this.store.append('resume', { previous: why, kind: 'drawdown', dd, open, scale: this.resumeScale });
    return true;
  }

  /**
   * @param {string} reason
   * @param {{kind?: 'daily'|'hard', resumeAt?: number}} opts
   * A daily-loss halt pauses trading until the next UTC day; a hard halt
   * (drawdown, integrity, manual) requires a human to press resume.
   */
  halt(reason, opts = {}) {
    if (this.halted) return;
    this.halted = true;
    this.haltReason = reason;
    this.haltKind = opts.kind || 'hard';
    this.resumeAt = opts.resumeAt || 0;
    this.log.error(`KILL SWITCH (${this.haltKind}): ${reason}`);
    this.store.append('halt', { reason, kind: this.haltKind, resumeAt: this.resumeAt, equity: this.state.equity });
  }

  resume() {
    this.halted = false;
    this.haltReason = null;
    this.haltKind = null;
    this.resumeAt = 0;
  }

  /** Called from the engine clock: daily pauses lift themselves at UTC midnight. */
  maybeAutoResume(ts = now()) {
    if (!this.halted || this.haltKind === 'hard') return false;
    if (!this.resumeAt || ts < this.resumeAt) return false;
    const why = this.haltReason;
    this.resume();
    this.log.info('daily pause lifted, trading resumes', { previous: why });
    this.store.append('resume', { previous: why, kind: this.haltKind || 'soft' });
    return true;
  }

  /** Called on every closed trade. Updates equity, streaks and the daily book. */
  settle({ pnl, fee, notional, win, symbol, tradeId }) {
    const s = this.state;
    const c = s.counters;
    s.equity += pnl;
    s.realizedPnl += pnl;
    s.feesPaid += fee || 0;
    c.trades++;
    c.tradesToday++;
    if (win) {
      c.wins++;
      c.grossProfit += pnl;
      c.lossesStreak = 0;
    } else {
      c.losses++;
      c.grossLoss += Math.abs(pnl);
      c.lossesStreak++;
    }
    this.peakEquity = Math.max(this.peakEquity, s.equity);
    s.peakEquity = this.peakEquity; // persist: see the constructor

    if (this.drawdownPct() >= this.cfg.risk.killSwitchDrawdownPct * 100) {
      this.halt(`drawdown ${this.drawdownPct().toFixed(2)}% >= ${(this.cfg.risk.killSwitchDrawdownPct * 100).toFixed(2)}%`);
    }
    if (this.dailyPnlPct() <= -this.cfg.risk.maxDailyLossPct * 100) {
      const nextDay = (Math.floor(now() / 86400000) + 1) * 86400000;
      this.halt(`daily loss ${this.dailyPnlPct().toFixed(2)}% >= ${(this.cfg.risk.maxDailyLossPct * 100).toFixed(2)}%`, {
        kind: 'daily',
        resumeAt: nextDay,
      });
    }
    if (c.lossesStreak >= this.cfg.risk.maxConsecutiveLosses) {
      this.state.cooldowns.__global = now() + this.cfg.risk.cooldownAfterLossMs;
      this.log.warn(`cooling down after ${c.lossesStreak} consecutive losses`);
    }
    // AngryBird stops the whole episode after a short losing streak. It is a
    // separate, stickier lock than the global cooldown above.
    const angryLockCfg = this.cfg.risk.angry && this.cfg.risk.angry.lockout;
    if (
      this.cfg.profile && this.cfg.profile.name === 'angrybird' &&
      angryLockCfg && angryLockCfg.enabled &&
      c.lossesStreak >= (Number(angryLockCfg.maxConsecutiveLosses) || 2) &&
      !s.angryLock
    ) {
      s.angryLock = { at: now(), losses: c.lossesStreak, gateClosedSince: false };
      this.log.warn(`angrybird lockout engaged after ${c.lossesStreak} consecutive losses`);
      try { this.store.append('angry_lockout', { ts: now(), losses: c.lossesStreak, equity: s.equity }); } catch { /* best effort */ }
    }
    this.store.append('settle', { tradeId, symbol, pnl, fee, equity: s.equity, win });
    return this.state.equity;
  }

  /** Full pre-trade check. Returns {ok, reason, checks}. */
  check(proposal, portfolio) {
    const s = this.state;
    const checks = [];
    const veto = (reason) => {
      checks.push({ rule: reason, pass: false });
      this.vetoes.push({ ts: now(), symbol: proposal.symbol, reason });
      if (this.vetoes.length > 200) this.vetoes.shift();
      this.lastVeto = { ts: now(), symbol: proposal.symbol, reason };
      return { ok: false, reason, checks };
    };
    const pass = (rule) => checks.push({ rule, pass: true });

    if (this.halted) return veto(`halted:${this.haltReason}`);
    pass('not_halted');

    // AngryBird: the nominal size ceiling is code, not advice. Up to the hard cap
    // only while every full-size condition holds; otherwise the reduced cap.
    if (this.cfg.risk.angry && this.cfg.risk.angry.enabled) {
      let cs = {};
      try { cs = this.courtState ? this.courtState() || {} : {}; } catch { cs = { redCard: true }; } // fail closed
      const cap = angryNotionalCap(this.cfg.risk.angry, {
        equity: s.equity,
        startEquity: this.cfg.risk.startEquity,
        drawdownPct: this.drawdownPct(),
        dailyPnlPct: this.dailyPnlPct(),
        lossStreak: (s.counters && s.counters.lossesStreak) || 0,
        yellowCards: cs.yellowCards || 0,
        redCard: Boolean(cs.redCard),
        halted: this.halted,
      });
      if (!(Number(proposal.notional) <= cap.cap)) {
        return veto(`angry_notional_cap(${Math.round(proposal.notional || 0)}>${cap.cap}; ${cap.reasons.join(',') || 'full_size_allowed'})`);
      }
      pass('angry_notional_cap');

      // The scenario only exists in muddy water: turbulent tape, most people
      // leaving, and the evidence already turning. Outside that window the
      // right trade is no trade. Context comes from the engine; missing
      // context closes the gate (fail closed).
      const act = this.cfg.risk.angry.activation;
      let gate = { active: true, reasons: [] };
      if (act && act.enabled) {
        let mctx = {};
        try { mctx = (this.marketContext ? this.marketContext() : null) || {}; } catch { mctx = {}; }
        gate = angryActivation(act, mctx);
      }

      // Two consecutive losses end the episode. The lock lifts only when the
      // market profile has changed (the gate closed and a new window opened)
      // and the cooling period has passed — never on time alone.
      const lockCfg = this.cfg.risk.angry.lockout;
      if (lockCfg && lockCfg.enabled) {
        const lockState = s.angryLock || null;
        if (lockState && !gate.active) lockState.gateClosedSince = true;
        const lock = angryLockout(lockCfg, {
          lossStreak: (s.counters && s.counters.lossesStreak) || 0,
          now: now(),
          lock: lockState,
        });
        if (lock.locked) {
          if (!lockState) {
            s.angryLock = {
              at: now(),
              losses: (s.counters && s.counters.lossesStreak) || 0,
              gateClosedSince: false,
            };
          }
          try { this.store.saveState(); } catch { /* best effort */ }
          return veto(`angry_lockout(${lock.reasons.join(',')})`);
        }
        if (lockState) {
          delete s.angryLock;
          try { this.store.saveState(); } catch { /* best effort */ }
          this.log.warn('angrybird lockout lifted: a fresh window is open');
          try { this.store.append('angry_lockout_lifted', { ts: now() }); } catch { /* best effort */ }
        }
        pass('angry_lockout');
      }

      if (act && act.enabled) {
        if (!gate.active) return veto(`angry_gate_closed(${gate.reasons.join(',')})`);
        pass('angry_gate_open');
      }
    }

    if (s.counters.tradesToday >= this.cfg.risk.maxDailyTrades) {
      return veto(`daily_trade_cap(${s.counters.tradesToday}/${this.cfg.risk.maxDailyTrades})`);
    }
    pass('daily_trade_cap');

    if (this.dailyPnlPct() <= -this.cfg.risk.maxDailyLossPct * 100) {
      return veto(`daily_loss_limit(${this.dailyPnlPct().toFixed(2)}%)`);
    }
    pass('daily_loss_limit');

    if (this.drawdownPct() >= this.cfg.risk.killSwitchDrawdownPct * 100) {
      return veto(`drawdown(${this.drawdownPct().toFixed(2)}%)`);
    }
    pass('drawdown');

    const cd = s.cooldowns.__global || 0;
    if (cd > now()) return veto(`cooldown(${Math.ceil((cd - now()) / 1000)}s)`);
    pass('cooldown');

    if (portfolio.openPositions().length >= this.cfg.risk.maxOpenPositions) {
      return veto(`max_open_positions(${this.cfg.risk.maxOpenPositions})`);
    }
    pass('max_open_positions');

    if (portfolio.hasPosition(proposal.symbol)) return veto('symbol_already_open');
    pass('single_position_per_symbol');

    const symExposure = portfolio.exposureBySymbol(proposal.symbol);
    const maxSym = this.cfg.risk.maxSymbolExposurePct * s.equity;
    if (symExposure + (proposal.notional || 0) > maxSym) {
      return veto(`symbol_exposure(${Math.round(symExposure)}+${Math.round(proposal.notional || 0)}>${Math.round(maxSym)})`);
    }
    pass('symbol_exposure');

    // directional cap: a book of four correlated longs is one bet, not four
    if (portfolio.netExposure && this.cfg.risk.maxNetExposurePct) {
      const signed = proposal.side === 'sell' ? -(proposal.notional || 0) : (proposal.notional || 0);
      const net = portfolio.netExposure() + signed;
      const maxNet = s.equity * this.cfg.risk.maxNetExposurePct;
      if (Math.abs(net) > maxNet) {
        return veto(`net_exposure(${Math.round(Math.abs(net))}>${Math.round(maxNet)})`);
      }
      pass('net_exposure');
    }

    const total = portfolio.totalExposure();
    const maxTotal = this.cfg.risk.maxOpenPositions * this.cfg.risk.maxPositionPct * s.equity;
    if (total + (proposal.notional || 0) > maxTotal) {
      return veto(`total_exposure(${Math.round(total)}+${Math.round(proposal.notional || 0)}>${Math.round(maxTotal)})`);
    }
    pass('total_exposure');

    if (s.equity <= this.cfg.risk.startEquity * (1 - this.cfg.risk.killSwitchDrawdownPct)) {
      return veto('equity_floor');
    }
    pass('equity_floor');

    return { ok: true, checks };
  }

  /**
   * Position sizing.
   * We size to a *profit target* (your "$1 per trade") but never beyond the
   * risk budget. If the target needs more than the budget allows, the trade is
   * simply smaller — the system never takes a bigger risk to hit a number.
   */
  size({ price, tpBps, slBps, entryFeeBps, exitFeeBps }) {
    const s = this.state;
    const equity = s.equity;
    const budget = equity * this.cfg.risk.maxPositionPct;
    const netEdgePct = Math.max(1e-6, (tpBps - entryFeeBps - exitFeeBps) / 10000);
    const target = this.cfg.risk.targetProfitUsdPerTrade / netEdgePct;

    // Risk-first sizing: the stop distance decides the size, so a wide stop
    // automatically gets a smaller position. The notional cap still applies.
    let notional = budget;
    let sizing = 'budget_cap';
    if (this.cfg.risk.useRiskSizing && slBps > 0) {
      const riskUsd = equity * this.cfg.risk.riskPerTradePct;
      const byRisk = riskUsd / (slBps / 10000);
      if (byRisk < notional) {
        notional = byRisk;
        sizing = 'risk_per_trade';
      }
    } else if (target < notional) {
      notional = target;
      sizing = 'profit_target';
    }

    const qty = price > 0 ? notional / price : 0;
    return {
      notional: Math.min(notional, budget),
      qty,
      budget,
      targetNotional: target,
      cappedByRisk: notional >= budget,
      sizing,
      netEdgePct,
      riskUsd: equity * this.cfg.risk.riskPerTradePct,
    };
  }

  /** Called by the engine clock; rolls the UTC day and records day-start equity. */
  rollDay() {
    const s = this.state;
    const today = dayKey();
    if (s.counters.day === today) {
      // A restart inside the same UTC day used to leave dayStartEquity unset
      // (it is only written on a day roll), so dailyPnlPct() fell back to
      // startEquity and a bot that was merely down 20% from its all-time high
      // reported a -20% *daily* loss and halted itself on boot. Anchor the day
      // to the current equity the first time we see a day with no anchor.
      if (!Number.isFinite(Number(s.dayStartEquity))) {
        s.dayStartEquity = s.equity;
        this.store.append('day_anchor', { day: today, equity: s.equity, reason: 'restart_same_day' });
      }
      return false;
    }
    s.counters.day = today;
    s.counters.tradesToday = 0;
    s.dayStartEquity = s.equity;
    this.store.append('day_roll', { day: today, equity: s.equity });
    this.log.info('new trading day', { day: today, equity: s.equity });
    return true;
  }

  snapshot() {
    return {
      equity: Math.round(this.state.equity * 100) / 100,
      peakEquity: Math.round(this.peakEquity * 100) / 100,
      drawdownPct: Math.round(this.drawdownPct() * 100) / 100,
      dailyPnlPct: Math.round(this.dailyPnlPct() * 100) / 100,
      tradesToday: this.state.counters.tradesToday,
      tradesTotal: this.state.counters.trades,
      wins: this.state.counters.wins,
      losses: this.state.counters.losses,
      lossesStreak: this.state.counters.lossesStreak,
      halted: this.halted,
      haltKind: this.haltKind,
      resumeAt: this.resumeAt,
      haltReason: this.haltReason,
      lastVeto: this.lastVeto,
    };
  }
}

module.exports = { RiskManager };
