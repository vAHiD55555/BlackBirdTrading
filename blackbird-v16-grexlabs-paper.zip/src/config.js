'use strict';
/**
 * BlackBird — configuration.
 * Precedence: defaults  <  config.json  <  environment variables.
 * Nothing here throws on startup for values you may not care about; `validate`
 * is called explicitly by the engine and prints a human readable summary.
 */
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const { applyProfile } = require('./profiles');
const PKG_VERSION = (() => { try { return require('../package.json').version; } catch { return '0.0.0'; } })();

const DEFAULTS = {
  // ---- identity & mode -----------------------------------------------------
  mode: 'paper', // 'paper' | 'live'
  market: 'futures', // 'spot' (long only) | 'futures' (long + short)
  market: 'futures', // 'spot' (long only) | 'futures' (long + short)
  exchange: 'binance', // binance | mexc | bitget | bybit | hyperliquid
  witnessExchange: 'bybit', // independent 2nd source for the witness layer

  // Hyperliquid — the second market. Selected with EXCHANGE=hyperliquid.
  // `mode` is the broker mode, independent of the engine's paper/live:
  //   paper   simulated fills against the real Hyperliquid book (default)
  //   dry-run orders are built and signed but never POSTed
  //   live    orders are POSTed (needs an API wallet + the money interlock)
  hyperliquid: {
    mode: 'paper',
    apiWalletKeyEnv: 'HL_API_WALLET_KEY',
    accountAddressEnv: 'HL_ACCOUNT_ADDRESS',
    vaultAddressEnv: 'HL_VAULT_ADDRESS',
    slippageBps: 30,
    tif: 'Gtc',
    reduceOnly: false,
    maxNotionalUsd: 0,
  },
  symbols: ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT'],
  quote: 'USDT',

  // ---- market data ---------------------------------------------------------
  data: {
    intervalMs: 60000, // derived from timeframe
    timeframe: '5m', // signal timeframe: 1m | 3m | 5m | 15m
    bootstrapBars: 300, // history loaded on start
    tickerPollMs: 1000,
    depthPollMs: 5000,
    depthLevels: 20,
    useWebSocket: true, // falls back to REST polling automatically
    staleQuoteMs: 20000, // quote older than this is considered dead
    maxClockSkewMs: 5000,
  },

  // ---- risk ----------------------------------------------------------------
  risk: {
    startEquity: 5000, // USDT (paper)
    maxPositionPct: 0.20, // notional per trade vs equity
    maxOpenPositions: 8, // charter §7: Risk Manager cap (rotator has its own 6)
    maxSymbolExposurePct: 0.25,
    maxDailyLossPct: 0.04, // charter §7: daily loss cap 4%
    maxDailyTrades: 30, // charter §7: 30 trades/day
    maxConsecutiveLosses: 4,
    cooldownAfterLossMs: 600 * 1000, // charter §7: 600s after consecutive losses
    killSwitchDrawdownPct: 0.12,
    // Charter §8: a halt must have a defined way back, and it must not be
    // "time passed". These three knobs are the resume contract, all panel-tunable.
    drawdownCooldownMs: 24 * 3600 * 1000, // cooling period before a resume is even considered
    resumeDrawdownPct: 0.06, // must have recovered to this drawdown (or be flat)
    resumeScale: 0.5, // first entries after a resume are half size
    minNotionalUsd: 15,
    maxNetExposurePct: 0.70, // |long - short| notional vs equity (charter §7)
    targetProfitUsdPerTrade: 1.0, // soft target used for sizing
    useRiskSizing: true, // size from stop distance instead of fixed notional
    riskPerTradePct: 0.005, // 0.5% of equity at risk per trade
  },

  // ---- strategy: "fishing in muddy water" ----------------------------------
  strategy: {
    // 'discretionary' = the v2 per-bar pattern hunter (scout/board/trader)
    // 'rotator'       = the v3 cross-sectional momentum book (Orbital)
    // 'hybrid'        = Orbital sleeve + v2 tactical trend-pullback sleeve
    mode: 'rotator',
    rotator: {
      rebalanceHours: 168,      // weekly rotation
            perPositionPct: 9, // charter §6/§7: % of equity per picked symbol
      maxGrossPct: 70, // charter §7: gross cap
      maxPositions: 6, // charter §7
      emergencyExitMs: 15 * 60 * 1000, // stale-quote exit policy (charter §25.4)
      minNotionalUsd: 15,
      disasterStopAtr: 6,       // wide stop: this is a swing book, not a scalp
      // Charter §12 trailing ladder. R = disasterStopAtr * atr.
      //   trailBeAtR  : profit in R at which the stop moves to the entry price
      //   trailLockAtR: profit in R at which profit starts being locked in
      //   trailLockR  : how much R is locked in at that point
      //   trailAtr    : distance behind the best price once the ladder is live
      trailEnabled: true,
      trailBeAtR: 1,
      trailLockAtR: 2,
      trailLockR: 1,
      trailAtr: 1.5,
      // Legacy knobs kept so an old .env does not break; they are no longer
      // read by the ladder (see _trail in strategy/rotator.js).
      trailStartAtr: 2,
      trailDistanceAtr: 2,
      gateSymbol: 'BTCUSDT',    // longs need the market above its 200-EMA
      volTargetPct: 45,         // annualised volatility target
      volFloor: 0.3,
      volCap: 1.6,
      ddSteps: [0.08, 0.6, 0.15, 0.35, 0.22, 0.2],
      variants: [
        { lookHours: 72, top: 2, neutral: true, gate: false },
        { lookHours: 168, top: 2, neutral: true, gate: true },
        { lookHours: 168, skipHours: 24, top: 3, neutral: true, gate: true },
      ],
    },
    // regime gate
    minVolPercentile: 0.55, // market must be turbulent enough...
    maxSpreadBps: 9, // ...but liquid enough to get out
    minDepthUsd: 25000, // top-of-book notional (both sides)
    maxTrendStrength: 2.6, // avoid one-way freight trains

    // signal
    bbPeriod: 20,
    bbStd: 2.0,
    rsiPeriod: 14,
    atrPeriod: 14,
    vwapWindow: 60,
    volSpikeMult: 1.4,

    // ---- trend / pullback (the core) ----
    requireUptrend: true,
    requireEmaCross: false,
    trendPullback: true,
    allowShort: true,
    pullbackRsiMin: 30,
    pullbackRsiMax: 62,
    rrTarget: 2.2,
    beAtR: 1.0,
    lockAtR: 2.0,
    trailAtr: 1.5,
    useBreadthGate: true,
    breadthMin: 0.5,

    // ---- range / vwap (secondary) ----
    minDeviationAtr: 1.2,
    sweepLookback: 40,
    stopBufferBps: 8,
    tpTargetFrac: 0.85,

    // ---- geometry ----
    minRR: 1.15,
    slAtrFloor: 1.6,
    slAtrCeil: 3.5,
    minTpBps: 30,
    maxTpBps: 400,
    minSlBps: 20,
    maxSlBps: 250,
    timeStopMs: 12 * 60 * 60 * 1000,
    entryType: 'maker',
    makerTimeoutMs: 10 * 60 * 1000,
  },

  // ---- futures -------------------------------------------------------------
  futures: {
    fundingBps: 1, // 0.01% per 8h funding interval (typical for BTC)
    leverage: 1, // notional never exceeds equity in this build
  },

  // ---- costs (must be modelled honestly or the "profit" is a lie) ----------
  fees: {
    // charter §14: maker 2bps, taker 5bps. The old 7.5/10 defaults were 3.75x
    // the charter and made every edge look unprofitable, which silently pushed
    // the engine to the most conservative corner of its own rules.
    makerBps: 2,
    takerBps: 5,
    slippageBpsPer1kNotional: 0.6, // additional market impact per $1k
    latencyMs: 120, // decision -> order at the venue
  },

  // ---- JEV: just-in-time execution vector ----------------------------------
  // NOTE: this is the *execution* layer (order intents + latency budget). It is
  // unrelated to the jev reasoning layer below; the two were both called "jev"
  // historically, so this one is keyed jevExec to keep them apart.
  jevExec: {
    enabled: true,
    prewarm: true, // pre-build order intents for every symbol at boot
    maxLatencyMs: 400, // if decision->submit exceeds this, abort the entry
    maxQueue: 64,
  },

  // ---- agents --------------------------------------------------------------
  board: {
    minApprove: 2, // out of 3 voting officers
    requireZeroVetoes: true,
    // Constitution §15: the risk officer's confidence floor is 0.55. It was
    // 0.45 here and 0.3 in config.json, so the board approved proposals the
    // charter says it must refuse.
    confidenceFloor: 0.55,
  },

  scout: {
    scanIntervalMs: 15000,
    proposalTtlMs: 45000,
    maxProposalsPerCycle: 2,
    minExpectedEdgeBps: 11,
  },

  // ---- the watch (دیده‌بان) ------------------------------------------------
  // Discovers NEW opportunities (symbols the book does not hold yet) and, when
  // the council approves, proposes replacing a stagnant or low-yield holding.
  // It never trades on its own: it produces a proposal, and the same board that
  // gates every other trade has to approve it.
  //
  // Everything here is panel-tunable (WATCH_* env vars) so the universe and the
  // thresholds can be changed without touching a file on the server.
  watch: {
    enabled: true,
    // Discovery used to run 4x/day. On a free tier the cost of a cycle is one
    // public REST call per symbol, so 2h is affordable and finds a rotation
    // while it is still worth taking. Panel: WATCH_INTERVAL_MS.
    intervalMs: 2 * 60 * 60 * 1000,
    // Symbols to look at. Empty = the exchange's own top-volume list, which is
    // the honest "what is actually liquid right now" answer.
    universe: [],
    // How many symbols the discovery scan pulls from the exchange. 12 was too
    // narrow: the top 12 by volume are the same majors every cycle, so the
    // watch never actually discovered anything new. 40 is still one cheap call.
    scanLimit: 40,
    maxCandidates: 5, // how many new ideas to surface per cycle
    minQuoteVolumeUsd: 5_000_000, // 24h turnover floor: no thin books
    minEdgeBps: 25, // expected edge a candidate must clear to be worth a swap
    // A holding counts as stagnant when, over `stagnantDays`, it returned less
    // than `stagnantReturnPct` AND the candidate beats it by `minEdgeBps`.
    stagnantDays: 14,
    stagnantReturnPct: 1.0,
    // autoApply=false means: propose, log, and wait for a human/council. This is
    // the default because replacing a position is a real decision.
    autoApply: false,
    requireCouncil: true, // the board must approve the swap
    maxSwapsPerCycle: 1, // one replacement per cycle, never a wholesale churn
    // A candidate must also be trending, not merely cheap: momentum over the
    // lookback must be positive and the trend quality must clear this floor.
    // Without it the watch kept proposing falling knives.
    minMomentumPct: 0.0,
    minTrendQuality: 0.35,
    lookbackBars: 72, // 3 days of 1h bars: long enough to see a trend
  },

  // ---- the apprentice (کارآموز) -------------------------------------------
  // A permanent learner that asks every actor "why?" and refuses an answer
  // without a reason. Its log is a portable training dataset, not a debug
  // trace. It never blocks a trade and never throws.
  apprentice: {
    enabled: true,
    maxBytesPerDay: 20 * 1024 * 1024,
    maxOpenQuestions: 200,
    maxRecordsInMemory: 2000,
    requireReason: true,
    minReasonChars: 8,
  },

  // ---- market intel (اخبار و هوش بازار) -----------------------------------
  // Event blackout + sentiment tilt. It can only REDUCE risk: a risk-on tone
  // returns a multiplier of exactly 1, never more. Off by default because it
  // needs at least one feed URL, and a feed with no URL is not a feature.
  intel: {
    enabled: false,
    feeds: {
      macro: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 1.0, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
      geo: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.8, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
      weather: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.5, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
      // Crypto-native (CoinDesk / Cointelegraph / Decrypt) and wire-service
      // (Reuters via the Google News RSS mirror) families. Both RSS, both
      // keyless. See src/intel/news.js for why Reuters is reached indirectly.
      crypto: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.9, format: 'rss', fallbackUrl: '', fallbackFormat: 'rss' },
      wire: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.9, format: 'rss', fallbackUrl: '', fallbackFormat: 'rss' },
    },
    refreshMs: 15 * 60 * 1000,
    timeoutMs: 8000,
    retry429: 1,
    retryDelayMs: 6000,
    maxItemsPerFeed: 40,
    blackoutBeforeMs: 30 * 60 * 1000,
    blackoutAfterMs: 15 * 60 * 1000,
    extremeThreshold: 0.6,
    maxRiskImpact: 0.25,
  },

  // ---- historical analog (نظیر تاریخی) ------------------------------------
  // Compares the current market shape against past shapes and reports what
  // happened next. A weak match is reported as "no match", never forced.
  analog: {
    enabled: true,
    k: 12,
    minSamples: 20,
    maxDistance: 0.55,
    // A matched analog whose win rate is below this blocks NEW entries.
    minWinRate: 0.35,
    // How many closed trades to keep as the reference set.
    maxHistory: 500,
  },

  reporter: {
    intervalMs: 60 * 60 * 1000, // hourly report contract
    dir: path.join(ROOT, 'reports'),
    keepDays: 30,
    writeMarkdown: true,
    writeJson: true,
  },

  notifications: {
    email: {
      enabled: false,
      host: '',
      port: 465,
      user: '',
      pass: '',
      from: '',
      to: '',
    },
    telegram: {
      enabled: false,
      botToken: '',
      reportChatId: '',
      alertChatId: '',
      // AngryBird's own channel, so its short episodes do not drown in the
      // hourly portfolio report. Empty = fall back to the report chat.
      angryChatId: '',
      controlUserIds: [],
      timeoutMs: 10000,
    },
  },

  auditor: {
    tickMs: 20000,
    latencyP99Ms: 900,
    slippageAlertBps: 18,
    dataGapMs: 90000,
    decayWindow: 20, // trades
    decayMinWinRate: 0.34,
    anomalyZ: 4.5,
  },

  learner: {
    enabled: true,
    minSamplesPerArm: 12,
    explorationRate: 0.15,
    adaptTpSl: true,
    adaptThresholds: true,
  },

  // Optional OpenAI-compatible model reviewer. OFF unless you point it at an
  // endpoint: a free host has no local Ollama and no API key, and the engine
  // must run perfectly without one. Setting SUPERVISOR_URL turns it on; when the
  // endpoint is missing or unreachable the supervisor probes once and switches
  // itself off, instead of logging a failure on every cycle.
  supervisor: {
    enabled: Boolean(process.env.SUPERVISOR_URL),
    url: process.env.SUPERVISOR_URL || '',
    model: process.env.SUPERVISOR_MODEL || 'qwen2.5:7b',
    apiKey: process.env.SUPERVISOR_API_KEY || '',
    intervalMs: 6 * 60 * 60 * 1000,
    timeoutMs: 15000,
    maxConsecutiveErrors: 3,
  },

  // Self-healing supervisor. It may only pause entries, cut the gross book or
  // move to another data venue — never open, enlarge or resume anything. The
  // model block is optional: without ADVISOR_URL the deterministic rules act
  // alone, which is the default and the safe path.
  heal: {
    enabled: true,
    checkEveryMs: 15000,
    feedOutageMs: 5 * 60 * 1000,
    staleProgressMs: 20 * 60 * 1000,
    maxActionsPerHour: 4,
    actionCooldownMs: 5 * 60 * 1000,
    pauseEntriesMinutes: 30,
    reduceGrossFactor: 0.5,
    fallbackExchanges: ['mexc', 'bitget', 'bybit', 'binance', 'hyperliquid'],
    model: {
      // KEYLESS AND REMOTE by default. `pollinations` needs no key and no local
      // process, so it works on a hosted free tier where 127.0.0.1 is the
      // container itself. The deterministic rules still decide first; the model
      // is only asked for the cases the rules cannot classify. Point ADVISOR_URL
      // at any OpenAI-compatible endpoint to change it from the panel.
      enabled: false,
      baseUrl: 'https://text.pollinations.ai',
      chatPath: '/openai',
      model: 'openai',
      apiKeyEnv: 'ADVISOR_API_KEY',
      timeoutMs: 15000,
    },
  },

  // jev — the central layer. Three roles in one: brain (reasoning), mediator
  // (arbitration between modules), manager (supervision of modules). It can only
  // REDUCE risk or veto new entries; it never replaces a rule and never widens
  // exposure. Off by default so the engine behaves exactly as before.
  // کارگر میانی اختیاری (Cloudflare Worker). اگر نشانی خالی باشد، هیچ تماسی
  // زده نمی‌شود و موتور دقیقاً مثل قبل کار می‌کند. این لایه هرگز در مسیر
  // تصمیم معامله نیست: فقط کش قیمت و درگاه مدل.
  worker: {
    enabled: null, // null = خودکار: اگر baseUrl ست شده باشد روشن است
    baseUrl: '',
    tokenEnv: 'BB_WORKER_TOKEN',
    useForModel: true,
    useForData: true,
    timeoutMs: 1500,
    cooldownMs: 60000,
    maxCooldownMs: 300000,
  },

  jev: {
    enabled: false,
    // KEYLESS AND REMOTE BY DEFAULT. `pollinations` needs no key at all and no
    // local process, so a fresh install on a hosted free tier can turn jev on
    // without signing up for anything. The old default was `ollama`, which can
    // never answer inside a container (127.0.0.1 is the container itself).
    // Override with JEV_PROVIDER / JEV_MODEL / JEV_BASE_URL from the panel.
    provider: 'pollinations', // pollinations | grex (keyless experimental) | cloudflare | groq | gemini | cerebras | mistral | openrouter | ollama (local only) | mock
    model: 'openai',
    baseUrl: '', // blank = provider default; set for a remote Ollama/LM Studio
    apiKeyEnv: 'JEV_API_KEY', // the key is read from the environment only
    // When the chosen provider is not usable (no key, endpoint down), try the
    // keyless providers in this order before giving up. Empty = no fallback.
    keylessFallback: ['pollinations', 'mock'],
    // Local models are skipped unless this is on. On a hosted container they can
    // only time out, and a timeout costs a whole cycle.
    allowLocal: false,
    timeoutMs: 20000,
    maxRiskMultiplier: 1, // hard ceiling; jev can never exceed this
    allowVeto: true,
    superviseIntervalMs: 10 * 60 * 1000,
    decideIntervalMs: 5 * 60 * 1000,
    allowQuarantine: true,

    // Multi-model panel. When enabled and quorate it outranks the single model
    // above: several opinions, and one dead provider cannot kill the cycle.
    // Off by default so nothing changes until you ask for it.
    consensus: {
      enabled: false,
      models: [],
      quorum: 2,
      timeoutMs: 20000,
      disagreementThreshold: 0.35,
    },

    // Observation ledger: one JSONL record per cycle, for later training.
    ledger: {
      enabled: true,
      maxBytesPerDay: 50 * 1024 * 1024,
      keepDays: 30,
      compressAfterDays: 2,
    },
  },

  // The lawyer: audits whether the system is at maximum productivity given
  // current conditions, and files findings on behalf of the capital owner.
  // Independent of jev — it runs whether jev is on, off, or broken.
  lawyer: {
    enabled: false,
    auditIntervalMs: 15 * 60 * 1000,
    clauses: {},
    severityThreshold: 'warn',
    autoObject: false,
    benchmarkAnnualPct: 5,
    latencyBudgetMs: 2000,
    maxFindings: 200,
    // Deflated Sharpe acceptance threshold. Configurable, never hardcoded:
    // 0.95 = "95% confident the edge survives the K-trial correction".
    dsrThreshold: 0.95,
  },

  // Trial registry (K). Every parameter change, backtest or model swap is a
  // test; K is what makes the Deflated Sharpe Ratio computable at all.
  trials: {
    enabled: true,
    file: null, // resolved to <dataDir>/trials.jsonl
    recordBaselineOnBoot: true,
    detectDrift: true,
  },

  // The live strategist. A separate pair of eyes that wakes every 3m30s and
  // asks whether the method still fits the market. OFF by default: an engine
  // that suddenly starts self-correcting on an upgrade is a surprise nobody
  // asked for. Every part of it is opt-in through the environment.
  //
  // Crisis authority — the right to act WITHOUT a committee answer after the
  // 60s window — is a second, narrower switch. It can only ever reduce risk.
  strategist: {
    enabled: false,
    intervalMs: 210000, // 3 minutes 30 seconds
    responseWindowMs: 60000, // the committee has 60s before self-execution
    requestMinSeverity: 'amber',
    liveReport: true,
    maxRecords: 20000,
    authority: {
      enabled: false,
      maxActionsPerHour: 6,
      maxRiskDeltaPct: 25,
      allowedActions: ['block_entries', 'reduce_risk', 'pause_strategy', 'flatten', 'notify'],
      overlayTtlMs: 30 * 60 * 1000,
    },
    publish: {
      mode: 'off', // off | github | mirror | both
      intervalMs: 5 * 60 * 1000,
      includeLogs: true,
    },
  },

  witness: {
    enabled: true,
    requireCrossSource: true,
    maxPriceDivergenceBps: 35, // trader vs witness reference
    maxPnlDivergenceUsd: 0.25,
    // charter §3: the witness refreshes every 5s. This used to be hard-coded in
    // witness.js while config.json carried an `updateMs` key that nothing read,
    // so an operator who set it saw no effect at all.
    updateMs: 5000,
  },

  // ---- runtime -------------------------------------------------------------
  runtime: {
    logLevel: 'info', // debug | info | warn | error
    logDir: path.join(ROOT, 'data', 'logs'),
    stateFile: path.join(ROOT, 'data', 'state.json'),
    journalFile: path.join(ROOT, 'data', 'journal.jsonl'),
    snapshotMs: 30000,
    heartbeatMs: 60000,
    reportOnBoot: false,
  },

  server: {
    enabled: true,
    // A managed host proxies exactly one port and tells us which one. Precedence:
    //   BB_PORT (our override) > PORT (Docker/Heroku/Render) > SERVER_PORT
    //   (Pterodactyl/Wings — Botkeep, KataBump) > 0.
    // 0 means "no port was assigned": the OS picks a free one and the log prints
    // it. No port number is imposed by this code base — a fixed default is exactly
    // what collides with another service on a shared host.
    // The authoritative resolution lives in src/web/status.js; this is the config
    // default so preflight, doctor and the dashboard all agree.
    port: Number(process.env.BB_PORT || process.env.PORT || process.env.SERVER_PORT || 0),
    host: '0.0.0.0',
  },
};

/** Minimal .env reader: KEY=VALUE, # comments, optional quotes. */
function loadDotEnv(file) {
  if (!fs.existsSync(file)) return 0;
  let n = 0;
  try {
    for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const eq = line.indexOf('=');
      if (eq < 0) continue;
      const key = line.slice(0, eq).trim();
      let val = line.slice(eq + 1).trim();
      // Strip an inline comment: a `#` only starts one when preceded by whitespace,
      // so `#` inside a value (a token, a URL fragment) survives.
      const hash = val.search(/\s#/);
      if (hash >= 0) val = val.slice(0, hash).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
      if (process.env[key] === undefined) { process.env[key] = val; n++; }
    }
  } catch { /* ignore */ }
  return n;
}

const ENV_MAP = {
  MODE: ['mode', String],
  EXCHANGE: ['exchange', String],
  WITNESS_EXCHANGE: ['witnessExchange', String],
  WITNESS_ENABLED: ['witness.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  WITNESS_REQUIRE_CROSS_SOURCE: ['witness.requireCrossSource', (v) => /^(1|true|yes)$/i.test(String(v))],
  WITNESS_MAX_DIVERGENCE_BPS: ['witness.maxPriceDivergenceBps', Number],
  WITNESS_MAX_PNL_DIVERGENCE_USD: ['witness.maxPnlDivergenceUsd', Number],
  WITNESS_UPDATE_MS: ['witness.updateMs', Number],
  // ---- the watch (دیده‌بان) ------------------------------------------------
  // NOTE: this block used to appear TWICE in ENV_MAP — once here and once
  // further down. A duplicate key in an object literal is silently overwritten,
  // so the later copy won and any variable added to this one was dead. The
  // single block now lives further down, next to the sleeves. Do not re-add it
  // here: tests/v14.test.js fails the build on a duplicate ENV_MAP key.
  SYMBOLS: ['symbols', (v) => String(v).split(',').map((s) => s.trim().toUpperCase()).filter(Boolean)],
  START_EQUITY: ['risk.startEquity', Number],
  MAX_POSITION_PCT: ['risk.maxPositionPct', Number],
  MAX_OPEN_POSITIONS: ['risk.maxOpenPositions', Number],
  MAX_DAILY_LOSS_PCT: ['risk.maxDailyLossPct', Number],
  MAX_DAILY_TRADES: ['risk.maxDailyTrades', Number],
  TARGET_PROFIT_USD: ['risk.targetProfitUsdPerTrade', Number],
  REPORT_INTERVAL_MS: ['reporter.intervalMs', Number],
  REPORT_ON_BOOT: ['runtime.reportOnBoot', (v) => /^(1|true|yes)$/i.test(String(v))],
  BB_INTERVAL: ['data.timeframe', String],
  TIMEFRAME: ['data.timeframe', String],
  MAKER_FEE_BPS: ['fees.makerBps', Number],
  TAKER_FEE_BPS: ['fees.takerBps', Number],
  SERVER_TOKEN: ['server.token', String],
  MIN_EDGE_BPS: ['scout.minExpectedEdgeBps', Number],
  MIN_VOL_PERCENTILE: ['strategy.minVolPercentile', Number],
  REQUIRE_UPTREND: ['strategy.requireUptrend', (v) => /^(1|true|yes)$/i.test(String(v))],
  // Board tuning from the panel. Without these, the confidence floor could only
  // be changed by editing config.json on the host, which is exactly the wall an
  // operator hits when the log says "confidence 0.37 < floor 0.55" every hour.
  CONFIDENCE_FLOOR: ['board.confidenceFloor', Number],
  BOARD_MIN_APPROVE: ['board.minApprove', Number],
  BOARD_REQUIRE_ZERO_VETOES: ['board.requireZeroVetoes', (v) => /^(1|true|yes)$/i.test(String(v))],
  MAX_SPREAD_BPS: ['strategy.maxSpreadBps', Number],
  MIN_DEPTH_USD: ['strategy.minDepthUsd', Number],
  BB_PORT: ['server.port', Number],
  PORT: ['server.port', Number],
  BB_STRATEGY: ['strategy.mode', String],
  PER_POSITION_PCT: ['strategy.rotator.perPositionPct', Number],
  MAX_GROSS_PCT: ['strategy.rotator.maxGrossPct', Number],
  VOL_TARGET_PCT: ['strategy.rotator.volTargetPct', Number],
  REBALANCE_HOURS: ['strategy.rotator.rebalanceHours', Number],
  KILL_SWITCH_DD_PCT: ['risk.killSwitchDrawdownPct', Number],
  DRAWDOWN_COOLDOWN_MS: ['risk.drawdownCooldownMs', Number],
  RESUME_DRAWDOWN_PCT: ['risk.resumeDrawdownPct', Number],
  RESUME_SCALE: ['risk.resumeScale', Number],
  LOG_LEVEL: ['runtime.logLevel', String],
  DATA_DIR: ['runtime.dataDir', String],
  API_KEY: ['keys.apiKey', String],
  API_SECRET: ['keys.apiSecret', String],
  BINANCE_TESTNET: ['keys.binanceTestnet', (v) => /^(1|true|yes)$/i.test(String(v))],
  EMAIL_ENABLED: ['notifications.email.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  SMTP_HOST: ['notifications.email.host', String],
  SMTP_PORT: ['notifications.email.port', Number],
  SMTP_USER: ['notifications.email.user', String],
  SMTP_PASS: ['notifications.email.pass', String],
  EMAIL_FROM: ['notifications.email.from', String],
  EMAIL_TO: ['notifications.email.to', String],
  TELEGRAM_ENABLED: ['notifications.telegram.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  TELEGRAM_BOT_TOKEN: ['notifications.telegram.botToken', String],
  TELEGRAM_REPORT_CHAT_ID: ['notifications.telegram.reportChatId', String],
  TELEGRAM_ANGRY_CHAT_ID: ['notifications.telegram.angryChatId', String],
  TELEGRAM_ALERT_CHAT_ID: ['notifications.telegram.alertChatId', String],
  // The name almost every guide uses. Accepted as an alias for the report chat,
  // because a user who sets only this one used to get `missing_chat_id` forever
  // with no hint that the variable name was the problem.
  TELEGRAM_CHAT_ID: ['notifications.telegram.reportChatId', String],
  TELEGRAM_TOKEN: ['notifications.telegram.botToken', String],
  TELEGRAM_CONTROL_USER_IDS: ['notifications.telegram.controlUserIds', (v) => String(v).split(',').map((x) => x.trim()).filter(Boolean)],
  TELEGRAM_TIMEOUT_MS: ['notifications.telegram.timeoutMs', Number],
  SUPERVISOR_ENABLED: ['supervisor.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  SUPERVISOR_URL: ['supervisor.url', String],
  SUPERVISOR_MODEL: ['supervisor.model', String],
  SUPERVISOR_API_KEY: ['supervisor.apiKey', String],
  SUPERVISOR_INTERVAL_MS: ['supervisor.intervalMs', Number],
  JEV_EXEC_ENABLED: ['jevExec.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  JEV_MAX_LATENCY_MS: ['jevExec.maxLatencyMs', Number],
  JEV_ENABLED: ['jev.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  JEV_PROVIDER: ['jev.provider', String],
  JEV_MODEL: ['jev.model', String],
  JEV_BASE_URL: ['jev.baseUrl', String],
  JEV_API_KEY_ENV: ['jev.apiKeyEnv', String],
  JEV_TIMEOUT_MS: ['jev.timeoutMs', Number],
  JEV_MAX_RISK_MULTIPLIER: ['jev.maxRiskMultiplier', Number],
  JEV_ALLOW_VETO: ['jev.allowVeto', (v) => /^(1|true|yes)$/i.test(String(v))],
  JEV_SUPERVISE_INTERVAL_MS: ['jev.superviseIntervalMs', Number],
  JEV_DECIDE_INTERVAL_MS: ['jev.decideIntervalMs', Number],
  JEV_CONSENSUS_ENABLED: ['jev.consensus.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  JEV_CONSENSUS_QUORUM: ['jev.consensus.quorum', Number],
  JEV_CONSENSUS_TIMEOUT_MS: ['jev.consensus.timeoutMs', Number],
  JEV_LEDGER_ENABLED: ['jev.ledger.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  JEV_LEDGER_MAX_BYTES_PER_DAY: ['jev.ledger.maxBytesPerDay', Number],
  JEV_LEDGER_KEEP_DAYS: ['jev.ledger.keepDays', Number],
  BB_WORKER_URL: ['worker.baseUrl', String],
  BB_WORKER_ENABLED: ['worker.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  BB_WORKER_LLM: ['worker.useForModel', (v) => /^(1|true|yes)$/i.test(String(v))],
  BB_WORKER_DATA: ['worker.useForData', (v) => /^(1|true|yes)$/i.test(String(v))],
  BB_WORKER_TIMEOUT_MS: ['worker.timeoutMs', Number],
  LAWYER_ENABLED: ['lawyer.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  LAWYER_AUDIT_INTERVAL_MS: ['lawyer.auditIntervalMs', Number],
  LAWYER_AUTO_OBJECT: ['lawyer.autoObject', (v) => /^(1|true|yes)$/i.test(String(v))],
  LAWYER_BENCHMARK_ANNUAL_PCT: ['lawyer.benchmarkAnnualPct', Number],
  LAWYER_DSR_THRESHOLD: ['lawyer.dsrThreshold', Number],
  TRIALS_ENABLED: ['trials.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  STRATEGIST_ENABLED: ['strategist.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  STRATEGIST_INTERVAL_MS: ['strategist.intervalMs', Number],
  STRATEGIST_RESPONSE_WINDOW_MS: ['strategist.responseWindowMs', Number],
  STRATEGIST_LIVE_REPORT: ['strategist.liveReport', (v) => /^(1|true|yes)$/i.test(String(v))],
  STRATEGIST_CRISIS_AUTHORITY: ['strategist.authority.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  STRATEGIST_MAX_ACTIONS_PER_HOUR: ['strategist.authority.maxActionsPerHour', Number],
  STRATEGIST_MAX_RISK_DELTA_PCT: ['strategist.authority.maxRiskDeltaPct', Number],
  STRATEGIST_OVERLAY_TTL_MS: ['strategist.authority.overlayTtlMs', Number],
  STRATEGIST_PUBLISH: ['strategist.publish.mode', String],
  STRATEGIST_PUBLISH_INTERVAL_MS: ['strategist.publish.intervalMs', Number],
  HL_MODE: ['hyperliquid.mode', String],
  HL_SLIPPAGE_BPS: ['hyperliquid.slippageBps', Number],
  HL_MAX_NOTIONAL_USD: ['hyperliquid.maxNotionalUsd', Number],

  // ---- panel-tunable risk & strategy knobs --------------------------------
  // Everything an operator realistically wants to change without editing a file
  // on the server. Each one is a plain scalar so the panel's variables editor
  // can set it; nothing here can raise a hard safety ceiling (the code caps
  // those independently).
  RISK_PER_TRADE_PCT: ['risk.riskPerTradePct', Number],
  MAX_SYMBOL_EXPOSURE_PCT: ['risk.maxSymbolExposurePct', Number],
  MAX_NET_EXPOSURE_PCT: ['risk.maxNetExposurePct', Number],
  MAX_CONSECUTIVE_LOSSES: ['risk.maxConsecutiveLosses', Number],
  COOLDOWN_AFTER_LOSS_MS: ['risk.cooldownAfterLossMs', Number],
  MIN_NOTIONAL_USD: ['risk.minNotionalUsd', Number],
  USE_RISK_SIZING: ['risk.useRiskSizing', (v) => /^(1|true|yes)$/i.test(String(v))],
  MAX_POSITIONS: ['strategy.rotator.maxPositions', Number],
  CORE_PCT: ['strategy.rotator.corePct', Number],
  CORE_TOP: ['strategy.rotator.coreTop', Number],
  DISASTER_STOP_ATR: ['strategy.rotator.disasterStopAtr', Number],
  // Trailing stop: panel-tunable so the trail can be widened, tightened or
  // switched off without touching a file on the server.
  TRAIL_ENABLED: ['strategy.rotator.trailEnabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  TRAIL_START_ATR: ['strategy.rotator.trailStartAtr', Number],
  TRAIL_DISTANCE_ATR: ['strategy.rotator.trailDistanceAtr', Number],
  // Charter §12 trailing ladder — panel-tunable, no file edit on the server.
  TRAIL_BE_AT_R: ['strategy.rotator.trailBeAtR', Number],
  TRAIL_LOCK_AT_R: ['strategy.rotator.trailLockAtR', Number],
  TRAIL_LOCK_R: ['strategy.rotator.trailLockR', Number],
  TRAIL_ATR: ['strategy.rotator.trailAtr', Number],
  GATE_SYMBOL: ['strategy.rotator.gateSymbol', String],
  VOL_FLOOR: ['strategy.rotator.volFloor', Number],
  VOL_CAP: ['strategy.rotator.volCap', Number],
  MIN_RR: ['strategy.minRR', Number],
  MIN_TP_BPS: ['strategy.minTpBps', Number],
  MAX_TP_BPS: ['strategy.maxTpBps', Number],
  MIN_SL_BPS: ['strategy.minSlBps', Number],
  MAX_SL_BPS: ['strategy.maxSlBps', Number],
  ALLOW_SHORT: ['strategy.allowShort', (v) => /^(1|true|yes)$/i.test(String(v))],
  USE_BREADTH_GATE: ['strategy.useBreadthGate', (v) => /^(1|true|yes)$/i.test(String(v))],
  BREADTH_MIN: ['strategy.breadthMin', Number],
  SLIPPAGE_BPS_PER_1K: ['fees.slippageBpsPer1kNotional', Number],
  STALE_QUOTE_MS: ['data.staleQuoteMs', Number],
  SCAN_INTERVAL_MS: ['scout.scanIntervalMs', Number],
  PROPOSAL_TTL_MS: ['scout.proposalTtlMs', Number],
  MAX_PROPOSALS_PER_CYCLE: ['scout.maxProposalsPerCycle', Number],

  // ---- sleeves: each can be switched on from the panel --------------------
  SLEEVE_DONCHIAN: ['strategy.rotator.sleeves.donchian.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  SLEEVE_MEANREV: ['strategy.rotator.sleeves.meanrev.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  SLEEVE_CARRY: ['strategy.rotator.sleeves.carry.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],

  // ---- the watch (دیده‌بان): opportunity discovery ------------------------
  // NOTE: this block used to appear TWICE in ENV_MAP. A duplicate key in an
  // object literal is silently overwritten, so the second copy won and any
  // variable added to the first was dead. One block, one source of truth.
  WATCH_ENABLED: ['watch.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  WATCH_INTERVAL_MS: ['watch.intervalMs', Number],
  WATCH_UNIVERSE: ['watch.universe', (v) => String(v).split(',').map((s) => s.trim().toUpperCase()).filter(Boolean)],
  WATCH_SCAN_LIMIT: ['watch.scanLimit', Number],
  WATCH_MAX_CANDIDATES: ['watch.maxCandidates', Number],
  WATCH_MIN_QUOTE_VOLUME_USD: ['watch.minQuoteVolumeUsd', Number],
  WATCH_MIN_EDGE_BPS: ['watch.minEdgeBps', Number],
  WATCH_STAGNANT_DAYS: ['watch.stagnantDays', Number],
  WATCH_STAGNANT_RETURN_PCT: ['watch.stagnantReturnPct', Number],
  WATCH_AUTO_APPLY: ['watch.autoApply', (v) => /^(1|true|yes)$/i.test(String(v))],
  WATCH_REQUIRE_COUNCIL: ['watch.requireCouncil', (v) => /^(1|true|yes)$/i.test(String(v))],
  WATCH_MAX_SWAPS_PER_CYCLE: ['watch.maxSwapsPerCycle', Number],
  WATCH_MIN_MOMENTUM_PCT: ['watch.minMomentumPct', Number],
  WATCH_MIN_TREND_QUALITY: ['watch.minTrendQuality', Number],
  WATCH_LOOKBACK_BARS: ['watch.lookbackBars', Number],
  JEV_KEYLESS_FALLBACK: ['jev.keylessFallback', (v) => String(v).split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)],
  JEV_ALLOW_LOCAL: ['jev.allowLocal', (v) => /^(1|true|yes)$/i.test(String(v))],
  // ---- the live advisor (heal) -------------------------------------------
  // ADVISOR_URL / ADVISOR_MODEL / ADVISOR_ENABLED are applied after the merge
  // (see loadConfig), because "give me an endpoint and it turns on" is the rule
  // an operator expects. ADVISOR_CHAT_PATH is here because Pollinations serves
  // its OpenAI-compatible endpoint at /openai, not /v1/chat/completions.
  ADVISOR_CHAT_PATH: ['heal.model.chatPath', String],
  ADVISOR_TIMEOUT_MS: ['heal.model.timeoutMs', Number],

  // ---- the apprentice (کارآموز) -------------------------------------------
  APPRENTICE_ENABLED: ['apprentice.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  APPRENTICE_MAX_BYTES_PER_DAY: ['apprentice.maxBytesPerDay', Number],
  APPRENTICE_MAX_OPEN_QUESTIONS: ['apprentice.maxOpenQuestions', Number],
  APPRENTICE_REQUIRE_REASON: ['apprentice.requireReason', (v) => /^(1|true|yes)$/i.test(String(v))],
  APPRENTICE_MIN_REASON_CHARS: ['apprentice.minReasonChars', Number],

  // ---- market intel (اخبار و هوش بازار) -----------------------------------
  // A feed with no URL is skipped, so setting only INTEL_ENABLED=true does
  // nothing until at least one URL is provided. That is deliberate: an
  // "enabled" module with no data would be a lie on the dashboard.
  INTEL_ENABLED: ['intel.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  INTEL_REFRESH_MS: ['intel.refreshMs', Number],
  INTEL_TIMEOUT_MS: ['intel.timeoutMs', Number],
  INTEL_RETRY_429: ['intel.retry429', Number],
  INTEL_RETRY_DELAY_MS: ['intel.retryDelayMs', Number],
  INTEL_BLACKOUT_BEFORE_MS: ['intel.blackoutBeforeMs', Number],
  INTEL_BLACKOUT_AFTER_MS: ['intel.blackoutAfterMs', Number],
  INTEL_EXTREME_THRESHOLD: ['intel.extremeThreshold', Number],
  INTEL_MAX_RISK_IMPACT: ['intel.maxRiskImpact', Number],
  INTEL_MACRO_URL: ['intel.feeds.macro.url', String],
  INTEL_MACRO_PATH: ['intel.feeds.macro.path', String],
  INTEL_MACRO_WEIGHT: ['intel.feeds.macro.weight', Number],
  INTEL_MACRO_FORMAT: ['intel.feeds.macro.format', String],
  INTEL_MACRO_FALLBACK_URL: ['intel.feeds.macro.fallbackUrl', String],
  INTEL_GEO_URL: ['intel.feeds.geo.url', String],
  INTEL_GEO_PATH: ['intel.feeds.geo.path', String],
  INTEL_GEO_WEIGHT: ['intel.feeds.geo.weight', Number],
  INTEL_GEO_FORMAT: ['intel.feeds.geo.format', String],
  INTEL_GEO_FALLBACK_URL: ['intel.feeds.geo.fallbackUrl', String],
  INTEL_WEATHER_URL: ['intel.feeds.weather.url', String],
  INTEL_WEATHER_PATH: ['intel.feeds.weather.path', String],
  INTEL_WEATHER_WEIGHT: ['intel.feeds.weather.weight', Number],
  INTEL_WEATHER_FORMAT: ['intel.feeds.weather.format', String],
  INTEL_WEATHER_FALLBACK_URL: ['intel.feeds.weather.fallbackUrl', String],
  // Crypto-native and wire-service families. Same shape as the three above, so
  // an operator who already knows INTEL_MACRO_* needs no new mental model.
  INTEL_CRYPTO_URL: ['intel.feeds.crypto.url', String],
  INTEL_CRYPTO_WEIGHT: ['intel.feeds.crypto.weight', Number],
  INTEL_CRYPTO_FORMAT: ['intel.feeds.crypto.format', String],
  INTEL_CRYPTO_FALLBACK_URL: ['intel.feeds.crypto.fallbackUrl', String],
  INTEL_WIRE_URL: ['intel.feeds.wire.url', String],
  INTEL_WIRE_WEIGHT: ['intel.feeds.wire.weight', Number],
  INTEL_WIRE_FORMAT: ['intel.feeds.wire.format', String],
  INTEL_WIRE_FALLBACK_URL: ['intel.feeds.wire.fallbackUrl', String],

  // ---- historical analog (نظیر تاریخی) ------------------------------------
  ANALOG_ENABLED: ['analog.enabled', (v) => /^(1|true|yes)$/i.test(String(v))],
  ANALOG_K: ['analog.k', Number],
  ANALOG_MIN_SAMPLES: ['analog.minSamples', Number],
  ANALOG_MAX_DISTANCE: ['analog.maxDistance', Number],
  ANALOG_MIN_WIN_RATE: ['analog.minWinRate', Number],
  ANALOG_MAX_HISTORY: ['analog.maxHistory', Number],
};

function deepMerge(base, extra) {
  if (extra === undefined || extra === null) return base;
  if (Array.isArray(base) || Array.isArray(extra)) return extra;
  if (typeof base !== 'object' || typeof extra !== 'object') return extra;
  const out = { ...base };
  for (const k of Object.keys(extra)) out[k] = deepMerge(base[k], extra[k]);
  return out;
}

/**
 * Dotted paths present in `user` that do not exist in `defaults`.
 * deepMerge drops them silently, so a typo in config.json used to look like a
 * setting that simply had no effect.
 */
function unknownKeys(user, defaults, prefix = '') {
  const out = [];
  if (!user || typeof user !== 'object' || Array.isArray(user)) return out;
  for (const [k, v] of Object.entries(user)) {
    const key = prefix ? `${prefix}.${k}` : k;
    const has = defaults && Object.prototype.hasOwnProperty.call(defaults, k);
    if (!has) {
      out.push(key);
      continue;
    }
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      out.push(...unknownKeys(v, defaults[k], key));
    }
  }
  return out;
}

function setPath(obj, dotted, value) {
  const parts = dotted.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (typeof cur[parts[i]] !== 'object' || cur[parts[i]] === null) cur[parts[i]] = {};
    cur = cur[parts[i]];
  }
  cur[parts[parts.length - 1]] = value;
}

function loadConfig(overrides = {}) {
  loadDotEnv(process.env.BB_ENV_FILE || path.join(ROOT, '.env'));
  let cfg = JSON.parse(JSON.stringify(DEFAULTS));

  const cfgPath = process.env.BB_CONFIG || path.join(ROOT, 'config.json');
  if (fs.existsSync(cfgPath)) {
    try {
      const user = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      // A key that exists in config.json but not in DEFAULTS is silently dropped
      // by deepMerge. That is how `witness.updateMs` and `PROFILE` sat in the
      // shipped config.json doing nothing at all. Say so instead of hiding it.
      for (const bad of unknownKeys(user, DEFAULTS)) {
        console.error(`[config] config.json key "${bad}" is not a known setting and was ignored`);
      }
      cfg = deepMerge(cfg, user);
    } catch (e) {
      console.error(`[config] config.json is not valid JSON, ignoring it: ${e.message}`);
    }
  }

  for (const [envKey, [dotted, cast]] of Object.entries(ENV_MAP)) {
    const raw = process.env[envKey];
    if (raw === undefined || raw === '') continue;
    const value = cast(raw);
    if (typeof value === 'number' && Number.isNaN(value)) {
      console.error(`[config] env ${envKey} is not a number, ignoring`);
      continue;
    }
    setPath(cfg, dotted, value);
  }

  cfg = deepMerge(cfg, overrides);

  // ---- profile: BlackBird (default, unchanged) or AngryBird ---------------
  // The AngryBird overlay is authoritative for its scenario ($100 start, $25
  // nominal ceiling, court limits): it is applied AFTER env/config so an
  // inherited START_EQUITY=5000 cannot quietly turn the $100 scenario into a
  // $5000 one. BlackBird takes no overlay at all.
  applyProfile(cfg, { env: process.env, defaults: DEFAULTS, pkgVersion: PKG_VERSION, root: ROOT });

  // ---- supervisor: an endpoint is the switch ------------------------------
  // config.json ships `supervisor.enabled: false` so the engine is keyless and
  // offline by default. But that file value would also override the env-derived
  // default, so setting only SUPERVISOR_URL would silently do nothing. The rule
  // the operator expects is: "give me an endpoint and it turns on". Apply it
  // after the merge, and let an explicit SUPERVISOR_ENABLED win either way.
  if (process.env.SUPERVISOR_ENABLED !== undefined && process.env.SUPERVISOR_ENABLED !== '') {
    cfg.supervisor.enabled = /^(1|true|yes)$/i.test(String(process.env.SUPERVISOR_ENABLED));
  } else if (process.env.SUPERVISOR_URL) {
    cfg.supervisor.enabled = true;
  }
  if (!cfg.supervisor.url) cfg.supervisor.enabled = false;

  // ---- self-healing supervisor: env parity, same variable names ----------
  // HEAL_ENABLED / HEAL_FALLBACKS control the rules; ADVISOR_URL (plus optional
  // ADVISOR_MODEL and ADVISOR_API_KEY_ENV) is what lets a model be consulted.
  // No endpoint means rules only — never a call to a service we do not have.
  if (process.env.HEAL_ENABLED !== undefined && process.env.HEAL_ENABLED !== '') {
    cfg.heal.enabled = /^(1|true|yes)$/i.test(String(process.env.HEAL_ENABLED));
  }
  if (process.env.HEAL_FALLBACKS) {
    cfg.heal.fallbackExchanges = String(process.env.HEAL_FALLBACKS)
      .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  }
  if (process.env.ADVISOR_URL) {
    cfg.heal.model.baseUrl = process.env.ADVISOR_URL;
    cfg.heal.model.enabled = true;
  }
  if (process.env.ADVISOR_MODEL) cfg.heal.model.model = process.env.ADVISOR_MODEL;
  if (process.env.ADVISOR_API_KEY_ENV) cfg.heal.model.apiKeyEnv = process.env.ADVISOR_API_KEY_ENV;
  if (process.env.ADVISOR_ENABLED !== undefined && process.env.ADVISOR_ENABLED !== '') {
    cfg.heal.model.enabled = /^(1|true|yes)$/i.test(String(process.env.ADVISOR_ENABLED));
  }
  // A keyless endpoint (Pollinations) must not be blocked by the "missing key"
  // guard in heal.js. The catalog decides, not a hard-coded list.
  if (cfg.heal.model.baseUrl && !cfg.heal.model.chatPath) {
    cfg.heal.model.chatPath = /pollinations\.ai/i.test(cfg.heal.model.baseUrl) ? '/openai' : '/chat/completions';
  }

  const TF_MS = { '1m': 60000, '3m': 180000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000 };
  if (cfg.data.timeframe) cfg.data.intervalMs = TF_MS[cfg.data.timeframe] || cfg.data.intervalMs;
  cfg.root = ROOT;
  cfg.configPath = cfgPath;

  // derived defaults
  if (cfg.runtime.dataDir && cfg.runtime.dataDir !== DEFAULTS.runtime.dataDir) {
    cfg.runtime.stateFile = path.join(cfg.runtime.dataDir, 'state.json');
    cfg.runtime.journalFile = path.join(cfg.runtime.dataDir, 'journal.jsonl');
    cfg.runtime.logDir = path.join(cfg.runtime.dataDir, 'logs');
    // Reports follow the data directory. In a container the app tree is often
    // read-only (or owned by root while the process runs as `node`), so writing
    // reports next to the source fails with EACCES and the dashboard's report
    // panel stays empty. DATA_DIR is the one path the operator guarantees is
    // writable, so reports belong under it unless explicitly overridden.
    if (!process.env.REPORT_DIR && cfg.reporter.dir === DEFAULTS.reporter.dir) {
      cfg.reporter.dir = path.join(cfg.runtime.dataDir, 'reports');
    }
  }
  if (process.env.REPORT_DIR) cfg.reporter.dir = process.env.REPORT_DIR;

  // The trial registry lives next to the journal: same durability, same backup.
  if (!cfg.trials.file) {
    const dir = cfg.runtime.dataDir || path.join(ROOT, 'data');
    cfg.trials.file = path.join(dir, 'trials.jsonl');
  }

  return cfg;
}

/** Human-readable, side-effect free validation. */
function validateConfig(cfg) {
  const problems = [];
  const warn = [];

  if (!['paper', 'live'].includes(cfg.mode)) problems.push(`mode must be paper|live (got ${cfg.mode})`);
  if (!cfg.symbols || cfg.symbols.length < 2) problems.push('need at least 2 symbols');
  if (cfg.symbols && cfg.symbols.length > 8) warn.push('more than 8 symbols will thin out the data budget');

  if (cfg.mode === 'live') {
    if (!cfg.keys || !cfg.keys.apiKey || !cfg.keys.apiSecret) {
      problems.push('live mode requires API_KEY and API_SECRET');
    }
    if (process.env.BB_I_UNDERSTAND_REAL_MONEY !== 'YES') {
      problems.push('live mode requires BB_I_UNDERSTAND_REAL_MONEY=YES (safety interlock)');
    }
  }

  // A profile that was asked for must exist, and AngryBird never trades live code
  // paths on its own: real capital needs independent validation, a paper run and
  // the emergency stop to be verified first (a human change, not a flag).
  if (cfg.profile && cfg.profile.name === 'angrybird' && cfg.mode !== 'paper') {
    problems.push('profile angrybird is paper-only; live trading is not enabled for it');
  }
  if (cfg.server && !(Number.isInteger(cfg.server.port) && cfg.server.port >= 0 && cfg.server.port <= 65535)) {
    problems.push(`server.port must be 0 (auto) or 1-65535 (got ${cfg.server.port})`);
  }

  const s = cfg.strategy;
  if (!(s.minTpBps > 0) || !(s.maxTpBps >= s.minTpBps)) {
    problems.push('strategy.minTpBps must be > 0 and <= maxTpBps');
  }
  if (!(s.minSlBps > 0) || !(s.maxSlBps >= s.minSlBps)) {
    problems.push('strategy.minSlBps must be > 0 and <= maxSlBps');
  }
  if (cfg.strategy.mode === 'rotator' || cfg.strategy.mode === 'hybrid') {
    const rc = cfg.strategy.rotator || {};
    if (!(rc.perPositionPct > 0) || rc.perPositionPct > 50) {
      problems.push(`strategy.rotator.perPositionPct must be in (0, 50] (got ${rc.perPositionPct})`);
    }
    if (!(rc.maxGrossPct > 0) || rc.maxGrossPct > 300) {
      problems.push(`strategy.rotator.maxGrossPct must be in (0, 300] (got ${rc.maxGrossPct})`);
    }
    if (!Array.isArray(rc.variants) || !rc.variants.length) {
      problems.push('strategy.rotator.variants must be a non-empty array');
    }
  }
  if (cfg.risk.maxPositionPct <= 0 || cfg.risk.maxPositionPct > 0.5) {
    warn.push(`maxPositionPct=${cfg.risk.maxPositionPct} is outside the sane 0..0.5 band`);
  }
  const roundTripBps = cfg.fees.makerBps + cfg.fees.takerBps;
  const minTp = Math.max(s.minTpBps, 0);
  if (minTp <= roundTripBps * 0.8) {
    warn.push(
      `minTpBps=${minTp} barely covers round-trip fees (${roundTripBps}bps); edge will be thin`
    );
  }

  if (cfg.reporter.intervalMs < 60000) warn.push('reporter.intervalMs < 60s is not representative');

  return { ok: problems.length === 0, problems, warnings: warn };
}

function summarise(cfg) {
  const f = (n) => n.toString();
  return [
    `mode=${cfg.mode}  exchange=${cfg.exchange}  witness=${cfg.witnessExchange}`,
    `symbols=${cfg.symbols.join(',')}`,
    `equity=${f(cfg.risk.startEquity)}  pos/trade<=${(cfg.risk.maxPositionPct * 100).toFixed(0)}%  maxOpen=${cfg.risk.maxOpenPositions}`,
    `daily: loss<=${(cfg.risk.maxDailyLossPct * 100).toFixed(1)}%  trades<=${cfg.risk.maxDailyTrades}`,
    `fees: maker=${cfg.fees.makerBps}bps taker=${cfg.fees.takerBps}bps  latency=${cfg.fees.latencyMs}ms`,
    `report every ${(cfg.reporter.intervalMs / 3600000).toFixed(1)}h -> ${cfg.reporter.dir}`,
  ].join('\n');
}

module.exports = { loadConfig, validateConfig, summarise, DEFAULTS, ROOT };
