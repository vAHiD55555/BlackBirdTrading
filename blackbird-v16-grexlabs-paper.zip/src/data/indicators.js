'use strict';
/**
 * BlackBird — indicators, computed from closed candles only.
 * Input `bars`: [{t, o, h, l, c, v}] oldest -> newest.
 */
const { mean, stdev, emaLast, rollingMean, percentileRank } = require('../core/util');

function rsi(closes, period = 14) {
  if (closes.length < period + 1) return 50;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d;
    else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(d, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-d, 0)) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

/** Wilder ATR. */
function atr(bars, period = 14) {
  if (bars.length < period + 1) return 0;
  const trs = [];
  for (let i = 1; i < bars.length; i++) {
    const b = bars[i];
    const p = bars[i - 1];
    trs.push(Math.max(b.h - b.l, Math.abs(b.h - p.c), Math.abs(b.l - p.c)));
  }
  let v = mean(trs.slice(0, period));
  for (let i = period; i < trs.length; i++) v = (v * (period - 1) + trs[i]) / period;
  return v;
}

function bollinger(closes, period = 20, k = 2) {
  if (closes.length < period) return null;
  const win = closes.slice(-period);
  const mid = mean(win);
  const sd = stdev(win);
  const upper = mid + k * sd;
  const lower = mid - k * sd;
  const last = closes[closes.length - 1];
  const widthBps = mid ? ((upper - lower) / mid) * 10000 : 0;
  const pctB = upper === lower ? 0.5 : (last - lower) / (upper - lower);
  return { mid, upper, lower, sd, widthBps, pctB };
}

function vwap(bars, window = 60) {
  const w = bars.slice(-window);
  let pv = 0;
  let vv = 0;
  for (const b of w) {
    const tp = (b.h + b.l + b.c) / 3;
    pv += tp * b.v;
    vv += b.v;
  }
  return vv ? pv / vv : (w.length ? w[w.length - 1].c : 0);
}

/** Normalised trend strength: |EMA9-EMA21| / ATR, clipped to 5. */
function trendStrength(closes, atrValue) {
  if (closes.length < 21 || !atrValue) return 0;
  const fast = emaLast(closes.slice(-60), 9);
  const slow = emaLast(closes.slice(-120), 21);
  return Math.min(5, Math.abs(fast - slow) / atrValue);
}

/** Realised volatility of 1m log returns, annualisation omitted on purpose. */
function realisedVol(closes, n = 60) {
  const w = closes.slice(-(n + 1));
  if (w.length < 3) return 0;
  const rets = [];
  for (let i = 1; i < w.length; i++) rets.push(Math.log(w[i] / w[i - 1]));
  return stdev(rets);
}

function volumeSpike(bars, n = 20) {
  if (bars.length < n + 1) return 1;
  const prev = bars.slice(-(n + 1), -1).map((b) => b.v);
  const base = mean(prev);
  return base > 0 ? bars[bars.length - 1].v / base : 1;
}

/** Percentile of the current ATR% inside its own recent history. */
function atrPercentile(bars, period = 14, lookback = 240) {
  if (bars.length < period + 20) return 0.5;
  const trs = new Array(bars.length).fill(0);
  for (let i = 1; i < bars.length; i++) {
    const b = bars[i];
    const p = bars[i - 1];
    trs[i] = Math.max(b.h - b.l, Math.abs(b.h - p.c), Math.abs(b.l - p.c));
  }
  // Wilder smoothing, written as a single pass
  const atrSeries = new Array(bars.length).fill(NaN);
  let v = mean(trs.slice(1, period + 1));
  atrSeries[period] = v;
  for (let i = period + 1; i < bars.length; i++) {
    v = (v * (period - 1) + trs[i]) / period;
    atrSeries[i] = v;
  }
  const series = [];
  for (let i = period; i < bars.length; i++) {
    const c = bars[i].c;
    if (c && Number.isFinite(atrSeries[i])) series.push((atrSeries[i] / c) * 10000);
  }
  if (series.length < 5) return 0.5;
  const current = series[series.length - 1];
  return percentileRank(series.slice(-lookback), current);
}

/**
 * One consolidated snapshot. This is the object every agent reasons about,
 * so it must be self-describing and JSON-serialisable (it lands in reports).
 */
function computeSnapshot(bars, cfg, extra = {}) {
  const closes = bars.map((b) => b.c);
  const last = bars[bars.length - 1];
  const a = atr(bars, cfg.atrPeriod);
  const aPct = last.c ? (a / last.c) * 10000 : 0;
  const bb = bollinger(closes, cfg.bbPeriod, cfg.bbStd);
  const r = rsi(closes, cfg.rsiPeriod);
  const vw = vwap(bars, cfg.vwapWindow);
  const vol = realisedVol(closes, 60);
  const ts = trendStrength(closes, a);
  const vSpike = volumeSpike(bars, 20);
  const ema9 = emaLast(closes.slice(-120), 9);
  const ema20 = emaLast(closes.slice(-200), 20);
  const ema200 = emaLast(closes.slice(-300), 200);
  const ema21 = emaLast(closes.slice(-200), 21);
  const ema50 = emaLast(closes.slice(-300), 50);
  const volPct = atrPercentile(bars, cfg.atrPeriod, 240);

  return {
    ts: last.t,
    price: last.c,
    close: last.c,
    open: last.o,
    high: last.h,
    low: last.l,
    volume: last.v,
    bars: bars.length,
    atr: a,
    atrPct: aPct,
    atrPercentile: volPct,
    rsi: r,
    bb,
    vwap: vw,
    vwapDevAtr: a ? (last.c - vw) / a : 0,
    realisedVol: vol,
    trendStrength: ts,
    ema9,
    ema20,
    ema21,
    ema50,
    ema200,
    volumeSpike: vSpike,
    ...extra,
  };
}

module.exports = {
  rsi, atr, bollinger, vwap, trendStrength, realisedVol, volumeSpike,
  atrPercentile, computeSnapshot, rollingMean,
};
