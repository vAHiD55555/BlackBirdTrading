'use strict';
/**
 * BlackBird — Hyperliquid adapter (public market data + venue rules).
 *
 * Hyperliquid is a different animal from Binance and the rest:
 *
 *   - It is an on-chain order book (HyperCore L1), not a CEX REST API.
 *   - Every call is a POST to one of two endpoints, with a JSON body whose
 *     `type` field selects the operation. There is no /api/v3/klines.
 *   - Symbols are bare coins ("BTC"), not pairs ("BTCUSDT"). The quote is
 *     always USDC on the perp book.
 *   - Prices and sizes are NOT free-form: a price may carry at most 5
 *     significant figures and at most (6 - szDecimals) decimals; a size is
 *     rounded to szDecimals. Sending anything else is rejected by the venue.
 *
 * Everything here is read-only. Order placement lives in
 * `src/exec/hyperliquid-broker.js`, because it needs signing.
 *
 * Sources (verified 2026-11-12):
 *   https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint
 *   https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/tick-and-lot-size
 *   https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/rate-limits-and-user-limits
 */

const { getFetch } = require('./fetch-compat');

const INFO_URL = 'https://api.hyperliquid.xyz/info';
const EXCHANGE_URL = 'https://api.hyperliquid.xyz/exchange';

/**
 * Canonical timeframe -> Hyperliquid interval.
 * Hyperliquid accepts these strings directly; the map exists so an unknown
 * timeframe fails loudly here instead of silently returning 1m candles.
 */
const HL_INTERVALS = {
  '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m',
  '1h': '1h', '2h': '2h', '4h': '4h', '8h': '8h', '12h': '12h',
  '1d': '1d', '3d': '3d', '1w': '1w', '1M': '1M',
};

const INTERVAL_MS = {
  '1m': 60000, '3m': 180000, '5m': 300000, '15m': 900000, '30m': 1800000,
  '1h': 3600000, '2h': 7200000, '4h': 14400000, '8h': 28800000,
  '12h': 43200000, '1d': 86400000, '3d': 259200000, '1w': 604800000,
};

/** Quote suffixes we strip to get from "BTCUSDT" to "BTC". */
const QUOTE_SUFFIXES = ['USDT', 'USDC', 'USD', 'BUSD', 'FDUSD'];

/**
 * "BTCUSDT" -> "BTC".  "BTC" -> "BTC".  "PURR/USDC" -> "PURR/USDC" (spot).
 *
 * The project's config speaks Binance pairs; Hyperliquid speaks coins. Doing
 * the translation in one place means the engine, the risk module, the lawyer
 * and the ledger never learn that the venue changed.
 */
function toCoin(symbol) {
  const s = String(symbol || '').trim().toUpperCase();
  if (!s) return s;
  if (s.includes('/')) return s; // already a spot pair
  for (const q of QUOTE_SUFFIXES) {
    if (s.length > q.length && s.endsWith(q)) return s.slice(0, -q.length);
  }
  return s;
}

/** "BTC" -> "BTCUSDT" (the project's canonical form). */
function toSymbol(coin, quote = 'USDT') {
  const c = String(coin || '').trim().toUpperCase();
  if (!c) return c;
  if (c.includes('/')) return c;
  return `${c}${quote}`;
}

// ---------------------------------------------------------------------------
// Venue rules: price and size quantisation
// ---------------------------------------------------------------------------

/**
 * Round a price to what Hyperliquid will accept.
 *
 * Rule (perps): at most 5 significant figures, and at most
 * (6 - szDecimals) decimal places. Integer prices are always allowed.
 *
 * @param {number} price
 * @param {number} szDecimals  from the `meta` response
 * @param {boolean} [isSpot]   spot allows 8 - szDecimals decimals
 * @returns {number}
 */
function roundPrice(price, szDecimals, isSpot = false) {
  const p = Number(price);
  if (!Number.isFinite(p) || p <= 0) return NaN;
  const maxDecimals = (isSpot ? 8 : 6) - (Number(szDecimals) || 0);
  if (maxDecimals < 0) return NaN;

  // Integer prices are always valid, whatever their significant figures.
  if (Number.isInteger(p)) return p;

  // 5 significant figures.
  const sig = Number(p.toPrecision(5));
  // Then clamp the decimal places.
  const factor = 10 ** Math.max(0, maxDecimals);
  const out = Math.round(sig * factor) / factor;
  return out > 0 ? out : NaN;
}

/**
 * Round a size to the asset's szDecimals.
 * @param {number} qty
 * @param {number} szDecimals
 * @returns {number}
 */
function roundSize(qty, szDecimals) {
  const q = Number(qty);
  if (!Number.isFinite(q) || q <= 0) return NaN;
  const d = Math.max(0, Math.min(8, Number(szDecimals) || 0));
  const factor = 10 ** d;
  const out = Math.floor(q * factor) / factor; // floor: never over-size
  return out > 0 ? out : NaN;
}

/** Smallest size increment for an asset. */
function lotSize(szDecimals) {
  return 10 ** -Math.max(0, Math.min(8, Number(szDecimals) || 0));
}

// ---------------------------------------------------------------------------
// Error mapping
// ---------------------------------------------------------------------------

/**
 * Hyperliquid answers HTTP 200 with an error body for some failures, and a
 * non-200 for others. Both must surface as the same shape the Binance adapter
 * produces, so the layers above cannot tell the venues apart:
 *
 *   Error("HTTP 429 <url> :: <body>")
 *
 * `code` is attached for the retry logic: 'rate_limited' | 'auth' | 'venue' |
 * 'network' | 'unknown'.
 */
function mapError(status, url, body) {
  const text = typeof body === 'string' ? body : JSON.stringify(body || {});
  const err = new Error(`HTTP ${status} ${url} :: ${text.slice(0, 200)}`);
  err.status = status;
  err.body = text;
  if (status === 429) err.code = 'rate_limited';
  else if (status === 401 || status === 403) err.code = 'auth';
  else if (status >= 500) err.code = 'venue';
  else if (status === 0) err.code = 'network';
  else err.code = 'venue';
  return err;
}

/** True when a Hyperliquid response body is actually an error. */
function isErrorBody(body) {
  if (!body || typeof body !== 'object') return false;
  if (body.status === 'err') return true;
  if (typeof body.error === 'string' && body.error) return true;
  return false;
}

// ---------------------------------------------------------------------------
// HTTP client (POST-only, weight-aware)
// ---------------------------------------------------------------------------

/**
 * Hyperliquid rate limits are WEIGHT based: 1200 weight per minute per IP.
 *   l2Book, allMids, clearinghouseState, orderStatus  -> weight 2
 *   candleSnapshot                                    -> weight 20 + 1/60 items
 *   everything else documented                        -> weight 20
 *
 * The limiter below is a token bucket in weight units, so a burst of candle
 * requests cannot starve the quote poller.
 */
class WeightLimiter {
  constructor({ weightPerMin = 1200, burst = 600 } = {}) {
    this.rate = weightPerMin / 60; // weight per second
    this.capacity = burst;
    this.tokens = burst;
    this.last = Date.now();
    this.queue = Promise.resolve();
  }

  take(weight = 1) {
    this.queue = this.queue.then(async () => {
      for (;;) {
        const t = Date.now();
        this.tokens = Math.min(this.capacity, this.tokens + ((t - this.last) / 1000) * this.rate);
        this.last = t;
        if (this.tokens >= weight) { this.tokens -= weight; return; }
        const need = (weight - this.tokens) / this.rate;
        await new Promise((r) => setTimeout(r, Math.min(500, Math.max(20, need * 1000))));
      }
    });
    return this.queue;
  }
}

class HyperliquidHttp {
  constructor({ timeoutMs = 10000, retries = 2, limiter } = {}) {
    this.timeoutMs = timeoutMs;
    this.retries = retries;
    this.limiter = limiter || new WeightLimiter();
    this.fetch = getFetch();
    this.stats = { ok: 0, fail: 0, lastError: null, weightUsed: 0 };
  }

  /**
   * POST a JSON body to an endpoint.
   * @param {string} url
   * @param {object} body
   * @param {number} [weight]
   */
  async post(url, body, weight = 20) {
    let lastErr;
    for (let attempt = 0; attempt <= this.retries; attempt++) {
      await this.limiter.take(weight);
      this.stats.weightUsed += weight;
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), this.timeoutMs);
      try {
        const res = await this.fetch(url, {
          method: 'POST',
          signal: ac.signal,
          headers: { 'content-type': 'application/json', accept: 'application/json' },
          body: JSON.stringify(body),
        });
        const text = await res.text();
        if (!res.ok) {
          lastErr = mapError(res.status, url, text);
          // 4xx other than 429 will not get better by retrying.
          if (res.status !== 429 && res.status < 500) throw lastErr;
          throw lastErr;
        }
        this.stats.ok++;
        const parsed = text ? JSON.parse(text) : {};
        if (isErrorBody(parsed)) {
          const e = mapError(res.status, url, parsed);
          e.code = 'venue';
          throw e;
        }
        return parsed;
      } catch (e) {
        lastErr = e;
        this.stats.fail++;
        this.stats.lastError = e.message;
        if (attempt === this.retries) throw e;
        await new Promise((r) => setTimeout(r, 300 * 2 ** attempt + Math.random() * 200));
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastErr;
  }

  info(body, weight) { return this.post(INFO_URL, body, weight); }
  exchange(body, weight) { return this.post(EXCHANGE_URL, body, weight); }
}

// ---------------------------------------------------------------------------
// Public market data
// ---------------------------------------------------------------------------

class HyperliquidPublic {
  constructor({ http, log } = {}) {
    this.http = http || new HyperliquidHttp();
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this._meta = null;      // { universe: [{name, szDecimals, maxLeverage}] }
    this._metaAt = 0;
    this._coinIndex = new Map();
  }

  /** Load (and cache) the perp universe. Needed for szDecimals and asset ids. */
  async meta({ maxAgeMs = 10 * 60 * 1000 } = {}) {
    if (this._meta && Date.now() - this._metaAt < maxAgeMs) return this._meta;
    const d = await this.http.info({ type: 'meta' }, 20);
    this._meta = d;
    this._metaAt = Date.now();
    this._coinIndex = new Map();
    (d.universe || []).forEach((u, i) => {
      if (u && u.name) this._coinIndex.set(u.name, { ...u, index: i });
    });
    return d;
  }

  /** Asset metadata for a coin, or null when the venue does not list it. */
  async asset(coin) {
    await this.meta();
    return this._coinIndex.get(toCoin(coin)) || null;
  }

  /** Asset id used in order actions (perps: index in `universe`). */
  async assetId(coin) {
    const a = await this.asset(coin);
    return a ? a.index : null;
  }

  /**
   * Candles, oldest -> newest, in the project's bar shape {t,o,h,l,c,v}.
   *
   * Hyperliquid returns at most 500 elements per time-range response, so a
   * 900-bar bootstrap is paginated. Without this the rotator would silently
   * compute momentum on a truncated series.
   */
  async klines(symbol, limit = 300, interval = '1m') {
    const coin = toCoin(symbol);
    const iv = HL_INTERVALS[interval];
    if (!iv) throw new Error(`hyperliquid: unsupported interval "${interval}"`);
    const step = INTERVAL_MS[iv] || 60000;
    const want = Math.max(1, Math.min(5000, Number(limit) || 300));

    const out = [];
    let endTime = Date.now();
    let guard = 0;

    while (out.length < want && guard++ < 20) {
      const need = want - out.length;
      const pageSize = Math.min(500, need);
      const startTime = endTime - pageSize * step;
      const rows = await this.http.info(
        { type: 'candleSnapshot', req: { coin, interval: iv, startTime, endTime } },
        20 + Math.ceil(pageSize / 60)
      );
      if (!Array.isArray(rows) || !rows.length) break;

      const bars = rows.map((r) => ({
        t: Number(r.t),
        o: Number(r.o),
        h: Number(r.h),
        l: Number(r.l),
        c: Number(r.c),
        v: Number(r.v),
      })).filter((b) => Number.isFinite(b.t) && Number.isFinite(b.c));

      // Prepend: we are walking backwards in time.
      out.unshift(...bars);
      const oldest = bars[0]?.t;
      if (!oldest) break;
      endTime = oldest - 1;
      if (bars.length < pageSize) break; // no more history
    }

    // De-duplicate (page boundaries can overlap) and sort ascending.
    const seen = new Set();
    const clean = [];
    for (const b of out) {
      if (seen.has(b.t)) continue;
      seen.add(b.t);
      clean.push(b);
    }
    clean.sort((a, b) => a.t - b.t);
    return clean.slice(-want);
  }

  /**
   * Best bid/ask for one coin.
   *
   * Hyperliquid has no single "ticker" call: `allMids` gives the mid only, and
   * `l2Book` gives the levels. We need both, because the paper broker prices
   * fills off the real book and the risk layer needs a spread.
   */
  async ticker(symbol) {
    const coin = toCoin(symbol);
    const [book, mids] = await Promise.all([
      this.http.info({ type: 'l2Book', coin }, 2),
      this.http.info({ type: 'allMids' }, 2),
    ]);
    const levels = book?.levels || [];
    const bids = levels[0] || [];
    const asks = levels[1] || [];
    const bid = bids.length ? Number(bids[0].px) : NaN;
    const ask = asks.length ? Number(asks[0].px) : NaN;
    const mid = Number(mids?.[coin]);
    const last = Number.isFinite(mid) ? mid : (Number.isFinite(bid) && Number.isFinite(ask) ? (bid + ask) / 2 : NaN);
    if (!Number.isFinite(bid) || !Number.isFinite(ask)) {
      throw new Error(`hyperliquid: no book for ${coin}`);
    }
    return { symbol: toSymbol(coin), bid, ask, last, ts: Date.now() };
  }

  /**
   * Batch quotes. `allMids` is one call for every coin, but it carries no
   * bid/ask, so the spread is approximated from the mid and the venue's
   * typical tick. That is honest for a quote poller and cheap; the paper
   * broker still uses the real `depth()` for fills.
   */
  async tickersBatch(symbols) {
    const mids = await this.http.info({ type: 'allMids' }, 2);
    const out = new Map();
    for (const sym of symbols) {
      const coin = toCoin(sym);
      const mid = Number(mids?.[coin]);
      if (!Number.isFinite(mid) || mid <= 0) continue;
      // No bid/ask in allMids. Use a 1bp half-spread as a placeholder and mark
      // it, so nothing downstream mistakes it for a real quote.
      const half = mid * 0.0001;
      out.set(toSymbol(coin), {
        symbol: toSymbol(coin),
        bid: mid - half,
        ask: mid + half,
        last: mid,
        ts: Date.now(),
        syntheticSpread: true,
      });
    }
    return out;
  }

  /** L2 book in the project's {bids:[[p,q]], asks:[[p,q]]} shape. */
  async depth(symbol, limit = 20) {
    const coin = toCoin(symbol);
    const d = await this.http.info({ type: 'l2Book', coin }, 2);
    const levels = d?.levels || [];
    const conv = (arr) => (arr || []).slice(0, limit).map((l) => [Number(l.px), Number(l.sz)]);
    return { bids: conv(levels[0]), asks: conv(levels[1]), ts: Number(d?.time) || Date.now() };
  }

  /**
   * Server time.
   *
   * NOT VERIFIED: the public docs do not document a server-time endpoint for
   * HyperCore. We return local time and say so, rather than inventing a call.
   * Clock skew therefore cannot be measured against this venue — the engine's
   * `maxClockSkewMs` check is a no-op here.
   */
  async serverTime() {
    return Date.now();
  }

  /** Venue health, for the panel. */
  async exchangeStatus() {
    try {
      const d = await this.http.info({ type: 'exchangeStatus' }, 2);
      return { ok: true, ...d };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
}

module.exports = {
  HyperliquidPublic,
  HyperliquidHttp,
  WeightLimiter,
  INFO_URL,
  EXCHANGE_URL,
  HL_INTERVALS,
  INTERVAL_MS,
  toCoin,
  toSymbol,
  roundPrice,
  roundSize,
  lotSize,
  mapError,
  isErrorBody,
};
