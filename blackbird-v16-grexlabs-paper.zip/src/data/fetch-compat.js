'use strict';
/**
 * fetch() compatibility layer.
 * Node 18+ has a global fetch; older runtimes (16 and below, which some free
 * hosts still offer) do not. Rather than dying 2 seconds after boot with
 * "fetch is not defined", we fall back to a minimal node:https client with the
 * same surface: { ok, status, text() }.
 */
const https = require('node:https');
const http = require('node:http');
const { URL } = require('node:url');

function rawRequest(url, { headers = {}, timeoutMs = 8000 } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try {
      u = new URL(url);
    } catch (e) {
      return reject(new Error(`invalid url: ${url}`));
    }
    const lib = u.protocol === 'http:' ? http : https;
    const req = lib.request(
      u,
      { method: 'GET', headers: { accept: 'application/json', 'user-agent': 'blackbird/1.0', ...headers } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          resolve({
            ok: res.statusCode >= 200 && res.statusCode < 300,
            status: res.statusCode,
            headers: res.headers,
            text: async () => text,
          });
        });
      }
    );
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout after ${timeoutMs}ms`)));
    req.on('error', reject);
    req.end();
  });
}

/** Minimal AbortSignal support for the fallback path. */
function withAbort(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(new Error('aborted'));
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(new Error('aborted'));
    signal.addEventListener?.('abort', onAbort, { once: true });
    promise.then(
      (v) => { signal.removeEventListener?.('abort', onAbort); resolve(v); },
      (e) => { signal.removeEventListener?.('abort', onAbort); reject(e); }
    );
  });
}

function getFetch() {
  if (typeof globalThis.fetch === 'function') return globalThis.fetch;
  return (url, opts = {}) => {
    const timeoutMs = opts.timeoutMs || 8000;
    return withAbort(rawRequest(url, { headers: opts.headers, timeoutMs }), opts.signal);
  };
}

const hasNativeFetch = typeof globalThis.fetch === 'function';

module.exports = { getFetch, hasNativeFetch, rawRequest };
