'use strict';
/**
 * BlackBird — market regime classifier.
 *
 * The whole "fishing in muddy water" idea lives here: we only want markets that
 * are *turbulent* (muddy -> mispricings appear) but *liquid and healthy*
 * (we can actually get out). Anything else is noise or a trap.
 *
 * Regimes:
 *   calm   -> too quiet, no edge, do nothing
 *   muddy  -> the hunting ground (default enabled)
 *   trend  -> strong directional flow; mean reversion is dangerous here
 *   toxic  -> wide spreads / thin book / violent spike; hard veto
 */
const { clamp } = require('../core/util');

const R = {
  CALM: 'calm',
  MUDDY: 'muddy',
  TREND: 'trend',
  TOXIC: 'toxic',
};

/**
 * @param {object} snap  output of computeSnapshot()
 * @param {object} book  {bid, ask, bidNotional, askNotional, spreadBps, depthUsd}
 * @param {object} cfg   cfg.strategy
 */
function classify(snap, book, cfg) {
  const reasons = [];
  const spreadBps = book?.spreadBps ?? 0;
  const depthUsd = book?.depthUsd ?? 0;
  const volPct = snap.atrPercentile ?? 0.5;
  const trend = snap.trendStrength ?? 0;

  let toxic = false;
  if (spreadBps > cfg.maxSpreadBps * 1.8) {
    toxic = true;
    reasons.push(`spread ${spreadBps.toFixed(1)}bps >= ${(cfg.maxSpreadBps * 1.8).toFixed(1)} (too wide)`);
  }
  if (depthUsd > 0 && depthUsd < cfg.minDepthUsd * 0.5) {
    toxic = true;
    reasons.push(`depth $${Math.round(depthUsd)} < $${Math.round(cfg.minDepthUsd * 0.5)} (thin book)`);
  }
  if (volPct > 0.985 && trend > 3.2) {
    toxic = true;
    reasons.push(`vol blow-off p${(volPct * 100).toFixed(1)} with trend ${trend.toFixed(1)}`);
  }

  if (toxic) return { regime: R.TOXIC, score: 0, reasons };

  // liquidity gate (soft): we tolerate up to 1.8x the spread budget elsewhere
  const liquid = spreadBps <= cfg.maxSpreadBps && (depthUsd === 0 || depthUsd >= cfg.minDepthUsd);
  const turbulent = volPct >= cfg.minVolPercentile;
  const trending = trend >= cfg.maxTrendStrength;

  let regime;
  let score;
  if (!turbulent) {
    regime = R.CALM;
    score = clamp(volPct / Math.max(cfg.minVolPercentile, 1e-6), 0, 1) * 0.6;
    reasons.push(`vol p${(volPct * 100).toFixed(1)} below gate ${(cfg.minVolPercentile * 100).toFixed(1)}`);
  } else if (trending) {
    regime = R.TREND;
    score = clamp(1 - (trend - cfg.maxTrendStrength) / cfg.maxTrendStrength, 0, 1) * 0.5;
    reasons.push(`trend strength ${trend.toFixed(2)} >= ${cfg.maxTrendStrength}`);
  } else if (!liquid) {
    regime = R.TOXIC;
    score = 0;
    reasons.push(`not liquid enough: spread ${spreadBps.toFixed(1)}bps depth $${Math.round(depthUsd)}`);
  } else {
    regime = R.MUDDY;
    // 0..1: how good the mud is — turbulent, but not insane, and liquid
    const volPart = clamp((volPct - cfg.minVolPercentile) / (0.995 - cfg.minVolPercentile), 0, 1);
    const liqPart = clamp(1 - spreadBps / Math.max(cfg.maxSpreadBps, 1e-6), 0, 1);
    const trendPart = clamp(1 - trend / Math.max(cfg.maxTrendStrength, 1e-6), 0, 1);
    score = 0.45 * volPart + 0.35 * liqPart + 0.2 * trendPart;
    reasons.push(
      `muddy: vol p${(volPct * 100).toFixed(1)}, spread ${spreadBps.toFixed(1)}bps, ` +
        `depth $${Math.round(depthUsd)}, trend ${trend.toFixed(2)}`
    );
  }

  return { regime, score: Math.round(score * 1000) / 1000, reasons };
}

/**
 * Historical analog matching (نظیر تاریخی).
 *
 * The classifier answers "what is the market now". This answers a different
 * question: "when did the market look like this before, and what happened
 * next?" That is the cheapest defence against the swamp — a setup that looks
 * attractive in isolation but has repeatedly failed in this exact shape.
 *
 * Method: a small, explicit feature vector, normalised, compared by weighted
 * Euclidean distance. No model, no training, no key. It is deterministic and
 * auditable, which is what a risk gate must be.
 *
 * Features (all already computed by computeSnapshot):
 *   volPercentile  — where current volatility sits in its own history
 *   trendStrength  — directional flow
 *   rsi            — momentum position
 *   vwapDevAtr     — stretch from the mean
 *   atrPct         — absolute volatility
 *
 * @param {object} snap   current snapshot
 * @param {Array<{snap: object, outcomePct: number, ts?: number}>} history
 * @param {object} [opts] { k, minSamples, maxDistance, weights }
 * @returns {object|null} null when there is not enough history to judge
 */
function findHistoricalAnalog(snap, history, opts = {}) {
  const o = {
    k: 12,
    minSamples: 20,
    maxDistance: 0.55,
    weights: { volPercentile: 1.0, trendStrength: 0.8, rsi: 0.6, vwapDevAtr: 0.7, atrPct: 0.5 },
    ...opts,
  };
  if (!snap || !Array.isArray(history) || history.length < o.minSamples) return null;

  const vec = (s) => ({
    volPercentile: clamp(Number(s?.atrPercentile) || 0, 0, 1),
    trendStrength: clamp((Number(s?.trendStrength) || 0) / 4, 0, 1),
    rsi: clamp((Number(s?.rsi) || 50) / 100, 0, 1),
    vwapDevAtr: clamp(((Number(s?.vwapDevAtr) || 0) + 3) / 6, 0, 1),
    atrPct: clamp((Number(s?.atrPct) || 0) / 5, 0, 1),
  });

  const a = vec(snap);
  const scored = [];
  for (const h of history) {
    if (!h || !h.snap || !Number.isFinite(h.outcomePct)) continue;
    const b = vec(h.snap);
    let sum = 0;
    let wsum = 0;
    for (const [key, w] of Object.entries(o.weights)) {
      const d = a[key] - b[key];
      sum += w * d * d;
      wsum += w;
    }
    const distance = wsum > 0 ? Math.sqrt(sum / wsum) : 1;
    scored.push({ distance, outcomePct: h.outcomePct, ts: h.ts || null });
  }
  if (scored.length < o.minSamples) return null;

  scored.sort((x, y) => x.distance - y.distance);
  const near = scored.slice(0, Math.min(o.k, scored.length));
  const meanDistance = near.reduce((s, x) => s + x.distance, 0) / near.length;
  if (meanDistance > o.maxDistance) {
    // Nothing close enough: say so instead of forcing a false analogy.
    return { matched: false, samples: near.length, meanDistance: Math.round(meanDistance * 1000) / 1000, winRate: null, meanOutcomePct: null };
  }

  const wins = near.filter((x) => x.outcomePct > 0).length;
  const meanOutcome = near.reduce((s, x) => s + x.outcomePct, 0) / near.length;
  return {
    matched: true,
    samples: near.length,
    meanDistance: Math.round(meanDistance * 1000) / 1000,
    winRate: Math.round((wins / near.length) * 1000) / 1000,
    meanOutcomePct: Math.round(meanOutcome * 100) / 100,
    worstOutcomePct: Math.round(Math.min(...near.map((x) => x.outcomePct)) * 100) / 100,
    bestOutcomePct: Math.round(Math.max(...near.map((x) => x.outcomePct)) * 100) / 100,
  };
}

module.exports = { classify, findHistoricalAnalog, REGIMES: R };
