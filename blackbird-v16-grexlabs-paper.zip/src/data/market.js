'use strict';
/**
 * BlackBird — market data hub.
 *
 * Keeps, per symbol: closed 1m candles, the live candle, best bid/ask and a
 * depth snapshot. Prefers a websocket for quotes and falls back to REST
 * polling (free hosts block long-lived sockets often enough to matter).
 */
const { EventEmitter } = require('node:events');
const { Ring, now } = require('../core/util');
const { computeSnapshot } = require('./indicators');

class MarketFeed extends EventEmitter {
  constructor(symbol, exchange, cfg, log) {
    super();
    this.symbol = symbol;
    this.exchange = exchange;
    this.cfg = cfg;
    this.log = log;
    this.maxBars = Math.max(cfg.data.bootstrapBars + 60, 400);
    this.bars = new Ring(this.maxBars);
    this.liveBar = null;
    this.ticker = null; // {bid, ask, last, ts}
    this.depth = null; // {bids, asks, ts}
    this.lastQuoteTs = 0;
    this.lastBarTs = 0;
    this.gapCount = 0;
    this.quoteSource = 'none';
  }

  async bootstrap() {
    const rows = await this.exchange.klines(this.symbol, this.cfg.data.bootstrapBars, this.cfg.data.timeframe);
    this.bars = new Ring(this.maxBars);
    for (const b of rows) this.bars.push(b);
    const last = rows[rows.length - 1];
    this.liveBar = last ? { ...last } : null;
    this.lastBarTs = last ? last.t : 0;
    this.log.info(`bootstrapped ${rows.length} bars`, { symbol: this.symbol, lastClose: last?.c });
    return rows.length;
  }

  /** Ingest a candle row; returns the bar that just closed, if any. */
  ingestBar(bar) {
    let closed = null;
    if (!this.liveBar) {
      this.liveBar = { ...bar };
      this.lastBarTs = bar.t;
      return null;
    }
    if (bar.t === this.liveBar.t) {
      this.liveBar = { ...bar };
      return null;
    }
    if (bar.t > this.liveBar.t) {
      closed = { ...this.liveBar };
      this.bars.push(closed);
      if (bar.t - this.liveBar.t > this.cfg.data.intervalMs) {
        this.gapCount++;
        this.log.warn('candle gap detected', { symbol: this.symbol, from: this.liveBar.t, to: bar.t });
      }
      this.liveBar = { ...bar };
      this.lastBarTs = bar.t;
      this.emit('bar', { symbol: this.symbol, bar: closed, feed: this });
      return closed;
    }
    return null; // older bar, ignore
  }

  setTicker(t) {
    if (!t || !(t.bid > 0) || !(t.ask > 0)) return;
    this.ticker = t;
    this.lastQuoteTs = now();
    this.emit('tick', t);
  }

  setDepth(d) {
    if (!d || !d.bids?.length || !d.asks?.length) return;
    this.depth = d;
  }

  get quoteAgeMs() {
    return this.lastQuoteTs ? now() - this.lastQuoteTs : Infinity;
  }

  get isStale() {
    return this.quoteAgeMs > this.cfg.data.staleQuoteMs;
  }

  book() {
    const t = this.ticker;
    if (!t) return null;
    const mid = (t.bid + t.ask) / 2;
    const spreadBps = mid ? ((t.ask - t.bid) / mid) * 10000 : 0;
    let depthUsd = 0;
    let bidNotional = 0;
    let askNotional = 0;
    if (this.depth) {
      const n = this.cfg.data.depthLevels;
      for (const [p, q] of this.depth.bids.slice(0, n)) bidNotional += p * q;
      for (const [p, q] of this.depth.asks.slice(0, n)) askNotional += p * q;
      depthUsd = bidNotional + askNotional;
    }
    return {
      bid: t.bid,
      ask: t.ask,
      mid,
      spreadBps,
      bidNotional,
      askNotional,
      depthUsd,
      quoteAgeMs: this.quoteAgeMs,
      depthTs: this.depth?.ts || 0,
    };
  }

  /** Snapshot used by every agent. Null until we have enough history. */
  snapshot() {
    const minBars = this.cfg.strategy.bbPeriod + this.cfg.strategy.atrPeriod + 10;
    if (this.bars.length < minBars) return null;
    const all = this.bars.toArray();
    const book = this.book();
    return computeSnapshot(all, this.cfg.strategy, {
      symbol: this.symbol,
      exchange: this.exchange.id,
      bid: book?.bid,
      ask: book?.ask,
      mid: book?.mid,
      spreadBps: book?.spreadBps ?? null,
      depthUsd: book?.depthUsd ?? null,
      quoteAgeMs: book?.quoteAgeMs ?? null,
      stale: this.isStale,
    });
  }
}

class MarketHub extends EventEmitter {
  constructor({ exchanges, cfg, log, worker }) {
    super();
    this.cfg = cfg;
    this.log = log;
    // کارگر لبه اختیاری: فقط وقتی صرافی از این میزبان در دسترس نیست قیمت
    // می‌دهد، و قیمت با برچسب edge ثبت می‌شود تا قابل تفکیک باشد.
    this.worker = worker || null;
    this.primary = exchanges.primary;
    this.witness = exchanges.witness;
    this.feeds = new Map();
    this.ws = null;
    this.wsRetry = 0;
    this.timers = [];
    this.running = false;
    // Symbols whose bootstrap failed. They are retried in the background rather
    // than killing the process: a hosted platform restarts a crashing service
    // forever and the operator never learns why.
    this.degraded = new Set();
    this._retryTimer = null;
  }

  /** Retry the feeds that failed at boot. Never throws. */
  async _retryDegraded() {
    if (!this.running || !this.degraded.size) return;
    for (const sym of [...this.degraded]) {
      const feed = this.feeds.get(sym);
      if (!feed) { this.degraded.delete(sym); continue; }
      try {
        await feed.bootstrap();
        this.degraded.delete(sym);
        this.log.info(`feed ${sym} recovered`);
      } catch (e) {
        this.log.debug(`feed ${sym} still degraded: ${e.message}`);
      }
    }
  }

  /** True when every configured feed has data. */
  get healthy() {
    return this.degraded.size === 0;
  }

  async start() {
    this.running = true;
    for (const sym of this.cfg.symbols) {
      const feed = new MarketFeed(sym, this.primary, this.cfg, this.log.child(sym));
      // the feed emits "bar" on itself; the engine listens on the hub — without
      // this forward nobody ever sees a closed candle (a silent, total outage
      // for every per-bar strategy).
      feed.on('bar', (evt) => this.emit('bar', evt));
      this.feeds.set(sym, feed);
      let attempt = 0;
      // Three attempts, not five: on a blocked exchange every attempt costs a
      // round trip, and eight symbols × five attempts is minutes of dead boot.
      // The background retry picks it up from there.
      const maxAttempts = Number(this.cfg.data.bootstrapAttempts) || 3;
      for (;;) {
        try {
          await feed.bootstrap();
          break;
        } catch (e) {
          attempt++;
          this.log.warn(`bootstrap failed (${attempt}/${maxAttempts}): ${e.message}`, { symbol: sym });
          if (attempt >= maxAttempts) {
            // A dead feed must not take the whole process down. On a hosted
            // plan the platform probes /healthz: if boot throws, the service is
            // killed and restarted forever, and the operator never sees why.
            // Degrade instead — serve health, keep retrying in the background.
            this.degraded.add(sym);
            this.log.error(
              `feed ${sym} is degraded after 5 attempts: ${e.message} — ` +
              'the engine will start without it and retry in the background'
            );
            break;
          }
          await new Promise((r) => setTimeout(r, 800 * attempt));
        }
      }
    }

    if (this.degraded.size) {
      this.log.warn(
        `${this.degraded.size}/${this.cfg.symbols.length} feed(s) degraded: ` +
        `${[...this.degraded].join(', ')} — retrying every 60s`
      );
      this._retryTimer = setInterval(() => this._retryDegraded(), 60000);
      if (this._retryTimer.unref) this._retryTimer.unref();
    }

    if (this.cfg.data.useWebSocket && typeof WebSocket === 'function' && this.primary.ws(this.cfg.symbols)) {
      this._startWs();
    } else {
      this.log.info('websocket unavailable -> REST polling only', { node: process.version });
    }
    this._startPolling();
    return this;
  }

  _setQuote(q, source) {
    const feed = this.feeds.get(q.symbol);
    if (!feed) return;
    q.source = source;
    feed.quoteSource = source;
    feed.setTicker(q);
    this.emit('tick', q);
  }

  _startWs() {
    const spec = this.primary.ws(this.cfg.symbols);
    let stopped = false;
    const connect = () => {
      if (stopped || !this.running) return;
      let socket;
      try {
        socket = new WebSocket(spec.url);
      } catch (e) {
        this.log.warn(`ws construct failed: ${e.message}`);
        return this._wsRetry(connect);
      }
      this.ws = socket;
      socket.onopen = () => {
        this.wsRetry = 0;
        this.log.info('ws connected', { url: spec.url });
        if (this.primary.wsSubscribe) {
          try {
            const sub = this.primary.wsSubscribe(this.cfg.symbols);
            if (sub) socket.send(JSON.stringify(sub));
          } catch (e) {
            this.log.warn(`ws subscribe failed: ${e.message}`);
          }
        }
      };
      socket.onmessage = (ev) => {
        try {
          const msg = JSON.parse(typeof ev.data === 'string' ? ev.data : ev.data.toString());
          const q = this.primary.parseWs(msg);
          if (q) this._setQuote(q, 'ws');
        } catch { /* malformed frame: ignore */ }
      };
      socket.onerror = () => { /* onclose handles the retry */ };
      socket.onclose = () => {
        if (stopped || !this.running) return;
        this._wsRetry(connect);
      };
    };
    connect();
    this._wsStop = () => { stopped = true; try { this.ws?.close(); } catch { /* ignore */ } };
  }

  _wsRetry(connect) {
    this.wsRetry++;
    const delay = Math.min(30000, 1000 * 2 ** Math.min(this.wsRetry, 5)) + Math.random() * 500;
    this.log.warn(`ws reconnect in ${Math.round(delay)}ms`, { attempt: this.wsRetry });
    const t = setTimeout(connect, delay);
    this.timers.push(t);
  }

  _startPolling() {
    const { tickerPollMs, depthPollMs } = this.cfg.data;
    const symbols = this.cfg.symbols;

    // quotes: batch first (1-2 requests for all symbols), then per-symbol only
    // for the ones that are actually going stale
    const tickLoop = setInterval(async () => {
      const need = symbols.filter((sym) => {
        const f = this.feeds.get(sym);
        return !f || !f.lastQuoteTs || now() - f.lastQuoteTs >= 3000;
      });
      if (!need.length) return;
      if (this.primary.tickersBatch) {
        try {
          const map = await this.primary.tickersBatch(need);
          for (const [sym, t] of map) this._setQuote(t, 'rest-batch');
          return;
        } catch (e) {
          this.log.debug(`batch ticker failed: ${e.message}`);
        }
      }
      for (const sym of need) {
        try {
          const t = await this.primary.ticker(sym);
          this._setQuote(t, 'rest');
        } catch (e) {
          this.log.debug(`ticker ${sym} failed: ${e.message}`);
        }
      }

      // آخرین شانس: کش لبه. فقط نمادهایی که هنوز قیمت تازه ندارند، و فقط
      // اگر کارگر تنظیم شده باشد. خطای این مسیر هیچ‌وقت چرخه را نمی‌شکند.
      const still = need.filter((sym) => {
        const f = this.feeds.get(sym);
        return !f || !f.lastQuoteTs || now() - f.lastQuoteTs >= 3000;
      });
      if (still.length && this.worker) {
        try {
          const snap = await this.worker.snapshot(still);
          for (const [sym, q] of Object.entries(snap || {})) {
            this._setQuote({ symbol: sym, bid: q.bid, ask: q.ask, last: q.last, ts: q.ts }, 'edge');
          }
        } catch (e) {
          this.log.debug(`edge snapshot failed: ${e.message}`);
        }
      }
    }, tickerPollMs);

    // depth: always REST (websocket orderbooks are a lot of state to babysit)
    const depthLoop = setInterval(async () => {
      for (const sym of symbols) {
        try {
          const d = await this.primary.depth(sym, this.cfg.data.depthLevels);
          this.feeds.get(sym)?.setDepth(d);
        } catch (e) {
          this.log.debug(`depth ${sym} failed: ${e.message}`);
        }
      }
    }, depthPollMs);

    // candles: poll the head of the series; a change of `t` means a bar closed
    const barLoop = setInterval(async () => {
      for (const sym of symbols) {
        const feed = this.feeds.get(sym);
        if (!feed) continue;
        try {
          const rows = await this.primary.klines(sym, 3, this.cfg.data.timeframe);
          for (const b of rows) feed.ingestBar(b);
        } catch (e) {
          this.log.debug(`klines ${sym} failed: ${e.message}`);
        }
      }
    }, 5000);

    this.timers.push(tickLoop, depthLoop, barLoop);
  }

  stop() {
    this.running = false;
    for (const t of this.timers) clearInterval(t);
    this.timers = [];
    if (this._retryTimer) { clearInterval(this._retryTimer); this._retryTimer = null; }
    try { this._wsStop?.(); } catch { /* ignore */ }
  }

  get(symbol) {
    return this.feeds.get(symbol);
  }
  all() {
    return [...this.feeds.values()];
  }
}

module.exports = { MarketHub, MarketFeed };
