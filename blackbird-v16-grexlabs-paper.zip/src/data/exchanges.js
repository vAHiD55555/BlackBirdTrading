'use strict';
/**
 * BlackBird — exchange adapters.
 *
 * One uniform surface over spot REST APIs (public market data only here).
 * Every adapter returns the same normalized shapes so no agent needs to know
 * which venue it is talking to.
 *
 *   klines(symbol, interval, limit) -> [{t,o,h,l,c,v}]
 *   ticker(symbol)                  -> {symbol,bid,ask,last,ts}
 *   tickers(symbols)                -> Map<symbol, ticker>
 *   depth(symbol, limit)            -> {bids:[[p,q]], asks:[[p,q]], ts}
 *   serverTime()                    -> ms
 */
const { setTimeout: sleep } = require('node:timers/promises');
const { getFetch, hasNativeFetch } = require('./fetch-compat');

const httpFetch = getFetch();

// ---------------------------------------------------------------------------
// HTTP with timeout, retry and a global token bucket (free hosts are noisy).
// ---------------------------------------------------------------------------
class RateLimiter {
  constructor({ ratePerSec = 8, burst = 12 } = {}) {
    this.rate = ratePerSec;
    this.capacity = burst;
    this.tokens = burst;
    this.last = Date.now();
    this.queue = Promise.resolve();
  }
  async take(n = 1) {
    // serialise waiters so the bucket is fair
    this.queue = this.queue.then(async () => {
      for (;;) {
        const nowTs = Date.now();
        this.tokens = Math.min(this.capacity, this.tokens + ((nowTs - this.last) / 1000) * this.rate);
        this.last = nowTs;
        if (this.tokens >= n) {
          this.tokens -= n;
          return;
        }
        const need = (n - this.tokens) / this.rate;
        await sleep(Math.min(500, Math.max(20, need * 1000)));
      }
    });
    return this.queue;
  }
}

class Http {
  constructor({ timeoutMs = 8000, retries = 2, limiter } = {}) {
    this.timeoutMs = timeoutMs;
    this.retries = retries;
    this.limiter = limiter || new RateLimiter({ ratePerSec: 20, burst: 30 });
    this.stats = { ok: 0, fail: 0, lastError: null };
  }

  async getJson(url, { weight = 1 } = {}) {
    let lastErr;
    for (let attempt = 0; attempt <= this.retries; attempt++) {
      await this.limiter.take(weight);
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), this.timeoutMs);
      try {
        const res = await httpFetch(url, {
          signal: ac.signal,
          headers: { accept: 'application/json', 'user-agent': 'blackbird-trader/1.0' },
        });
        const text = await res.text();
        if (!res.ok) {
          // 418/429/451: back off harder
          const retryable = res.status === 429 || res.status >= 500 || res.status === 418;
          lastErr = new Error(`HTTP ${res.status} ${url} :: ${text.slice(0, 120)}`);
          if (!retryable) throw lastErr;
          throw lastErr;
        }
        this.stats.ok++;
        return text ? JSON.parse(text) : {};
      } catch (e) {
        lastErr = e;
        this.stats.fail++;
        this.stats.lastError = e.message;
        if (attempt === this.retries) throw e;
        await sleep(250 * 2 ** attempt + Math.random() * 150);
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastErr;
  }
}

const num = (v) => (typeof v === 'number' ? v : parseFloat(v));

// timeframe maps: our canonical form is '1m' | '5m' | '15m'
const BINANCE_TF = { '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h' };
const binanceTf = (t) => BINANCE_TF[t] || '1m';
const BITGET_TF = { '1m': '1min', '3m': '3min', '5m': '5min', '15m': '15min', '30m': '30min', '1h': '1h' };
const bitgetTf = (t) => BITGET_TF[t] || '1min';
const BYBIT_TF = { '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30', '1h': '60' };
const bybitTf = (t) => BYBIT_TF[t] || '1';
// MEXC uses minute-count intervals: 1h is rejected with -1121 "Invalid interval".
const MEXC_TF = { '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '4h', '1d': '1d' };
const mexcTf = (t) => MEXC_TF[t] || '1m';

function normalizeBarsBinance(rows) {
  return rows.map((r) => ({ t: Number(r[0]), o: num(r[1]), h: num(r[2]), l: num(r[3]), c: num(r[4]), v: num(r[5]) }));
}

// ---------------------------------------------------------------------------
// Adapters
// ---------------------------------------------------------------------------
const ADAPTERS = {
  binance: {
    id: 'binance',
    base: 'https://api.binance.com',
    interval: () => '1m',
    async klines(http, symbol, limit, interval = '1m') {
      const d = await http.getJson(
        `${this.base}/api/v3/klines?symbol=${symbol}&interval=${binanceTf(interval)}&limit=${limit}`
      );
      return normalizeBarsBinance(d);
    },
    async ticker(http, symbol) {
      const [b, t] = await Promise.all([
        http.getJson(`${this.base}/api/v3/ticker/bookTicker?symbol=${symbol}`, { weight: 2 }),
        http.getJson(`${this.base}/api/v3/ticker/price?symbol=${symbol}`, { weight: 1 }),
      ]);
      return { symbol, bid: num(b.bidPrice), ask: num(b.askPrice), last: num(t.price), ts: Date.now() };
    },
    async tickersBatch(http, symbols) {
      // one call for every symbol: 2 requests instead of 2N
      const q = encodeURIComponent(JSON.stringify(symbols));
      const [book, price] = await Promise.all([
        http.getJson(`${this.base}/api/v3/ticker/bookTicker?symbols=${q}`, { weight: 4 }),
        http.getJson(`${this.base}/api/v3/ticker/price?symbols=${q}`, { weight: 4 }),
      ]);
      const px = new Map((price || []).map((p) => [p.symbol, num(p.price)]));
      const out = new Map();
      for (const b of book || []) {
        out.set(b.symbol, { symbol: b.symbol, bid: num(b.bidPrice), ask: num(b.askPrice), last: px.get(b.symbol) || (num(b.bidPrice) + num(b.askPrice)) / 2, ts: Date.now() });
      }
      return out;
    },
    async depth(http, symbol, limit) {
      const d = await http.getJson(`${this.base}/api/v3/depth?symbol=${symbol}&limit=${limit}`, { weight: 5 });
      return {
        bids: d.bids.map((r) => [num(r[0]), num(r[1])]),
        asks: d.asks.map((r) => [num(r[0]), num(r[1])]),
        ts: Date.now(),
      };
    },
    async serverTime(http) {
      const d = await http.getJson(`${this.base}/api/v3/time`, { weight: 1 });
      return Number(d.serverTime);
    },
    /**
     * Perpetual funding rate, in bps per 8h interval.
     *
     * The carry sleeve needs this and nothing else from the futures API. It is
     * read from the public premiumIndex endpoint, which needs no key. A venue
     * that does not expose it returns null and the sleeve simply finds no
     * candidates — it never invents a rate.
     */
    async funding(http, symbol) {
      const d = await http.getJson(`${this.base}/fapi/v1/premiumIndex?symbol=${symbol}`, { weight: 1 });
      const rate = num(d.lastFundingRate);
      if (!Number.isFinite(rate)) return null;
      return {
        symbol,
        fundingBps: rate * 10000, // decimal -> bps per interval
        mark: num(d.markPrice),
        index: num(d.indexPrice),
        nextFundingMs: Number(d.nextFundingTime) || null,
      };
    },
    ws(symbols) {
      const streams = symbols.map((s) => `${s.toLowerCase()}@bookTicker`).join('/');
      return { url: `wss://stream.binance.com:9443/stream?streams=${streams}`, kind: 'binance-combined' };
    },
    parseWs(msg) {
      const d = msg?.data || msg;
      if (!d || !d.s || d.e !== 'bookTicker') return null;
      return { symbol: String(d.s).toUpperCase(), bid: num(d.b), ask: num(d.a), last: (num(d.b) + num(d.a)) / 2, ts: Date.now() };
    },
  },

  mexc: {
    id: 'mexc',
    base: 'https://api.mexc.com',
    async klines(http, symbol, limit, interval = '1m') {
      const d = await http.getJson(`${this.base}/api/v3/klines?symbol=${symbol}&interval=${mexcTf(interval)}&limit=${limit}`);
      return normalizeBarsBinance(d);
    },
    async ticker(http, symbol) {
      const d = await http.getJson(`${this.base}/api/v3/ticker/bookTicker?symbol=${symbol}`);
      return {
        symbol,
        bid: num(d.bidPrice),
        ask: num(d.askPrice),
        last: (num(d.bidPrice) + num(d.askPrice)) / 2,
        ts: Date.now(),
      };
    },
    async depth(http, symbol, limit) {
      const d = await http.getJson(`${this.base}/api/v3/depth?symbol=${symbol}&limit=${limit}`);
      return {
        bids: (d.bids || []).map((r) => [num(r[0]), num(r[1])]),
        asks: (d.asks || []).map((r) => [num(r[0]), num(r[1])]),
        ts: Date.now(),
      };
    },
    async serverTime(http) {
      const d = await http.getJson(`${this.base}/api/v3/time`);
      return Number(d.serverTime);
    },
    ws() { return null; },
  },

  bitget: {
    id: 'bitget',
    base: 'https://api.bitget.com',
    async klines(http, symbol, limit, interval = '1m') {
      const d = await http.getJson(
        `${this.base}/api/v2/spot/market/candles?symbol=${symbol}&granularity=${bitgetTf(interval)}&limit=${Math.min(limit, 1000)}`
      );
      // oldest -> newest
      return (d.data || [])
        .map((r) => ({ t: Number(r[0]), o: num(r[1]), h: num(r[2]), l: num(r[3]), c: num(r[4]), v: num(r[5]) }))
        .sort((a, b) => a.t - b.t);
    },
    async ticker(http, symbol) {
      const d = await http.getJson(`${this.base}/api/v2/spot/market/tickers?symbol=${symbol}`);
      const t = (d.data || [])[0];
      if (!t) throw new Error(`bitget: no ticker for ${symbol}`);
      return { symbol, bid: num(t.bid1), ask: num(t.ask1), last: num(t.lastPr), ts: Date.now() };
    },
    async depth(http, symbol, limit) {
      const d = await http.getJson(
        `${this.base}/api/v2/spot/market/orderbook?symbol=${symbol}&type=step0&limit=${limit}`
      );
      return {
        bids: (d.data?.bids || []).map((r) => [num(r[0]), num(r[1])]),
        asks: (d.data?.asks || []).map((r) => [num(r[0]), num(r[1])]),
        ts: Date.now(),
      };
    },
    async serverTime(http) {
      const d = await http.getJson(`${this.base}/api/v2/public/time`);
      return Number(d.data?.serverTime || Date.now());
    },
    ws() { return null; },
  },

  bybit: {
    id: 'bybit',
    base: 'https://api.bybit.com',
    async klines(http, symbol, limit, interval = '1m') {
      const d = await http.getJson(
        `${this.base}/v5/market/kline?category=spot&symbol=${symbol}&interval=${bybitTf(interval)}&limit=${Math.min(limit, 1000)}`
      );
      const list = d.result?.list || [];
      // bybit returns newest -> oldest
      return list
        .map((r) => ({ t: Number(r[0]), o: num(r[1]), h: num(r[2]), l: num(r[3]), c: num(r[4]), v: num(r[5]) }))
        .sort((a, b) => a.t - b.t);
    },
    async ticker(http, symbol) {
      const d = await http.getJson(`${this.base}/v5/market/tickers?category=spot&symbol=${symbol}`);
      const t = d.result?.list?.[0];
      if (!t) throw new Error(`bybit: no ticker for ${symbol}`);
      return { symbol, bid: num(t.bid1Price), ask: num(t.ask1Price), last: num(t.lastPrice), ts: Date.now() };
    },
    async depth(http, symbol, limit) {
      const d = await http.getJson(
        `${this.base}/v5/market/orderbook?category=spot&symbol=${symbol}&limit=${Math.min(limit, 200)}`
      );
      const r = d.result || {};
      return {
        bids: (r.b || []).map((x) => [num(x[0]), num(x[1])]),
        asks: (r.a || []).map((x) => [num(x[0]), num(x[1])]),
        ts: Date.now(),
      };
    },
    async serverTime(http) {
      const d = await http.getJson(`${this.base}/v5/market/time`);
      return Number(d.result?.timeNano ? Number(d.result.timeNano) / 1e6 : Date.now());
    },
    /** Perpetual funding rate in bps per 8h interval (public, no key). */
    async funding(http, symbol) {
      const d = await http.getJson(
        `${this.base}/v5/market/tickers?category=linear&symbol=${symbol}`
      );
      const t = d.result?.list?.[0];
      if (!t) return null;
      const rate = num(t.fundingRate);
      if (!Number.isFinite(rate)) return null;
      return {
        symbol,
        fundingBps: rate * 10000,
        mark: num(t.markPrice),
        index: num(t.indexPrice),
        nextFundingMs: Number(t.nextFundingTime) || null,
      };
    },
    ws(symbols) {
      return { url: 'wss://stream.bybit.com/v5/public/spot', kind: 'bybit-v5', symbols };
    },
    parseWs(msg) {
      if (!msg || !msg.topic || !msg.data) return null;
      if (!msg.topic.startsWith('tickers.')) return null;
      const d = msg.data;
      const symbol = String(d.symbol || '').toUpperCase();
      if (!symbol) return null;
      return { symbol, bid: num(d.bid1Price), ask: num(d.ask1Price), last: num(d.lastPrice), ts: Date.now() };
    },
    wsSubscribe(symbols) {
      return {
        op: 'subscribe',
        args: symbols.flatMap((s) => [`tickers.${s}`, `orderbook.1.${s}`]),
      };
    },
  },

  // -------------------------------------------------------------------------
  // Hyperliquid — an on-chain order book, not a CEX REST API.
  //
  // Every call is a POST with a `type` field, symbols are bare coins ("BTC"),
  // and the quote is USDC. The heavy lifting lives in ./hyperliquid.js; this
  // entry only adapts it to the surface every other venue already exposes, so
  // the engine, risk, lawyer and ledger never learn the venue changed.
  //
  // `http` (the GET-based client above) is deliberately unused here: it cannot
  // POST, and Hyperliquid has no GET endpoints.
  // -------------------------------------------------------------------------
  hyperliquid: {
    id: 'hyperliquid',
    base: 'https://api.hyperliquid.xyz',
    _pub: null,
    _api() {
      if (!this._pub) {
        // Required lazily to avoid a circular require at module load.
        const { HyperliquidPublic } = require('./hyperliquid');
        this._pub = new HyperliquidPublic();
      }
      return this._pub;
    },
    async klines(http, symbol, limit, interval = '1m') {
      return this._api().klines(symbol, limit, interval);
    },
    async ticker(http, symbol) {
      return this._api().ticker(symbol);
    },
    async tickersBatch(http, symbols) {
      return this._api().tickersBatch(symbols);
    },
    async depth(http, symbol, limit) {
      return this._api().depth(symbol, limit);
    },
    async serverTime(http) {
      return this._api().serverTime();
    },
    // Hyperliquid's websocket is a separate protocol (subscription objects over
    // wss://api.hyperliquid.xyz/ws). Not implemented: REST polling is used, and
    // returning null makes MarketHub fall back to it explicitly rather than
    // silently opening a socket that never delivers a quote.
    ws() { return null; },
  },
};

function createExchange(name) {
  const key = String(name || '').toLowerCase();
  const a = ADAPTERS[key];
  if (!a) {
    throw new Error(`unknown exchange "${name}" (available: ${Object.keys(ADAPTERS).join(', ')})`);
  }
  const http = new Http();
  return {
    id: a.id,
    http,
    klines: (symbol, limit = 300, interval = '1m') => a.klines.call(a, http, symbol, limit, interval),
    ticker: (symbol) => a.ticker.call(a, http, symbol),
    depth: (symbol, limit = 20) => a.depth.call(a, http, symbol, limit),
    tickersBatch: a.tickersBatch ? (symbols) => a.tickersBatch.call(a, http, symbols) : null,
    serverTime: () => a.serverTime.call(a, http),
    funding: a.funding ? (symbol) => a.funding.call(a, http, symbol) : null,
    ws: a.ws ? (symbols) => a.ws.call(a, symbols) : () => null,
    parseWs: a.parseWs ? (m) => a.parseWs(m) : () => null,
    wsSubscribe: a.wsSubscribe ? (s) => a.wsSubscribe.call(a, s) : null,
    stats: http.stats,
  };
}

/** Optimal order-book walk: how much notional to fill `qty` and at what price. */
function walkBook(levels, qty) {
  let remaining = qty;
  let cost = 0;
  let filled = 0;
  let worst = levels[0]?.[0] ?? NaN;
  for (const [p, q] of levels) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, q);
    cost += take * p;
    filled += take;
    remaining -= take;
    worst = p;
  }
  return { filled, cost, avgPrice: filled ? cost / filled : NaN, worstPrice: worst, complete: remaining <= 1e-12 };
}

module.exports = { createExchange, Http, RateLimiter, walkBook, ADAPTERS };
