'use strict';

// Optional dependency-free SMTP notifier. It only supports implicit TLS on
// port 465; refusing other ports prevents accidental plaintext credentials.
const tls = require('node:tls');

function b64(value) { return Buffer.from(String(value), 'utf8').toString('base64'); }

function sendSmtp({ host, port, user, pass, from, to, subject, text }, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    if (Number(port) !== 465) return reject(new Error('only implicit TLS SMTP on port 465 is supported'));
    const socket = tls.connect({ host, port: Number(port), servername: host });
    let buffer = '';
    let step = 0;
    let settled = false;
    const fail = (e) => { if (!settled) { settled = true; socket.destroy(); reject(e instanceof Error ? e : new Error(String(e))); } };
    const ok = () => { if (!settled) { settled = true; socket.end(); resolve(); } };
    const write = (line) => socket.write(`${line}\r\n`);
    const commands = [
      () => write('EHLO blackbird-trader'),
      () => write(`AUTH LOGIN`),
      () => write(b64(user)),
      () => write(b64(pass)),
      () => write(`MAIL FROM:<${from}>`),
      () => write(`RCPT TO:<${to}>`),
      () => write('DATA'),
      () => {
        const body = String(text).replace(/\r?\n/g, '\r\n').replace(/^\./gm, '..');
        socket.write(`From: ${from}\r\nTo: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${body}\r\n.\r\n`);
      },
      () => write('QUIT'),
    ];
    const expected = [2, 3, 3, 2, 2, 2, 3, 2, 2];
    const timer = setTimeout(() => fail(new Error('SMTP timeout')), timeoutMs);
    socket.setEncoding('utf8');
    socket.on('error', fail);
    socket.on('close', () => { clearTimeout(timer); if (!settled) fail(new Error('SMTP connection closed')); });
    socket.on('data', (chunk) => {
      buffer += chunk;
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || '';
      for (const line of lines) {
        if (!/^\d{3}(?: |$)/.test(line)) continue;
        const code = Number(line.slice(0, 3));
        const want = expected[step];
        if (Math.floor(code / 100) !== want) return fail(new Error(`SMTP ${code}`));
        if (step === commands.length - 1) return ok();
        commands[step++]();
      }
    });
  });
}

async function sendConfiguredEmail(cfg, report, markdown) {
  const e = cfg.notifications?.email;
  if (!e?.enabled) return { skipped: true, reason: 'disabled' };
  const required = ['host', 'port', 'user', 'pass', 'from', 'to'];
  const missing = required.filter((key) => !e[key]);
  if (missing.length) return { skipped: true, reason: `missing:${missing.join(',')}` };
  if (Number(e.port) !== 465) return { skipped: true, reason: 'smtp_port_must_be_465_tls_only' };
  const subject = `BlackBird phase-zero report #${report.round} | ${report.summary?.pnl >= 0 ? '+' : ''}${Number(report.summary?.pnl || 0).toFixed(2)} USDT`;
  await sendSmtp({ ...e, subject, text: markdown });
  return { sent: true };
}

module.exports = { sendConfiguredEmail };
