'use strict';
/**
 * AngryBird — its own Telegram report.
 *
 * The BlackBird report covers the whole portfolio every hour; this one exists
 * because the $100 scenario runs in short bursts and the operator wants to know
 * three things, in this order, at the moment they happen:
 *
 *   why it started   — the muddy-water measurements that opened the gate
 *   how it entered   — venue style (maker/taker), symbols, sides, sizes
 *   how it ended     — each trade's result and the session total
 *
 * It is deliberately separate: its own chat id, its own message shape, and it
 * stays silent unless the profile is AngryBird. Nothing here can place, resize
 * or close an order — it only reads the portfolio and sends text.
 */
const { angryActivation } = require('../risk/angry-limits');
const { sendTelegramChunks } = require('./telegram');

const money = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return `${n >= 0 ? '+' : ''}${n.toFixed(2)}`;
};
const pct = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? `${n >= 0 ? '+' : ''}${n.toFixed(2)}%` : '—';
};
const usd = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? `${n.toFixed(2)} دلار` : '—';
};
const score = (v) => (Number.isFinite(Number(v)) ? Number(v).toFixed(2) : '—');

class AngryReporter {
  constructor({ cfg, log, store, clock = Date.now, send = null, checkEveryMs = 10000 } = {}) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.clock = clock;
    this.checkEveryMs = checkEveryMs;
    this._lastTick = 0;
    this.session = null;
    this.sent = 0;
    this.lastError = null;

    const t = (cfg && cfg.notifications && cfg.notifications.telegram) || {};
    this.chatId = t.angryChatId || t.reportChatId || '';
    this.enabled = Boolean(
      cfg && cfg.profile && cfg.profile.name === 'angrybird' &&
      t.enabled && t.botToken && this.chatId,
    );
    this._send = send || ((text) => sendTelegramChunks(cfg, this.chatId, text));
    // Injected in tests: a sender that records instead of calling Telegram.
    this._deliver = (text) => {
      if (!this.enabled) return null;
      try {
        const p = this._send(text);
        if (p && typeof p.catch === 'function') {
          p.catch((e) => { this.lastError = e.message; this.log.warn(`angry report failed: ${e.message}`); });
        }
        this.sent++;
        return p;
      } catch (e) {
        this.lastError = e.message;
        this.log.warn(`angry report failed: ${e.message}`);
        return null;
      }
    };
  }

  /** Called from the housekeeping clock. Cheap, self-throttled. */
  tick({ context, positions = [], equity } = {}) {
    if (!this.enabled) return null;
    const t = this.clock();
    if (t - this._lastTick < this.checkEveryMs) return null;
    this._lastTick = t;

    const act = this.cfg.risk && this.cfg.risk.angry && this.cfg.risk.angry.activation;
    const gate = act && act.enabled ? angryActivation(act, context || {}) : { active: true, score: null, reasons: [] };

    if (!this.session && gate.active && positions.length > 0) {
      this._start(gate, context, positions, equity);
      return 'started';
    }
    if (this.session && positions.length === 0) {
      this._finish(equity);
      return 'finished';
    }
    // The gate closing while the book is still open is worth one line: the
    // reason the episode started no longer holds.
    if (this.session && !this.session.gateClosed && !gate.active) {
      this.session.gateClosed = true;
      this._deliver(
        `🐦🔥 AngryBird — پنجره‌ی ورود بسته شد\n` +
        `دلیل: ${gate.reasons.join(' · ')}\n` +
        `پوزیشن‌های باز: ${positions.length} — مدیریت خروج ادامه دارد.`,
      );
    }
    return null;
  }

  _start(gate, context, positions, equity) {
    this.session = {
      openedAt: this.clock(),
      gate: {
        score: gate.score,
        atrPercentile: context && context.atrPercentile,
        exodusBreadth: context && context.exodusBreadth,
        recoveryScore: context && context.recoveryScore,
      },
      trades: [],
      gateClosed: false,
      equityAtStart: Number(equity) || null,
    };

    const entryType = (positions.find((p) => p.entryType) || {}).entryType || this.cfg.strategy?.entryType || 'maker';
    const lines = positions.slice(0, 6).map((p) => {
      const side = String(p.side || (Number(p.dir) < 0 ? 'sell' : 'buy')) === 'sell' ? 'فروش' : 'خرید';
      return `• ${p.symbol}: ${side} ${usd(p.notional)}`;
    });

    const text = [
      '🐦🔥 AngryBird — شروع فعالیت',
      `علت شروع: التهاب ${score(this.session.gate.atrPercentile)} · خروج جمعی ${score(this.session.gate.exodusBreadth)} · شواهد برگشت ${score(this.session.gate.recoveryScore)}`,
      `نوع ورود: ${entryType} · ${positions.length} پوزیشن`,
      ...lines,
      `سرمایه: ${usd(equity)} · سقف هر معامله: ${usd(this.cfg.risk?.angry?.maxTradeNotionalUsd)}`,
    ].join('\n');

    this.log.info('angrybird session report: start', { positions: positions.length, gate: this.session.gate });
    try { this.store?.append('angry_report_start', { ts: this.clock(), gate: this.session.gate, positions: positions.length }); } catch { /* best effort */ }
    this._deliver(text);
  }

  /** One message per closed trade, with the running session total. */
  onTradeClosed(trade) {
    if (!this.enabled || !trade) return null;
    const pnl = Number(trade.pnl);
    const pnlPct = Number(trade.pnlPct);
    const reason = (trade.exit && trade.exit.reason) || trade.reason || '—';
    const line = `• ${trade.symbol}: ${trade.win ? 'برد' : 'باخت'} · ${money(pnl)} دلار (${pct(pnlPct)}) · خروج: ${reason}`;

    if (!this.session) {
      // Closed after a restart: report the trade on its own rather than invent
      // a session that never existed.
      this._deliver(`🐦🔥 AngryBird — نتیجه معامله\n${line}\nسرمایه: ${usd(this.cfg.runtime?.lastEquity)}`);
      return 'trade';
    }

    this.session.trades.push({ symbol: trade.symbol, pnl: Number.isFinite(pnl) ? pnl : 0, win: Boolean(trade.win), reason });
    const total = this.session.trades.reduce((a, x) => a + x.pnl, 0);
    const wins = this.session.trades.filter((x) => x.win).length;
    const equity = this.session.equityAtStart != null ? this.session.equityAtStart + total : null;

    const text = [
      '🐦🔥 AngryBird — نتیجه معامله',
      line,
      `جمع این دور: ${money(total)} دلار · ${wins} برد / ${this.session.trades.length - wins} باخت`,
      `سرمایه: ${usd(equity)}`,
    ].join('\n');

    try { this.store?.append('angry_report_trade', { ts: this.clock(), symbol: trade.symbol, pnl: Number.isFinite(pnl) ? pnl : null, win: Boolean(trade.win), reason }); } catch { /* best effort */ }
    this._deliver(text);
    return 'trade';
  }

  _finish(equity) {
    const s = this.session;
    if (!s) return;
    const total = s.trades.reduce((a, x) => a + x.pnl, 0);
    const wins = s.trades.filter((x) => x.win).length;
    const trades = s.trades.length;
    const winRate = trades ? Math.round((wins / trades) * 100) : null;
    const endEquity = s.equityAtStart != null ? s.equityAtStart + total : Number(equity);

    const text = [
      '🐦🔥 AngryBird — پایان دور',
      trades
        ? `نتیجه: ${money(total)} دلار در ${trades} معامله · نرخ برد ${winRate}٪`
        : 'نتیجه: بدون معامله‌ی بسته‌شده',
      `علت شروع: التهاب ${score(s.gate.atrPercentile)} · خروج جمعی ${score(s.gate.exodusBreadth)} · شواهد برگشت ${score(s.gate.recoveryScore)}`,
      s.equityAtStart != null ? `سرمایه از ${usd(s.equityAtStart)} به ${usd(endEquity)}` : `سرمایه: ${usd(endEquity)}`,
    ].join('\n');

    this.log.info('angrybird session report: end', { trades, total });
    try { this.store?.append('angry_report_end', { ts: this.clock(), trades, total, winRate }); } catch { /* best effort */ }
    this._deliver(text);
    this.session = null;
  }

  snapshot() {
    return {
      enabled: this.enabled,
      sent: this.sent,
      lastError: this.lastError,
      session: this.session
        ? {
            openedAt: this.session.openedAt,
            trades: this.session.trades.length,
            gate: this.session.gate,
          }
        : null,
    };
  }
}

module.exports = { AngryReporter };
