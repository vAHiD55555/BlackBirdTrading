'use strict';

// Dependency-free Telegram Bot API notifier.
//
// Two things this file gets right that the first version did not:
//
//   1. It accepts the variable names people actually set. The documented names
//      are TELEGRAM_REPORT_CHAT_ID / TELEGRAM_ALERT_CHAT_ID, but almost every
//      guide on the internet says TELEGRAM_CHAT_ID — and a user who sets that
//      one used to get `{"skipped":true,"reason":"missing_chat_id"}` forever,
//      with no hint that the name was the problem. Both are accepted now.
//
//   2. It reports what Telegram actually said. `telegram HTTP 401` is useless;
//      Telegram returns a JSON body with `error_code` and `description`
//      ("Unauthorized", "chat not found", "bot was blocked by the user"), and
//      that is the sentence the operator needs. The token is never logged.
//
// A Telegram failure must never stop the trading engine: every function here
// returns a result object and never throws.

/** Telegram accepts a numeric id (-100… for channels) or an @username. */
function normalizeChatId(raw) {
  if (raw === undefined || raw === null) return '';
  const s = String(raw).trim();
  if (!s) return '';
  // A pasted "https://t.me/name" or "t.me/name" is a common mistake.
  const m = s.match(/^(?:https?:\/\/)?t\.me\/([A-Za-z0-9_]+)\/?$/i);
  if (m) return `@${m[1]}`;
  return s;
}

/**
 * Pull the human-readable reason out of a Telegram error response.
 * Telegram's shape: { ok:false, error_code:400, description:"chat not found" }
 */
async function describeTelegramFailure(res) {
  let description = '';
  let errorCode = res.status;
  try {
    const body = await res.json();
    if (body && typeof body === 'object') {
      description = body.description || '';
      if (body.error_code) errorCode = body.error_code;
    }
  } catch { /* non-JSON body — the status is all we have */ }
  const hint = {
    400: 'bad request — usually a wrong chat_id or malformed text',
    401: 'unauthorized — the bot token is wrong or was revoked',
    403: 'forbidden — the bot was blocked, or it is not a member of that chat',
    404: 'not found — no such bot token',
    409: 'conflict — webhook is set; delete it with deleteWebhook',
    429: 'rate limited — too many messages, wait and retry',
  }[errorCode];
  return {
    ok: false,
    errorCode,
    description: description || hint || `HTTP ${res.status}`,
    hint: hint || null,
  };
}

async function sendTelegramMessage({ token, chatId, text, timeoutMs = 10000 }) {
  const id = normalizeChatId(chatId);
  if (!token) return { ok: false, skipped: true, reason: 'missing_token' };
  if (!id) return { ok: false, skipped: true, reason: 'missing_chat_id' };

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(`https://api.telegram.org/bot${encodeURIComponent(token)}/sendMessage`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ chat_id: id, text: String(text).slice(0, 4090), disable_web_page_preview: true }),
      signal: ctl.signal,
    });
    if (!res.ok) {
      const failure = await describeTelegramFailure(res);
      return { ...failure, chatId: id };
    }
    const body = await res.json();
    if (!body.ok) {
      return { ok: false, errorCode: body.error_code || null, description: body.description || 'rejected', chatId: id };
    }
    return { ok: true, sent: true, messageId: body.result?.message_id || null, chatId: id };
  } catch (e) {
    // Network-level failure: blocked host, DNS, timeout. Say which.
    const reason = e.name === 'AbortError'
      ? `timed out after ${timeoutMs}ms`
      : (e.cause?.code || e.code || e.message || 'network error');
    return { ok: false, network: true, reason, chatId: id };
  } finally {
    clearTimeout(timer);
  }
}

async function sendTelegramChunks(cfg, chatId, text) {
  const t = cfg.notifications?.telegram;
  if (!t?.enabled) return { ok: false, skipped: true, reason: 'disabled' };
  const id = normalizeChatId(chatId);
  if (!id) return { ok: false, skipped: true, reason: 'missing_chat_id' };
  if (!t.botToken) return { ok: false, skipped: true, reason: 'missing_token' };

  const raw = String(text);
  const chunks = [];
  for (let i = 0; i < raw.length; i += 3900) chunks.push(raw.slice(i, i + 3900));

  let sent = 0;
  for (const chunk of chunks) {
    const r = await sendTelegramMessage({ token: t.botToken, chatId: id, text: chunk, timeoutMs: t.timeoutMs });
    if (!r.ok) return { ...r, sent, chunks: chunks.length };
    sent++;
  }
  return { ok: true, sent: true, chunks: chunks.length, chatId: id };
}

async function sendConfiguredTelegram(cfg, kind, text) {
  const t = cfg.notifications?.telegram;
  // Report and alert may share one chat. Fall back to whichever is set, so a
  // single TELEGRAM_CHAT_ID is enough to receive both.
  const chatId = kind === 'alert'
    ? (t?.alertChatId || t?.reportChatId)
    : (t?.reportChatId || t?.alertChatId);
  return sendTelegramChunks(cfg, chatId, text);
}

/**
 * Send a test message right now, without waiting for the hourly report.
 * Used by `node scripts/telegram-test.js` and by the dashboard's test button.
 */
async function sendTestMessage(cfg) {
  const t = cfg.notifications?.telegram;
  if (!t?.enabled) {
    return { ok: false, skipped: true, reason: 'telegram is disabled — set TELEGRAM_ENABLED=true' };
  }
  if (!t.botToken) {
    return { ok: false, skipped: true, reason: 'TELEGRAM_BOT_TOKEN is empty' };
  }
  const chatId = t.reportChatId || t.alertChatId;
  if (!chatId) {
    return {
      ok: false,
      skipped: true,
      reason: 'no chat id — set TELEGRAM_CHAT_ID (or TELEGRAM_REPORT_CHAT_ID)',
    };
  }
  const text = `🐦 BlackBird — پیام تست\n\nاتصال تلگرام درست کار می‌کند.\nزمان: ${new Date().toISOString()}`;
  return sendTelegramChunks(cfg, chatId, text);
}

module.exports = {
  sendTelegramMessage,
  sendTelegramChunks,
  sendConfiguredTelegram,
  sendTestMessage,
  normalizeChatId,
};
