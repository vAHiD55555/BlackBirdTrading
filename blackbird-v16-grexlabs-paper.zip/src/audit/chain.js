'use strict';
/**
 * Evidence chain — append-only, hash-linked, verifiable.
 *
 * Each record carries the SHA-256 of the previous record, so deleting, editing
 * or re-ordering any line breaks verification from that point on. There is no
 * delete/update/truncate API on purpose: nothing that calls this module (model,
 * overseer, council) can remove evidence through it.
 *
 * What it is NOT: tamper-proof against someone who can rewrite the whole file
 * and every hash. For that, publish the head hash somewhere the writer cannot
 * edit (see `head()`); a mismatch with the published head exposes a full rewrite.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const GENESIS = '0'.repeat(64);

function canonical(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  return '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
}
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

class EvidenceChain {
  /** @param {{file?: string|null, clock?: () => number}} opts file=null keeps it in memory. */
  constructor({ file = null, clock = Date.now } = {}) {
    this.file = file;
    this.clock = clock;
    this.records = [];
    this._head = GENESIS;
    if (file) {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      if (fs.existsSync(file)) {
        const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
        for (const l of lines) this.records.push(JSON.parse(l));
        const v = EvidenceChain.verify(this.records);
        if (!v.ok) throw new Error(`evidence chain corrupted at index ${v.brokenAt}: ${v.reason}`);
        if (this.records.length) this._head = this.records[this.records.length - 1].hash;
      }
    }
  }

  append(kind, actor, data = {}) {
    const rec = {
      seq: this.records.length,
      ts: this.clock(),
      kind: String(kind),
      actor: String(actor),
      data,
      prev: this._head,
    };
    rec.hash = sha(rec.prev + canonical({ seq: rec.seq, ts: rec.ts, kind: rec.kind, actor: rec.actor, data: rec.data }));
    if (this.file) fs.appendFileSync(this.file, JSON.stringify(rec) + '\n');
    this.records.push(rec);
    this._head = rec.hash;
    return rec;
  }

  head() { return { seq: this.records.length - 1, hash: this._head }; }
  /** A copy: callers get evidence to read, never the live array. */
  list() { return this.records.map((r) => JSON.parse(JSON.stringify(r))); }

  static verify(records) {
    let prev = GENESIS;
    for (let i = 0; i < records.length; i++) {
      const r = records[i];
      if (r.seq !== i) return { ok: false, brokenAt: i, reason: 'sequence gap or reorder' };
      if (r.prev !== prev) return { ok: false, brokenAt: i, reason: 'previous-hash mismatch (record removed or inserted)' };
      const h = sha(r.prev + canonical({ seq: r.seq, ts: r.ts, kind: r.kind, actor: r.actor, data: r.data }));
      if (h !== r.hash) return { ok: false, brokenAt: i, reason: 'content altered' };
      prev = r.hash;
    }
    return { ok: true, count: records.length };
  }
  verify() { return EvidenceChain.verify(this.records); }
}

module.exports = { EvidenceChain, GENESIS };
