'use strict';
/**
 * The overseer's court — a deterministic state machine.
 *
 * The overseer ("قاضی‌القضات") is a model and may RECOMMEND. This module is what
 * decides what a recommendation is allowed to do, how often, and what happens
 * next. Nothing here reads a model's answer to decide a limit.
 *
 * Per season:
 *   - at most `maxInvisibleInterventionsPerSeason` invisible interventions;
 *   - at most `maxYellowCardsPerSeason` yellow cards, each alerting the user on
 *     at least `minAlertChannels` channels;
 *   - a red card (serious financial-loss risk or ecosystem collapse) moves the
 *     season to the closing phase.
 *
 * Red card, in this order, synchronously and BEFORE any waiting:
 *   1. block every new order;
 *   2. cancel / review pending orders by protocol;
 *   3. start the pre-approved controlled exit of open positions (never a blind
 *      close-everything — that can make the loss worse);
 *   4. offer control to the user and start the takeover window.
 * The window only decides WHO commands. It never delays step 1-3. If the user
 * does not take control in time, the standby council is summoned.
 *
 * Open positions may continue only on an explicit user request that accepts
 * responsibility, or by formal council ruling within its approved authority.
 *
 * Every transition is written to the evidence chain.
 */
const { checkSeparationOfDuties } = require('../charter/foundation');

const RED_GROUNDS = Object.freeze(['serious_financial_loss_risk', 'ecosystem_collapse']);

class Court {
  /**
   * @param {object} o
   * @param {object} o.cfg       cfg.court
   * @param {object} o.evidence  EvidenceChain
   * @param {object} o.hooks     { alert(channel, msg), blockOrders(reason), cancelPending(reason),
   *                               controlledExit(policy), offerControl(info), summonCouncil(info),
   *                               closeSeason(report) }  — all optional, all wrapped in try/catch
   * @param {object} [o.roster]  { actor, overseer, approver, evaluator, council: [ids] }
   * @param {function} [o.clock]
   * @param {object} [o.timers]  { setTimeout, clearTimeout } (injected in tests)
   */
  constructor({ cfg, evidence, hooks = {}, roster = null, clock = Date.now, timers = { setTimeout, clearTimeout } }) {
    this.cfg = cfg;
    this.evidence = evidence;
    this.hooks = hooks;
    this.clock = clock;
    this.timers = timers;
    this.roster = roster;
    this.season = null;
    this._timer = null;
  }

  // ------------------------------------------------------------------ helpers
  _call(name, ...args) {
    try { return this.hooks[name] ? this.hooks[name](...args) : undefined; } catch (e) {
      this.evidence.append('hook_error', 'court', { hook: name, message: String(e.message).slice(0, 200) });
      return undefined;
    }
  }
  _log(kind, actor, data) { return this.evidence.append(kind, actor, { season: this.season?.id ?? null, ...data }); }

  // ------------------------------------------------------------------- season
  startSeason({ id, roster = this.roster } = {}) {
    if (this.season && this.season.phase !== 'ended') return { ok: false, reason: 'season_already_running' };
    if (!roster) return { ok: false, reason: 'roster_required' };
    const sod = checkSeparationOfDuties(roster);
    if (!sod.ok) return { ok: false, reason: 'separation_of_duties', violations: sod.violations };
    if (!Array.isArray(roster.council) || new Set(roster.council).size < this.cfg.councilQuorum) {
      return { ok: false, reason: 'council_below_quorum' };
    }
    // The standby council must be independent of everyone it will judge.
    const parties = new Set([roster.actor, roster.overseer]);
    if (roster.council.some((m) => parties.has(m))) return { ok: false, reason: 'council_member_is_a_party' };
    this.roster = roster;
    this.season = { id: id || `season-${this.clock()}`, phase: 'normal', interventions: 0, yellow: 0, red: null, commander: 'system', report: null };
    this._log('season_start', 'court', { roster: { ...roster, council: [...roster.council] } });
    return { ok: true, season: this.season.id };
  }

  get phase() { return this.season ? this.season.phase : 'none'; }
  get yellowCards() { return this.season ? this.season.yellow : 0; }
  get redCardActive() { return Boolean(this.season && this.season.red); }

  // ------------------------------------------------- invisible interventions
  intervene({ rationale, source = 'overseer' } = {}) {
    if (!this.season || this.season.phase !== 'normal') return { ok: false, reason: `phase_${this.phase}` };
    if (this.season.interventions >= this.cfg.maxInvisibleInterventionsPerSeason) {
      this._log('intervention_refused', 'court', { reason: 'season_limit', source });
      return { ok: false, reason: 'intervention_limit_reached' };
    }
    this.season.interventions += 1;
    this._log('intervention', source, { n: this.season.interventions, rationale: String(rationale || '').slice(0, 500) });
    // Deliberately no hook and no user-facing signal: invisible by design. Evidence only.
    return { ok: true, n: this.season.interventions };
  }

  // -------------------------------------------------------------- yellow card
  yellowCard({ reason, evidence = null, source = 'overseer' } = {}) {
    if (!this.season || this.season.phase !== 'normal') return { ok: false, reason: `phase_${this.phase}` };
    if (this.season.yellow >= this.cfg.maxYellowCardsPerSeason) {
      this._log('yellow_refused', 'court', { reason: 'season_limit', source });
      return { ok: false, reason: 'yellow_limit_reached' };
    }
    this.season.yellow += 1;
    const msg = `Yellow card ${this.season.yellow}/${this.cfg.maxYellowCardsPerSeason}: ${String(reason || '').slice(0, 300)}`;
    const delivered = [];
    for (const ch of this.cfg.alertChannels || []) {
      const r = this._call('alert', ch, msg);
      // A channel counts only if the hook says so explicitly. Silence is not delivery.
      if (r === true || (r && r.ok === true)) delivered.push(ch);
    }
    const degraded = delivered.length < this.cfg.minAlertChannels;
    this._log('yellow_card', source, { n: this.season.yellow, reason: String(reason || '').slice(0, 500), evidence, delivered, degradedAlert: degraded });
    return { ok: true, n: this.season.yellow, delivered, degradedAlert: degraded };
  }

  // ---------------------------------------------------------------- red card
  redCard({ ground, reason, source = 'overseer' } = {}) {
    if (!this.season) return { ok: false, reason: 'no_season' };
    if (this.season.phase !== 'normal') return { ok: false, reason: `phase_${this.phase}` };
    if (!RED_GROUNDS.includes(ground)) {
      this._log('red_refused', 'court', { reason: 'ground_not_allowed', ground: String(ground), source });
      return { ok: false, reason: 'ground_not_allowed' };
    }
    const s = this.season;
    s.phase = 'closing';
    s.red = { ground, at: this.clock(), reason: String(reason || '').slice(0, 500) };
    this._log('red_card', source, { ground, reason: s.red.reason });

    // 1-3 happen NOW. The takeover window below must not delay any of them.
    this._call('blockOrders', `red_card:${ground}`);
    this._log('orders_blocked', 'court', {});
    this._call('cancelPending', `red_card:${ground}`);
    this._log('pending_review_started', 'court', {});
    this._call('controlledExit', { policy: 'pre_approved_staged_exit', blind_close_all: false });
    this._log('controlled_exit_started', 'court', { blind_close_all: false });

    // 4. Offer control to the user, then start the window.
    const windowMs = this.cfg.userTakeoverWindowMs;
    this._call('offerControl', { windowMs, ground });
    this._log('control_offered', 'court', { windowMs });
    this._timer = this.timers.setTimeout(() => this._windowExpired(), windowMs);
    if (this._timer && typeof this._timer.unref === 'function') this._timer.unref();
    return { ok: true, phase: s.phase, windowMs };
  }

  /** The user (or the client) steps in within the window. */
  takeControl({ userId, continueOpenPositions = false, acceptResponsibility = false } = {}) {
    const s = this.season;
    if (!s || s.phase !== 'closing') return { ok: false, reason: 'not_in_closing_phase' };
    if (s.commander !== 'system') return { ok: false, reason: 'already_commanded' };
    if (!userId) return { ok: false, reason: 'user_required' };
    if (this._timer) { this.timers.clearTimeout(this._timer); this._timer = null; }
    s.commander = `user:${userId}`;
    let continued = false;
    if (continueOpenPositions) {
      // Exception to the controlled exit: only with an explicit, responsibility-accepting request.
      if (acceptResponsibility !== true) {
        this._log('continue_refused', 'court', { by: s.commander, reason: 'responsibility_not_accepted' });
        return { ok: true, commander: s.commander, continued: false, note: 'continue_refused_without_responsibility' };
      }
      continued = true;
      this._log('continue_authorized', s.commander, { acceptedResponsibility: true });
      this._call('continueOpenPositions', { by: s.commander });
    }
    this._log('control_taken', s.commander, { continued });
    return { ok: true, commander: s.commander, continued };
  }

  _windowExpired() {
    this._timer = null;
    const s = this.season;
    if (!s || s.phase !== 'closing' || s.commander !== 'system') return;
    s.commander = 'council';
    this._log('control_window_expired', 'court', {});
    this._call('summonCouncil', { members: [...this.roster.council], ground: s.red.ground });
    this._log('council_summoned', 'court', { members: [...this.roster.council] });
  }

  /**
   * The council's written ruling. Shape is enforced here; content is theirs.
   * report = { members, observations[], hearsay[], scores:{actor, overseer}, ruling }
   * Observations (first-hand, from logs) are kept apart from hearsay, and both
   * parties are scored. A council that is not the one that was summoned, is below
   * quorum, or contains a party, is rejected.
   */
  submitCouncilReport(report) {
    const s = this.season;
    if (!s || s.phase !== 'closing') return { ok: false, reason: 'not_in_closing_phase' };
    if (s.commander !== 'council' && !s.commander.startsWith('user:')) return { ok: false, reason: 'no_commander' };
    const r = report || {};
    const members = Array.isArray(r.members) ? r.members : [];
    const roster = new Set(this.roster.council);
    if (new Set(members).size < this.cfg.councilQuorum) return { ok: false, reason: 'below_quorum' };
    if (members.some((m) => !roster.has(m))) return { ok: false, reason: 'member_not_on_standby_roster' };
    if (!Array.isArray(r.observations) || !Array.isArray(r.hearsay)) return { ok: false, reason: 'observations_and_hearsay_required' };
    const sc = r.scores || {};
    const okScore = (v) => Number.isFinite(v) && v >= 0 && v <= 100;
    if (!okScore(sc.actor) || !okScore(sc.overseer)) return { ok: false, reason: 'both_parties_must_be_scored_0_100' };
    s.report = { members: [...new Set(members)], observations: r.observations, hearsay: r.hearsay, scores: { actor: sc.actor, overseer: sc.overseer }, ruling: String(r.ruling || '').slice(0, 2000) };
    this._log('council_report', 'council', s.report);
    return this.endSeason({ via: 'council_report' });
  }

  endSeason({ via = 'manual' } = {}) {
    const s = this.season;
    if (!s || s.phase === 'ended') return { ok: false, reason: 'no_running_season' };
    if (this._timer) { this.timers.clearTimeout(this._timer); this._timer = null; }
    s.phase = 'ended';
    this._log('season_end', 'court', { via, yellow: s.yellow, interventions: s.interventions, red: s.red });
    this._call('closeSeason', { id: s.id, report: s.report });
    return { ok: true, season: s.id };
  }

  /**
   * What may be shown to the public. The overseer's existence, interventions and
   * identity are NOT public; only the coarse phase and card counts are.
   */
  publicView() {
    const s = this.season;
    if (!s) return { phase: 'none', yellowCards: 0, closing: false };
    return { phase: s.phase === 'closing' ? 'closing' : s.phase, yellowCards: s.yellow, closing: s.phase === 'closing' };
  }
}

module.exports = { Court, RED_GROUNDS };
