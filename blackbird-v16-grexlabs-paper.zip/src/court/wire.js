'use strict';
/**
 * Connects the court (pure state machine) to the engine's real hands.
 * Every hook here either REDUCES risk or reports; none can open a position,
 * raise a limit or lift a halt.
 */
const { Court } = require('./court');
const { sendConfiguredTelegram } = require('../notify/telegram');

function buildCourt(engine) {
  const cfg = engine.cfg;
  if (!cfg.court || !cfg.court.enabled) return null;
  const log = engine.log.child('court');
  engine.courtAlerts = []; // what the public dashboard may show: counts + coarse text only

  const hooks = {
    alert(channel, msg) {
      if (channel === 'dashboard') {
        engine.courtAlerts.push({ at: Date.now(), level: 'yellow' });
        return { ok: true };
      }
      if (channel === 'telegram') {
        const t = cfg.notifications && cfg.notifications.telegram;
        if (!t || !t.enabled || !t.botToken) return { ok: false };
        sendConfiguredTelegram(cfg, 'alert', msg).catch((e) => log.warn(`telegram alert failed: ${e.message}`));
        return { ok: true }; // dispatched; delivery failures are logged, not assumed
      }
      if (channel === 'email') {
        const e = cfg.notifications && cfg.notifications.email;
        return { ok: Boolean(e && e.enabled && e.host && e.to) }; // report channel; counted only when configured
      }
      return { ok: false };
    },
    // Red card, step 1: no new risk, immediately and until a human resumes.
    blockOrders(reason) { engine.risk.halt(`court:${reason}`, { kind: 'hard' }); },
    cancelPending(reason) {
      try { if (engine.broker && typeof engine.broker.cancelAll === 'function') engine.broker.cancelAll(); } catch (e) { log.warn(`cancelAll failed: ${e.message}`); }
      log.warn(`pending orders cancelled (${reason})`);
    },
    controlledExit() { engine._courtExit = true; engine._courtContinue = false; },
    continueOpenPositions() { engine._courtExit = false; engine._courtContinue = true; },
    offerControl(info) { log.error(`RED CARD (${info.ground}): control offered to the user for ${Math.round(info.windowMs / 1000)}s`); },
    summonCouncil(info) { log.error(`control window expired: standby council summoned (${info.members.length} members)`); },
    closeSeason(info) { log.error(`season ${info.id} closed`); engine._courtExit = false; },
  };

  return new Court({ cfg: cfg.court, evidence: engine.evidence, hooks, roster: cfg.court.roster || null });
}

/**
 * Controlled exit, one position per housekeeping tick, worst unrealised loss first.
 * Deliberately NOT "close everything now": a simultaneous market dump of a thin
 * book can turn a bad day into a worse one. Rotator positions only; tactical
 * trades are already blocked from re-entry and leave through their own TP/SL.
 */
function courtStagedExit(engine) {
  if (!engine._courtExit || engine._courtContinue || !engine.rotator) return 0;
  const open = engine.portfolio.openPositions().filter((p) => p.strategy === 'ORBITAL');
  if (!open.length) return 0;
  open.sort((a, b) => a.unrealisedPnl() - b.unrealisedPnl());
  try { return engine.rotator._close(open[0].symbol, 'court_controlled_exit') ? 1 : 0; } catch { return 0; }
}

module.exports = { buildCourt, courtStagedExit };
