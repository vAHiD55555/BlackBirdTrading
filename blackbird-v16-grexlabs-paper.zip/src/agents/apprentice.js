'use strict';
/**
 * BlackBird — the Apprentice (کارآموز).
 *
 * A permanent learner that sits beside every actor in the system and asks one
 * question, over and over: "why did you do that?"
 *
 * The contract, and it is a contract, not a suggestion:
 *
 *   1. Every actor that acts must be able to answer. `ask()` opens a question
 *      and `answer()` closes it. An answer with an empty reason is refused.
 *   2. An unanswered question is recorded as a violation, not dropped. Silence
 *      is the one thing the apprentice will not accept, because a decision
 *      nobody can explain is a decision nobody can improve.
 *   3. Everything is written to disk as JSONL, append-only, one record per
 *      line. The log is the asset: it is a dataset, not a debug trace.
 *   4. The dataset is portable. `exportDataset()` emits plain
 *      {instruction, input, output} triples that any model can be trained or
 *      fine-tuned on — not only this apprentice.
 *
 * Design rules that keep it from becoming a liability:
 *   - It never blocks a trade. `ask()` is synchronous and returns an id; the
 *     answer arrives later or never, and the engine does not wait.
 *   - It never throws. A learner that can crash the engine is worse than none.
 *   - It never stores a secret. Records pass through the same redaction idea as
 *     the jev ledger: keys and tokens are stripped before the line is written.
 *   - It is bounded: a per-day byte cap and a ring of open questions, so a
 *     runaway loop cannot fill the disk.
 */

const fs = require('node:fs');
const path = require('node:path');
const { now, uuid } = require('../core/util');

const DEFAULTS = {
  enabled: true,
  dir: null, // resolved from cfg.runtime.dataDir by the caller
  maxBytesPerDay: 20 * 1024 * 1024,
  maxOpenQuestions: 200,
  maxRecordsInMemory: 2000,
  requireReason: true,
  minReasonChars: 8,
};

/** Strip anything that looks like a credential before it reaches disk. */
const SECRET_PATTERNS = [
  /\b(sk|pk|rk)-[A-Za-z0-9_-]{16,}\b/g,
  /\bghp_[A-Za-z0-9]{20,}\b/g,
  /\bAIza[0-9A-Za-z_-]{30,}\b/g,
  /\bgsk_[A-Za-z0-9]{20,}\b/g,
  /\bcsk-[A-Za-z0-9]{20,}\b/g,
  /\bsk-or-v1-[A-Za-z0-9]{20,}\b/g,
  /\bBearer\s+[A-Za-z0-9._-]{16,}/gi,
  /\b\d{6,}:[A-Za-z0-9_-]{20,}\b/g, // telegram bot token
  /\b0x[0-9a-fA-F]{40,}\b/g,
];

function redact(value) {
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') {
    let out = value;
    for (const re of SECRET_PATTERNS) out = out.replace(re, '[redacted]');
    return out;
  }
  if (Array.isArray(value)) return value.map(redact);
  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (/(KEY|TOKEN|SECRET|PASS|PRIVATE|SEED|MNEMONIC)/i.test(k)) {
        out[k] = '[redacted]';
      } else {
        out[k] = redact(v);
      }
    }
    return out;
  }
  return value;
}

/** One-line summary of an arbitrary payload, safe to store. */
function summarise(payload) {
  if (payload === null || payload === undefined) return null;
  if (typeof payload !== 'object') return redact(String(payload)).slice(0, 400);
  const keep = {};
  const keys = [
    'symbol', 'side', 'strategy', 'regime', 'confidence', 'approved', 'reason',
    'pnl', 'pnlBps', 'notional', 'price', 'edgeBps', 'action', 'level', 'code',
    'message', 'score', 'verdict', 'resolution', 'riskMultiplier', 'what', 'from', 'to', 'why',
  ];
  for (const k of keys) {
    if (payload[k] !== undefined) keep[k] = redact(payload[k]);
  }
  if (!Object.keys(keep).length) {
    // Nothing recognisable: keep the shape, not the values.
    return { keys: Object.keys(payload).slice(0, 12) };
  }
  return keep;
}

class Apprentice {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]    cfg.apprentice
   * @param {object} [opts.log]
   * @param {object} [opts.store]  optional store (journal mirror)
   * @param {string} [opts.dir]    where the JSONL lives
   * @param {object} [opts.bus]    optional bus to auto-subscribe
   */
  constructor({ cfg = {}, log, store = null, dir = null, bus = null } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
    this.store = store;
    this.dir = dir || this.cfg.dir || path.join(process.cwd(), 'data');
    this.file = path.join(this.dir, 'apprentice-log.jsonl');

    this.open = new Map(); // id -> question record
    this.records = []; // in-memory ring, newest last
    this.stats = {
      asked: 0,
      answered: 0,
      unanswered: 0,
      refused: 0,
      violations: 0,
      bytesToday: 0,
      day: new Date().toISOString().slice(0, 10),
    };
    this._subs = [];
    if (bus) this.attach(bus);
  }

  get enabled() {
    return this.cfg.enabled !== false;
  }

  // ------------------------------------------------------------------ storage
  _ensureDir() {
    try {
      fs.mkdirSync(this.dir, { recursive: true });
    } catch (e) {
      this.log.warn(`apprentice: cannot create ${this.dir}: ${e.message}`);
    }
  }

  _rollDay() {
    const day = new Date().toISOString().slice(0, 10);
    if (day !== this.stats.day) {
      this.stats.day = day;
      this.stats.bytesToday = 0;
    }
  }

  /** Append one record. Never throws; returns the record or null. */
  _write(record) {
    if (!this.enabled) return null;
    this._rollDay();
    const line = JSON.stringify(record);
    if (this.stats.bytesToday + line.length > this.cfg.maxBytesPerDay) {
      this.log.warn('apprentice: daily byte cap reached, record dropped');
      return null;
    }
    this._ensureDir();
    try {
      fs.appendFileSync(this.file, line + '\n');
      this.stats.bytesToday += line.length + 1;
    } catch (e) {
      this.log.warn(`apprentice: write failed: ${e.message}`);
      return null;
    }
    this.records.push(record);
    if (this.records.length > this.cfg.maxRecordsInMemory) this.records.shift();
    return record;
  }

  // ---------------------------------------------------------------- questions
  /**
   * Open a question to an actor. Synchronous and non-blocking: it returns an id
   * the actor can answer later, or never.
   *
   * @param {string} actor    who is being asked (scout, board, trader, jev, ...)
   * @param {string} question what is being asked, in the actor's own terms
   * @param {object} [context] the decision under question
   * @returns {string|null}   question id, or null when disabled
   */
  ask(actor, question, context = {}) {
    if (!this.enabled) return null;
    if (!actor || !question) {
      this.stats.refused++;
      return null;
    }
    if (this.open.size >= this.cfg.maxOpenQuestions) {
      // Drop the oldest open question as a violation rather than growing forever.
      const oldest = this.open.keys().next().value;
      this._close(oldest, null, 'evicted');
    }
    const id = uuid('q');
    const rec = {
      id,
      ts: now(),
      kind: 'question',
      actor: String(actor).slice(0, 40),
      question: redact(String(question)).slice(0, 500),
      context: summarise(context),
      status: 'open',
    };
    this.open.set(id, rec);
    this.stats.asked++;
    this._write(rec);
    return id;
  }

  /**
   * Answer an open question. The reason is mandatory: an answer without one is
   * refused and counted, because "because" is not an explanation.
   *
   * @returns {{ok: boolean, reason?: string}}
   */
  answer(id, reason, detail = null) {
    if (!this.enabled) return { ok: false, reason: 'disabled' };
    const q = this.open.get(id);
    if (!q) return { ok: false, reason: 'unknown_or_closed_question' };
    const text = String(reason === undefined || reason === null ? '' : reason).trim();
    if (this.cfg.requireReason && text.length < this.cfg.minReasonChars) {
      this.stats.refused++;
      this._write({
        id: uuid('v'),
        ts: now(),
        kind: 'violation',
        actor: q.actor,
        questionId: id,
        violation: 'empty_or_short_reason',
        got: text.slice(0, 120),
      });
      return { ok: false, reason: `reason must be at least ${this.cfg.minReasonChars} characters` };
    }
    this._close(id, text, 'answered', detail);
    return { ok: true };
  }

  _close(id, reason, status, detail = null) {
    const q = this.open.get(id);
    if (!q) return null;
    this.open.delete(id);
    const rec = {
      id: uuid('a'),
      ts: now(),
      kind: 'answer',
      questionId: id,
      actor: q.actor,
      question: q.question,
      context: q.context,
      status,
      reason: reason ? redact(String(reason)).slice(0, 1200) : null,
      detail: detail ? summarise(detail) : null,
    };
    if (status === 'answered') this.stats.answered++;
    else {
      this.stats.unanswered++;
      this.stats.violations++;
    }
    this._write(rec);
    return rec;
  }

  /**
   * Record a decision together with its reason in one call. This is the path
   * the engine uses for events that are already self-explaining (a board vote
   * carries its veto reasons, a trade carries its rationale).
   */
  observe(actor, action, reason, context = {}) {
    if (!this.enabled) return null;
    const text = String(reason === undefined || reason === null ? '' : reason).trim();
    if (this.cfg.requireReason && text.length < this.cfg.minReasonChars) {
      this.stats.refused++;
      this._write({
        id: uuid('v'),
        ts: now(),
        kind: 'violation',
        actor: String(actor || 'unknown').slice(0, 40),
        violation: 'observe_without_reason',
        action: String(action || '').slice(0, 80),
      });
      return null;
    }
    return this._write({
      id: uuid('o'),
      ts: now(),
      kind: 'observation',
      actor: String(actor || 'unknown').slice(0, 40),
      action: String(action || '').slice(0, 80),
      reason: redact(text).slice(0, 1200),
      context: summarise(context),
    });
  }

  // ------------------------------------------------------------------- wiring
  /**
   * Subscribe to the bus and turn every meaningful event into an observation.
   * Each mapping names the actor and extracts the reason the payload already
   * carries — the apprentice does not invent one.
   */
  attach(bus) {
    if (!bus || !this.enabled) return this;
    const map = [
      ['entry:submitted', 'trader', (p) => ({
        action: `entry ${p?.proposal?.symbol || '?'} ${p?.proposal?.side || ''}`,
        reason: (p?.proposal?.rationale || []).join(' | ') || p?.decision?.reason || '',
        context: { proposal: p?.proposal, decision: p?.decision },
      })],
      ['trade:closed', 'trader', (t) => ({
        action: `close ${t?.symbol || '?'} ${t?.exit?.reason || ''}`,
        reason: (t?.rationale || []).join(' | ') || `exit ${t?.exit?.reason || 'unknown'}`,
        context: t,
      })],
      ['report:ready', 'reporter', (p) => ({
        action: `report #${p?.report?.round ?? '?'}`,
        reason: (p?.report?.lessons || []).join(' | ') || 'periodic report',
        context: { summary: p?.report?.summary },
      })],
      ['audit:alert', 'auditor', (f) => ({
        action: `alert ${f?.code || '?'}`,
        reason: f?.message || '',
        context: f,
      })],
    ];
    for (const [topic, actor, extract] of map) {
      const off = bus.on(topic, (payload) => {
        try {
          const e = extract(payload);
          this.observe(actor, e.action, e.reason, e.context);
        } catch (err) {
          this.log.debug(`apprentice: ${topic} handler failed: ${err.message}`);
        }
      });
      this._subs.push(off);
    }
    return this;
  }

  detach() {
    for (const off of this._subs) {
      try { off(); } catch { /* ignore */ }
    }
    this._subs = [];
  }

  // ------------------------------------------------------------------ dataset
  /**
   * Export the log as a portable training dataset.
   *
   * Shape: one JSON object per line, {instruction, input, output, meta}. That
   * is the format every fine-tuning pipeline understands, and it is deliberately
   * model-agnostic: the same file trains the apprentice, a local model, or a
   * hosted one.
   *
   * @param {object} [opts] { since, actor, limit }
   * @returns {Array<object>}
   */
  exportDataset(opts = {}) {
    const since = Number(opts.since) || 0;
    const actor = opts.actor ? String(opts.actor) : null;
    const limit = Number(opts.limit) || 0;
    const out = [];
    for (const r of this.records) {
      if (r.ts < since) continue;
      if (actor && r.actor !== actor) continue;
      if (r.kind === 'question') continue; // a question without an answer is not a lesson
      if (r.kind === 'violation') continue;
      const reason = r.reason || (r.kind === 'answer' ? null : null);
      if (!reason) continue;
      out.push({
        instruction: `Explain why ${r.actor} did: ${r.action || r.question || 'this'}`,
        input: JSON.stringify(r.context || {}),
        output: reason,
        meta: { ts: r.ts, actor: r.actor, kind: r.kind, status: r.status || 'observed' },
      });
    }
    return limit > 0 ? out.slice(-limit) : out;
  }

  /** Write the dataset to a file. Returns the path, or null on failure. */
  writeDataset(file = null) {
    const target = file || path.join(this.dir, 'apprentice-dataset.jsonl');
    const rows = this.exportDataset();
    try {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, rows.map((r) => JSON.stringify(r)).join('\n') + (rows.length ? '\n' : ''));
      return target;
    } catch (e) {
      this.log.warn(`apprentice: dataset write failed: ${e.message}`);
      return null;
    }
  }

  snapshot() {
    return {
      enabled: this.enabled,
      file: this.file,
      open: this.open.size,
      records: this.records.length,
      ...this.stats,
      recent: this.records.slice(-5).map((r) => ({
        ts: r.ts, kind: r.kind, actor: r.actor,
        action: r.action || r.question || null,
        reason: r.reason ? String(r.reason).slice(0, 160) : null,
      })),
    };
  }
}

module.exports = { Apprentice, redact, summarise, DEFAULTS };
