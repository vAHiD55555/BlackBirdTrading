'use strict';
/**
 * BlackBird — exit ladder (shared by the live trader and the backtester).
 *
 *   gain < 1R            -> structural stop stands
 *   gain >= 1R           -> stop to breakeven
 *   gain >= 2R           -> stop to +1R (a real profit is locked)
 *   after 1R             -> stop trails behind price by 1.5 * ATR
 *
 * Direction aware: a long trails upward, a short trails downward.
 */
function updateStop(pos, { price, atr, beAtR = 1, lockAtR = 2, trailAtr = 1.5 }) {
  const R = pos.riskUnit;
  const dir = pos.dir || 1;
  if (!R || R <= 0 || !Number.isFinite(price)) return null;

  const gain = (price - pos.entry) * dir;
  if (gain < beAtR * R) return null;

  if (dir > 0) {
    const candidates = [pos.sl, pos.entry];
    if (gain >= lockAtR * R) candidates.push(pos.entry + R);
    if (atr > 0) candidates.push(price - trailAtr * atr);
    const next = Math.max(...candidates);
    if (next > pos.sl + 1e-12) {
      pos.sl = next;
      return next;
    }
    return null;
  }

  const candidates = [pos.sl, pos.entry];
  if (gain >= lockAtR * R) candidates.push(pos.entry - R);
  if (atr > 0) candidates.push(price + trailAtr * atr);
  const next = Math.min(...candidates);
  if (next < pos.sl - 1e-12) {
    pos.sl = next;
    return next;
  }
  return null;
}

/** Funding is charged to the holder when the rate is positive. */
function fundingFor(pos, rateBps) {
  if (!rateBps) return 0;
  const side = pos.dir > 0 ? 1 : -1;
  return (pos.notional * rateBps) / 10000 * side;
}

module.exports = { updateStop, fundingFor };
