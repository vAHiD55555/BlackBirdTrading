'use strict';
/**
 * BlackBird — the Watch (دیده‌بان).
 *
 * The scout hunts patterns inside the symbols we already trade. The watch does
 * the opposite job: it looks OUTSIDE the current book for something better, and
 * proposes replacing a holding that has gone stagnant or low-yield.
 *
 * Three stages, each of which can say no:
 *
 *   1. DISCOVER  — ask the exchange for its most liquid symbols (public, no key,
 *                  no paid data), drop anything we already hold, drop thin books.
 *   2. RANK      — score each candidate on momentum, trend quality, volatility
 *                  and cost. A candidate must beat the incumbent by `minEdgeBps`
 *                  to be worth the round trip.
 *   3. PROPOSE   — build a swap proposal and hand it to the SAME board that
 *                  gates every other trade. The watch never opens a position
 *                  itself, and `autoApply` defaults to false.
 *
 * Design rules that matter:
 *   - It is read-only against the exchange: public endpoints only.
 *   - It never raises a risk limit. A swap is a replacement, not an addition:
 *     the new notional is capped by the incumbent's own notional.
 *   - Every decision is written to the journal, including the ones it refuses,
 *     so "why did nothing change?" is answerable from the log.
 *   - A failure anywhere returns an empty result. Discovery is optional; the
 *     book must keep running when the exchange is unreachable.
 */
const { now, clamp, uuid, bps } = require('../core/util');

const HOUR = 3600000;
const DAY = 86400000;

/** Annualised realised volatility from a close series. */
function realisedVol(closes, barsPerYear) {
  if (!Array.isArray(closes) || closes.length < 20) return NaN;
  const rets = [];
  for (let i = 1; i < closes.length; i++) {
    if (closes[i - 1] > 0) rets.push(closes[i] / closes[i - 1] - 1);
  }
  if (rets.length < 15) return NaN;
  const m = rets.reduce((a, b) => a + b, 0) / rets.length;
  const v = rets.reduce((a, b) => a + (b - m) ** 2, 0) / (rets.length - 1);
  return Math.sqrt(v) * Math.sqrt(barsPerYear);
}

/** Simple moving average of the last `n` values. */
function sma(values, n) {
  if (!Array.isArray(values) || values.length < n) return NaN;
  const slice = values.slice(-n);
  return slice.reduce((a, b) => a + b, 0) / n;
}

/**
 * Score one candidate from its bars. Pure: no I/O, no clock, no config reads
 * beyond the numbers passed in. That is what makes it testable.
 *
 * @param {Array<{t,o,h,l,c,v}>} bars  oldest first, at least ~60 bars
 * @param {object} opts { barsPerYear, costBps }
 * @returns {object|null} null when there is not enough data to judge
 */
function scoreCandidate(bars, opts = {}) {
  const o = { barsPerYear: 24 * 365, costBps: 20, ...opts };
  if (!Array.isArray(bars) || bars.length < 60) return null;
  const closes = bars.map((b) => b.c).filter((c) => Number.isFinite(c) && c > 0);
  if (closes.length < 60) return null;

  const last = closes[closes.length - 1];
  const ret = (n) => {
    if (closes.length <= n) return NaN;
    const prev = closes[closes.length - 1 - n];
    return prev > 0 ? (last / prev - 1) * 100 : NaN;
  };

  const r7 = ret(7 * 24); // one week of hourly bars
  const r30 = ret(30 * 24);
  const r90 = ret(90 * 24);
  const ma50 = sma(closes, 50);
  const ma200 = sma(closes, 200);
  const vol = realisedVol(closes.slice(-240), o.barsPerYear);

  // Trend quality: is the move orderly (above both averages, averages stacked)
  // or is it a spike that will mean-revert? A spike scores badly on purpose.
  const aboveMa50 = Number.isFinite(ma50) ? last > ma50 : false;
  const stacked = Number.isFinite(ma50) && Number.isFinite(ma200) ? ma50 > ma200 : false;
  const trendQuality = (aboveMa50 ? 0.5 : 0) + (stacked ? 0.5 : 0);

  // Momentum: blend the windows so one lucky week cannot carry a candidate.
  const mom = [r7, r30, r90].filter((v) => Number.isFinite(v));
  const momentum = mom.length ? mom.reduce((a, b) => a + b, 0) / mom.length : 0;

  // Volatility: we want movement, but not a coin flip. Penalise the extremes.
  const volPct = Number.isFinite(vol) ? vol * 100 : null;
  let volScore = 0.5;
  if (volPct !== null) {
    if (volPct < 20) volScore = 0.2; // too quiet to pay for the round trip
    else if (volPct > 180) volScore = 0.2; // too wild to size safely
    else volScore = clamp(1 - Math.abs(volPct - 70) / 110, 0.2, 1);
  }

  // Expected edge: momentum, discounted by cost and by how orderly the trend is.
  const grossEdgeBps = momentum * 100; // percent -> bps
  const expectedEdgeBps = grossEdgeBps * (0.4 + 0.6 * trendQuality) - o.costBps;

  const score = clamp(
    0.45 * clamp(expectedEdgeBps / 400, 0, 1) +
      0.30 * trendQuality +
      0.25 * volScore,
    0,
    1
  );

  // A candidate must be TRENDING, not merely cheap. Without this gate the watch
  // kept proposing falling knives: a symbol down 30% has a great "edge" on
  // paper and is exactly the wrong thing to rotate into. Both floors are panel
  // knobs (WATCH_MIN_MOMENTUM_PCT / WATCH_MIN_TREND_QUALITY).
  const minMomentum = Number.isFinite(Number(o.minMomentumPct)) ? Number(o.minMomentumPct) : 0;
  const minTrend = Number.isFinite(Number(o.minTrendQuality)) ? Number(o.minTrendQuality) : 0.35;
  const passesGate = momentum >= minMomentum && trendQuality >= minTrend;

  return {
    last,
    r7: Number.isFinite(r7) ? Math.round(r7 * 100) / 100 : null,
    r30: Number.isFinite(r30) ? Math.round(r30 * 100) / 100 : null,
    r90: Number.isFinite(r90) ? Math.round(r90 * 100) / 100 : null,
    momentumPct: Math.round(momentum * 100) / 100,
    volPct: volPct === null ? null : Math.round(volPct * 10) / 10,
    trendQuality: Math.round(trendQuality * 100) / 100,
    volScore: Math.round(volScore * 100) / 100,
    expectedEdgeBps: Math.round(expectedEdgeBps * 10) / 10,
    score: Math.round(score * 1000) / 1000,
    passesGate,
  };
}

/**
 * Is a holding stagnant? Two independent tests, either of which is enough:
 *   - it barely moved over the window (dead capital), or
 *   - it lost money over the window (worse than dead).
 * A holding that is simply down but still moving is NOT stagnant: that is a
 * losing trade, and the stop/exit logic owns it, not the watch.
 */
function isStagnant(holding, cfg) {
  // Number(null) is 0 and Number('') is 0, so a missing return would read as
  // "perfectly flat" and get a healthy position swapped out. Reject anything
  // that is not an actual finite number first.
  const raw = holding ? holding.returnPct : undefined;
  if (raw === null || raw === undefined || raw === '') return { stagnant: false, reason: 'no_return_data' };
  const ret = Number(raw);
  if (!Number.isFinite(ret)) return { stagnant: false, reason: 'no_return_data' };
  if (ret <= -Math.abs(cfg.stagnantReturnPct)) {
    return { stagnant: true, reason: `losing(${ret.toFixed(2)}%)` };
  }
  if (Math.abs(ret) < Math.abs(cfg.stagnantReturnPct)) {
    return { stagnant: true, reason: `flat(${ret.toFixed(2)}%)` };
  }
  return { stagnant: false, reason: `moving(${ret.toFixed(2)}%)` };
}

class Watch {
  /**
   * @param {object} o
   * @param {object} o.cfg      full config (reads cfg.watch, cfg.fees, cfg.symbols)
   * @param {object} o.log
   * @param {object} o.store    journal
   * @param {object} o.hub      MarketHub (for bars of symbols we already track)
   * @param {object} o.exchange primary exchange adapter (public endpoints)
   * @param {object} [o.portfolio]
   * @param {object} [o.board]  the council; when present a swap must be approved
   * @param {object} [o.risk]
   * @param {object} [o.executor] the only thing allowed to touch the book:
   *        { close(symbol, reason) -> {ok, reason?}, open(swap, decision) -> {ok, reason?} }
   * @param {function} [o.clock]
   */
  constructor({ cfg, log, store, hub, exchange, portfolio = null, board = null, risk = null, executor = null, clock = now }) {
    this.cfg = cfg;
    this.w = cfg.watch || {};
    this.log = log;
    this.store = store;
    this.hub = hub;
    this.exchange = exchange;
    this.portfolio = portfolio;
    this.board = board;
    this.risk = risk;
    this.executor = executor;
    this.clock = clock;

    this.lastRunAt = 0;
    this.lastResult = null;
    this.proposals = [];
    this.stats = {
      cycles: 0,
      discovered: 0,
      gated: 0, // candidates rejected for not trending
      ranked: 0,
      proposed: 0,
      approved: 0,
      applied: 0,
      refused: 0,
      errors: 0,
    };
  }

  get enabled() {
    return Boolean(this.w.enabled);
  }

  _costBps() {
    const f = this.cfg.fees || {};
    // A swap is two round trips: out of the incumbent, into the candidate.
    return (Number(f.takerBps) || 10) * 2 + (Number(f.slippageBpsPer1kNotional) || 0.6) * 2;
  }

  /** Symbols we already hold or already track. A candidate must be new. */
  _heldSymbols() {
    const held = new Set();
    try {
      if (this.portfolio && typeof this.portfolio.openPositions === 'function') {
        for (const p of this.portfolio.openPositions()) held.add(String(p.symbol).toUpperCase());
      }
    } catch { /* no portfolio: nothing is held */ }
    for (const s of this.cfg.symbols || []) held.add(String(s).toUpperCase());
    return held;
  }

  /**
   * Ask the exchange for liquid symbols. Public endpoint only; no key, no paid
   * feed. Returns [] on any failure — discovery is optional.
   */
  async discover() {
    const held = this._heldSymbols();
    const configured = Array.isArray(this.w.universe) ? this.w.universe : [];
    let symbols = configured;

    if (!symbols.length) {
      // No explicit universe: use the venue's own 24h volume ranking. This is
      // the honest answer to "what is liquid right now" and needs no key.
      try {
        if (this.exchange && typeof this.exchange.tickers === 'function') {
          const map = await this.exchange.tickers();
          const rows = [...map.values()]
            .filter((t) => t && Number.isFinite(Number(t.quoteVolume)))
            .sort((a, b) => Number(b.quoteVolume) - Number(a.quoteVolume));
          symbols = rows.map((t) => t.symbol);
        }
      } catch (e) {
        this.log.debug(`watch discovery failed: ${e.message}`);
        this.stats.errors++;
        return [];
      }
    }

    const out = [];
    // `scanLimit` is how many of the venue's liquid symbols we actually look
    // at. It used to be hard-wired to `maxCandidates * 4` (20 by default), which
    // meant the scan only ever saw the same top-20 majors and never discovered
    // anything genuinely new. It is now its own panel knob.
    const scanLimit = Math.max(1, Number(this.w.scanLimit) || 40);
    for (const raw of symbols) {
      const sym = String(raw).toUpperCase();
      if (!sym || held.has(sym)) continue;
      out.push(sym);
      if (out.length >= scanLimit) break;
    }
    this.stats.discovered += out.length;
    return out;
  }

  /** Bars for a symbol: from the hub when we track it, else fetched. */
  async _bars(symbol, limit = 240) {
    const feed = this.hub && typeof this.hub.get === 'function' ? this.hub.get(symbol) : null;
    if (feed && feed.bars && typeof feed.bars.toArray === 'function') {
      const local = feed.bars.toArray();
      if (local.length >= 60) return local;
    }
    if (this.exchange && typeof this.exchange.klines === 'function') {
      try {
        return await this.exchange.klines(symbol, limit, '1h');
      } catch (e) {
        this.log.debug(`watch klines ${symbol} failed: ${e.message}`);
        return [];
      }
    }
    return [];
  }

  /** Rank candidates. Pure scoring lives in scoreCandidate(). */
  async rank(symbols) {
    const costBps = this._costBps();
    const rows = [];
    let gated = 0;
    for (const sym of symbols) {
      try {
        const bars = await this._bars(sym);
        const s = scoreCandidate(bars, {
          barsPerYear: 24 * 365,
          costBps,
          minMomentumPct: this.w.minMomentumPct,
          minTrendQuality: this.w.minTrendQuality,
        });
        if (!s) continue;
        if (s.expectedEdgeBps < Number(this.w.minEdgeBps || 0)) continue;
        // A candidate that is not trending is not a candidate. Counting it as
        // "gated" rather than silently dropping it makes the dashboard honest
        // about how many ideas were rejected and why.
        if (!s.passesGate) { gated++; continue; }
        rows.push({ symbol: sym, ...s });
      } catch (e) {
        this.log.debug(`watch rank ${sym} failed: ${e.message}`);
      }
    }
    this.stats.gated = (this.stats.gated || 0) + gated;
    rows.sort((a, b) => b.score - a.score);
    this.stats.ranked += rows.length;
    return rows.slice(0, Math.max(1, Number(this.w.maxCandidates) || 5));
  }

  /** Current holdings with their return over the stagnation window. */
  _holdings() {
    const out = [];
    try {
      if (!this.portfolio || typeof this.portfolio.openPositions !== 'function') return out;
      for (const p of this.portfolio.openPositions()) {
        const entry = Number(p.entry);
        const last = Number(p.last);
        const returnPct = entry > 0 && Number.isFinite(last) ? ((last - entry) / entry) * 100 * (p.dir || 1) : NaN;
        out.push({
          symbol: String(p.symbol).toUpperCase(),
          dir: p.dir || 1,
          notional: Math.abs(Number(p.qty) * (Number.isFinite(last) ? last : entry)) || 0,
          returnPct: Number.isFinite(returnPct) ? Math.round(returnPct * 100) / 100 : null,
          strategy: p.strategy || null,
        });
      }
    } catch { /* no portfolio */ }
    return out;
  }

  /**
   * Build swap proposals: for each stagnant holding, the best candidate that
   * beats it by `minEdgeBps`. One proposal per holding, capped by
   * `maxSwapsPerCycle`.
   */
  buildSwaps(candidates, holdings) {
    const swaps = [];
    const used = new Set();
    const minEdge = Number(this.w.minEdgeBps) || 0;
    const maxSwaps = Math.max(0, Number(this.w.maxSwapsPerCycle) || 0);

    for (const h of holdings) {
      if (swaps.length >= maxSwaps) break;
      const st = isStagnant(h, this.w);
      if (!st.stagnant) continue;
      const best = candidates.find((c) => !used.has(c.symbol));
      if (!best) continue;
      // The candidate must beat the incumbent's own return by the edge floor.
      const incumbentEdge = Number.isFinite(h.returnPct) ? h.returnPct * 100 : 0;
      if (best.expectedEdgeBps - incumbentEdge < minEdge) continue;
      used.add(best.symbol);
      swaps.push({
        id: uuid('swap'),
        ts: this.clock(),
        out: { symbol: h.symbol, notional: h.notional, returnPct: h.returnPct, reason: st.reason },
        in: { symbol: best.symbol, score: best.score, expectedEdgeBps: best.expectedEdgeBps, momentumPct: best.momentumPct },
        // A swap is a REPLACEMENT: the new notional never exceeds the old one.
        notional: h.notional,
        edgeBps: Math.round((best.expectedEdgeBps - incumbentEdge) * 10) / 10,
        status: 'pending',
      });
    }
    return swaps;
  }

  /**
   * One discovery cycle. Never throws: a failure returns an empty result and is
   * journalled, because a broken watch must not stop the book.
   */
  async run() {
    if (!this.enabled) return { ok: false, reason: 'disabled', swaps: [] };
    this.stats.cycles++;
    this.lastRunAt = this.clock();
    try {
      const symbols = await this.discover();
      if (!symbols.length) {
        this.lastResult = { ok: true, at: this.lastRunAt, candidates: [], swaps: [], note: 'nothing_new' };
        return this.lastResult;
      }
      const candidates = await this.rank(symbols);
      const holdings = this._holdings();
      const swaps = this.buildSwaps(candidates, holdings);

      for (const s of swaps) {
        this.stats.proposed++;
        this.proposals.push(s);
        try {
          this.store.append('watch_proposal', {
            id: s.id, out: s.out.symbol, in: s.in.symbol, edgeBps: s.edgeBps, notional: s.notional,
          });
        } catch { /* journal is best effort here */ }
        this.log.info(`watch: swap ${s.out.symbol} -> ${s.in.symbol} (edge ${s.edgeBps}bps, ${s.out.reason})`);
      }
      if (this.proposals.length > 200) this.proposals = this.proposals.slice(-200);

      this.lastResult = {
        ok: true,
        at: this.lastRunAt,
        candidates: candidates.map((c) => ({ symbol: c.symbol, score: c.score, edgeBps: c.expectedEdgeBps })),
        swaps,
      };
      return this.lastResult;
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`watch cycle failed: ${e.message}`);
      this.lastResult = { ok: false, reason: e.message, candidates: [], swaps: [] };
      return this.lastResult;
    }
  }

  /**
   * Hand a swap to the council. Returns the decision; never applies anything
   * itself. `autoApply` only decides whether the caller MAY act on an approval.
   */
  review(swap) {
    if (!swap) return { ok: false, reason: 'no_swap' };
    if (!this.w.requireCouncil || !this.board) {
      return { ok: true, approved: true, reason: 'council_not_required', swapId: swap.id };
    }
    // The board speaks in proposals, so the swap is expressed as one. The
    // notional is the incumbent's, which is what makes this a replacement.
    const proposal = {
      id: swap.id,
      ts: swap.ts,
      symbol: swap.in.symbol,
      side: 'buy',
      strategy: 'WATCH_SWAP',
      entryType: 'taker',
      price: 0,
      tpBps: Math.max(Number(this.cfg.strategy?.minTpBps) || 30, swap.edgeBps),
      slBps: Number(this.cfg.strategy?.maxSlBps) || 250,
      confidence: clamp(swap.in.score, 0, 1),
      notional: swap.notional,
      expectedEdgeBps: swap.edgeBps,
    };
    try {
      const decision = this.board.review(proposal, this.portfolio, 0);
      if (decision && decision.approved) this.stats.approved++;
      else this.stats.refused++;
      return { ok: true, approved: Boolean(decision && decision.approved), decision, swapId: swap.id };
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`watch council review failed: ${e.message}`);
      return { ok: false, reason: e.message, approved: false, swapId: swap.id };
    }
  }

  /**
   * Apply an approved swap to the book. This is the ONLY method that changes
   * positions, and it is deliberately paranoid:
   *
   *   - `autoApply` must be on. Off means propose-and-wait, always.
   *   - the council must have approved. A missing decision is a refusal.
   *   - the incumbent must still be open, and the candidate must not be held.
   *   - the notional is clamped to the incumbent's own notional: a swap is a
   *     replacement, never an addition, so it can never raise exposure.
   *   - close first, open second. If the open fails we are flat, not doubled.
   *
   * @param {object} swap
   * @param {object} decision  the council's decision for this swap
   * @returns {{ok: boolean, reason?: string, applied?: boolean}}
   */
  applySwap(swap, decision) {
    if (!swap) return { ok: false, reason: 'no_swap' };
    if (!this.w.autoApply) return { ok: false, reason: 'auto_apply_off' };
    if (!decision || !decision.approved) return { ok: false, reason: 'not_approved' };
    if (!this.executor) return { ok: false, reason: 'no_executor' };

    const outSym = String(swap.out?.symbol || '').toUpperCase();
    const inSym = String(swap.in?.symbol || '').toUpperCase();
    if (!outSym || !inSym || outSym === inSym) return { ok: false, reason: 'bad_swap' };

    // The incumbent must still be there. Between proposal and approval the
    // stop or the time stop may have closed it; swapping then would open a
    // position nobody asked for.
    const incumbent = this.portfolio && typeof this.portfolio.get === 'function'
      ? this.portfolio.get(outSym)
      : null;
    if (!incumbent) return { ok: false, reason: 'incumbent_gone' };

    if (this.portfolio && typeof this.portfolio.hasPosition === 'function' && this.portfolio.hasPosition(inSym)) {
      return { ok: false, reason: 'candidate_already_held' };
    }

    // Replacement sizing: never more than what is actually held right now.
    const heldNotional = Math.abs(Number(incumbent.notional) || 0);
    const notional = Math.min(Math.abs(Number(swap.notional) || 0), heldNotional);
    const minNotional = Number(this.cfg.risk?.minNotionalUsd) || 0;
    if (!(notional > 0) || notional < minNotional) {
      return { ok: false, reason: 'below_min_notional' };
    }

    // 1. close the incumbent
    let closed;
    try {
      closed = this.executor.close(outSym, 'watch_swap');
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`watch apply: close ${outSym} threw: ${e.message}`);
      this._journalApply(swap, { applied: false, reason: 'close_failed', error: e.message });
      return { ok: false, reason: 'close_failed' };
    }
    if (!closed || closed.ok === false) {
      this._journalApply(swap, { applied: false, reason: 'close_failed', detail: closed?.reason });
      return { ok: false, reason: 'close_failed' };
    }

    // 2. open the candidate, sized to the incumbent
    const sized = { ...decision, notional, qty: decision.qty };
    let opened;
    try {
      opened = this.executor.open({ ...swap, notional }, sized);
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`watch apply: open ${inSym} threw: ${e.message}`);
      this._journalApply(swap, { applied: false, reason: 'open_failed_flat', error: e.message });
      return { ok: false, reason: 'open_failed_flat' };
    }
    if (!opened || opened.ok === false) {
      // We are flat now. That is the safe failure: no double exposure, and the
      // next cycle can propose again.
      this._journalApply(swap, { applied: false, reason: 'open_failed_flat', detail: opened?.reason });
      return { ok: false, reason: 'open_failed_flat' };
    }

    swap.status = 'applied';
    this.stats.applied++;
    this._journalApply(swap, { applied: true, notional });
    this.log.info(`watch: applied swap ${outSym} -> ${inSym} ($${Math.round(notional)})`);
    return { ok: true, applied: true, notional };
  }

  _journalApply(swap, outcome) {
    try {
      this.store.append('watch_applied', {
        id: swap.id, out: swap.out?.symbol, in: swap.in?.symbol, ...outcome,
      });
    } catch { /* journal is best effort */ }
    if (!outcome.applied) {
      try {
        this.store.append('watch_apply_failed', { id: swap.id, reason: outcome.reason });
      } catch { /* best effort */ }
    }
  }

  /**
   * A full cycle: discover, rank, propose, ask the council, and (only when
   * `autoApply` is on) apply. `run()` stays the read-only discovery pass; this
   * is the one the engine schedules when it wants the swap to actually happen.
   *
   * Never throws. Every swap gets an outcome, applied or refused, so the log
   * answers "why did nothing change?".
   */
  async runCycle() {
    const base = await this.run();
    if (!base || !base.ok) return { ...base, outcomes: [] };

    const outcomes = [];
    for (const swap of base.swaps || []) {
      const rev = this.review(swap);
      if (!rev.approved) {
        outcomes.push({ swapId: swap.id, applied: false, reason: rev.reason || 'not_approved' });
        continue;
      }
      const ap = this.applySwap(swap, rev.decision);
      outcomes.push({ swapId: swap.id, applied: Boolean(ap.applied), reason: ap.reason || 'applied' });
    }

    this.lastResult = { ...base, outcomes };
    return this.lastResult;
  }

  snapshot() {
    return {
      enabled: this.enabled,
      lastRunAt: this.lastRunAt,
      ...this.stats,
      last: this.lastResult
        ? {
            at: this.lastResult.at,
            candidates: (this.lastResult.candidates || []).slice(0, 5),
            swaps: (this.lastResult.swaps || []).map((s) => ({ out: s.out.symbol, in: s.in.symbol, edgeBps: s.edgeBps })),
          }
        : null,
    };
  }
}

module.exports = { Watch, scoreCandidate, isStagnant, realisedVol, sma };
