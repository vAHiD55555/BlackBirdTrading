'use strict';
/**
 * BlackBird — Trader ("معامله‌گر").
 *
 * Executes only what the board approved, then owns the position until it is
 * closed. Long (spot) and short (futures) are handled by the same code: every
 * price comparison is multiplied by pos.dir, so there is one path to audit.
 *
 * Exit priority:
 *   1. halt / kill switch -> flatten at market
 *   2. stop loss          -> market (must get out)
 *   3. take profit        -> limit (we stay the maker and keep the fee)
 *   4. time stop          -> market
 *   5. funding            -> accrued every 8h boundary, settled at close
 */
const { now } = require('../core/util');
const { updateStop, fundingFor } = require('./exits');
const { Position } = require('../exec/portfolio');

class Trader {
  constructor({ cfg, log, store, broker, portfolio, risk, jev, hub, bus }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.broker = broker;
    this.portfolio = portfolio;
    this.risk = risk;
    this.jev = jev;
    this.hub = hub;
    this.bus = bus;
    this.pendingEntries = new Map();
    this.pendingExits = new Map();
    this.trades = [];
    this.observations = [];
    this.maxObservations = 400;
    this.stats = { entries: 0, exits: 0, rejected: 0, longs: 0, shorts: 0 };
  }

  observe(symbol, snap, regime) {
    this.observations.push({
      ts: now(),
      symbol,
      price: snap.price,
      regime: regime.regime,
      regimeScore: regime.score,
      atrPct: Math.round(snap.atrPct * 100) / 100,
      rsi: Math.round(snap.rsi * 10) / 10,
      bbPctB: snap.bb ? Math.round(snap.bb.pctB * 1000) / 1000 : null,
      trend: Math.round(snap.trendStrength * 100) / 100,
      volPct: Math.round(snap.atrPercentile * 1000) / 1000,
      reasons: regime.reasons,
    });
    if (this.observations.length > this.maxObservations) this.observations.shift();
  }

  // -------------------------------------------------------------------- entry
  enter(proposal, decision) {
    if (!decision.approved) {
      this.stats.rejected++;
      return { ok: false, reason: 'not_approved' };
    }
    if (this.portfolio.hasPosition(proposal.symbol)) return { ok: false, reason: 'already_open' };

    const feed = this.hub.get(proposal.symbol);
    const book = feed?.book();
    if (!book || feed.isStale) return { ok: false, reason: 'stale_book' };

    const isShort = proposal.side === 'sell';
    const entryType = (proposal.entryType === 'market' || proposal.entryType === 'taker') ? 'market' : 'limit';
    const price = entryType === 'market'
      ? (isShort ? book.bid : book.ask)
      : (isShort ? Math.max(book.ask, proposal.price) : Math.min(book.bid, proposal.price));

    const qty = decision.qty || this.risk.size({
      price,
      tpBps: proposal.tpBps,
      slBps: proposal.slBps,
      entryFeeBps: entryType === 'maker' ? this.cfg.fees.makerBps : this.cfg.fees.takerBps,
      exitFeeBps: this.cfg.fees.makerBps,
    }).qty;

    const signalTs = proposal.ts;
    const built = this.jev.build({
      symbol: proposal.symbol,
      side: isShort ? 'sell' : 'buy',
      type: entryType,
      qty,
      price,
      signalTs,
      ttlMs: this.cfg.strategy.makerTimeoutMs,
      tag: 'entry:' + proposal.id,
    });
    if (!built.ok) {
      this.stats.rejected++;
      this.store.append('entry_aborted', { symbol: proposal.symbol, reason: built.reason });
      return { ok: false, reason: built.reason };
    }

    const res = this.broker.submit(built.order);
    const latencyMs = now() - signalTs;
    this.jev.record(latencyMs, { symbol: proposal.symbol, kind: 'entry' });

    if (res.status === 'rejected') {
      this.stats.rejected++;
      this.store.append('entry_rejected', { symbol: proposal.symbol, reason: res.reason });
      return { ok: false, reason: res.reason };
    }

    this.pendingEntries.set(res.orderId || built.order.orderId, { decision, proposal, order: built.order });
    this.store.append('order', {
      kind: 'entry',
      orderId: res.orderId || built.order.orderId,
      symbol: proposal.symbol,
      side: isShort ? 'sell' : 'buy',
      type: entryType,
      qty: built.order.qty,
      price: built.order.price,
      status: res.status,
      latencyMs,
      jevMs: built.latencyMs,
      decisionId: decision.id,
    });
    this.log.info('entry ' + proposal.symbol + ' ' + (isShort ? 'SHORT' : 'LONG') + ' ' + entryType, {
      qty: built.order.qty, price, status: res.status, latencyMs,
    });

    if (res.status === 'filled') this._onEntryFill(res, proposal, decision);
    return { ok: true, status: res.status, orderId: res.orderId, latencyMs };
  }

  _onEntryFill(fill, proposal, decision) {
    const dir = proposal.side === 'sell' ? -1 : 1;
    const slPrice = fill.price * (1 - dir * (proposal.slBps / 10000));
    const tpPrice = fill.price * (1 + dir * (proposal.tpBps / 10000));
    const pos = this.portfolio.open(new Position({
      symbol: proposal.symbol,
      side: dir > 0 ? 'long' : 'short',
      qty: fill.qty,
      entry: fill.price,
      fee: fill.fee,
      notional: fill.price * fill.qty,
      strategy: proposal.strategy,
      tp: tpPrice,
      sl: slPrice,
      timeStopAt: now() + this.cfg.strategy.timeStopMs,
      proposalId: proposal.id,
      decisionId: decision.id,
      context: proposal.features,
      rationale: proposal.rationale,
      riskUnit: Math.abs(fill.price - slPrice),
    }));
    this.stats.entries++;
    this.stats[dir > 0 ? 'longs' : 'shorts']++;
    this.store.append('fill', {
      kind: 'entry', tradeId: pos.id, symbol: pos.symbol, side: pos.side,
      price: pos.entry, qty: pos.qty, fee: pos.entryFee, feeKind: fill.feeKind,
      slippageBps: fill.slippageBps, tp: pos.tp, sl: pos.sl, strategy: pos.strategy,
    });
    this.bus.emit('position:opened', pos);
    this.log.info('position open ' + pos.symbol + ' ' + pos.side.toUpperCase(), {
      entry: pos.entry, tp: Math.round(pos.tp * 100) / 100, sl: Math.round(pos.sl * 100) / 100,
      notional: Math.round(pos.notional),
    });
  }

  // --------------------------------------------------------------------- ticks
  onTick(ticker, feed) {
    const fills = this.broker.onTick(ticker, feed);
    for (const f of fills) {
      if (f.tag && String(f.tag).startsWith('entry:')) {
        const pending = this.pendingEntries.get(f.orderId);
        this.pendingEntries.delete(f.orderId);
        if (pending) this._onEntryFill(f, pending.proposal, pending.decision);
      } else if (String(f.tag || '').startsWith('exit:')) {
        this._onExitFill(f);
      }
    }

    const pos = this.portfolio.get(ticker.symbol);
    if (!pos) return;
    if (pos.strategy === 'ORBITAL') return;
    pos.mark(ticker.bid);
    if (this.risk.halted) return this._exit(pos, 'kill_switch', 'market');

    const t = now();
    const dir = pos.dir;
    // a short is stopped on the ask, a long on the bid
    const mkt = dir > 0 ? ticker.bid : ticker.ask;
    if (dir > 0) {
      if (mkt <= pos.sl) return this._exit(pos, 'stop_loss', 'market');
      if (mkt >= pos.tp) return this._exit(pos, 'take_profit', 'limit');
    } else {
      if (ticker.ask >= pos.sl) return this._exit(pos, 'stop_loss', 'market');
      if (ticker.bid <= pos.tp) return this._exit(pos, 'take_profit', 'limit');
    }
    if (t >= pos.timeStopAt) return this._exit(pos, 'time_stop', 'market');
    return undefined;
  }

  /** On each closed candle: trailing stop + funding accrual. */
  onBar(symbol, snap) {
    const pos = this.portfolio.get(symbol);
    if (!pos || !snap) return null;
    if (pos.strategy === 'ORBITAL') return null;

    // funding: charged at 00:00 / 08:00 / 16:00 UTC
    if (this.cfg.market === 'futures' && this.cfg.futures?.fundingBps > 0) {
      const f = fundingFor(pos, this.cfg.futures.fundingBps);
      const boundary = fundingBoundarySince(pos.lastFundingAt || pos.openedAt);
      if (boundary) {
        pos.fundingPaid += f;
        pos.lastFundingAt = boundary;
        this.store.append('funding', { symbol, tradeId: pos.id, amount: Math.round(f * 1e6) / 1e6 });
      }
    }

    const moved = updateStop(pos, {
      price: snap.close,
      atr: snap.atr,
      beAtR: this.cfg.strategy.beAtR ?? 1,
      lockAtR: this.cfg.strategy.lockAtR ?? 2,
      trailAtr: this.cfg.strategy.trailAtr ?? 1.5,
    });
    if (moved) {
      this.store.append('trail', { symbol, tradeId: pos.id, newSl: Math.round(moved * 1e6) / 1e6, price: snap.close });
      this.log.info('trail stop ' + symbol, { newSl: Math.round(moved * 100) / 100, entry: pos.entry, side: pos.side });
    }
    return moved;
  }

  onClock() {
    for (const e of this.broker.expire(now())) {
      const pending = this.pendingEntries.get(e.orderId);
      if (pending) {
        this.pendingEntries.delete(e.orderId);
        this.store.append('order_expired', { orderId: e.orderId, symbol: e.symbol, side: e.side });
      }
    }
  }

  _exit(pos, reason, type) {
    if (this.pendingExits.has(pos.id)) return;
    const feed = this.hub.get(pos.symbol);
    const book = feed?.book();
    if (!book) return;
    const closingSide = pos.dir > 0 ? 'sell' : 'buy';
    const price = type === 'limit' ? pos.tp : (closingSide === 'sell' ? book.bid : book.ask);

    const built = this.jev.build({
      symbol: pos.symbol, side: closingSide, type, qty: pos.qty, price,
      signalTs: now(), ttlMs: 15000, tag: 'exit:' + pos.id,
    });
    if (!built.ok) {
      built.order = { symbol: pos.symbol, side: closingSide, type: 'market', qty: pos.qty, price: null, ttlMs: 5000, tag: 'exit:' + pos.id };
      built.ok = true;
    }
    const res = this.broker.submit(built.order);
    this.store.append('order', {
      kind: 'exit', reason, orderId: res.orderId || built.order.orderId, symbol: pos.symbol,
      side: closingSide, type, qty: built.order.qty, price: built.order.price, status: res.status,
    });
    if (res.status === 'filled') {
      this._onExitFill({ ...res, tag: 'exit:' + pos.id }, reason);
      this.pendingExits.delete(pos.id);
    } else {
      this.pendingExits.set(pos.id, { pos, reason, orderId: res.orderId });
      this.pendingExits.set(res.orderId, { pos, reason });
    }
    this.log.info('exit ' + pos.symbol + ' ' + reason, {
      type, status: res.status, price: Math.round((res.price || price) * 100) / 100,
    });
  }

  _onExitFill(fill, reasonOverride) {
    const pos = this.portfolio.get(fill.symbol);
    if (!pos) return;
    const pending = this.pendingExits.get(fill.orderId);
    const reason = reasonOverride || pending?.reason || 'unknown';
    const trade = this.portfolio.close(pos.symbol, {
      price: fill.price, fee: fill.fee, feeKind: fill.feeKind, reason, ts: fill.ts,
    });
    if (!trade) return;
    this.pendingExits.delete(pos.id);
    if (pending) this.pendingExits.delete(pending.orderId);
    this.stats.exits++;
    this.trades.push(trade);
    this.store.append('trade_closed', trade);
    this.risk.settle({
      pnl: trade.pnl,
      fee: (trade.exit.fee || 0) + (trade.entry.fee || 0),
      notional: trade.entry.notional,
      win: trade.win,
      symbol: trade.symbol,
      tradeId: trade.id,
    });
    this.bus.emit('trade:closed', trade);
    this.log.info('closed ' + trade.symbol + ' ' + trade.side + ' ' + reason, {
      pnl: trade.pnl, pnlPct: trade.pnlPct, equity: Math.round(this.risk.state.equity * 100) / 100,
    });
    return trade;
  }

  flattenAll(reason = 'flatten') {
    const out = [];
    for (const pos of this.portfolio.openPositions()) {
      this._exit(pos, reason, 'market');
      out.push(pos.symbol);
    }
    return out;
  }

  snapshot() {
    return {
      stats: this.stats,
      pendingEntries: this.pendingEntries.size,
      pendingExits: this.pendingExits.size,
      openPositions: this.portfolio.openPositions().map((p) => ({
        symbol: p.symbol, side: p.side, entry: p.entry,
        tp: Math.round(p.tp * 100) / 100, sl: Math.round(p.sl * 100) / 100,
        qty: p.qty, notional: Math.round(p.notional * 100) / 100,
        strategy: p.strategy, ageMs: now() - p.openedAt,
        unrealised: Math.round(p.unrealisedPnl() * 100) / 100,
      })),
      trades: this.trades.length,
    };
  }
}

/** Epoch ms of the most recent 00:00/08:00/16:00 UTC boundary after `since`. */
function fundingBoundarySince(since) {
  const H = 8 * 3600 * 1000;
  const sinceFloor = Math.floor((since || 0) / H) * H;
  const next = sinceFloor + H;
  return next <= Date.now() ? next : null;
}

module.exports = { Trader };
