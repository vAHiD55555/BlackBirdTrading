'use strict';
/**
 * BlackBird — Advisory board ("هیئت مشاوره").
 *
 * The scout may not enter a market on its own. Three officers vote, and they
 * are deliberately built to disagree: risk cares about survival, execution
 * cares about cost and fill quality, integrity cares about whether the data we
 * are looking at is even true.
 *
 * A single veto blocks the trade. Silence (abstain) does not.
 */
const { now, uuid } = require('../core/util');

class Board {
  constructor({ cfg, log, store, risk, witness, hub, jev }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.risk = risk;
    this.witness = witness;
    this.hub = hub;
    this.jev = jev;
    this.votes = [];
    this.maxVotes = 500;
    this.stats = { sessions: 0, approved: 0, rejected: 0 };
  }

  // ---- officer 1: risk -----------------------------------------------------
  _riskOfficer(proposal, sized) {
    const checks = [];
    const r = this.risk.check({ ...proposal, notional: sized.notional }, this._portfolioRef);
    if (!r.ok) {
      return { officer: 'risk', vote: 'reject', reason: r.reason, checks: r.checks };
    }
    if (proposal.confidence < this.cfg.board.confidenceFloor) {
      return {
        officer: 'risk',
        vote: 'reject',
        reason: `confidence ${proposal.confidence} < floor ${this.cfg.board.confidenceFloor}`,
        checks,
      };
    }
    checks.push({ rule: 'confidence_floor', pass: true });
    if (sized.notional < this.cfg.risk.minNotionalUsd) {
      return {
        officer: 'risk',
        vote: 'reject',
        reason: `sized notional $${sized.notional.toFixed(2)} < min $${this.cfg.risk.minNotionalUsd}`,
        checks,
      };
    }
    checks.push({ rule: 'min_notional', pass: true });
    return {
      officer: 'risk',
      vote: 'approve',
      reason: `notional $${sized.notional.toFixed(2)} (${(this.cfg.risk.maxPositionPct * 100).toFixed(0)}% cap)`,
      checks,
    };
  }

  // ---- officer 2: execution ------------------------------------------------
  _executionOfficer(proposal) {
    const feed = this.hub.get(proposal.symbol);
    const book = feed?.book();
    const s = this.cfg.strategy;
    const checks = [];
    if (!book) return { officer: 'execution', vote: 'reject', reason: 'no order book', checks };

    if (book.quoteAgeMs > this.cfg.data.staleQuoteMs) {
      return { officer: 'execution', vote: 'reject', reason: `quote age ${Math.round(book.quoteAgeMs)}ms`, checks };
    }
    checks.push({ rule: 'quote_fresh', pass: true });

    if (book.spreadBps > s.maxSpreadBps) {
      return {
        officer: 'execution',
        vote: 'reject',
        reason: `spread ${book.spreadBps.toFixed(1)}bps > ${s.maxSpreadBps}`,
        checks,
      };
    }
    checks.push({ rule: 'spread', pass: true });

    if (book.depthUsd > 0 && book.depthUsd < s.minDepthUsd) {
      return {
        officer: 'execution',
        vote: 'reject',
        reason: `depth $${Math.round(book.depthUsd)} < $${s.minDepthUsd}`,
        checks,
      };
    }
    checks.push({ rule: 'depth', pass: true });

    // is our own latency infra healthy enough right now?
    const p99 = this.jev ? this.jev.percentile(99) : 0;
    if (this.jev && this.jev.latencies.length > 20 && p99 > this.cfg.jevExec.maxLatencyMs) {
      return {
        officer: 'execution',
        vote: 'reject',
        reason: `JEV p99 ${p99}ms > budget ${this.cfg.jevExec.maxLatencyMs}ms`,
        checks,
      };
    }
    checks.push({ rule: 'jevs_latency', pass: true });

    // expected capture vs estimated round-trip cost
    const costBps =
      this.cfg.fees.makerBps * 2 + this.cfg.fees.slippageBpsPer1kNotional * 2 + book.spreadBps * 0.5;
    if (proposal.tpBps - costBps < 4) {
      return {
        officer: 'execution',
        vote: 'reject',
        reason: `net capture ${(proposal.tpBps - costBps).toFixed(1)}bps < 4bps after cost ${costBps.toFixed(1)}bps`,
        checks,
      };
    }
    checks.push({ rule: 'net_capture', pass: true });

    return {
      officer: 'execution',
      vote: 'approve',
      reason: `spread ${book.spreadBps.toFixed(1)}bps, depth $${Math.round(book.depthUsd)}, net ${(proposal.tpBps - costBps).toFixed(1)}bps`,
      checks,
    };
  }

  // ---- officer 3: integrity (the witness's representative) -----------------
  _integrityOfficer(proposal) {
    const checks = [];
    if (!this.cfg.witness.enabled) return { officer: 'integrity', vote: 'abstain', reason: 'witness disabled', checks };

    const feed = this.hub.get(proposal.symbol);
    const local = feed?.ticker;
    if (!local) return { officer: 'integrity', vote: 'reject', reason: 'no local quote', checks };

    const ref = this.witness?.price(proposal.symbol);
    if (!ref) {
      checks.push({ rule: 'cross_source', pass: false, note: 'reference unavailable' });
      // Without a second source we cannot validate the price, but we do not
      // want a witness outage to stop all trading: downgrade to abstain.
      return { officer: 'integrity', vote: 'abstain', reason: 'witness reference unavailable', checks };
    }

    const mid = (local.bid + local.ask) / 2;
    const divBps = Math.abs(((mid - ref.price) / ref.price) * 10000);
    if (divBps > this.cfg.witness.maxPriceDivergenceBps) {
      return {
        officer: 'integrity',
        vote: 'reject',
        reason: `price divergence ${divBps.toFixed(1)}bps vs ${ref.exchange}`,
        checks,
      };
    }
    checks.push({ rule: 'cross_source_price', pass: true, divergenceBps: Math.round(divBps * 10) / 10 });

    if (feed.gapCount > 0 && now() - (feed.lastBarTs || 0) > 3 * this.cfg.data.intervalMs) {
      return { officer: 'integrity', vote: 'reject', reason: 'candle gap / stale series', checks };
    }
    checks.push({ rule: 'data_continuity', pass: true });

    return {
      officer: 'integrity',
      vote: 'approve',
      reason: `cross-source ok (${divBps.toFixed(1)}bps vs ${ref.exchange})`,
      checks,
    };
  }

  /**
   * Run a session for one proposal.
   * @param {object} proposal
   * @param {object} portfolio
   */
  review(proposal, portfolio, learnerBias = 0) {
    this._portfolioRef = portfolio;
    const fees = this.cfg.fees;
    const sized = this.risk.size({
      price: proposal.price,
      tpBps: proposal.tpBps,
      slBps: proposal.slBps,
      entryFeeBps: proposal.entryType === 'maker' ? fees.makerBps : fees.takerBps,
      exitFeeBps: fees.makerBps,
    });

    const votes = [
      this._riskOfficer(proposal, sized),
      this._executionOfficer(proposal),
      this._integrityOfficer(proposal),
    ];

    const approvals = votes.filter((v) => v.vote === 'approve').length;
    const vetoes = votes.filter((v) => v.vote === 'reject');
    const approved =
      approvals >= this.cfg.board.minApprove &&
      (!this.cfg.board.requireZeroVetoes || vetoes.length === 0) &&
      sized.notional >= this.cfg.risk.minNotionalUsd;

    const decision = {
      id: uuid('dec'),
      ts: now(),
      proposalId: proposal.id,
      symbol: proposal.symbol,
      strategy: proposal.strategy,
      approved,
      approvals,
      vetoes: vetoes.length,
      votes,
      notional: Math.round(sized.notional * 100) / 100,
      qty: sized.qty,
      sizedReason: sized.sizing || (sized.cappedByRisk ? 'capped_by_risk_budget' : 'sized_to_profit_target'),
      learnerBias,
      reason: approved
        ? `${approvals}/3 approved`
        : vetoes.length
        ? `veto: ${vetoes.map((v) => `${v.officer}:${v.reason}`).join(' | ')}`
        : `${approvals}/3 approved (need ${this.cfg.board.minApprove})`,
    };

    this.stats.sessions++;
    if (approved) this.stats.approved++;
    else this.stats.rejected++;

    this.votes.push(decision);
    if (this.votes.length > this.maxVotes) this.votes.shift();

    this.store.append('board_decision', {
      id: decision.id,
      proposalId: proposal.id,
      symbol: proposal.symbol,
      approved,
      approvals,
      vetoes: vetoes.map((v) => `${v.officer}:${v.reason}`),
      notional: decision.notional,
      votes: votes.map((v) => ({ officer: v.officer, vote: v.vote, reason: v.reason })),
    });

    this.log.info(`board ${approved ? 'APPROVE' : 'REJECT'} ${proposal.symbol}`, {
      approvals,
      notional: decision.notional,
      reason: decision.reason.slice(0, 120),
    });

    return decision;
  }

  snapshot(limit = 10) {
    return { stats: this.stats, recent: this.votes.slice(-limit) };
  }
}

module.exports = { Board };
