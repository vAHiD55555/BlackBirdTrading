'use strict';
/**
 * BlackBird — Learner ("معامله‌گرِ همیشه‌درحال‌آموختن").
 *
 * Keeps a per-(symbol, strategy, regime) arm and slowly moves risk toward what
 * actually works. Two rules keep it honest:
 *
 *  - it only learns from *closed, witness-verified* trades
 *  - it never changes a hard limit; it only nudges confidence and TP/SL shape,
 *    within tight clamps, and every change is written to the journal so the
 *    next report can explain it.
 */
const { clamp, mean } = require('../core/util');

class Learner {
  constructor({ cfg, log, store }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.arms = new Map(); // key -> arm
    this.history = [];
    this.changes = [];
    this._load();
  }

  _load() {
    const saved = this.store.state.learned?.arms;
    if (saved && typeof saved === 'object') {
      for (const [k, v] of Object.entries(saved)) this.arms.set(k, v);
    }
  }

  _persist() {
    this.store.state.learned = {
      arms: Object.fromEntries(this.arms),
      params: this.params,
      updatedAt: Date.now(),
    };
  }

  static key(symbol, strategy, regime) {
    return `${symbol}|${strategy}|${regime}`;
  }

  arm(symbol, strategy, regime) {
    const k = Learner.key(symbol, strategy, regime);
    if (!this.arms.has(k)) this.arms.set(k, { n: 0, wins: 0, pnl: 0, grossWin: 0, grossLoss: 0, lastUpdate: 0 });
    return this.arms.get(k);
  }

  /** Confidence adjustment in [-0.2, +0.2]. */
  bias(symbol, strategy, regime) {
    if (!this.cfg.learner.enabled) return 0;
    const a = this.arm(symbol, strategy, regime);
    if (a.n < this.cfg.learner.minSamplesPerArm) return 0;
    const expectancy = a.pnl / a.n;
    const scale = Math.max(Math.abs(a.grossWin - a.grossLoss) / Math.max(a.n, 1), 0.5);
    return Math.round(clamp((expectancy / scale) * 0.2, -0.2, 0.2) * 1000) / 1000;
  }

  observe(trade) {
    if (!this.cfg.learner.enabled) return;
    const a = this.arm(trade.symbol, trade.strategy, trade.context?.regime || 'unknown');
    a.n++;
    a.pnl += trade.pnl;
    if (trade.win) {
      a.wins++;
      a.grossWin += trade.pnl;
    } else {
      a.grossLoss += Math.abs(trade.pnl);
    }
    a.lastUpdate = Date.now();
    this.history.push({ ts: Date.now(), key: Learner.key(trade.symbol, trade.strategy, 'x'), pnl: trade.pnl, n: a.n });
    if (this.history.length > 500) this.history.shift();
    this._persist();
  }

  /**
   * Adapt TP/SL shape. Only called once per report cycle, and only with enough
   * evidence. Movements are capped at 8% per cycle.
   */
  adapt(trades) {
    if (!this.cfg.learner.enabled || !this.cfg.learner.adaptTpSl) return null;
    if (!trades || trades.length < this.cfg.learner.minSamplesPerArm) return null;
    const wins = trades.filter((t) => t.win);
    const losses = trades.filter((t) => !t.win);
    if (!wins.length || !losses.length) return null;

    const avgWin = mean(wins.map((t) => t.pnlBps));
    const avgLoss = Math.abs(mean(losses.map((t) => t.pnlBps)));
    const wr = wins.length / trades.length;
    const expectancy = mean(trades.map((t) => t.pnlBps));

    const before = { ...this.params };
    const p = { ...this.params };

    if (expectancy < 0) {
      // we are paying fees for noise: tighten entries (raise volatility gate)
      p.minVolPercentile = clamp(p.minVolPercentile + 0.03, 0.45, 0.85);
      this.changes.push({ ts: Date.now(), what: 'minVolPercentile', from: before.minVolPercentile, to: p.minVolPercentile, why: `expectancy ${expectancy.toFixed(2)}bps < 0` });
    } else if (wr > 0.6 && avgWin < avgLoss) {
      // too many tiny wins: let winners run a little
      p.tpAtrMult = clamp(p.tpAtrMult * 1.05, 0.5, 2.5);
      this.changes.push({ ts: Date.now(), what: 'tpAtrMult', from: before.tpAtrMult, to: p.tpAtrMult, why: `wr ${(wr * 100).toFixed(0)}% but avg win ${avgWin.toFixed(1)}bps < avg loss ${avgLoss.toFixed(1)}bps` });
    } else if (wr < 0.4 && avgLoss > avgWin * 1.4) {
      // stops too wide for the edge: tighten
      p.slAtrMult = clamp(p.slAtrMult * 0.95, 0.3, 2);
      this.changes.push({ ts: Date.now(), what: 'slAtrMult', from: before.slAtrMult, to: p.slAtrMult, why: `wr ${(wr * 100).toFixed(0)}% with wide stops` });
    }

    this.params = p;
    this._persist();
    return this.params !== before ? this.params : null;
  }

  get params() {
    if (!this._params) {
      this._params = this.store.state.learned?.params || {
        minVolPercentile: this.cfg.strategy.minVolPercentile,
        tpAtrMult: this.cfg.strategy.tpAtrMult,
        slAtrMult: this.cfg.strategy.slAtrMult,
      };
    }
    return this._params;
  }
  set params(v) {
    this._params = v;
  }

  snapshot() {
    const arms = [...this.arms.entries()]
      .map(([k, a]) => ({
        key: k,
        n: a.n,
        winRate: a.n ? Math.round((a.wins / a.n) * 1000) / 10 : 0,
        pnl: Math.round(a.pnl * 100) / 100,
        expectancy: a.n ? Math.round((a.pnl / a.n) * 100) / 100 : 0,
      }))
      .sort((x, y) => y.n - x.n);
    return {
      arms: arms.slice(0, 20),
      params: this.params,
      recentChanges: this.changes.slice(-5),
    };
  }
}

module.exports = { Learner };
