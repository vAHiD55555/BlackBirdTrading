'use strict';
/**
 * BlackBird — hourly reporter.
 *
 * The trader is contractually obliged to produce, every 6 hours:
 *   - what it saw in the market (and how it classified it)
 *   - why each trade was taken (the reasoning, not just the numbers)
 *   - what happened
 * The witness then scores that report against its own independent price series.
 *
 * Output: reports/YYYY-MM-DD/report-<ts>.md + .json, and a journal entry.
 */
const fs = require('node:fs');
const path = require('node:path');
const { now, iso, mean, uuid } = require('../core/util');
const { riskXray } = require('../risk/xray');
const { sendConfiguredEmail } = require('../notify/email');
const { sendConfiguredTelegram } = require('../notify/telegram');

const fmt = (x, d = 2) => (x === null || x === undefined || Number.isNaN(x) ? '—' : Number(x).toFixed(d));
const pctStr = (x) => `${x >= 0 ? '+' : ''}${fmt(x, 2)}%`;
const usd = (x) => `$${fmt(x, 2)}`;

class Reporter {
  constructor({ cfg, log, store, trader, portfolio, risk, scout, board, auditor, witness, learner, jev, hub, rotator, intel }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.trader = trader;
    this.portfolio = portfolio;
    this.risk = risk;
    this.scout = scout;
    this.board = board;
    this.auditor = auditor;
    this.witness = witness;
    this.learner = learner;
    this.jev = jev;
    this.hub = hub;
    this.rotator = rotator || null;
    // Market intel is optional: a report must render whether or not the news
    // layer is configured, so a missing module is a missing section, not a crash.
    this.intel = intel || null;
    this.lastReportAt = store.state.lastReportAt || 0;
    this.round = store.state.reportedRounds || 0;
    this.lastReport = null;
  }

  _marketSection(fromTs, toTs) {
    const obs = this.trader.observations.filter((o) => o.ts >= fromTs && o.ts <= toTs);
    const perSymbol = {};
    const regimeCounts = {};
    for (const sym of this.cfg.symbols) {
      const points = obs.filter((o) => o.symbol === sym);
      if (!points.length) {
        perSymbol[sym] = null;
        continue;
      }
      const prices = points.map((p) => p.price);
      const first = prices[0];
      const last = prices[prices.length - 1];
      const high = Math.max(...prices);
      const low = Math.min(...prices);
      for (const p of points) regimeCounts[p.regime] = (regimeCounts[p.regime] || 0) + 1;
      perSymbol[sym] = {
        samples: points.length,
        first,
        last,
        high,
        low,
        changePct: Math.round(((last / first - 1) * 100) * 1000) / 1000,
        rangePct: Math.round(((high / low - 1) * 100) * 1000) / 1000,
        avgAtrPct: Math.round(mean(points.map((p) => p.atrPct)) * 100) / 100,
        avgVolPct: Math.round(mean(points.map((p) => p.volPct)) * 1000) / 1000,
        avgRsi: Math.round(mean(points.map((p) => p.rsi)) * 10) / 10,
        regimes: points.reduce((acc, p) => ((acc[p.regime] = (acc[p.regime] || 0) + 1), acc), {}),
      };
    }
    const total = Object.values(regimeCounts).reduce((a, b) => a + b, 0) || 1;
    return {
      perSymbol,
      regimeMix: Object.fromEntries(Object.entries(regimeCounts).map(([k, v]) => [k, Math.round((v / total) * 1000) / 10])),
      samples: obs.length,
    };
  }

  _narrative(market, trades, board) {
    const lines = [];
    const mix = market.regimeMix;
    const dominant = Object.entries(mix).sort((a, b) => b[1] - a[1])[0];
    if (dominant) {
      lines.push(
        `در این بازه بازار عمدتاً در وضعیت «${dominant[0]}» بود (${dominant[1]}٪ نمونه‌ها). ` +
          (dominant[0] === 'muddy'
            ? 'یعنی نوسان کافی برای شکار وجود داشت و عمق بازار اجازه‌ی ورود/خروج می‌داد.'
            : dominant[0] === 'calm'
            ? 'نوسان کمتر از آستانه بود؛ بنابراین «آب گل‌آلود» نداشتیم و ورود نکردیم.'
            : dominant[0] === 'trend'
            ? 'جریان جهت‌دار قوی بود و استراتژی بازگشتی را کنار گذاشتیم.'
            : 'شرایط سمی (اسپرد/عمق بد) بود و ریسک ورود نکردیم.')
      );
    }
    const actives = Object.entries(market.perSymbol).filter(([, v]) => v);
    actives.sort((a, b) => Math.abs(b[1].changePct) - Math.abs(a[1].changePct));
    if (actives.length) {
      const top = actives.slice(0, 3).map(([s, v]) => `${s} ${pctStr(v.changePct)} (دامنه ${fmt(v.rangePct, 2)}٪)`);
      lines.push(`بیشترین حرکت: ${top.join('، ')}.`);
    }
    lines.push(
      `از ${board.stats.sessions} درخواست ورود، ${board.stats.approved} مورد تأیید هیئت مشاوره شد و ${board.stats.rejected} مورد رد شد.`
    );
    if (trades.length) {
      const reasons = {};
      for (const t of trades) reasons[t.exit.reason] = (reasons[t.exit.reason] || 0) + 1;
      lines.push(
        `خروج‌ها: ${Object.entries(reasons)
          .map(([k, v]) => `${k}=${v}`)
          .join('، ')}.`
      );
    } else {
      lines.push('در این بازه معامله‌ای بسته نشد.');
    }
    return lines;
  }

  _lessons(trades, learning, witnessVerdict) {
    const out = [];
    const wins = trades.filter((t) => t.win);
    const losses = trades.filter((t) => !t.win);
    if (trades.length >= 5) {
      out.push(
        `نرخ برد ${fmt((wins.length / trades.length) * 100, 1)}٪ با میانگین سود ${fmt(mean(wins.map((t) => t.pnlBps)) || 0, 1)}bps و میانگین ضرر ${fmt(Math.abs(mean(losses.map((t) => t.pnlBps)) || 0), 1)}bps.`
      );
    }
    for (const c of learning.recentChanges || []) {
      out.push(`تنظیم پارامتر: ${c.what} ${fmt(c.from, 3)} → ${fmt(c.to, 3)} — دلیل: ${c.why}`);
    }
    if (witnessVerdict) {
      out.push(`ارزیابی شاهد: ${witnessVerdict.verdict} (امتیاز ${witnessVerdict.score}/100).`);
      for (const c of witnessVerdict.checks.filter((c) => c.result === 'fail' || c.result === 'warn')) {
        out.push(`⚠️ شاهد: ${c.check} → ${c.result} (${JSON.stringify(c).slice(0, 160)})`);
      }
    }
    if (!out.length) out.push('داده‌ی کافی برای نتیجه‌گیری در این بازه جمع نشد.');
    return out;
  }

  build(windowStart = this.lastReportAt || now() - this.cfg.reporter.intervalMs, windowEnd = now()) {
    const trades = this.trader.trades.filter((t) => t.exit.ts >= windowStart && t.exit.ts <= windowEnd);
    const market = this._marketSection(windowStart, windowEnd);
    const digest = this.witness?.marketDigest(windowStart, windowEnd) || {};
    for (const [sym, d] of Object.entries(digest)) {
      if (market.perSymbol[sym] && d) {
        market.perSymbol[sym].witness = {
          exchange: d.exchange,
          changePct: d.changePct,
          rangePct: d.rangePct,
          stepVolBps: d.stepVolBps,
        };
      }
    }

    const wins = trades.filter((t) => t.win);
    const losses = trades.filter((t) => !t.win);
    const pnl = trades.reduce((s, t) => s + t.pnl, 0);
    const fees = trades.reduce((s, t) => s + (t.entry.fee || 0) + (t.exit.fee || 0), 0);
    const boardWindow = this.board.votes.filter((v) => v.ts >= windowStart && v.ts <= windowEnd);

    const report = {
      id: uuid('rep'),
      type: 'periodic',
      round: this.round + 1,
      generatedAt: now(),
      windowStart,
      windowEnd,
      windowHuman: `${iso(windowStart)} → ${iso(windowEnd)}`,
      mode: this.cfg.mode,
      exchange: this.cfg.exchange,
      strategy: this.cfg.strategy.mode,
      rotator: this.rotator ? this.rotator.snapshot() : null,
      summary: {
        trades: trades.length,
        wins: wins.length,
        losses: losses.length,
        winRate: trades.length ? Math.round((wins.length / trades.length) * 1000) / 10 : 0,
        pnl: Math.round(pnl * 100) / 100,
        fees: Math.round(fees * 100) / 100,
        expectancy: trades.length ? Math.round((pnl / trades.length) * 100) / 100 : 0,
        avgPnlBps: trades.length ? Math.round(mean(trades.map((t) => t.pnlBps)) * 10) / 10 : 0,
        bestTrade: trades.length ? Math.round(Math.max(...trades.map((t) => t.pnl)) * 100) / 100 : 0,
        worstTrade: trades.length ? Math.round(Math.min(...trades.map((t) => t.pnl)) * 100) / 100 : 0,
        equity: Math.round(this.risk.state.equity * 100) / 100,
        openPnl: Math.round(this.portfolio.unrealisedTotal() * 100) / 100,
        equityMtm: Math.round((this.risk.state.equity + this.portfolio.unrealisedTotal()) * 100) / 100,
        drawdownPct: Math.round(this.risk.drawdownPct() * 100) / 100,
        tradesToday: this.risk.state.counters.tradesToday,
      },
      riskXray: riskXray(this.portfolio, this.risk.state.equity),
      activity: {
        proposals: this.scout.stats.proposed,
        boardSessions: boardWindow.length,
        approved: boardWindow.filter((v) => v.approved).length,
        rejected: boardWindow.filter((v) => !v.approved).length,
        vetoReasons: countVetoes(boardWindow),
        skipReasons: this.scout.stats.skipped,
        jev: this.jev.stats(),
      },
      market,
      narrative: [],
      trades: trades.map((t) => ({
        id: t.id,
        symbol: t.symbol,
        strategy: t.strategy,
        entry: t.entry,
        exit: t.exit,
        pnl: t.pnl,
        pnlBps: t.pnlBps,
        win: t.win,
        durationMs: t.durationMs,
        reason: t.exit.reason,
        rationale: t.rationale,
        context: t.context,
      })),
      auditors: this.auditor.summary(),
      // Compact intel block: the digest text plus the numbers behind it. The
      // full snapshot (every feed's error string) stays on /status, not in a
      // report that is mailed and pushed to a phone.
      intel: this.intel
        ? {
            enabled: this.intel.enabled,
            digest: this.intel.digest(),
            tone: this.intel.last ? this.intel.last.tone : null,
            confidence: this.intel.last ? this.intel.last.confidence : null,
            blackout: this.intel.last ? this.intel.last.blackout : null,
            items: this.intel.last ? this.intel.last.items : 0,
            byFeed: this.intel.last ? this.intel.last.byFeed : null,
            riskMultiplier: this.intel.riskMultiplier(),
          }
        : null,
      learning: this.learner.snapshot(),
      positionsOpen: this.portfolio.openPositions().map((p) => ({
        symbol: p.symbol,
        entry: p.entry,
        notional: Math.round(p.notional * 100) / 100,
        unrealised: Math.round(p.unrealisedPnl() * 100) / 100,
      })),
    };

    report.narrative = this._narrative(market, trades, { stats: { sessions: boardWindow.length, approved: boardWindow.filter((v) => v.approved).length, rejected: boardWindow.filter((v) => !v.approved).length } });

    const witnessVerdict = this.witness?.scoreReport(
      { ...report, market: { ...market, digest: digest } },
      digest
    );
    report.witness = witnessVerdict || null;
    report.lessons = this._lessons(trades, report.learning, witnessVerdict);

    return report;
  }

  renderMarkdown(r) {
    const L = [];
    let sec = 0;
    const H = (title) => { sec++; L.push(`## ${sec}) ${title}`); };
    const s = r.summary;
    L.push(`# 🐦 گزارش معامله‌گر BlackBird — دور ${r.round}`);
    L.push('');
    L.push(`**بازه:** ${r.windowHuman}`);
    L.push(`**حالت:** ${r.mode} روی ${r.exchange}  |  **سرمایه:** ${usd(s.equity)}${s.openPnl ? `  |  **سود/زیان باز:** ${s.openPnl > 0 ? '+' : ''}${usd(s.openPnl)}` : ''}${s.equityMtm && s.equityMtm !== s.equity ? `  (معادل ${usd(s.equityMtm)})` : ''}  |  **افت:** ${fmt(s.drawdownPct, 2)}٪`);
    L.push('');
    H('خلاصه‌ی عملکرد');
    L.push('');
    L.push('| متریک | مقدار |');
    L.push('|---|---|');
    L.push(`| معاملات بسته‌شده | ${s.trades} |`);
    L.push(`| برد / باخت | ${s.wins} / ${s.losses} |`);
    L.push(`| نرخ برد | ${fmt(s.winRate, 1)}٪ |`);
    L.push(`| سود/زیان خالص | ${usd(s.pnl)} |`);
    L.push(`| کارمزد پرداختی | ${usd(s.fees)} |`);
    L.push(`| انتظار ریاضی هر معامله | ${usd(s.expectancy)} |`);
    L.push(`| میانگین هر معامله | ${fmt(s.avgPnlBps, 1)} bps |`);
    L.push(`| بهترین / بدترین | ${usd(s.bestTrade)} / ${usd(s.worstTrade)} |`);
    L.push('');
    if (r.rotator) {
      const ro = r.rotator;
      H('کتاب Orbital (استراتژی فعال)');
      L.push('');
      L.push(`- وضعیت: ${ro.ready ? 'آماده' : 'در حال گرم‌شدن'} · ری‌بالانس هر ${ro.rebalanceHours} ساعت · ${ro.variants} واریانت`);
      L.push(`- مقیاس نوسان: ${fmt(ro.volScale, 2)}× · ترمز افت: ${fmt(ro.ddScale, 2)}×`);
      L.push(`- ری‌بالانس‌ها: ${ro.rebalances} · باز شده: ${ro.opens} · بسته شده: ${ro.closes} · استاپ: ${ro.stops}`);
      if (ro.lastRebalanceAt) L.push(`- آخرین ری‌بالانس: ${iso(ro.lastRebalanceAt)}`);
      L.push('');
      L.push('### پوزیشن‌های باز');
      L.push('');
      if (!ro.positions.length) {
        L.push('_هیچ پوزیشن بازی نیست._');
      } else {
        L.push('| نماد | جهت | ورود | حد ضرر | سود/زیان باز |');
        L.push('|---|---|---|---|---|');
        for (const p of ro.positions) {
          L.push(`| ${p.symbol} | ${p.side === 'long' ? 'خرید' : 'فروش'} | ${fmt(p.entry, 4)} | ${fmt(p.stop, 4)} | ${usd(p.pnl)} |`);
        }
      }
      L.push('');
      if (ro.lastTargets && ro.lastTargets.length) {
        L.push('### کتاب هدف آخرین ری‌بالانس');
        L.push('');
        L.push('| نماد | جهت | وزن (٪ سرمایه) |');
        L.push('|---|---|---|');
        for (const t of ro.lastTargets) {
          L.push(`| ${t.symbol} | ${t.dir > 0 ? 'خرید' : 'فروش'} | ${fmt(t.pct, 1)}٪ |`);
        }
        L.push('');
      }
    }
    H('آنچه در بازار دیدم (تشخیص بازار)');
    L.push('');
    for (const line of r.narrative) L.push(`- ${line}`);
    L.push('');
    L.push('### ترکیب رژیم‌ها');
    L.push('');
    L.push('| رژیم | سهم |');
    L.push('|---|---|');
    for (const [k, v] of Object.entries(r.market.regimeMix)) L.push(`| ${k} | ${v}٪ |`);
    L.push('');
    L.push('### وضعیت هر نماد');
    L.push('');
    L.push('| نماد | تغییر | دامنه | ATR٪ | صدک نوسان | RSI | شاهد (مرجع) |');
    L.push('|---|---|---|---|---|---|---|');
    for (const [sym, m] of Object.entries(r.market.perSymbol)) {
      if (!m) {
        L.push(`| ${sym} | — | — | — | — | — | — |`);
        continue;
      }
      const w = m.witness ? `${m.witness.exchange} ${fmt(m.witness.changePct, 2)}٪` : '—';
      L.push(`| ${sym} | ${pctStr(m.changePct)} | ${fmt(m.rangePct, 2)}٪ | ${fmt(m.avgAtrPct, 2)} | ${fmt(m.avgVolPct, 2)} | ${fmt(m.avgRsi, 1)} | ${w} |`);
    }
    L.push('');
    // Market intel. Rendered from the module's own digest so the report and the
    // dashboard can never disagree about which sources answered.
    if (this.intel) {
      H('هوش بازار (اخبار)');
      L.push('');
      for (const line of String(this.intel.digest()).split('\n')) L.push(`- ${line}`);
      const top = this.intel.last && Array.isArray(this.intel.last.top) ? this.intel.last.top : [];
      if (top.length) {
        L.push('');
        L.push('| تیتر | خانواده | لحن | اثر |');
        L.push('|---|---|---|---|');
        for (const t of top) {
          L.push(`| ${String(t.title).replace(/\|/g, '/')} | ${t.feed || '—'} | ${fmt(t.tone, 2)} | ${fmt(t.impact, 2)} |`);
        }
      }
      L.push('');
    }
    H('فعالیت هیئت مشاوره');
    L.push('');
    L.push(`- درخواست‌های ورود: ${r.activity.proposals}`);
    L.push(`- جلسات هیئت: ${r.activity.boardSessions} (تأیید ${r.activity.approved} / رد ${r.activity.rejected})`);
    const vr = Object.entries(r.activity.vetoReasons || {});
    if (vr.length) L.push(`- دلایل وتو: ${vr.map(([k, v]) => `${k}×${v}`).join('، ')}`);
    const sk = Object.entries(r.activity.skipReasons || {}).sort((a, b) => b[1] - a[1]).slice(0, 6);
    if (sk.length) L.push(`- دلایل رد توسط کاشف: ${sk.map(([k, v]) => `${k}×${v}`).join('، ')}`);
    L.push(`- JEV: p50=${r.activity.jev.p50}ms p99=${r.activity.jev.p99}ms (بودجه ${r.activity.jev.budgetMs}ms، ارسال ${r.activity.jev.sent}، لغو ${r.activity.jev.aborted})`);
    L.push('');
    H('معاملات و دلیل هرکدام');
    L.push('');
    if (!r.trades.length) {
      L.push('_در این بازه معامله‌ای انجام نشد._');
    } else {
      L.push('| # | نماد | استراتژی | ورود | خروج | دلیل خروج | سود | bps | مدت |');
      L.push('|---|---|---|---|---|---|---|---|---|');
      r.trades.forEach((t, i) => {
        L.push(
          `| ${i + 1} | ${t.symbol} | ${t.strategy} | ${fmt(t.entry.price, 4)} | ${fmt(t.exit.price, 4)} | ${t.reason} | ${usd(t.pnl)} | ${fmt(t.pnlBps, 1)} | ${Math.round(t.durationMs / 1000)}s |`
        );
      });
      L.push('');
      L.push('**دلیل ورود هر معامله:**');
      L.push('');
      r.trades.forEach((t, i) => {
        L.push(`${i + 1}. **${t.symbol} / ${t.strategy}** — ${usd(t.pnl)} (${t.win ? 'برد' : 'باخت'})`);
        for (const why of t.rationale || []) L.push(`   - ${why}`);
      });
    }
    L.push('');
    H('لایه‌های نظارتی');
    L.push('');
    const a = r.auditors;
    L.push(`- هشدارها: ${a.alerts} | بحرانی: ${a.criticals}`);
    for (const [code, f] of Object.entries(a.latest || {})) {
      L.push(`- \`${code}\` [${f.level}] ${f.message}`);
    }
    L.push('');
    H('سنجش شاهد (مقایسه‌ی گزارش با واقعیت بازار)');
    L.push('');
    if (r.witness) {
      L.push(`**امتیاز: ${r.witness.score}/100 — ${r.witness.verdict}**`);
      L.push('');
      for (const c of r.witness.checks) L.push(`- ${c.result === 'pass' ? '✅' : c.result === 'warn' ? '⚠️' : '❌'} ${c.check}${c.note ? ` — ${c.note}` : ''}`);
    } else {
      L.push('_شاهد غیرفعال است._');
    }
    L.push('');
    H('آموخته‌ها');
    L.push('');
    for (const l of r.lessons) L.push(`- ${l}`);
    L.push('');
    L.push('---');
    L.push(`_تولید‌شده توسط BlackBird ${new Date(r.generatedAt).toISOString()}_`);
    return L.join('\n');
  }

  write(report) {
    // The reports directory is created here, not assumed. A fresh checkout (or a
    // container built from a .dockerignore that drops `reports/`) has no such
    // directory, and the old code only mkdir'd the dated subdirectory — which
    // fails with ENOENT when the parent is missing. The report then silently
    // never appears and /report/latest answers 404 forever.
    try {
      fs.mkdirSync(this.cfg.reporter.dir, { recursive: true });
    } catch (e) {
      this.log.error(`cannot create reports dir ${this.cfg.reporter.dir}: ${e.message}`);
    }
    const dir = path.join(this.cfg.reporter.dir, new Date(report.generatedAt).toISOString().slice(0, 10));
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch (e) {
      this.log.error(`cannot create report day dir ${dir}: ${e.message}`);
    }
    const stamp = new Date(report.generatedAt).toISOString().replace(/[:.]/g, '-');
    const base = path.join(dir, `report-${stamp}`);
    const out = { report, markdownPath: null, jsonPath: null };
    try {
      if (this.cfg.reporter.writeJson) {
        fs.writeFileSync(`${base}.json`, JSON.stringify(report, null, 2));
        out.jsonPath = `${base}.json`;
      }
      if (this.cfg.reporter.writeMarkdown) {
        fs.writeFileSync(`${base}.md`, this.renderMarkdown(report));
        out.markdownPath = `${base}.md`;
      }
      fs.writeFileSync(path.join(this.cfg.reporter.dir, 'latest.md'), this.renderMarkdown(report));
      fs.writeFileSync(path.join(this.cfg.reporter.dir, 'latest.json'), JSON.stringify(report, null, 2));
    } catch (e) {
      this.log.error(`report write failed: ${e.message}`);
    }
    this.store.append('report', {
      id: report.id,
      round: report.round,
      windowStart: report.windowStart,
      windowEnd: report.windowEnd,
      summary: report.summary,
      witness: report.witness ? { score: report.witness.score, verdict: report.witness.verdict } : null,
      markdownPath: out.markdownPath,
    });
    this.lastReportAt = report.windowEnd;
    this.round = report.round;
    this.store.state.lastReportAt = this.lastReportAt;
    this.store.state.reportedRounds = this.round;
    this.lastReport = report;
    this.log.info('report written', { round: report.round, trades: report.summary.trades, pnl: report.summary.pnl, md: out.markdownPath });
    // Notification is optional and never blocks report persistence.
    if (this.cfg.notifications?.email?.enabled) {
      sendConfiguredEmail(this.cfg, report, this.renderMarkdown(report))
        .then((r) => this.log.info('email notification', r))
        .catch((e) => this.log.warn(`email notification failed: ${e.message}`));
    }
    if (this.cfg.notifications?.telegram?.enabled) {
      const text = `🐦 BlackBird گزارش ساعتی #${report.round}\n\n${this.renderMarkdown(report)}`;
      sendConfiguredTelegram(this.cfg, 'report', text)
        .then((r) => {
          // Log the outcome honestly. A silent `skipped` is what hid the broken
          // chat_id for days: the operator saw "skipped" and assumed it was
          // normal. Now a failure names the cause Telegram gave us.
          if (r.ok) {
            this.log.info('telegram report sent', { chunks: r.chunks, chatId: r.chatId });
          } else if (r.skipped) {
            this.log.warn(
              `telegram report NOT sent: ${r.reason} — set TELEGRAM_BOT_TOKEN and ` +
                'TELEGRAM_CHAT_ID (or TELEGRAM_REPORT_CHAT_ID) in the panel environment'
            );
          } else if (r.network) {
            this.log.warn(`telegram report NOT sent: network error (${r.reason}) — api.telegram.org may be blocked from this host`);
          } else {
            this.log.warn(
              `telegram report NOT sent: ${r.errorCode || ''} ${r.description || 'unknown'}` +
                (r.hint ? ` — ${r.hint}` : '')
            );
          }
        })
        .catch((e) => this.log.warn(`telegram report notification failed: ${e.message}`));
    }
    return out;
  }

  /** Generate + write + adapt. Called by the 6h scheduler. */
  run() {
    const report = this.build();
    const written = this.write(report);
    const trades = this.trader.trades.filter((t) => t.exit.ts >= report.windowStart && t.exit.ts <= report.windowEnd);
    this.learner.adapt(trades);
    return { ...written, report };
  }
}

function countVetoes(votes) {
  const out = {};
  for (const v of votes) {
    if (v.approved) continue;
    for (const vote of v.votes || []) {
      if (vote.vote === 'reject') {
        const key = `${vote.officer}:${String(vote.reason).split('(')[0].slice(0, 40)}`;
        out[key] = (out[key] || 0) + 1;
      }
    }
  }
  return out;
}

module.exports = { Reporter };
