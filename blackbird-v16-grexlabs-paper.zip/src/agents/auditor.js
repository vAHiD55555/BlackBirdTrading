'use strict';
/**
 * BlackBird — independent auditors ("لایه‌های نظارتی").
 *
 * Seven watchdogs, each with its own state and its own opinion. They are not
 * asked "is everything fine?" (the answer is always yes); they are asked
 * specific, falsifiable questions about the system's weaknesses:
 *
 *   latency   are decisions arriving at the venue fast enough to still matter?
 *   slippage  are fills worse than the model predicted?
 *   risk      is any hard limit silently being exceeded?
 *   data      are we trading on stale or gapped data?
 *   decay     has the edge died?
 *   integrity is the record self-consistent and unmodified?
 *   anomaly   is the local feed diverging from the witness (venue glitch)?
 *
 * Any CRITICAL finding escalates to the kill switch.
 */
const { now, mean } = require('../core/util');

class Auditor {
  constructor({ cfg, log, store, risk, portfolio, trader, jev, hub, witness, broker, bus }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.risk = risk;
    this.portfolio = portfolio;
    this.trader = trader;
    this.jev = jev;
    this.hub = hub;
    this.witness = witness;
    this.broker = broker;
    this.bus = bus;
    this.findings = [];
    this.maxFindings = 300;
    this.alerts = 0;
    this.criticals = 0;
    this.timer = null;
    this._lastGapTotal = 0;
    this._lastChainCheck = 0;
    this._chainOk = true;
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.runCycle(), this.cfg.auditor.tickMs);
    // do not keep the process alive only for this timer
    if (this.timer.unref) this.timer.unref();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  _add(level, code, message, metrics) {
    const f = { ts: now(), level, code, message, metrics };
    this.findings.push(f);
    if (this.findings.length > this.maxFindings) this.findings.shift();
    if (level !== 'ok') {
      this.alerts++;
      this.store.append('audit_alert', f);
      this.log.warn(`[${code}] ${message}`, metrics);
      this.bus?.emit('audit:alert', f);
    }
    if (level === 'critical') {
      this.criticals++;
      // Data/latency problems are usually a hiccup, not a broken bot: pause for
      // a few minutes instead of freezing the engine forever.
      const soft = ['data', 'latency', 'slippage', 'decay', 'anomaly'].includes(code);
      this.risk.halt(`auditor:${code}: ${message}`, soft
        ? { kind: 'soft', resumeAt: now() + 5 * 60000 }
        : { kind: 'hard' });
      this.bus?.emit('audit:critical', f);
    }
    return f;
  }

  runCycle() {
    const out = [];
    for (const fn of [
      this.checkLatency,
      this.checkSlippage,
      this.checkRiskLimits,
      this.checkData,
      this.checkDecay,
      this.checkIntegrity,
      this.checkAnomaly,
      this.checkStructural,
    ]) {
      try {
        const f = fn.call(this);
        if (f) out.push(f);
      } catch (e) {
        out.push(this._add('warn', 'auditor_error', `${fn.name} threw: ${e.message}`));
      }
    }
    this.lastCycle = out;
    return out;
  }

  // ---------------------------------------------------------------- checks
  checkLatency() {
    const s = this.jev.stats();
    if (s.n < 5) return this._add('ok', 'latency', `insufficient samples (${s.n})`, s);
    if (s.p99 > this.cfg.jevExec.maxLatencyMs * 4) {
      return this._add('critical', 'latency', `JEV p99 ${s.p99}ms > 4x budget`, s);
    }
    if (s.p99 > this.cfg.auditor.latencyP99Ms) {
      return this._add('warn', 'latency', `JEV p99 ${s.p99}ms > alert ${this.cfg.auditor.latencyP99Ms}ms`, s);
    }
    return this._add('ok', 'latency', `p50=${s.p50}ms p99=${s.p99}ms`, s);
  }

  checkSlippage() {
    const fills = (this.broker.fills || []).filter((f) => Number.isFinite(f.slippageBps));
    const recent = fills.slice(-20);
    if (recent.length < 3) return this._add('ok', 'slippage', 'not enough fills');
    const avgAbs = mean(recent.map((f) => Math.abs(f.slippageBps)));
    const worst = Math.max(...recent.map((f) => Math.abs(f.slippageBps)));
    const metrics = { avgAbsBps: Math.round(avgAbs * 10) / 10, worstBps: Math.round(worst * 10) / 10, n: recent.length };
    if (avgAbs > this.cfg.auditor.slippageAlertBps) {
      return this._add('warn', 'slippage', `avg slippage ${metrics.avgAbsBps}bps > ${this.cfg.auditor.slippageAlertBps}bps`, metrics);
    }
    return this._add('ok', 'slippage', `avg ${metrics.avgAbsBps}bps`);
  }

  checkRiskLimits() {
    const st = this.risk.state;
    const total = this.portfolio.totalExposure();
    const cap = this.cfg.risk.maxOpenPositions * this.cfg.risk.maxPositionPct * st.equity * 1.05;
    const metrics = { exposure: Math.round(total), cap: Math.round(cap), positions: this.portfolio.openPositions().length };
    if (total > cap) {
      return this._add('critical', 'risk', `total exposure $${metrics.exposure} > cap $${metrics.cap}`, metrics);
    }
    if (this.portfolio.openPositions().length > this.cfg.risk.maxOpenPositions) {
      return this._add('critical', 'risk', `open positions ${metrics.positions} > max ${this.cfg.risk.maxOpenPositions}`, metrics);
    }
    if (st.counters.tradesToday > this.cfg.risk.maxDailyTrades) {
      return this._add('warn', 'risk', `daily trades ${st.counters.tradesToday} > cap ${this.cfg.risk.maxDailyTrades}`);
    }
    return this._add('ok', 'risk', `exposure $${metrics.exposure}/$${metrics.cap}`);
  }

  checkData() {
    const stale = [];
    let gaps = 0;
    for (const f of this.hub.all()) {
      if (f.isStale) stale.push(f.symbol);
      gaps += f.gapCount;
    }
    const metrics = { stale: stale.length, gapsDelta: gaps - this._lastGapTotal };
    this._lastGapTotal = gaps;
    // require the condition to persist across two cycles (the poll interval is
    // 1s, the auditor ticks every 20s) before calling it critical
    this._staleStreak = stale.length === this.cfg.symbols.length ? (this._staleStreak || 0) + 1 : 0;
    if (stale.length === this.cfg.symbols.length && this._staleStreak >= 2) {
      return this._add('critical', 'data', 'all feeds stale', metrics);
    }
    if (stale.length === this.cfg.symbols.length) {
      return this._add('warn', 'data', 'all feeds stale (first sample)', metrics);
    }
    if (stale.length * 2 >= this.cfg.symbols.length) {
      return this._add('warn', 'data', `majority of feeds stale: ${stale.join(',')}`, metrics);
    }
    if (stale.length) return this._add('ok', 'data', `1 feed quiet (${stale.join(',')}), others live`, metrics);
    if (metrics.gapsDelta > 0) return this._add('warn', 'data', `${metrics.gapsDelta} candle gap(s)`, metrics);
    return this._add('ok', 'data', 'feeds live');
  }

  checkDecay() {
    const trades = this.trader.trades.slice(-this.cfg.auditor.decayWindow);
    if (trades.length < this.cfg.auditor.decayWindow) {
      return this._add('ok', 'decay', `warming up (${trades.length}/${this.cfg.auditor.decayWindow})`);
    }
    const wins = trades.filter((t) => t.win).length;
    const wr = wins / trades.length;
    const expectancy = mean(trades.map((t) => t.pnl));
    const metrics = { winRate: Math.round(wr * 1000) / 10, expectancy: Math.round(expectancy * 100) / 100, n: trades.length };
    if (wr < this.cfg.auditor.decayMinWinRate) {
      return this._add('warn', 'decay', `win rate ${metrics.winRate}% < ${this.cfg.auditor.decayMinWinRate * 100}%`, metrics);
    }
    if (expectancy < 0) {
      return this._add('warn', 'decay', `negative expectancy ${metrics.expectancy}$/trade`, metrics);
    }
    return this._add('ok', 'decay', `wr ${metrics.winRate}% exp $${metrics.expectancy}`);
  }

  checkIntegrity() {
    const t = now();
    if (t - this._lastChainCheck > 5 * 60 * 1000) {
      this._lastChainCheck = t;
      const v = this.store.verifyChain();
      this._chainOk = v.ok;
      if (!v.ok) return this._add('critical', 'integrity', `journal chain broken at #${v.brokenAt}`, v);
    }
    const ws = this.witness?.stats;
    if (ws && ws.discrepancy > 0) {
      return this._add('warn', 'integrity', `${ws.discrepancy} trade(s) failed witness verification`, ws);
    }
    // duplicate trade ids would mean double accounting
    const seen = new Set();
    for (const tr of this.trader.trades) {
      if (seen.has(tr.id)) return this._add('critical', 'integrity', `duplicate trade id ${tr.id}`);
      seen.add(tr.id);
    }
    return this._add('ok', 'integrity', 'chain + witness consistent');
  }

  checkAnomaly() {
    for (const feed of this.hub.all()) {
      const local = feed.ticker;
      const ref = this.witness?.price(feed.symbol);
      if (!local || !ref) continue;
      const mid = (local.bid + local.ask) / 2;
      const div = Math.abs(((mid - ref.price) / ref.price) * 10000);
      if (div > this.cfg.auditor.anomalyZ * 20) {
        return this._add('warn', 'anomaly', `${feed.symbol} diverges ${div.toFixed(0)}bps from ${ref.exchange}`, {
          symbol: feed.symbol,
          divergenceBps: Math.round(div),
        });
      }
    }
    return this._add('ok', 'anomaly', 'sources aligned');
  }

  checkStructural() {
    const t = now();
    // positions that outlive 3x their time stop are a logic bug, not a trade
    for (const p of this.portfolio.openPositions()) {
      if (t - p.openedAt > this.cfg.strategy.timeStopMs * 3) {
        return this._add('critical', 'structural', `${p.symbol} position age ${Math.round((t - p.openedAt) / 1000)}s exceeds 3x time stop`);
      }
    }
    // entries stuck in limbo
    if (this.trader.pendingEntries.size > this.cfg.risk.maxOpenPositions * 2) {
      return this._add('warn', 'structural', `${this.trader.pendingEntries.size} pending entries`);
    }
    // impossible geometry
    for (const p of this.portfolio.openPositions()) {
      // direction matters: a short's stop sits ABOVE entry and its target below
      const d = p.dir || (p.side === 'short' ? -1 : 1);
      const slOk = d > 0 ? p.sl < p.entry : p.sl > p.entry;
      const tpOk = p.tp === null || p.tp === undefined ? true : d > 0 ? p.tp > p.entry : p.tp < p.entry;
      if (!slOk || !tpOk) {
        return this._add('critical', 'structural', `${p.symbol} invalid tp/sl geometry`);
      }
    }
    return this._add('ok', 'structural', 'geometry ok');
  }

  // ---------------------------------------------------------------- reporting
  summary() {
    const byLevel = { ok: 0, warn: 0, critical: 0 };
    for (const f of this.findings) byLevel[f.level] = (byLevel[f.level] || 0) + 1;
    const latest = {};
    for (const f of this.findings) latest[f.code] = f;
    return {
      alerts: this.alerts,
      criticals: this.criticals,
      byLevel,
      latest,
      recent: this.findings.filter((f) => f.level !== 'ok').slice(-10),
    };
  }
}

module.exports = { Auditor };
