'use strict';
/**
 * BlackBird — Witness ("شاهد").
 *
 * An independent observer that never trades. Three jobs:
 *
 *  1. Keep a *second, independent* price series from a different exchange.
 *     The trader's own numbers are never trusted as ground truth.
 *  2. Verify every closed trade against that series (entry price, exit price,
 *     recomputed P&L, duration) and against the hash-chained journal.
 *  3. Re-derive the market conditions the trader claims in its report, so the
 *     6-hour report can be scored: "did you describe the market you were in?"
 *
 * The witness is the reason a lying or buggy trader cannot quietly rewrite its
 * own performance.
 */
const { now, bps, stdev } = require('../core/util');

class Witness {
  constructor({ cfg, log, store, exchange }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.exchange = exchange;
    this.refs = new Map(); // symbol -> [{ts, price}]
    this.maxRefs = 2000;
    this.verdicts = [];
    this.stats = { checked: 0, verified: 0, discrepancy: 0, unverifiable: 0 };
    this.timer = null;
    this.running = false;
  }

  async start() {
    this.running = true;
    await this._poll();
    // charter §3: 5s by default, but panel-tunable (WITNESS_UPDATE_MS).
    const every = Math.max(1000, Number(this.cfg.witness && this.cfg.witness.updateMs) || 5000);
    this.timer = setInterval(() => this._poll().catch(() => {}), every);
    return this;
  }

  async _poll() {
    if (!this.exchange) return;
    for (const sym of this.cfg.symbols) {
      try {
        const t = await this.exchange.ticker(sym);
        const arr = this.refs.get(sym) || [];
        arr.push({ ts: t.ts, price: (t.bid + t.ask) / 2 });
        if (arr.length > this.maxRefs) arr.shift();
        this.refs.set(sym, arr);
      } catch (e) {
        this.log.debug(`witness ${sym} failed: ${e.message}`);
      }
    }
  }

  stop() {
    this.running = false;
    if (this.timer) clearInterval(this.timer);
  }

  /** Reference price snapshot for the board / scout. */
  price(symbol) {
    const arr = this.refs.get(symbol);
    if (!arr || !arr.length) return null;
    const last = arr[arr.length - 1];
    return {
      price: last.price,
      ts: last.ts,
      ageMs: now() - last.ts,
      exchange: this.exchange?.id || 'n/a',
    };
  }

  /** Nearest reference price at or before `ts`. */
  priceAt(symbol, ts) {
    const arr = this.refs.get(symbol);
    if (!arr || !arr.length) return null;
    // refs are append-only and small; a linear scan from the tail is fine
    for (let i = arr.length - 1; i >= 0; i--) {
      if (arr[i].ts <= ts) {
        return { ...arr[i], exchange: this.exchange?.id || 'n/a', lagMs: ts - arr[i].ts };
      }
    }
    return null;
  }

  /**
   * Verify one closed trade. Returns a verdict object that lands in the report.
   */
  verifyTrade(trade) {
    const checks = [];
    let hardFail = false;
    let softFail = false;

    // 1. independent price at entry
    const ref = this.priceAt(trade.symbol, trade.entry.ts);
    if (!ref) {
      checks.push({ check: 'entry_price_cross_source', result: 'unverifiable', note: 'no reference sample' });
    } else {
      const div = Math.abs(bps(trade.entry.price, ref.price));
      const ok = div <= this.cfg.witness.maxPriceDivergenceBps;
      checks.push({
        check: 'entry_price_cross_source',
        result: ok ? 'pass' : 'fail',
        divergenceBps: Math.round(div * 10) / 10,
        reference: ref.price,
        referenceExchange: ref.exchange,
      });
      if (!ok) hardFail = true;
    }

    // 2. recompute P&L from the reported fills
    const gross = (trade.exit.price - trade.entry.price) * trade.entry.qty * (trade.dir || 1);
    const fees = (trade.entry.fee || 0) + (trade.exit.fee || 0);
    const recomputed = gross - fees;
    const pnlDiff = Math.abs(recomputed - trade.pnl);
    const pnlOk = pnlDiff <= this.cfg.witness.maxPnlDivergenceUsd;
    checks.push({
      check: 'pnl_recompute',
      result: pnlOk ? 'pass' : 'fail',
      reported: trade.pnl,
      recomputed: Math.round(recomputed * 100) / 100,
      diff: Math.round(pnlDiff * 100) / 100,
    });
    if (!pnlOk) hardFail = true;

    // 3. duration sanity
    const dur = trade.exit.ts - trade.entry.ts;
    const durOk = Math.abs(dur - trade.durationMs) < 2000 && dur > 0;
    checks.push({ check: 'duration', result: durOk ? 'pass' : 'fail', ms: dur });
    if (!durOk) softFail = true;

    // 4. journal presence (the chain is the source of truth)
    const entries = this.store.readJournal({ limit: 4000, type: 'trade_closed' });
    const inJournal = entries.some((e) => e.data?.id === trade.id);
    checks.push({ check: 'journal_presence', result: inJournal ? 'pass' : 'fail' });
    if (!inJournal) hardFail = true;

    // 5. fees are not zero (a trade with no fees is a simulation bug, not a win)
    const feeOk = fees > 0;
    checks.push({ check: 'fees_accounted', result: feeOk ? 'pass' : 'warn', fees: Math.round(fees * 100) / 100 });
    if (!feeOk) softFail = true;

    const verdict = hardFail ? 'discrepancy' : softFail ? 'soft_discrepancy' : 'verified';
    this.stats.checked++;
    this.stats[verdict === 'verified' ? 'verified' : verdict === 'discrepancy' ? 'discrepancy' : 'unverifiable']++;

    const out = {
      tradeId: trade.id,
      symbol: trade.symbol,
      ts: now(),
      verdict,
      checks,
      pnl: trade.pnl,
      score: hardFail ? 0 : softFail ? 0.6 : 1,
    };
    this.verdicts.push(out);
    if (this.verdicts.length > 1000) this.verdicts.shift();
    this.store.append('witness_verdict', out);
    if (verdict !== 'verified') {
      this.log.warn(`witness ${verdict} on ${trade.symbol}`, { tradeId: trade.id, checks: checks.filter((c) => c.result === 'fail') });
    }
    return out;
  }

  /**
   * Independently re-derive the market over a window from the witness series.
   * Used to score the trader's narrative.
   */
  marketDigest(fromTs, toTs) {
    const out = {};
    for (const sym of this.cfg.symbols) {
      const arr = (this.refs.get(sym) || []).filter((r) => r.ts >= fromTs && r.ts <= toTs);
      if (arr.length < 3) {
        out[sym] = null;
        continue;
      }
      const prices = arr.map((r) => r.price);
      const rets = [];
      for (let i = 1; i < prices.length; i++) rets.push((prices[i] - prices[i - 1]) / prices[i - 1]);
      out[sym] = {
        samples: arr.length,
        first: prices[0],
        last: prices[prices.length - 1],
        changePct: Math.round(((prices[prices.length - 1] / prices[0] - 1) * 100) * 1000) / 1000,
        high: Math.max(...prices),
        low: Math.min(...prices),
        rangePct: Math.round(((Math.max(...prices) / Math.min(...prices) - 1) * 100) * 1000) / 1000,
        stepVolBps: Math.round(stdev(rets) * 10000 * 100) / 100,
        exchange: this.exchange?.id || 'n/a',
      };
    }
    return out;
  }

  /**
   * Score the trader's 6h report against witness reality.
   * @param {object} report  the trader report object
   * @param {object} digest  marketDigest(from,to)
   */
  scoreReport(report, digest) {
    const checks = [];
    let score = 100;

    // chain integrity
    const chain = this.store.verifyChain();
    checks.push({
      check: 'journal_chain',
      result: chain.ok ? 'pass' : 'fail',
      entries: chain.count,
      brokenAt: chain.brokenAt,
    });
    if (!chain.ok) score -= 50;

    // trade count must match the journal
    const closed = this.store.readJournal({ limit: 5000, type: 'trade_closed' }).filter((e) => e.ts >= report.windowStart && e.ts <= report.windowEnd);
    const claimed = report.summary?.trades ?? 0;
    const countOk = closed.length === claimed;
    checks.push({ check: 'trade_count', result: countOk ? 'pass' : 'fail', journal: closed.length, claimed });
    if (!countOk) score -= 20;

    // P&L must match the journal
    const journalPnl = closed.reduce((s, e) => s + (e.data?.pnl || 0), 0);
    const claimedPnl = report.summary?.pnl ?? 0;
    const pnlOk = Math.abs(journalPnl - claimedPnl) <= 0.02 * Math.max(1, Math.abs(journalPnl));
    checks.push({
      check: 'pnl_match',
      result: pnlOk ? 'pass' : 'fail',
      journal: Math.round(journalPnl * 100) / 100,
      claimed: Math.round(claimedPnl * 100) / 100,
    });
    if (!pnlOk) score -= 20;

    // narrative vs reality: did the trader report the same volatility/range?
    const narrative = report.market?.digest || {};
    for (const sym of this.cfg.symbols) {
      const claim = narrative[sym];
      const truth = digest?.[sym];
      if (!claim || !truth) continue;
      const rangeDiff = Math.abs((claim.rangePct ?? 0) - (truth.rangePct ?? 0));
      const ok = rangeDiff <= Math.max(0.35, truth.rangePct * 0.6);
      checks.push({
        check: `narrative_range_${sym}`,
        result: ok ? 'pass' : 'warn',
        claimed: claim.rangePct,
        witness: truth.rangePct,
      });
      if (!ok) score -= 5;
    }

    // per-trade verdicts inside the window
    const windowVerdicts = this.verdicts.filter((v) => v.ts >= report.windowStart && v.ts <= report.windowEnd);
    const bad = windowVerdicts.filter((v) => v.verdict === 'discrepancy').length;
    checks.push({ check: 'trade_verdicts', result: bad === 0 ? 'pass' : 'fail', bad, total: windowVerdicts.length });
    if (bad > 0) score -= Math.min(30, bad * 10);

    return {
      score: Math.max(0, Math.min(100, score)),
      checks,
      verdict: score >= 85 ? 'trusted' : score >= 60 ? 'partially_trusted' : 'disputed',
    };
  }

  snapshot() {
    return {
      stats: this.stats,
      refs: Object.fromEntries([...this.refs.entries()].map(([k, v]) => [k, v.length])),
      lastVerdicts: this.verdicts.slice(-5),
    };
  }
}

module.exports = { Witness };
