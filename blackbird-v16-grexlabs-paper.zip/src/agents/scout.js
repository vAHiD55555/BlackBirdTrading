'use strict';
/**
 * BlackBird — Scout ("کاشف بازارهای مستعد سودآوری").
 *
 * Turns raw market state into a fully formed proposal. Two directions, three
 * ideas, each with its own notion of "good water":
 *
 *   TREND_PULLBACK (long)   uptrend, price pulls into the 20-EMA and reclaims.
 *   TREND_PULLBACK_SHORT    downtrend, price rallies into the 20-EMA and fails.
 *   RANGE_FADE (long)       wide 40-bar range, price near the low -> rest a bid.
 *   VWAP_SNAP (long)        stretched below VWAP -> rest a bid 1 ATR lower.
 *
 * Everything rests a passive order. Nothing chases. If the market does not come
 * to us there is no trade and no fee.
 */
const { uuid, now, clamp } = require('../core/util');
const { classify } = require('../data/regime');

const SIGNAL_NAMES = {
  TREND_PULLBACK: 'TREND_PULLBACK',
  TREND_PULLBACK_SHORT: 'TREND_PULLBACK_SHORT',
  RANGE_FADE: 'RANGE_FADE',
  VWAP_SNAP: 'VWAP_SNAP',
};

class Scout {
  constructor({ cfg, log, store, hub, risk, learner }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.hub = hub;
    this.risk = risk;
    this.learner = learner;
    this.proposals = new Map();
    this.stats = { scanned: 0, proposed: 0, skipped: {} };
    this._breadth = null;
    this._breadthTs = 0;
  }

  _skip(reason, symbol) {
    this.stats.skipped[reason] = (this.stats.skipped[reason] || 0) + 1;
    this.log.debug('skip ' + symbol + ': ' + reason);
    return null;
  }

  /** Share of the board trading above its 50-EMA. Cached for a minute. */
  _marketBreadth() {
    const t = now();
    if (this._breadth !== null && t - this._breadthTs < 60000) return this._breadth;
    let above = 0;
    let total = 0;
    for (const f of this.hub.all()) {
      const snap = f.snapshot();
      if (!snap || !snap.ema50) continue;
      total++;
      if (snap.close > snap.ema50) above++;
    }
    this._breadth = total ? above / total : 0;
    this._breadthTs = t;
    return this._breadth;
  }

  _costBps() {
    const f = this.cfg.fees;
    return f.makerBps + f.makerBps + f.slippageBpsPer1kNotional * 2;
  }

  /** Regime policy per strategy. Toxic kills everything. */
  _regimeAllows(name, regime) {
    if (regime === 'toxic') return false;
    if (name === SIGNAL_NAMES.TREND_PULLBACK || name === SIGNAL_NAMES.TREND_PULLBACK_SHORT) return true;
    return regime === 'muddy';
  }

  /** Direction-aware breadth gate. */
  _breadthAllows(side) {
    if (!this.cfg.strategy.useBreadthGate) return true;
    const b = this._marketBreadth();
    return side === 'buy' ? b >= this.cfg.strategy.breadthMin : b <= 1 - this.cfg.strategy.breadthMin;
  }

  _signals(snap, book, bars) {
    const out = [];
    const s = this.cfg.strategy;
    const costBps = this._costBps();
    const last = bars[bars.length - 1];
    if (!last || bars.length < 15) return out;

    const bullTrend = snap.ema200 && snap.ema50 > snap.ema200 && snap.close > snap.ema200;
    const bearTrend = snap.ema200 && snap.ema50 < snap.ema200 && snap.close < snap.ema200;

    // ---------------- TREND_PULLBACK (long) ---------------------------
    if (s.trendPullback && bullTrend) {
      const touched = last.l <= snap.ema20 * 1.0015 && last.c > snap.ema20;
      const rsiOk = snap.rsi >= s.pullbackRsiMin && snap.rsi <= s.pullbackRsiMax;
      if (touched && rsiOk && this._breadthAllows('buy')) {
        const lows = bars.slice(-4).map((b) => b.l);
        const stopLow = Math.min(Math.min.apply(null, lows), snap.ema50) * (1 - s.stopBufferBps / 10000);
        const risk = Math.max(1e-9, snap.close - stopLow);
        out.push({
          name: SIGNAL_NAMES.TREND_PULLBACK,
          side: 'buy',
          strength: clamp(
            0.35 * clamp((snap.ema50 / snap.ema200 - 1) * 60, 0, 1) +
              0.35 * clamp((snap.ema20 - last.l) / Math.max(snap.atr, 1e-9), 0, 1) +
              0.3 * clamp((this._marketBreadth() - 0.5) * 2, 0, 1),
            0, 1),
          why: 'pullback to EMA20 in uptrend, rsi ' + snap.rsi.toFixed(0) + ', breadth ' + Math.round(this._marketBreadth() * 100) + '%',
          limitPrice: Math.min(snap.ema20, last.c * 0.9995),
          slPrice: stopLow,
          tpPrice: snap.close + s.rrTarget * risk,
          structure: { ema20: snap.ema20, ema50: snap.ema50, ema200: snap.ema200, breadth: Math.round(this._marketBreadth() * 100) / 100 },
        });
      }
    }

    // ---------------- TREND_PULLBACK_SHORT ----------------------------
    if (s.allowShort && bearTrend) {
      const touched = last.h >= snap.ema20 * 0.9985 && last.c < snap.ema20;
      const rsiOk = snap.rsi >= (100 - s.pullbackRsiMax) && snap.rsi <= (100 - s.pullbackRsiMin) + 12;
      if (touched && rsiOk && this._breadthAllows('sell')) {
        const highs = bars.slice(-4).map((b) => b.h);
        const stopHigh = Math.max(Math.max.apply(null, highs), snap.ema50) * (1 + s.stopBufferBps / 10000);
        const risk = Math.max(1e-9, stopHigh - snap.close);
        out.push({
          name: SIGNAL_NAMES.TREND_PULLBACK_SHORT,
          side: 'sell',
          strength: clamp(
            0.35 * clamp((1 - snap.ema50 / snap.ema200) * 60, 0, 1) +
              0.35 * clamp((last.h - snap.ema20) / Math.max(snap.atr, 1e-9), 0, 1) +
              0.3 * clamp((0.5 - this._marketBreadth()) * 2, 0, 1),
            0, 1),
          why: 'rally into EMA20 in downtrend, rsi ' + snap.rsi.toFixed(0) + ', breadth ' + Math.round(this._marketBreadth() * 100) + '%',
          limitPrice: Math.max(snap.ema20, last.c * 1.0005),
          slPrice: stopHigh,
          tpPrice: snap.close - s.rrTarget * risk,
          structure: { ema20: snap.ema20, ema50: snap.ema50, ema200: snap.ema200, breadth: Math.round(this._marketBreadth() * 100) / 100 },
        });
      }
    }

    // ---------------- RANGE_FADE (long) -------------------------------
    const look = Math.min(s.sweepLookback, bars.length);
    const win = bars.slice(-look);
    let low = Infinity;
    let high = -Infinity;
    for (const b of win) {
      if (b.l < low) low = b.l;
      if (b.h > high) high = b.h;
    }
    const rangeBps = ((high - low) / low) * 10000;
    const posInRange = high > low ? (last.c - low) / (high - low) : 0.5;
    if (rangeBps >= costBps * 3 && posInRange <= 0.45 && this._breadthAllows('buy')) {
      out.push({
        name: SIGNAL_NAMES.RANGE_FADE,
        side: 'buy',
        strength: clamp(
          0.4 * clamp((0.45 - posInRange) / 0.45, 0, 1) +
            0.35 * clamp(rangeBps / (costBps * 6), 0, 1) +
            0.25 * clamp((snap.volumeSpike - 0.8) / 1.4, 0, 1),
          0, 1),
        why: 'close at ' + (posInRange * 100).toFixed(0) + '% of a ' + (rangeBps / 100).toFixed(2) + '% range',
        limitPrice: low * 1.0004,
        slPrice: low * (1 - s.stopBufferBps / 10000),
        tpPrice: low + (high - low) * 0.62,
        structure: { low, high, rangeBps: Math.round(rangeBps * 10) / 10, posInRange: Math.round(posInRange * 1000) / 1000 },
      });
    }

    // ---------------- VWAP_SNAP (long) --------------------------------
    const atr = snap.atr || 0;
    if (atr > 0 && snap.vwapDevAtr <= -0.4 && snap.vwapDevAtr >= -3.5 && this._breadthAllows('buy')) {
      const limitPrice = snap.vwap - atr;
      out.push({
        name: SIGNAL_NAMES.VWAP_SNAP,
        side: 'buy',
        strength: clamp(
          0.55 * clamp(Math.abs(snap.vwapDevAtr) / 2.5, 0, 1) +
            0.45 * clamp((45 - Math.min(snap.rsi, 45)) / 25, 0, 1),
          0, 1),
        why: snap.vwapDevAtr.toFixed(2) + ' ATR below VWAP, rsi ' + snap.rsi.toFixed(1),
        limitPrice,
        slPrice: limitPrice - atr * 0.8,
        tpPrice: snap.vwap,
        structure: { vwap: snap.vwap, devAtr: Math.round(snap.vwapDevAtr * 100) / 100 },
      });
    }

    let obiBoost = 0;
    if (book && book.bidNotional > 0 && book.askNotional > 0) {
      const obi = book.bidNotional / (book.bidNotional + book.askNotional);
      if (obi <= 0.38) obiBoost = clamp((0.42 - obi) / 0.15, 0, 1) * 0.1;
    }
    for (const sig of out) sig.strength = clamp(sig.strength + obiBoost, 0, 1);

    return out.sort((a, b) => b.strength - a.strength);
  }

  evaluate(symbol) {
    this.stats.scanned++;
    const feed = this.hub.get(symbol);
    if (!feed) return this._skip('no_feed', symbol);
    if (feed.isStale) return this._skip('stale_quote', symbol);

    const snap = feed.snapshot();
    if (!snap) return this._skip('not_enough_bars', symbol);
    const book = feed.book();
    if (!book) return this._skip('no_book', symbol);

    const s = this.cfg.strategy;
    const reg = classify(snap, book, s);

    const bars = feed.bars.toArray();
    const all = this._signals(snap, book, bars);
    if (!all.length) return this._skip('no_signal', symbol);
    const allowed = all.filter((sig) => this._regimeAllows(sig.name, reg.regime));
    if (!allowed.length) return this._skip('regime_' + reg.regime, symbol);
    const best = allowed[0];
    const dir = best.side === 'sell' ? -1 : 1;

    const costBps = this._costBps();
    const entry = best.side === 'sell'
      ? Math.max(best.limitPrice, book.ask * 1.00005)
      : Math.min(best.limitPrice, book.bid * 0.99995);
    if (!(entry > 0)) return this._skip('bad_limit', symbol);

    let stopPrice = best.slPrice;
    if (snap.atr > 0 && (best.name === SIGNAL_NAMES.TREND_PULLBACK || best.name === SIGNAL_NAMES.TREND_PULLBACK_SHORT)) {
      const floor = entry - dir * s.slAtrFloor * snap.atr;
      const ceil = entry - dir * s.slAtrCeil * snap.atr;
      stopPrice = dir > 0 ? Math.min(stopPrice, floor) : Math.max(stopPrice, floor);
      stopPrice = dir > 0 ? Math.max(stopPrice, ceil) : Math.min(stopPrice, ceil);
    }

    let slBps = ((entry - stopPrice) / entry) * 10000 * dir;
    if (!(slBps > 0)) return this._skip('bad_stop', symbol);
    if (slBps > s.maxSlBps * 2.5) return this._skip('stop_too_wide', symbol);
    slBps = clamp(slBps, s.minSlBps, s.maxSlBps);

    const conf = clamp(0.4 * reg.score + 0.4 * best.strength + 0.2 * clamp(snap.atrPercentile, 0, 1), 0, 1);
    const confFactor = 0.55 + 0.45 * conf;
    const minEdge = this.cfg.scout.minExpectedEdgeBps;

    let tpBps = ((best.tpPrice - entry) / entry) * 10000 * dir;
    tpBps = Math.max(tpBps, costBps + minEdge / Math.max(0.25, confFactor));
    tpBps = clamp(tpBps, s.minTpBps, s.maxTpBps);

    if (tpBps / Math.max(slBps, 1e-9) < s.minRR) return this._skip('rr_too_low', symbol);

    const expectedEdgeBps = Math.round((tpBps - costBps) * confFactor * 100) / 100;
    if (expectedEdgeBps < minEdge) return this._skip('expected_edge_low', symbol);

    const learnedBias = this.learner ? this.learner.bias(symbol, best.name, reg.regime) : 0;
    const tpPrice = entry * (1 + dir * (tpBps / 10000));
    const slFinal = entry * (1 - dir * (slBps / 10000));

    const proposal = {
      id: uuid('prop'),
      ts: now(),
      symbol,
      side: best.side,
      strategy: best.name,
      entryType: (best.name === SIGNAL_NAMES.TREND_PULLBACK || best.name === SIGNAL_NAMES.TREND_PULLBACK_SHORT) ? 'taker' : s.entryType,
      price: entry,
      tpBps: Math.round(tpBps * 10) / 10,
      slBps: Math.round(slBps * 10) / 10,
      tpPrice,
      slPrice: slFinal,
      rr: Math.round((tpBps / slBps) * 100) / 100,
      confidence: Math.round(clamp(conf + learnedBias, 0, 1) * 1000) / 1000,
      expectedEdgeBps,
      learnedBias,
      regime: reg.regime,
      regimeScore: reg.score,
      regimeReasons: reg.reasons,
      structure: best.structure,
      features: {
        price: snap.price,
        timeframe: this.cfg.data.timeframe,
        atrPct: Math.round(snap.atrPct * 100) / 100,
        atrPercentile: snap.atrPercentile,
        rsi: Math.round(snap.rsi * 10) / 10,
        bbPctB: snap.bb ? Math.round(snap.bb.pctB * 1000) / 1000 : null,
        vwapDevAtr: Math.round(snap.vwapDevAtr * 1000) / 1000,
        trendStrength: Math.round(snap.trendStrength * 100) / 100,
        volumeSpike: Math.round(snap.volumeSpike * 100) / 100,
        spreadBps: Math.round(book.spreadBps * 10) / 10,
        depthUsd: Math.round(book.depthUsd),
        quoteAgeMs: book.quoteAgeMs,
        regime: reg.regime,
        breadth: Math.round(this._marketBreadth() * 100) / 100,
      },
      rationale: [
        'regime=' + reg.regime + ' score=' + reg.score + ': ' + reg.reasons.join('; '),
        'signal ' + best.name + ': ' + best.why + ' (strength ' + best.strength.toFixed(2) + ')',
        (dir > 0 ? 'long' : 'short') + ' entry ' + entry + ' stop ' + slFinal.toFixed(6) + ' (' + slBps.toFixed(1) + 'bps) target ' +
          tpPrice.toFixed(6) + ' (' + tpBps.toFixed(1) + 'bps) R:R ' + (tpBps / slBps).toFixed(2),
        'cost ' + costBps.toFixed(1) + 'bps -> expected edge ' + expectedEdgeBps + 'bps after confidence ' + conf.toFixed(2),
      ],
      ttlMs: this.cfg.scout.proposalTtlMs,
      status: 'pending',
    };

    this.proposals.set(proposal.id, proposal);
    this.stats.proposed++;
    this.store.append('proposal', {
      id: proposal.id, symbol, side: proposal.side, strategy: proposal.strategy,
      limit: entry, tpBps: proposal.tpBps, slBps: proposal.slBps, rr: proposal.rr,
      confidence: proposal.confidence, expectedEdgeBps, features: proposal.features,
    });
    this.log.info('proposal ' + symbol + ' ' + (dir > 0 ? 'LONG ' : 'SHORT ') + best.name, {
      conf: proposal.confidence, edgeBps: expectedEdgeBps, tp: proposal.tpBps, sl: proposal.slBps, rr: proposal.rr,
    });
    return proposal;
  }

  scan() {
    const out = [];
    for (const sym of this.cfg.symbols) {
      try {
        const p = this.evaluate(sym);
        if (p) out.push(p);
      } catch (e) {
        this.log.warn('scout error on ' + sym + ': ' + e.message);
      }
    }
    const t = now();
    for (const [id, p] of this.proposals) {
      if (p.status === 'pending' && t - p.ts > p.ttlMs) {
        p.status = 'expired';
        this.proposals.delete(id);
      }
    }
    return out
      .sort((a, b) => b.expectedEdgeBps * b.confidence - a.expectedEdgeBps * a.confidence)
      .slice(0, this.cfg.scout.maxProposalsPerCycle);
  }

  markDecision(id, status) {
    const p = this.proposals.get(id);
    if (p) { p.status = status; this.proposals.delete(id); }
  }

  snapshot() {
    return { scanned: this.stats.scanned, proposed: this.stats.proposed, skipped: this.stats.skipped };
  }
}

module.exports = { Scout, SIGNAL_NAMES };
