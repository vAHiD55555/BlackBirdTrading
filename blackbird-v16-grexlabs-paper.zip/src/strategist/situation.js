'use strict';
/**
 * BlackBird — strategist situation model.
 *
 * A PURE function: engine status in, a severity verdict out. No clock, no
 * network, no randomness. Two calls with the same status must agree exactly,
 * or the strategist's decision cannot be defended after the fact.
 *
 * Three severities, and the boundaries are numbers, not adjectives:
 *
 *   green  nothing to do. The strategist stays silent. Silence is a success
 *          state, not a failure to find something.
 *   amber  something is off but the book is not in danger. Report it, do not
 *          act. Amber never grants crisis authority.
 *   red    the book is in danger. Only red may trigger self-execution, and only
 *          after the committee has had its full response window.
 *
 * The thresholds are fractions of the operator's own configured limits, so a
 * conservative risk config produces a conservative strategist automatically.
 */

const SEVERITY_RANK = { green: 0, amber: 1, red: 2 };

function num(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function arr(v) {
  return Array.isArray(v) ? v : [];
}

function mean(a) {
  return a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0;
}

function stdev(a) {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(a.reduce((s, v) => s + (v - m) ** 2, 0) / (a.length - 1));
}

/**
 * Assess a status snapshot.
 *
 * @param {object} status  engine.status()
 * @param {object} cfg     the full config (reads cfg.risk, cfg.strategy)
 * @returns {object} { severity, reasons, signals, contradiction, opportunity }
 */
function assess(status, cfg = {}) {
  const risk = status?.risk || {};
  const health = status?.health || {};
  const market = arr(status?.market);
  const rotator = status?.rotator || null;
  const lawyer = status?.lawyer || null;
  const jev = status?.jev || null;
  const limits = cfg?.risk || {};
  const strat = cfg?.strategy || {};

  const reasons = [];
  let severity = 'green';

  const bump = (level, why, evidence) => {
    if (SEVERITY_RANK[level] > SEVERITY_RANK[severity]) severity = level;
    reasons.push({ severity: level, why, evidence: evidence ?? null });
  };

  // ---------------------------------------------------------------- 1. halt
  if (risk.halted) {
    bump('red', `risk engine halted: ${risk.haltReason || risk.haltKind || 'unknown'}`);
  }

  // ------------------------------------------------- 2. drawdown vs kill switch
  const dd = num(risk.drawdownPct);
  const killPct = num(limits.killSwitchDrawdownPct) != null ? num(limits.killSwitchDrawdownPct) * 100 : null;
  if (dd != null && killPct != null && killPct > 0) {
    if (dd >= killPct * 0.8) {
      bump('red', `drawdown ${dd.toFixed(2)}% is at ${((dd / killPct) * 100).toFixed(0)}% of the kill switch (${killPct.toFixed(1)}%)`);
    } else if (dd >= killPct * 0.5) {
      bump('amber', `drawdown ${dd.toFixed(2)}% is past half the kill switch (${killPct.toFixed(1)}%)`);
    }
  }

  // ------------------------------------------------------- 3. daily loss budget
  const daily = num(risk.dailyPnlPct);
  const dailyCap = num(limits.maxDailyLossPct) != null ? num(limits.maxDailyLossPct) * 100 : null;
  if (daily != null && dailyCap != null && dailyCap > 0) {
    if (daily <= -dailyCap * 0.8) {
      bump('red', `daily P&L ${daily.toFixed(2)}% has used ${((Math.abs(daily) / dailyCap) * 100).toFixed(0)}% of the daily loss budget`);
    } else if (daily <= -dailyCap * 0.5) {
      bump('amber', `daily P&L ${daily.toFixed(2)}% is past half the daily loss budget`);
    }
  }

  // ------------------------------------------------------------ 4. data health
  const feedsTotal = num(health.feedsTotal) || 0;
  const feedsDown = num(health.feedsDegraded) || 0;
  if (feedsTotal > 0 && feedsDown > 0) {
    const share = feedsDown / feedsTotal;
    if (share >= 0.5) {
      bump('red', `${feedsDown}/${feedsTotal} market feeds are down — the engine is trading blind`, { degraded: arr(health.degradedSymbols) });
    } else {
      bump('amber', `${feedsDown}/${feedsTotal} market feeds are down`, { degraded: arr(health.degradedSymbols) });
    }
  }

  // --------------------------------------------------------- 5. execution cost
  const spreads = market.map((m) => num(m.spreadBps)).filter((x) => x != null);
  const maxSpread = num(strat.maxSpreadBps);
  if (spreads.length && maxSpread != null) {
    const over = spreads.filter((s) => s > maxSpread).length;
    if (over === spreads.length && spreads.length >= 3) {
      bump('red', `every symbol is above the spread gate (max ${Math.max(...spreads).toFixed(1)}bps > ${maxSpread}bps) — any fill is a loss`);
    } else if (over > 0) {
      bump('amber', `${over}/${spreads.length} symbols are above the spread gate`);
    }
  }

  // ------------------------------------------------------------ 6. lawyer view
  const criticalFindings = arr(lawyer?.openFindings).filter((f) => f.severity === 'critical').length;
  if (criticalFindings >= 2) {
    bump('red', `the lawyer holds ${criticalFindings} critical findings`);
  } else if (criticalFindings === 1) {
    bump('amber', 'the lawyer holds one critical finding');
  }
  if (lawyer?.vetoActive) bump('amber', `lawyer veto active: ${lawyer.vetoReason || 'no reason given'}`);

  // ---------------------------------------------------------------- 7. jev
  if (jev?.decision?.veto) bump('amber', 'jev is vetoing new entries');

  // ------------------------------------------------------- 8. regime mixture
  const regimes = market.map((m) => String(m.regime || 'n/a'));
  const share = (name) => (regimes.length ? regimes.filter((r) => r === name).length / regimes.length : 0);
  const toxicShare = share('toxic');
  if (toxicShare >= 0.5) bump('amber', `${(toxicShare * 100).toFixed(0)}% of symbols are in a toxic regime`);

  // ============================================== contradiction: method vs market
  // "The system's method disagrees with what the market is doing." Each entry
  // names the measured fact, not an opinion.
  const contradiction = [];
  const mode = String(strat.mode || 'rotator');
  const positions = arr(status?.trader?.openPositions);

  if ((mode === 'rotator' || mode === 'hybrid') && regimes.length >= 3 && toxicShare >= 0.5) {
    contradiction.push({
      kind: 'momentum_in_toxic_market',
      detail: `the book is a cross-sectional momentum book, but ${(toxicShare * 100).toFixed(0)}% of symbols are toxic`,
      evidence: { toxicShare, regimes },
    });
  }

  if (rotator && rotator.ready === false && positions.length > 0) {
    contradiction.push({
      kind: 'trading_without_warmup',
      detail: 'positions are open while the rotator reports it is not ready (insufficient history)',
      evidence: { ready: rotator.ready, positions: positions.length },
    });
  }

  if (positions.length > 0 && toxicShare >= 0.5) {
    contradiction.push({
      kind: 'holding_into_toxic',
      detail: `${positions.length} position(s) are open while ${(toxicShare * 100).toFixed(0)}% of symbols are toxic`,
      evidence: { positions: positions.length, toxicShare },
    });
  }

  const breadth = num(strat.breadthMin);
  if (breadth != null && regimes.length >= 3) {
    const upShare = share('trend');
    if (upShare < breadth && positions.some((p) => String(p.side || '').toLowerCase() === 'long')) {
      contradiction.push({
        kind: 'longs_below_breadth_gate',
        detail: `long positions are open while only ${(upShare * 100).toFixed(0)}% of symbols trend (gate ${(breadth * 100).toFixed(0)}%)`,
        evidence: { upShare, breadth },
      });
    }
  }

  // ============================================ opportunity: a better method fits
  // Dispersion is measured as the coefficient of variation of ATR% across
  // symbols. It is a PROXY for cross-sectional dispersion, not the thing
  // itself — see STRATEGIST.md, where that is marked as unverified.
  const atrs = market.map((m) => num(m.atrPct)).filter((x) => x != null && x > 0);
  const dispersion = atrs.length >= 3 ? stdev(atrs) / (mean(atrs) || 1) : null;
  const trendShare = share('trend');
  const rangeShare = share('muddy') + share('calm');

  const opportunity = [];
  if (dispersion != null && dispersion >= 0.6 && trendShare >= 0.5) {
    opportunity.push({
      method: 'cross_sectional_momentum',
      detail: `dispersion ${dispersion.toFixed(2)} with ${(trendShare * 100).toFixed(0)}% trending — the current method is the right one, size may be raised`,
      evidence: { dispersion, trendShare },
      verified: false,
    });
  }
  if (dispersion != null && dispersion <= 0.25 && rangeShare >= 0.5) {
    opportunity.push({
      method: 'mean_reversion',
      detail: `dispersion ${dispersion.toFixed(2)} with ${(rangeShare * 100).toFixed(0)}% ranging — a mean-reversion method would fit better than momentum`,
      evidence: { dispersion, rangeShare },
      verified: false,
    });
  }

  // A named contradiction is itself a finding. Leaving the severity at green
  // while reporting "the method disagrees with the market" produces a report
  // that contradicts itself, and the dashboard shows a green badge over a
  // paragraph explaining why the book is wrong.
  if (contradiction.length > 0 && SEVERITY_RANK[severity] < SEVERITY_RANK.amber) {
    severity = 'amber';
  }

  return {
    severity,
    reasons,
    contradiction,
    opportunity,
    signals: {
      drawdownPct: dd,
      killSwitchPct: killPct,
      dailyPnlPct: daily,
      dailyCapPct: dailyCap,
      feedsDown,
      feedsTotal,
      toxicShare,
      trendShare,
      dispersion,
      positions: positions.length,
      criticalFindings,
      halted: Boolean(risk.halted),
    },
  };
}

module.exports = { assess, SEVERITY_RANK, num, arr, mean, stdev };
