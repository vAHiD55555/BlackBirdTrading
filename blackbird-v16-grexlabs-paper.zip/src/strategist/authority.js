'use strict';
/**
 * BlackBird — crisis authority.
 *
 * The strategist may act on its own ONLY when the committee has failed to
 * answer inside the response window AND the situation is red. That is a real
 * power, so it is bounded in code, not in prose:
 *
 *   1. RISK CAN ONLY GO DOWN. Every action either blocks entries, pauses the
 *      strategy, flattens the book, or lowers the risk multiplier. There is no
 *      code path that raises exposure. A crisis is not an opportunity.
 *   2. A HARD RATE LIMIT. maxActionsPerHour, counted from the audit trail.
 *   3. A WHITELIST. An action not in allowedActions is refused, whatever the
 *      strategist asks for.
 *   4. A KILL SWITCH. STRATEGIST_KILL_SWITCH=1 disables the authority and
 *      clears any overlay immediately, without a restart.
 *   5. EVERY ACTION IS LOGGED. Refusals are logged too — a refused action is
 *      evidence about the strategist, and hiding it would make the audit lie.
 *
 * The overlay the authority produces EXPIRES. A crisis action that silently
 * persisted forever would be a permanent, invisible change to the strategy.
 */

const DEFAULTS = {
  enabled: false,
  maxActionsPerHour: 6,
  maxRiskDeltaPct: 25, // a single action may cut the risk multiplier by at most this many points
  allowedActions: ['block_entries', 'reduce_risk', 'pause_strategy', 'flatten', 'notify'],
  overlayTtlMs: 30 * 60 * 1000,
  killSwitchEnv: 'STRATEGIST_KILL_SWITCH',
};

/** Actions that can only ever reduce risk. Anything else is refused. */
const RISK_REDUCING = new Set(['block_entries', 'reduce_risk', 'pause_strategy', 'flatten', 'notify']);

class CrisisAuthority {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]
   * @param {object} [opts.log]
   * @param {object} [opts.env]
   * @param {function} [opts.clock]
   */
  constructor({ cfg = {}, log, env, clock } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.env = env || process.env;
    this.clock = clock || (() => Date.now());

    this.audit = [];
    this.maxAudit = 500;
    this.stats = { granted: 0, refused: 0, applied: 0, reverted: 0, killSwitchHits: 0 };
  }

  get enabled() {
    return Boolean(this.cfg.enabled);
  }

  /** The operator's instant off switch. Read live, so no restart is needed. */
  get killed() {
    const v = this.env[this.cfg.killSwitchEnv || 'STRATEGIST_KILL_SWITCH'];
    return /^(1|true|yes|on)$/i.test(String(v || ''));
  }

  /** Actions applied in the last hour, from the audit trail. */
  actionsLastHour() {
    const since = this.clock() - 3600000;
    return this.audit.filter((a) => a.applied && a.at >= since).length;
  }

  /**
   * May the strategist perform this action right now?
   *
   * @param {string} action
   * @param {object} [params]
   * @param {object} [ctx]  { currentMultiplier }
   * @returns {{ok: boolean, reason: string}}
   */
  canAct(action, params = {}, ctx = {}) {
    if (this.killed) {
      this.stats.killSwitchHits++;
      return this._refuse(action, 'kill switch is on');
    }
    if (!this.enabled) return this._refuse(action, 'crisis authority is disabled');
    if (!RISK_REDUCING.has(action)) return this._refuse(action, `"${action}" is not a risk-reducing action`);
    if (!(this.cfg.allowedActions || []).includes(action)) {
      return this._refuse(action, `"${action}" is not in allowedActions`);
    }
    if (this.actionsLastHour() >= Number(this.cfg.maxActionsPerHour || 0)) {
      return this._refuse(action, `rate limit: ${this.actionsLastHour()} actions in the last hour (max ${this.cfg.maxActionsPerHour})`);
    }

    if (action === 'reduce_risk') {
      const cur = Number.isFinite(ctx.currentMultiplier) ? ctx.currentMultiplier : 1;
      const next = Number(params.multiplier);
      if (!Number.isFinite(next) || next < 0 || next > 1) {
        return this._refuse(action, `multiplier ${params.multiplier} is outside 0..1`);
      }
      if (next >= cur) {
        return this._refuse(action, `multiplier ${next} would not reduce risk (current ${cur})`);
      }
      const deltaPct = (cur - next) * 100;
      if (deltaPct > Number(this.cfg.maxRiskDeltaPct || 0)) {
        return this._refuse(action, `a single cut of ${deltaPct.toFixed(0)} points exceeds maxRiskDeltaPct=${this.cfg.maxRiskDeltaPct}`);
      }
    }

    return { ok: true, reason: 'within authority' };
  }

  _refuse(action, reason) {
    this.stats.refused++;
    this._push({ action, applied: false, reason, at: this.clock() });
    this.log.warn(`crisis authority refused ${action}: ${reason}`);
    return { ok: false, reason };
  }

  /** Record an applied action. Returns the audit entry. */
  record(action, params, result, reason) {
    this.stats.granted++;
    this.stats.applied++;
    const entry = {
      id: `A-${String(this.audit.length + 1).padStart(4, '0')}`,
      at: this.clock(),
      action,
      params: params || {},
      result: result || null,
      reason: reason || '',
      applied: true,
    };
    this._push(entry);
    this.log.warn(`crisis authority applied ${action} ${JSON.stringify(params || {})} — ${reason || 'no reason'}`);
    return entry;
  }

  _push(entry) {
    this.audit.push(entry);
    if (this.audit.length > this.maxAudit) this.audit.shift();
  }

  snapshot() {
    return {
      enabled: this.enabled,
      killed: this.killed,
      maxActionsPerHour: this.cfg.maxActionsPerHour,
      maxRiskDeltaPct: this.cfg.maxRiskDeltaPct,
      allowedActions: this.cfg.allowedActions,
      actionsLastHour: this.actionsLastHour(),
      audit: this.audit.slice(-20),
      ...this.stats,
    };
  }
}

module.exports = { CrisisAuthority, DEFAULTS, RISK_REDUCING };
