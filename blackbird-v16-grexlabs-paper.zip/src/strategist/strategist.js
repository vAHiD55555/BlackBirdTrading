'use strict';
/**
 * BlackBird — the live strategist.
 *
 * A separate pair of eyes on the same book. It wakes every 3m30s, reads the
 * engine's own status, and answers one question: is the method still right for
 * the market in front of it?
 *
 * THE CYCLE
 * ---------
 *   1. assess()          pure function, no judgement, numbers only
 *   2. if severity is green      report and go back to sleep
 *   3. if amber                  raise a request, but never act
 *   4. if red or a contradiction raise a request to the committee and open a
 *                                60-second response window
 *   5. window expires with no answer AND severity is red
 *                                -> crisis authority: act, within bounds
 *   6. every cycle              write a live record (disk + publisher)
 *
 * WHY THE WINDOW EXISTS
 * ---------------------
 * A strategist that acts the instant it feels danger is a second, unsupervised
 * risk engine. Giving the committee 60s first means a working system always
 * keeps authority, and self-execution only happens when the committee is
 * genuinely gone — which is exactly the failure mode that loses money quietly.
 *
 * WHAT IT CAN NEVER DO
 * --------------------
 * Raise exposure. Every action in the authority's whitelist reduces risk. A
 * strategist that can add risk is a strategist that can blow up the book while
 * calling it an opportunity.
 */

const fs = require('node:fs');
const path = require('node:path');
const { now } = require('../core/util');
const { assess, SEVERITY_RANK } = require('./situation');
const { CrisisAuthority } = require('./authority');
const { Publisher } = require('./publisher');

const DEFAULTS = {
  enabled: false,
  intervalMs: 210000, // 3 minutes 30 seconds
  responseWindowMs: 60000, // the committee gets 60s before self-execution
  requestMinSeverity: 'amber', // the lowest severity that raises a request
  liveReport: true,
  maxRecords: 20000,
  authority: {},
  publish: {},
};

class Strategist {
  /**
   * @param {object} opts
   * @param {object} opts.cfg      cfg.strategist
   * @param {object} opts.engineCfg the full config (limits live there)
   * @param {object} opts.log
   * @param {object} [opts.store]  for the journal
   * @param {function} [opts.getStatus]
   * @param {function} [opts.requestAction] async (request) -> {approved, reason}
   *        The committee. Returning nothing, throwing, or hanging is "no answer".
   * @param {function} [opts.applyAction]  (action, params) -> result
   *        The engine's hands. Only called by the authority path.
   * @param {object} [opts.env]
   * @param {function} [opts.clock]
   */
  constructor({ cfg = {}, engineCfg = {}, log, store, getStatus, requestAction, applyAction, env, clock } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.engineCfg = engineCfg || {};
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.store = store || null;
    this.getStatus = getStatus || (() => null);
    this.requestAction = requestAction || null;
    this.applyAction = applyAction || null;
    this.env = env || process.env;
    this.clock = clock || (() => Date.now());

    this.authority = new CrisisAuthority({
      cfg: this.cfg.authority || {},
      log: this.log,
      env: this.env,
      clock: this.clock,
    });

    this.publisher = new Publisher({
      cfg: { ...(this.cfg.publish || {}), logDir: this.engineCfg?.runtime?.logDir },
      log: this.log,
      env: this.env,
      clock: this.clock,
    });

    this.dir = path.join(this.engineCfg?.runtime?.dataDir || path.join(process.cwd(), 'data'), 'strategist');
    this.file = path.join(this.dir, 'live.jsonl');

    this.lastCycleAt = 0;
    this.startedAt = null;
    this.lastAssessment = null;
    this.pending = null; // { at, deadline, severity, request, answered }
    this.records = [];
    this._loaded = false;
    this._timer = null;
    this.overlay = null; // { at, expiresAt, actions[] } — the crisis overlay, always expiring

    this.stats = {
      cycles: 0, requests: 0, answered: 0, timedOut: 0, selfExecutions: 0,
      green: 0, amber: 0, red: 0, errors: 0, overlaysExpired: 0,
    };
  }

  get enabled() {
    return Boolean(this.cfg.enabled);
  }

  // ------------------------------------------------------------- persistence
  load() {
    if (this._loaded) return this.records;
    this._loaded = true;
    // Records written during this process are already in memory. Re-reading the
    // file on top of them would duplicate every one of them, and a journal that
    // counts each cycle twice is a journal that lies about how often the
    // strategist looked.
    if (this.records.length > 0) return this.records;
    try {
      if (!fs.existsSync(this.file)) return this.records;
      const text = fs.readFileSync(this.file, 'utf8');
      for (const line of text.split('\n')) {
        if (!line.trim()) continue;
        try { this.records.push(JSON.parse(line)); } catch { /* torn line */ }
      }
      if (this.records.length > this.cfg.maxRecords) {
        this.records = this.records.slice(-this.cfg.maxRecords);
      }
    } catch (e) {
      this.log.warn(`strategist history load failed: ${e.message}`);
    }
    return this.records;
  }

  _write(record) {
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      fs.appendFileSync(this.file, `${JSON.stringify(record)}\n`, 'utf8');
      this.records.push(record);
      if (this.records.length > this.cfg.maxRecords) this.records = this.records.slice(-this.cfg.maxRecords);
      return true;
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`strategist write failed: ${e.message}`);
      return false;
    }
  }

  // ------------------------------------------------------------------- cycle
  /**
   * One full cycle. Safe to call directly (tests) and from the timer.
   * Never throws.
   *
   * @param {object} [statusOverride]
   * @returns {Promise<object>} the record it wrote
   */
  async cycle(statusOverride) {
    const at = this.clock();
    const started = now();
    this.stats.cycles++;
    this.lastCycleAt = at;

    let status = statusOverride;
    try {
      if (!status) status = this.getStatus();
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`strategist could not read status: ${e.message}`);
      status = null;
    }

    if (!status) {
      const rec = this._record(at, { severity: 'unknown', note: 'no status available' });
      return rec;
    }

    let verdict;
    try {
      verdict = assess(status, this.engineCfg);
    } catch (e) {
      this.stats.errors++;
      this.log.warn(`strategist assess failed: ${e.message}`);
      verdict = { severity: 'unknown', reasons: [{ severity: 'amber', why: `assess threw: ${e.message}` }], signals: {}, contradiction: [], opportunity: [] };
    }

    this.lastAssessment = verdict;
    this.stats[verdict.severity] = (this.stats[verdict.severity] || 0) + 1;

    // ---- 1. resolve the previous request, if any ------------------------
    if (this.pending && !this.pending.answered) {
      this._checkWindow(at, status, verdict);
    }

    // ---- 2. raise a new request when the situation warrants one ---------
    const floor = SEVERITY_RANK[this.cfg.requestMinSeverity] ?? SEVERITY_RANK.amber;
    const warrants = (SEVERITY_RANK[verdict.severity] ?? 0) >= floor
      || (verdict.contradiction || []).length > 0
      || (verdict.opportunity || []).length > 0;

    let request = null;
    if (warrants && !this.pending) {
      request = this._buildRequest(verdict, status);
      if (request) await this._sendRequest(request, at, verdict);
    }

    // ---- 3. the overlay expires, always --------------------------------
    if (this.overlay && at >= this.overlay.expiresAt) {
      this.stats.overlaysExpired++;
      this.log.info(`strategist overlay expired (${this.overlay.actions.length} action(s)) — normal authority restored`);
      const expired = this.overlay;
      this.overlay = null;
      try { this.applyAction?.('clear_overlay', { reason: 'ttl expired' }); } catch { /* engine must survive */ }
      this._write({ ts: at, type: 'overlay_expired', actions: expired.actions });
    }

    // ---- 4. the live record -------------------------------------------
    const rec = this._record(at, verdict, {
      request: request ? { action: request.action, reason: request.reason } : null,
      latencyMs: now() - started,
    });

    // ---- 5. flush the publisher when due -------------------------------
    try { this.publisher.maybeFlush(); } catch { /* never blocks */ }

    return rec;
  }

  /** Build the request this situation calls for. Null when nothing fits. */
  _buildRequest(verdict, status) {
    const cont = (verdict.contradiction || [])[0];
    const opp = (verdict.opportunity || [])[0];

    if (verdict.severity === 'red') {
      return {
        action: 'reduce_risk',
        multiplier: this._suggestedMultiplier(verdict),
        reason: `red: ${(verdict.reasons || []).map((r) => r.why).join(' | ') || 'unspecified'}`,
        kind: 'crisis',
        severity: verdict.severity,
      };
    }
    if (cont) {
      return {
        action: cont.kind === 'holding_into_toxic' || cont.kind === 'momentum_in_toxic_market' ? 'block_entries' : 'review_method',
        reason: `contradiction: ${cont.detail}`,
        kind: 'contradiction',
        severity: verdict.severity,
      };
    }
    if (opp) {
      return {
        action: 'review_method',
        reason: `opportunity: ${opp.detail}`,
        kind: 'opportunity',
        severity: verdict.severity,
        proposedMethod: opp.method,
      };
    }
    // Amber with no named contradiction still deserves a request: the operator
    // asked to be told when something is off, and "off but not yet dangerous"
    // is exactly the state that gets ignored until it is dangerous.
    if (verdict.severity === 'amber') {
      return {
        action: 'notify',
        reason: `amber: ${(verdict.reasons || []).map((r) => r.why).join(' | ') || 'unspecified'}`,
        kind: 'advisory',
        severity: verdict.severity,
      };
    }
    return null;
  }

  /**
   * How far to cut. Proportional to how far past the kill switch the book is,
   * floored at 0.25 so a crisis action actually does something.
   *
   * The result is then clamped to the authority's own maxRiskDeltaPct. Without
   * that clamp the strategist proposes a cut it is never allowed to make, the
   * authority refuses every time, and the crisis path is dead code that looks
   * alive in the logs.
   */
  _suggestedMultiplier(verdict) {
    const s = verdict.signals || {};
    const ratio = (s.drawdownPct != null && s.killSwitchPct) ? s.drawdownPct / s.killSwitchPct : 0.85;
    const raw = Math.max(0.25, Math.min(0.75, 1 - ratio * 0.5));
    const cap = Number(this.cfg.authority?.maxRiskDeltaPct);
    const floor = Number.isFinite(cap) && cap > 0 ? 1 - cap / 100 : 0;
    const bounded = Math.max(floor, raw);
    return Math.round(bounded * 100) / 100;
  }

  /**
   * Send a request and open the response window.
   * The committee answering is asynchronous: if it answers inside the window we
   * record it; if it does not, `_checkWindow` decides on the next tick.
   */
  async _sendRequest(request, at, verdict) {
    this.stats.requests++;
    this.pending = {
      at,
      deadline: at + Number(this.cfg.responseWindowMs || 60000),
      severity: verdict.severity,
      request,
      answered: false,
    };
    // The request goes to the journal as well as the publisher. Without this
    // the live journal records the cycles and the refusals but not the thing
    // they are about, and a reader cannot tell a quiet strategist from one
    // whose requests were all dropped.
    this._write({ ts: at, type: 'request', severity: verdict.severity, ...request });
    this.publisher.queue({ ts: at, type: 'request', ...request });
    this.log.warn(
      `strategist request (${verdict.severity}): ${request.action} — ${request.reason} ` +
      `(window ${Math.round((this.cfg.responseWindowMs || 60000) / 1000)}s)`
    );

    if (!this.requestAction) return;

    // The committee is asked, but the cycle does NOT wait for it.
    //
    // This is the whole point of the response window: a committee that hangs
    // must not hang the strategist. Awaiting here would mean a dead committee
    // freezes the cycle, the window never closes, and the one mechanism built
    // to survive a silent committee is disabled by a silent committee.
    const windowAt = at;
    Promise.resolve()
      .then(() => this.requestAction(request))
      .then((answer) => {
        if (!this.pending || this.pending.at !== windowAt) return; // a newer window took over
        this.pending.answered = true;
        this.stats.answered++;
        const approved = Boolean(answer && answer.approved);
        this.log.info(`strategist request answered by the committee: ${approved ? 'approved' : 'declined'}${answer?.reason ? ` — ${answer.reason}` : ''}`);
        this._write({
          ts: this.clock(), type: 'answer', action: request.action,
          approved, reason: answer?.reason || '', latencyMs: this.clock() - windowAt,
        });
        this.pending = null;
      })
      .catch((e) => {
        // A committee that throws has not answered. The window stays open; the
        // timeout path is what turns that into an action.
        this.log.warn(`strategist request failed to reach the committee: ${e.message}`);
      });
  }

  /** The 60s window: expired and still red and still unanswered -> act. */
  _checkWindow(at, status, verdict) {
    const p = this.pending;
    if (!p || at < p.deadline) return;

    this.stats.timedOut++;
    const stillRed = verdict.severity === 'red';
    const wasRed = p.severity === 'red';

    if (!stillRed) {
      this.log.info(`strategist window expired with no answer; situation is now ${verdict.severity}, so no self-execution`);
      this._write({ ts: at, type: 'window_expired', acted: false, severity: verdict.severity, reason: 'no longer red' });
      this.pending = null;
      return;
    }

    // Crisis authority is only for a red that was already red when the window
    // opened. A request raised in amber does not become a licence to act just
    // because the book got worse while the committee was away: that is exactly
    // when an unsupervised decision is most dangerous.
    if (!wasRed) {
      this.log.warn('strategist window expired in red, but the request was raised in amber — self-execution refused');
      this._write({ ts: at, type: 'self_execution_refused', reason: 'request was not raised at red severity' });
      this.pending = null;
      return;
    }

    this._selfExecute(p.request, at, verdict);
    this.pending = null;
  }

  /** Act, within the authority's bounds. Every refusal is recorded. */
  _selfExecute(request, at, verdict) {
    const ctx = { currentMultiplier: this.overlay?.multiplier ?? 1 };
    const check = this.authority.canAct(request.action, request, ctx);

    if (!check.ok) {
      this._write({ ts: at, type: 'self_execution_refused', action: request.action, reason: check.reason });
      this.publisher.queue({ ts: at, type: 'self_execution_refused', action: request.action, reason: check.reason });
      return null;
    }

    let result = null;
    try {
      result = this.applyAction ? this.applyAction(request.action, request) : { applied: false, reason: 'no applyAction wired' };
    } catch (e) {
      result = { applied: false, reason: `applyAction threw: ${e.message}` };
    }

    if (!result || result.applied === false) {
      this._write({ ts: at, type: 'self_execution_failed', action: request.action, reason: result?.reason || 'engine did not apply it' });
      return null;
    }

    this.stats.selfExecutions++;
    const ttl = Number(this.cfg.authority?.overlayTtlMs || 30 * 60 * 1000);
    this.overlay = {
      at,
      expiresAt: at + ttl,
      multiplier: request.action === 'reduce_risk' ? Number(request.multiplier) : (this.overlay?.multiplier ?? 1),
      actions: [...(this.overlay?.actions || []), { at, action: request.action, params: { ...request } }],
    };

    const entry = this.authority.record(request.action, request, result, request.reason);
    this.log.error(
      `strategist SELF-EXECUTED ${request.action} after ${Math.round((at - (this.pending?.at || at)) / 1000)}s without a committee answer — ${request.reason}`
    );
    this._write({ ts: at, type: 'self_execution', action: request.action, params: request, result, authority: entry.id, verdict: verdict.signals });
    this.publisher.queue({ ts: at, type: 'self_execution', action: request.action, result, authority: entry.id });
    if (this.store) {
      try { this.store.append('strategist_act', { action: request.action, reason: request.reason, result }); } catch { /* journal is a bonus */ }
    }
    return entry;
  }

  /** Write the live record, to disk and to the publisher. */
  _record(at, verdict, extra = {}) {
    const rec = {
      ts: at,
      type: 'cycle',
      severity: verdict.severity,
      reasons: (verdict.reasons || []).map((r) => ({ severity: r.severity, why: r.why })),
      contradiction: (verdict.contradiction || []).map((c) => ({ kind: c.kind, detail: c.detail })),
      opportunity: (verdict.opportunity || []).map((o) => ({ method: o.method, detail: o.detail, verified: o.verified })),
      signals: verdict.signals || {},
      overlay: this.overlay ? { multiplier: this.overlay.multiplier, expiresAt: this.overlay.expiresAt } : null,
      pending: this.pending ? { action: this.pending.request.action, deadline: this.pending.deadline } : null,
      ...extra,
    };
    if (this.cfg.liveReport) {
      this._write(rec);
      this.publisher.queue(rec);
    }
    return rec;
  }

  // ---------------------------------------------------------------- control
  start() {
    if (!this.enabled) {
      this.log.info('strategist: off (STRATEGIST_ENABLED not set)');
      return false;
    }
    if (this._timer) return true;
    this.startedAt = this.clock();
    const every = Math.max(1000, Number(this.cfg.intervalMs) || DEFAULTS.intervalMs);
    this._timer = setInterval(() => {
      this.cycle().catch((e) => this.log.warn(`strategist cycle failed: ${e.message}`));
    }, every);
    if (this._timer.unref) this._timer.unref();
    this.log.info(
      `strategist: live, every ${Math.round(every / 1000)}s, response window ` +
      `${Math.round((this.cfg.responseWindowMs || 60000) / 1000)}s, crisis authority ` +
      `${this.authority.enabled ? 'ARMED' : 'disarmed'}`
    );
    // First look immediately: waiting 3m30s to find out the book is in danger
    // is 3m30s of avoidable exposure.
    this.cycle().catch(() => null);
    return true;
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }

  /** Effective risk multiplier: the crisis overlay, or 1. Never above 1. */
  riskMultiplier() {
    if (!this.overlay) return 1;
    if (this.clock() >= this.overlay.expiresAt) return 1;
    const m = Number(this.overlay.multiplier);
    if (!Number.isFinite(m)) return 1;
    // Clamped here as well as in the rotator: a value above 1 must be
    // impossible to read out of this object, not merely ignored downstream.
    return Math.min(1, Math.max(0, m));
  }

  /** Should new entries be blocked right now? */
  blocksEntries() {
    if (!this.overlay) return false;
    if (this.clock() >= this.overlay.expiresAt) return false;
    return this.overlay.actions.some((a) => a.action === 'block_entries' || a.action === 'pause_strategy' || a.action === 'flatten');
  }

  snapshot() {
    return {
      enabled: this.enabled,
      intervalMs: this.cfg.intervalMs,
      responseWindowMs: this.cfg.responseWindowMs,
      lastCycleAt: this.lastCycleAt || null,
      startedAt: this.startedAt || null,
      severity: this.lastAssessment?.severity ?? null,
      reasons: (this.lastAssessment?.reasons || []).slice(0, 5),
      contradiction: this.lastAssessment?.contradiction || [],
      opportunity: this.lastAssessment?.opportunity || [],
      signals: this.lastAssessment?.signals || null,
      overlay: this.overlay ? {
        multiplier: this.overlay.multiplier,
        expiresAt: this.overlay.expiresAt,
        actions: this.overlay.actions.map((a) => a.action),
      } : null,
      pending: this.pending ? { action: this.pending.request.action, deadline: this.pending.deadline, severity: this.pending.severity } : null,
      authority: this.authority.snapshot(),
      publisher: this.publisher.snapshot(),
      records: this.load().length,
      recent: this.load().slice(-8),
      ...this.stats,
    };
  }
}

module.exports = { Strategist, DEFAULTS };
