'use strict';
/**
 * BlackBird — strategist report publisher.
 *
 * The strategist's reports and the server log are pushed to two places: a
 * GitHub repository and a second mirror. Both are OFF by default and both are
 * configured entirely from the environment, so no credential ever lives in a
 * file in this repository.
 *
 *   STRATEGIST_PUBLISH=github|mirror|both|off   (default off)
 *   GITHUB_TOKEN, GITHUB_REPO=owner/name, GITHUB_BRANCH, GITHUB_PATH
 *   MIRROR_REPO=owner/name, MIRROR_TOKEN, MIRROR_BRANCH, MIRROR_PATH
 *   MIRROR_URL  — a plain HTTP PUT endpoint instead of a git host
 *
 * Rules that matter more than the feature:
 *   - Nothing here throws. A failed upload must never stop the engine.
 *   - Nothing here blocks. Publishing runs on its own timer, never on the
 *     trading clock.
 *   - Every payload is redacted before it leaves the process. A token that
 *     reaches a public repository is unrecoverable.
 *   - A failure is reported ONCE per distinct reason, not on every cycle.
 */

const fs = require('node:fs');
const path = require('node:path');
const { redact } = require('../jev/ledger');

const DEFAULTS = {
  mode: 'off', // off | github | mirror | both
  intervalMs: 5 * 60 * 1000,
  timeoutMs: 15000,
  includeLogs: true,
  logTailBytes: 64 * 1024,
  maxBufferLines: 5000,
};

class Publisher {
  constructor({ cfg = {}, log, env, clock, fetchImpl } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.env = env || process.env;
    this.clock = clock || (() => Date.now());
    this.fetch = fetchImpl || (typeof fetch === 'function' ? fetch : null);

    this.buffer = [];
    this.lastFlushAt = 0;
    this.lastError = null;
    this._reported = new Set();
    this.stats = { queued: 0, flushed: 0, pushed: 0, failed: 0, skipped: 0, bytes: 0 };
  }

  get mode() {
    const m = String(this.env.STRATEGIST_PUBLISH || this.cfg.mode || 'off').toLowerCase();
    return ['off', 'github', 'mirror', 'both'].includes(m) ? m : 'off';
  }

  get enabled() {
    return this.mode !== 'off';
  }

  /** Queue one record. Never throws, never blocks. */
  queue(record) {
    if (!this.enabled) { this.stats.skipped++; return false; }
    try {
      this.buffer.push(redact(record));
      if (this.buffer.length > this.cfg.maxBufferLines) this.buffer.shift();
      this.stats.queued++;
      return true;
    } catch (e) {
      this.stats.failed++;
      this.lastError = e.message;
      return false;
    }
  }

  /** Flush when due. Called from the engine clock; returns immediately. */
  maybeFlush() {
    if (!this.enabled) return null;
    if (this.clock() - this.lastFlushAt < this.cfg.intervalMs) return null;
    this.lastFlushAt = this.clock();
    return this.flush().catch(() => null);
  }

  /**
   * Push the buffer to every configured target.
   * @returns {Promise<{ok:boolean, targets:Array}>}
   */
  async flush() {
    if (!this.enabled) return { ok: false, targets: [] };
    if (!this.buffer.length) return { ok: true, targets: [] };
    if (!this.fetch) {
      this._once('no-fetch', 'publisher: no fetch available in this runtime');
      return { ok: false, targets: [] };
    }

    const lines = this.buffer.slice();
    this.buffer = [];
    const day = new Date(this.clock()).toISOString().slice(0, 10);
    const body = `${lines.map((l) => JSON.stringify(l)).join('\n')}\n`;

    const targets = [];
    if (this.mode === 'github' || this.mode === 'both') targets.push(this._githubTarget('GITHUB', 'strategist'));
    if (this.mode === 'mirror' || this.mode === 'both') targets.push(this._githubTarget('MIRROR', 'mirror'));

    const results = [];
    for (const t of targets) {
      if (!t) continue;
      try {
        const r = await this._put(t, `${t.path}/${day}.jsonl`, body);
        results.push({ target: t.name, ok: r.ok, status: r.status, error: r.error || null });
        if (r.ok) { this.stats.pushed++; this.stats.bytes += Buffer.byteLength(body); }
        else { this.stats.failed++; this._once(`${t.name}:${r.status}`, `publisher ${t.name} failed: ${r.error || r.status}`); }
      } catch (e) {
        this.stats.failed++;
        results.push({ target: t.name, ok: false, error: e.message });
        this._once(`${t.name}:${e.message}`, `publisher ${t.name} failed: ${e.message}`);
      }
    }

    // The server log rides along, bounded, so a report can be read next to the
    // lines that produced it.
    if (this.cfg.includeLogs) {
      try {
        const tail = this._logTail();
        if (tail) {
          for (const t of targets) {
            if (!t) continue;
            await this._put(t, `${t.path}/logs/${day}.log`, tail).catch(() => null);
          }
        }
      } catch { /* logs are a bonus, never a requirement */ }
    }

    this.stats.flushed++;
    this.lastError = results.find((r) => !r.ok)?.error || null;
    return { ok: results.every((r) => r.ok), targets: results };
  }

  _githubTarget(prefix, name) {
    const repo = String(this.env[`${prefix}_REPO`] || '').trim();
    const token = String(this.env[`${prefix}_TOKEN`] || '').trim();
    const url = String(this.env[`${prefix}_URL`] || '').trim();
    if (!repo && !url) return null;
    if (!token) {
      this._once(`${name}:no-token`, `publisher ${name}: ${prefix}_REPO is set but ${prefix}_TOKEN is empty — skipping`);
      return null;
    }
    return {
      name,
      repo,
      token,
      url,
      branch: String(this.env[`${prefix}_BRANCH`] || 'main').trim(),
      path: String(this.env[`${prefix}_PATH`] || 'blackbird/strategist').replace(/^\/+|\/+$/g, ''),
    };
  }

  /** PUT a file. GitHub contents API when a repo is given, plain PUT otherwise. */
  async _put(target, filePath, content) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(new Error('timeout')), this.cfg.timeoutMs);
    try {
      if (target.url) {
        const res = await this.fetch(`${target.url.replace(/\/+$/, '')}/${filePath}`, {
          method: 'PUT',
          headers: { 'content-type': 'application/x-ndjson', authorization: `Bearer ${target.token}` },
          body: content,
          signal: ctl.signal,
        });
        return { ok: res.ok, status: res.status, error: res.ok ? null : `HTTP ${res.status}` };
      }

      const api = `https://api.github.com/repos/${target.repo}/contents/${filePath}`;
      const headers = {
        authorization: `Bearer ${target.token}`,
        accept: 'application/vnd.github+json',
        'user-agent': 'blackbird-strategist',
        'content-type': 'application/json',
      };

      // The contents API replaces a whole file, so the existing sha is needed.
      let sha = null;
      const head = await this.fetch(`${api}?ref=${encodeURIComponent(target.branch)}`, { headers, signal: ctl.signal });
      if (head.ok) {
        const j = await head.json().catch(() => null);
        sha = j?.sha || null;
      } else if (head.status !== 404) {
        return { ok: false, status: head.status, error: `HTTP ${head.status} reading ${filePath}` };
      }

      const res = await this.fetch(api, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          message: `strategist: ${filePath}`,
          content: Buffer.from(content, 'utf8').toString('base64'),
          branch: target.branch,
          ...(sha ? { sha } : {}),
        }),
        signal: ctl.signal,
      });
      return { ok: res.ok, status: res.status, error: res.ok ? null : `HTTP ${res.status}` };
    } finally {
      clearTimeout(timer);
    }
  }

  /** Last N bytes of the newest log file, or null. */
  _logTail() {
    const dir = this.cfg.logDir;
    if (!dir || !fs.existsSync(dir)) return null;
    try {
      const files = fs.readdirSync(dir).filter((f) => f.endsWith('.log')).sort();
      if (!files.length) return null;
      const full = path.join(dir, files[files.length - 1]);
      const st = fs.statSync(full);
      const start = Math.max(0, st.size - this.cfg.logTailBytes);
      const fd = fs.openSync(full, 'r');
      const buf = Buffer.alloc(st.size - start);
      fs.readSync(fd, buf, 0, buf.length, start);
      fs.closeSync(fd);
      return buf.toString('utf8');
    } catch {
      return null;
    }
  }

  /** Log a distinct failure once, not on every cycle. */
  _once(key, message) {
    if (this._reported.has(key)) return;
    this._reported.add(key);
    this.log.warn(message);
  }

  snapshot() {
    return {
      mode: this.mode,
      enabled: this.enabled,
      buffered: this.buffer.length,
      lastFlushAt: this.lastFlushAt || null,
      lastError: this.lastError,
      targets: {
        github: Boolean(this.env.GITHUB_REPO || this.env.GITHUB_URL),
        mirror: Boolean(this.env.MIRROR_REPO || this.env.MIRROR_URL),
      },
      ...this.stats,
    };
  }
}

module.exports = { Publisher, DEFAULTS };
