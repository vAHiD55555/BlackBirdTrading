'use strict';
/**
 * BlackBird — market intel (اخبار و هوش بازار).
 *
 * The engine already knows what price did. This module answers a different
 * question: what is happening in the world that price has not priced yet?
 *
 * Three feed families, all free and keyless by default:
 *
 *   macro    — economic calendar / policy headlines (rate decisions, CPI, ...)
 *   geo      — political and geopolitical headlines
 *   weather  — severe-weather alerts that move energy and agriculture
 *
 * How the signal is used (and how it is NOT used):
 *
 *   - It produces a *bias*, not an order. `bias()` returns a number in
 *     [-1, +1] plus a confidence, and the engine may only use it to REDUCE
 *     risk or to widen a stop. It can never open a position or raise a limit.
 *   - It is a gate, not a predictor. A high-impact event inside the blackout
 *     window blocks NEW entries; it does not predict direction. Predicting
 *     direction from a headline is how accounts die.
 *   - Every feed is optional. No URL configured means no call, and the module
 *     reports `enabled: false` rather than pretending to have data.
 *
 * The technique, in one line: *event blackout + sentiment tilt*. Stand aside
 * when a scheduled high-impact event is imminent, and lean against the crowd
 * when the aggregate tone is extreme and price has not moved yet.
 *
 * Nothing here throws. A news outage must never stop trading.
 */

const { now, clamp } = require('../core/util');

const DEFAULTS = {
  enabled: false,
  // Each feed is a plain HTTP GET. `format` is 'json' or 'rss'. For JSON,
  // `path` is a dotted path into the response and `titleField`/`timeField`
  // name the fields. For RSS, the item/title/pubDate tags are parsed directly.
  //
  // `fallbackUrl` is the escape hatch: GDELT answers HTTP 429 from shared
  // datacenter IPs (it allows one request per 5 s per IP), so a primary feed
  // that fails falls through to a keyless RSS mirror instead of leaving the
  // card empty. A feed that fails BOTH is reported as failed, never faked.
  feeds: {
    macro: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 1.0, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
    geo: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.8, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
    weather: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.5, format: 'json', fallbackUrl: '', fallbackFormat: 'rss' },
    // Crypto-native and wire-service feeds. These are the two families that
    // actually move a crypto book: a coin-desk headline lands minutes before
    // the price does, and a wire-service markets headline is the same story
    // the macro feed carries, from a second independent source.
    //
    // Both are RSS-only and keyless. Reuters' own feeds.reuters.com host has
    // been dead since 2021 and www.reuters.com/markets/rss answers 401, so the
    // Reuters family is reached through Google News' RSS search, which is a
    // keyless mirror of the same wire copy. That is stated in the source name
    // the dashboard shows, never disguised as a direct Reuters feed.
    crypto: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.9, format: 'rss', fallbackUrl: '', fallbackFormat: 'rss' },
    wire: { url: '', path: '', titleField: 'title', timeField: 'published', weight: 0.9, format: 'rss', fallbackUrl: '', fallbackFormat: 'rss' },
  },
  refreshMs: 15 * 60 * 1000,
  timeoutMs: 8000,
  // GDELT's limit is one request per 5 s per IP. One retry after 6 s turns a
  // transient 429 into a success without ever hammering the endpoint.
  retry429: 1,
  retryDelayMs: 6000,
  maxItemsPerFeed: 40,
  // A scheduled event this close blocks new entries.
  blackoutBeforeMs: 30 * 60 * 1000,
  blackoutAfterMs: 15 * 60 * 1000,
  // Aggregate tone beyond this magnitude is "extreme" and tilts the bias.
  extremeThreshold: 0.6,
  // How much the bias may move the risk multiplier. Hard ceiling, never raised.
  maxRiskImpact: 0.25,
};

/**
 * Keyword lexicons. Deliberately small and explicit: a big opaque model is not
 * needed to know that "rate hike" is hawkish, and a list can be audited.
 */
const LEXICON = {
  hawkish: [
    'rate hike', 'hikes rates', 'tightening', 'inflation surge', 'inflation rises',
    'hotter than expected', 'hawkish', 'yields jump', 'bond selloff', 'strong jobs',
    'tapering', 'quantitative tightening',
  ],
  dovish: [
    'rate cut', 'cuts rates', 'easing', 'inflation cools', 'inflation falls',
    'cooler than expected', 'dovish', 'yields fall', 'bond rally', 'weak jobs',
    'stimulus', 'quantitative easing',
  ],
  riskOff: [
    'war', 'invasion', 'strike', 'attack', 'sanctions', 'default', 'crisis',
    'crash', 'collapse', 'bank failure', 'emergency', 'escalation', 'conflict',
    'shutdown', 'contagion', 'panic',
  ],
  riskOn: [
    'ceasefire', 'truce', 'agreement', 'deal', 'resolution', 'recovery',
    'rebound', 'optimism', 'breakthrough', 'peace',
  ],
  weatherSevere: [
    'hurricane', 'typhoon', 'cyclone', 'blizzard', 'heatwave', 'drought',
    'flood', 'wildfire', 'freeze', 'storm warning', 'severe weather',
  ],
  // Scheduled events that deserve a blackout regardless of tone.
  highImpact: [
    'fomc', 'federal reserve', 'interest rate decision', 'cpi', 'nonfarm payrolls',
    'gdp', 'ecb', 'boj', 'unemployment', 'pce', 'retail sales',
  ],
  // Crypto-native vocabulary. A coin-desk headline uses a different language
  // from a macro wire: "ETF inflow", "halving", "exchange hack" and "stablecoin
  // depeg" move a crypto book and appear in none of the lists above.
  cryptoRiskOff: [
    'hack', 'exploit', 'breach', 'stolen', 'rug pull', 'depeg', 'insolvency',
    'bankruptcy', 'withdrawals halted', 'freeze', 'delist', 'sec sues', 'lawsuit',
    'liquidation cascade', 'outflow', 'dump',
  ],
  cryptoRiskOn: [
    'etf inflow', 'etf approval', 'institutional adoption', 'halving',
    'upgrade', 'mainnet launch', 'partnership', 'buyback', 'accumulation',
    'all-time high', 'record high', 'inflow',
  ],
};

/** Count lexicon hits in a lower-cased string. */
function hits(text, words) {
  let n = 0;
  for (const w of words) if (text.includes(w)) n++;
  return n;
}

/**
 * Score one headline. Pure: no I/O, no clock. That is what makes it testable.
 *
 * @param {string} title
 * @param {object} [opts] { weight }
 * @returns {{tone: number, impact: number, tags: string[]}}
 *   tone   in [-1, +1]: negative = risk-off / hawkish, positive = risk-on / dovish
 *   impact in [0, 1]: how much this headline deserves attention
 */
function scoreHeadline(title, opts = {}) {
  const weight = Number.isFinite(opts.weight) ? opts.weight : 1;
  const t = String(title || '').toLowerCase();
  if (!t) return { tone: 0, impact: 0, tags: [] };

  const hawk = hits(t, LEXICON.hawkish);
  const dove = hits(t, LEXICON.dovish);
  const off = hits(t, LEXICON.riskOff);
  const on = hits(t, LEXICON.riskOn);
  const wx = hits(t, LEXICON.weatherSevere);
  const hi = hits(t, LEXICON.highImpact);
  const cOff = hits(t, LEXICON.cryptoRiskOff);
  const cOn = hits(t, LEXICON.cryptoRiskOn);

  const tags = [];
  if (hawk) tags.push('hawkish');
  if (dove) tags.push('dovish');
  if (off) tags.push('risk_off');
  if (on) tags.push('risk_on');
  if (wx) tags.push('weather');
  if (hi) tags.push('high_impact');
  if (cOff) tags.push('crypto_risk_off');
  if (cOn) tags.push('crypto_risk_on');

  // Tone: risk-off and hawkish push down, risk-on and dovish push up. The
  // crypto lists fold into the same two sides, so a coin-desk headline and a
  // macro headline are scored on one scale instead of two.
  const down = hawk + off + wx * 0.5 + cOff;
  const up = dove + on + cOn;
  const total = down + up;
  const tone = total === 0 ? 0 : clamp((up - down) / total, -1, 1);

  // Impact: a scheduled event or a severe-weather alert matters more than a
  // generic opinion piece. Saturating, so ten keywords do not score ten times.
  // A crypto exchange hack is weighted like a geopolitical shock: it is the
  // one headline class that can gap a crypto book overnight.
  const raw = hi * 0.5 + off * 0.3 + wx * 0.4 + hawk * 0.2 + dove * 0.2 + on * 0.2 + cOff * 0.35 + cOn * 0.15;
  const impact = clamp(1 - Math.exp(-raw), 0, 1) * clamp(weight, 0, 2);

  return { tone: Math.round(tone * 1000) / 1000, impact: Math.round(impact * 1000) / 1000, tags };
}

/**
 * Hard limits on untrusted input. A feed is not a trusted document: without a
 * cap, one hostile response can put a 200 KB "headline" into the report and
 * the journal, or 5 000 items into memory.
 */
const MAX_TITLE_CHARS = 400;
const MAX_ITEMS = 500;

/**
 * Patterns that mean "this is not a headline, it is an attack".
 *
 * A real news title never contains a tag, a script scheme or an event handler,
 * so a match DROPS the item instead of repairing it. Repairing would keep a
 * hostile string in the pipeline (report, journal, dashboard payload) for no
 * benefit at all.
 */
const HOSTILE = [
  /<\s*[a-z!/]/i, // a tag, closed or not — the unclosed case is the bug
  /&lt;\s*[a-z!/]/i, // a tag that survived double-encoding
  /&#0*6[0-9];/i, // &#60; is '<'
  /javascript\s*:/i,
  /\bon[a-z]+\s*=/i, // onerror=, onload=, onclick=
  /\bdata\s*:\s*text\/html/i,
  /\bvbscript\s*:/i,
];

/**
 * Decode entities and unwrap CDATA, but leave tags IN PLACE.
 *
 * This is the form the sanitiser must see. Stripping tags first would turn
 * `<script>alert(1)</script>` into the harmless-looking `alert(1)` and hide
 * the attack from every check that follows.
 */
function decodeRaw(s) {
  return String(s)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
}

/**
 * Minimal RSS/Atom parser. No dependency, no DOM: a regex over <item>/<entry>
 * blocks is enough for headline extraction and cannot be tricked into running
 * anything. Entities are decoded so "Fed&#39;s" scores the same as "Fed's".
 */
function decodeEntities(s) {
  return decodeRaw(s)
    .replace(/<[^>]+>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Turn one untrusted title into something safe to store and render.
 *
 * Two different treatments, on purpose:
 *
 *   - Control characters and ANSI escapes are NOISE, not an attack: they are
 *     removed and the headline is kept. An ANSI escape in a terminal log
 *     rewrites what an operator sees, which is why it cannot stay.
 *   - Markup, a script scheme or an event handler is an ATTACK: the whole
 *     headline is dropped. There is no legitimate news title containing
 *     `<img` or `onerror=`.
 *
 * @param {*} raw  the title as it came out of the feed (tags still present)
 * @returns {string} a safe headline, or '' when the item must be dropped
 */
function sanitizeTitle(raw) {
  let s = String(raw === null || raw === undefined ? '' : raw);
  // ANSI first: the escape byte is what the sequence is anchored on.
  s = s.replace(/\u001b\[[0-9;]*[A-Za-z]/g, '');
  // eslint-disable-next-line no-control-regex
  s = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  for (const re of HOSTILE) if (re.test(s)) return '';
  // Defence in depth: nothing above should have let a tag through.
  s = s.replace(/<[^>]*>/g, ' ');
  s = s.replace(/\s+/g, ' ').trim();
  if (!s) return '';
  if (s.length > MAX_TITLE_CHARS) s = s.slice(0, MAX_TITLE_CHARS).trim();
  return s;
}

/** Pull the text of the first <tag> inside a block, tags stripped. */
function tagText(block, tag) {
  const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
  return m ? decodeEntities(m[1]) : '';
}

/** Pull the text of the first <tag> inside a block, tags LEFT IN PLACE. */
function tagRaw(block, tag) {
  const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
  return m ? decodeRaw(m[1]) : '';
}

/**
 * Parse an RSS 2.0 or Atom document into [{title, ts}].
 * @param {string} xml
 * @returns {Array<{title: string, ts: number|null}>}
 */
function parseRss(xml) {
  const text = String(xml || '');
  const out = [];
  const blocks = text.match(/<(item|entry)\b[\s\S]*?<\/\1>/gi) || [];
  for (const block of blocks) {
    // The RAW title (entities decoded, tags NOT yet stripped) is what the
    // sanitiser must see: stripping first would turn "<script>alert(1)</script>"
    // into the harmless-looking "alert(1)" and hide the attack.
    const title = sanitizeTitle(tagRaw(block, 'title'));
    if (!title) continue;
    const rawDate = tagText(block, 'pubDate') || tagText(block, 'published') || tagText(block, 'updated') || tagText(block, 'dc:date');
    let ts = null;
    if (rawDate) {
      const parsed = Date.parse(rawDate);
      if (Number.isFinite(parsed)) ts = parsed;
    }
    out.push({ title, ts });
    if (out.length >= MAX_ITEMS) break;
  }
  return out;
}

/** Read a dotted path out of a parsed JSON body. */
function pick(obj, dotted) {
  if (!dotted) return obj;
  let cur = obj;
  for (const part of String(dotted).split('.')) {
    if (cur === null || cur === undefined) return undefined;
    cur = cur[part];
  }
  return cur;
}

/** Normalise a feed body into an array of {title, ts}. */
function extractItems(body, feedCfg) {
  const node = pick(body, feedCfg.path);
  const arr = Array.isArray(node) ? node : Array.isArray(body) ? body : [];
  const titleField = feedCfg.titleField || 'title';
  const timeField = feedCfg.timeField || 'published';
  const out = [];
  for (const item of arr.slice(0, MAX_ITEMS)) {
    if (!item || typeof item !== 'object') continue;
    const rawTitle = item[titleField];
    if (typeof rawTitle !== 'string' || !rawTitle.trim()) continue;
    // A JSON feed is just as untrusted as an RSS one: the same sanitiser runs
    // on both paths, so a hostile title cannot slip in through the other door.
    const title = sanitizeTitle(rawTitle);
    if (!title) continue;
    const rawTs = item[timeField];
    let ts = null;
    if (typeof rawTs === 'number') ts = rawTs < 1e12 ? rawTs * 1000 : rawTs;
    else if (typeof rawTs === 'string') {
      const parsed = Date.parse(rawTs);
      if (Number.isFinite(parsed)) ts = parsed;
    }
    out.push({ title, ts });
    if (out.length >= MAX_ITEMS) break;
  }
  return out;
}

/**
 * Fold a list of scored headlines into one view.
 *
 * @param {Array<{title, ts, feed}>} items
 * @param {object} [opts] { now, blackoutBeforeMs, blackoutAfterMs, extremeThreshold }
 */
function aggregate(items, opts = {}) {
  const t = Number.isFinite(opts.now) ? opts.now : now();
  const before = Number.isFinite(opts.blackoutBeforeMs) ? opts.blackoutBeforeMs : DEFAULTS.blackoutBeforeMs;
  const after = Number.isFinite(opts.blackoutAfterMs) ? opts.blackoutAfterMs : DEFAULTS.blackoutAfterMs;
  const extreme = Number.isFinite(opts.extremeThreshold) ? opts.extremeThreshold : DEFAULTS.extremeThreshold;

  let weightedTone = 0;
  let weightSum = 0;
  let maxImpact = 0;
  let blackout = false;
  let blackoutReason = null;
  const tags = new Set();
  const scored = [];

  for (const item of items || []) {
    const s = scoreHeadline(item.title, { weight: item.weight });
    scored.push({ ...item, ...s });
    if (s.impact <= 0) continue;
    weightedTone += s.tone * s.impact;
    weightSum += s.impact;
    if (s.impact > maxImpact) maxImpact = s.impact;
    for (const tag of s.tags) tags.add(tag);

    // Blackout: a high-impact item whose timestamp is inside the window.
    if (s.tags.includes('high_impact') && Number.isFinite(item.ts)) {
      const delta = item.ts - t;
      if (delta <= before && delta >= -after) {
        blackout = true;
        blackoutReason = item.title.slice(0, 160);
      }
    }
  }

  const tone = weightSum > 0 ? clamp(weightedTone / weightSum, -1, 1) : 0;
  const confidence = clamp(weightSum / 3, 0, 1); // three solid items = full confidence
  const extremeTone = Math.abs(tone) >= extreme;

  // Per-family counts. The dashboard shows which family carried the signal, so
  // an operator can tell "the macro feed is quiet" from "the macro feed is
  // broken" without opening the logs.
  const byFeed = {};
  for (const s of scored) {
    const f = s.feed || 'unknown';
    byFeed[f] = (byFeed[f] || 0) + 1;
  }

  return {
    tone: Math.round(tone * 1000) / 1000,
    confidence: Math.round(confidence * 1000) / 1000,
    maxImpact: Math.round(maxImpact * 1000) / 1000,
    extreme: extremeTone,
    blackout,
    blackoutReason,
    tags: [...tags],
    items: scored.length,
    byFeed,
    top: scored
      .filter((s) => s.impact > 0)
      .sort((a, b) => b.impact - a.impact)
      .slice(0, 5)
      .map((s) => ({ title: s.title.slice(0, 160), tone: s.tone, impact: s.impact, tags: s.tags, feed: s.feed || null })),
  };
}

class Intel {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]   cfg.intel
   * @param {object} [opts.log]
   * @param {Function} [opts.fetchImpl] injectable fetch (tests)
   * @param {object} [opts.env]
   */
  constructor({ cfg = {}, log, fetchImpl = null, env = process.env } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.cfg.feeds = { ...DEFAULTS.feeds, ...(cfg?.feeds || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
    this.fetchImpl = fetchImpl || (typeof fetch === 'function' ? fetch : null);
    this.env = env;
    this.last = null;
    this.lastRunAt = 0;
    this.errors = 0;
    this.feedStatus = {};
    this.stats = { runs: 0, items: 0, failures: 0, blackouts: 0 };
  }

  get enabled() {
    if (!this.cfg.enabled) return false;
    // Enabled but with no feed URL is a misconfiguration, not a feature.
    return Object.values(this.cfg.feeds).some((f) => f && f.url);
  }

  /** Resolve a feed URL, allowing ${ENV_VAR} substitution for a keyed feed. */
  _resolveUrl(raw) {
    if (!raw) return '';
    return String(raw).replace(/\$\{([A-Z0-9_]+)\}/g, (_, name) => this.env[name] || '');
  }

  /**
   * Fetch one URL and normalise it to [{title, ts}].
   *
   * GDELT allows one request per 5 s per IP and answers 429 otherwise, but the
   * limit is per-IP and shared, so the same URL alternates between 200 and 429
   * within seconds. One retry after a short wait therefore converts a large
   * share of failures into successes — measured on this host: 1 of 3 raw
   * requests succeeded, and a single retry lifted that to 2 of 3.
   *
   * @returns {Promise<{items: Array, error: string|null}>}
   */
  async _fetchOne(url, feedCfg, format, attempt = 0) {
    if (!url || !this.fetchImpl) return { items: [], error: 'no-url' };
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), this.cfg.timeoutMs);
    try {
      const res = await this.fetchImpl(url, {
        method: 'GET',
        headers: {
          accept: format === 'rss' ? 'application/rss+xml, application/xml, text/xml, */*' : 'application/json',
          'user-agent': 'BlackBird/1.0 (+market-intel)',
        },
        signal: ctl.signal,
      });
      if (!res.ok) {
        // 429 is the one status worth retrying: it is transient by definition.
        if (res.status === 429 && attempt < this.cfg.retry429) {
          clearTimeout(timer);
          await new Promise((r) => setTimeout(r, this.cfg.retryDelayMs));
          return this._fetchOne(url, feedCfg, format, attempt + 1);
        }
        throw new Error(`HTTP ${res.status}`);
      }
      if (format === 'rss') {
        const xml = await res.text();
        return { items: parseRss(xml), error: null };
      }
      const body = await res.json();
      return { items: extractItems(body, feedCfg), error: null };
    } catch (e) {
      // undici reports a low-level failure as a bare "fetch failed" and hides
      // the real reason (ENOTFOUND, ECONNRESET, cert error) in `cause`. Without
      // unwrapping it the panel shows "fetch failed" and the operator has no
      // way to tell a DNS problem from a rate limit.
      const cause = e && e.cause ? (e.cause.code || e.cause.message) : null;
      const detail = e.name === 'AbortError' ? 'timeout' : cause ? `${e.message} (${cause})` : e.message;
      return { items: [], error: detail };
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Fetch a feed, falling through to its fallback URL when the primary fails.
   * Records which source actually answered so the dashboard can say so.
   */
  async _fetchFeed(name, feedCfg) {
    const primaryUrl = this._resolveUrl(feedCfg.url);
    const fallbackUrl = this._resolveUrl(feedCfg.fallbackUrl);
    const primaryFormat = feedCfg.format || 'json';
    const fallbackFormat = feedCfg.fallbackFormat || 'rss';

    let items = [];
    let error = null;
    let source = null;

    if (primaryUrl) {
      const r = await this._fetchOne(primaryUrl, feedCfg, primaryFormat);
      if (r.items.length) { items = r.items; source = 'primary'; }
      else error = r.error || 'empty';
    }

    if (!items.length && fallbackUrl) {
      const r = await this._fetchOne(fallbackUrl, feedCfg, fallbackFormat);
      if (r.items.length) { items = r.items; source = 'fallback'; error = null; }
      else error = error ? `${error} / fallback: ${r.error || 'empty'}` : (r.error || 'empty');
    }

    if (!items.length) {
      this.stats.failures++;
      this.feedStatus[name] = { ok: false, source: null, error: error || 'no-url', items: 0, at: now() };
      this.log.debug(`intel: feed ${name} failed: ${error || 'no-url'}`);
      return [];
    }

    this.feedStatus[name] = { ok: true, source, error: null, items: items.length, at: now() };
    return items
      .slice(0, this.cfg.maxItemsPerFeed)
      .map((it) => ({ ...it, feed: name, weight: feedCfg.weight }));
  }

  /** Refresh every configured feed. Never throws. */
  async refresh() {
    if (!this.enabled) return this.last;
    this.stats.runs++;
    const all = [];
    for (const [name, feedCfg] of Object.entries(this.cfg.feeds)) {
      if (!feedCfg || !feedCfg.url) continue;
      const items = await this._fetchFeed(name, feedCfg);
      all.push(...items);
    }
    this.stats.items += all.length;
    const view = aggregate(all, {
      now: now(),
      blackoutBeforeMs: this.cfg.blackoutBeforeMs,
      blackoutAfterMs: this.cfg.blackoutAfterMs,
      extremeThreshold: this.cfg.extremeThreshold,
    });
    if (view.blackout) this.stats.blackouts++;
    this.last = view;
    this.lastRunAt = now();
    return view;
  }

  /**
   * The only thing the engine is allowed to consume.
   *
   * @returns {{bias: number, confidence: number, blackout: boolean, reason: string|null}}
   *   bias in [-1, +1]; negative means "lean defensive".
   */
  bias() {
    if (!this.last) return { bias: 0, confidence: 0, blackout: false, reason: null };
    const v = this.last;
    // Only an extreme, confident tone produces a bias. Everything else is zero,
    // because a mild headline is noise and noise must not move risk.
    const bias = v.extreme && v.confidence >= 0.3 ? clamp(v.tone * v.confidence, -1, 1) : 0;
    return {
      bias: Math.round(bias * 1000) / 1000,
      confidence: v.confidence,
      blackout: v.blackout,
      reason: v.blackout ? v.blackoutReason : v.extreme ? `extreme tone ${v.tone}` : null,
    };
  }

  /**
   * Risk multiplier in [1 - maxRiskImpact, 1]. It can only ever reduce risk:
   * a positive (risk-on) bias returns exactly 1, never more.
   */
  riskMultiplier() {
    const b = this.bias();
    if (b.blackout) return 1 - this.cfg.maxRiskImpact;
    if (b.bias >= 0) return 1;
    return clamp(1 + b.bias * this.cfg.maxRiskImpact, 1 - this.cfg.maxRiskImpact, 1);
  }

  snapshot() {
    return {
      enabled: this.enabled,
      lastRunAt: this.lastRunAt,
      ...this.stats,
      feeds: this.feedStatus,
      last: this.last
        ? {
            tone: this.last.tone,
            confidence: this.last.confidence,
            extreme: this.last.extreme,
            blackout: this.last.blackout,
            blackoutReason: this.last.blackoutReason,
            tags: this.last.tags,
            items: this.last.items,
            byFeed: this.last.byFeed,
            top: this.last.top,
          }
        : null,
    };
  }

  /**
   * A short, human-readable digest for the Telegram report.
   *
   * The report is read on a phone, so this is deliberately three lines: what
   * the world looks like, whether entries are blocked, and which sources
   * answered. It never claims a source answered when it did not.
   *
   * @returns {string} markdown-ish plain text, safe to send as-is
   */
  digest() {
    if (!this.enabled) return 'هوش بازار: خاموش (هیچ منبع خبری تنظیم نشده).';
    const v = this.last;
    if (!v) return 'هوش بازار: فعال است اما هنوز خبری خوانده نشده.';

    const feeds = this.feedStatus || {};
    const names = Object.keys(feeds);
    const ok = names.filter((n) => feeds[n] && feeds[n].ok);
    const fb = ok.filter((n) => feeds[n].source === 'fallback');
    const bad = names.filter((n) => feeds[n] && !feeds[n].ok);

    const lines = [];
    const mood = v.blackout
      ? '⛔ پنجرهٔ توقف فعال — ورود جدید مسدود'
      : v.extreme
      ? `⚠️ لحن شدید (${v.tone}) — ریسک کاهش می‌یابد`
      : '✅ جوّ بازار عادی';
    lines.push(`هوش بازار: ${mood}`);
    lines.push(`خبر خوانده‌شده: ${v.items} · لحن ${v.tone} · اطمینان ${v.confidence}`);

    const fam = Object.entries(v.byFeed || {})
      .filter(([, n]) => n > 0)
      .map(([k, n]) => `${k}=${n}`)
      .join('، ');
    if (fam) lines.push(`به تفکیک خانواده: ${fam}`);

    lines.push(
      `منابع: ${ok.length}/${names.length}` +
        (fb.length ? ` (${fb.length} از پشتیبان: ${fb.join('، ')})` : '') +
        (bad.length ? ` · ناموفق: ${bad.join('، ')}` : '')
    );

    if (v.blackout && v.blackoutReason) lines.push(`رویداد: ${v.blackoutReason}`);
    return lines.join('\n');
  }
}

module.exports = {
  Intel,
  scoreHeadline,
  aggregate,
  extractItems,
  pick,
  parseRss,
  decodeEntities,
  decodeRaw,
  sanitizeTitle,
  LEXICON,
  DEFAULTS,
  MAX_TITLE_CHARS,
  MAX_ITEMS,
};
