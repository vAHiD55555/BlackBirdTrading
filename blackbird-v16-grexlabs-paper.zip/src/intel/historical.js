'use strict';
/**
 * BlackBird — historical market intel for the offline backtest.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * The live intel module (`news.js`) reads headlines over the network. The
 * backtest is deliberately no-network, so it cannot call it. Without a
 * historical source, "does market intel help?" could only ever be answered by
 * opinion.
 *
 * WHAT IT CAN HONESTLY PROVIDE
 * ----------------------------
 * The technique in `news.js` has two halves:
 *
 *   1. EVENT BLACKOUT — stand aside when a scheduled high-impact event is
 *      imminent. This half needs no news feed at all: the FOMC calendar is
 *      published years in advance, so it is knowable offline and exactly
 *      reproducible.
 *
 *   2. SENTIMENT TILT — lean against the crowd when the aggregate tone is
 *      extreme. This half needs the actual headlines of that day. We do not
 *      have them offline, and inventing a tone series would be fabricating the
 *      very input being measured.
 *
 * So this module supplies ONLY the blackout half, and `riskMultiplier()` is
 * always exactly 1. The backtest therefore measures the blackout rule alone.
 * That is stated in the report, not hidden: a result from this file is a
 * statement about the calendar gate, never about the sentiment gate.
 *
 * THE CALENDAR
 * ------------
 * FOMC meeting dates are hardcoded below from the published Federal Reserve
 * calendar. They are DATA, not logic: the Fed publishes the next year's
 * schedule in advance, and this list must be extended once a year. A date that
 * is wrong here silently weakens the test, so the list is kept short, explicit
 * and easy to audit.
 *
 * Nothing here throws and nothing here touches the network.
 */

/**
 * FOMC decision days (the second day of each two-day meeting, when the
 * statement and the press conference happen). Times are 18:00 UTC, which is
 * 14:00 ET during EDT and 13:00 ET during EST — close enough for a 30-minute
 * blackout window, and stated here rather than assumed silently.
 */
const FOMC_2025 = [
  '2025-01-29', '2025-03-19', '2025-05-07', '2025-06-18',
  '2025-07-30', '2025-09-17', '2025-10-29', '2025-12-10',
];
const FOMC_2026 = [
  '2026-01-28', '2026-03-18', '2026-04-29', '2026-06-17',
  '2026-07-29', '2026-09-16', '2026-10-28', '2026-12-09',
];

/** US CPI release days are not published as a fixed calendar, so they are not
 *  included. A guessed CPI date would be worse than no CPI date. */

const DEFAULTS = {
  blackoutBeforeMs: 30 * 60 * 1000,
  blackoutAfterMs: 15 * 60 * 1000,
};

/** Turn 'YYYY-MM-DD' into the epoch ms of 18:00 UTC that day. */
function dayToMs(day) {
  const ms = Date.parse(`${day}T18:00:00Z`);
  return Number.isFinite(ms) ? ms : null;
}

/** Build the event list from the hardcoded calendar. */
function buildEvents(days = [...FOMC_2025, ...FOMC_2026]) {
  const out = [];
  for (const day of days) {
    const ts = dayToMs(day);
    if (ts === null) continue;
    out.push({ ts, label: `FOMC ${day}` });
  }
  out.sort((a, b) => a.ts - b.ts);
  return out;
}

class HistoricalIntel {
  /**
   * @param {object} [opts]
   * @param {Array<{ts:number,label:string}>} [opts.events]
   * @param {number} [opts.blackoutBeforeMs]
   * @param {number} [opts.blackoutAfterMs]
   */
  constructor({ events, blackoutBeforeMs, blackoutAfterMs } = {}) {
    this.events = Array.isArray(events) ? events.slice().sort((a, b) => a.ts - b.ts) : buildEvents();
    this.before = Number.isFinite(blackoutBeforeMs) ? blackoutBeforeMs : DEFAULTS.blackoutBeforeMs;
    this.after = Number.isFinite(blackoutAfterMs) ? blackoutAfterMs : DEFAULTS.blackoutAfterMs;
    this.stats = { calls: 0, blackouts: 0 };
  }

  /**
   * The intel view at one instant. Pure: same ts, same answer, always.
   *
   * @param {number} ts epoch ms
   * @returns {{riskMultiplier: number, blackout: boolean, reason: string|null}}
   */
  at(ts) {
    this.stats.calls++;
    const t = Number(ts);
    if (!Number.isFinite(t)) return { riskMultiplier: 1, blackout: false, reason: null };

    // Binary search would be premature: the list is ~16 entries and this is
    // called once per rebalance, not once per tick.
    for (const ev of this.events) {
      const delta = ev.ts - t;
      if (delta > this.before) break; // events are sorted; nothing later can match
      if (delta <= this.before && delta >= -this.after) {
        this.stats.blackouts++;
        return { riskMultiplier: 1, blackout: true, reason: ev.label };
      }
    }
    return { riskMultiplier: 1, blackout: false, reason: null };
  }

  /** How many events fall inside a window — used by the report. */
  countIn(fromTs, toTs) {
    return this.events.filter((e) => e.ts >= fromTs && e.ts <= toTs).length;
  }

  snapshot() {
    return { events: this.events.length, ...this.stats, before: this.before, after: this.after };
  }
}

module.exports = {
  HistoricalIntel,
  buildEvents,
  dayToMs,
  FOMC_2025,
  FOMC_2026,
  DEFAULTS,
};
