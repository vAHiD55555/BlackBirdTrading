'use strict';
/**
 * BlackBird — offline candle CSV reader.
 *
 * WHY A PARSER AND NOT `split(',')`
 * --------------------------------
 * A backtest is only as honest as its input. The dangerous failure is not a
 * crash — it is a file that parses "successfully" while silently dropping half
 * its rows, or reordering them, or reading seconds as milliseconds and putting
 * every candle in 1970. The strategy then runs on garbage and reports a
 * beautiful equity curve.
 *
 * So this module never guesses quietly. It accepts the common shapes, and
 * everything it had to repair or discard is counted and reported in
 * `report.problems`. A caller that ignores the report is choosing to be lied to.
 *
 * ACCEPTED SHAPES
 * ---------------
 *   separator   ,  ;  tab  (auto-detected from the header/first line)
 *   header      present (named, any order, aliases) or absent (t,o,h,l,c,v)
 *   time        epoch ms | epoch seconds | ISO-8601 | "YYYY-MM-DD HH:mm:ss"
 *   numbers     plain, quoted, with thousands separators, scientific notation
 *   blank lines, CRLF, BOM, trailing separator — all tolerated
 *
 * OUTPUT
 * ------
 *   { bars, report }
 *   bars   [{ t, o, h, l, c, v }]  sorted ascending, duplicates removed
 *   report { ok, rows, accepted, rejected, duplicates, outOfOrder, gaps,
 *            problems[], firstAt, lastAt, intervalMs, symbols? }
 */

const fs = require('node:fs');

const COLUMN_ALIASES = {
  t: ['t', 'time', 'timestamp', 'ts', 'date', 'datetime', 'open_time', 'opentime', 'open time', 'open time utc'],
  o: ['o', 'open'],
  h: ['h', 'high'],
  l: ['l', 'low'],
  c: ['c', 'close'],
  v: ['v', 'volume', 'vol', 'basevolume', 'base_volume', 'base volume', 'base asset volume'],
};

const DEFAULT_ORDER = ['t', 'o', 'h', 'l', 'c', 'v'];

/** Strip a BOM, quotes and thousands separators; return a trimmed string. */
function cleanCell(raw) {
  let s = String(raw == null ? '' : raw).trim();
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1);
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    s = s.slice(1, -1).trim();
  }
  return s;
}

/** Parse a numeric cell, tolerating "1,234.5" and "1.2e-3". */
function parseNumber(raw) {
  const s = cleanCell(raw).replace(/,/g, '').replace(/\s+/g, '');
  if (s === '' || s === '-' || s === 'null' || s === 'NaN') return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/**
 * Parse a timestamp cell into epoch milliseconds.
 *
 * The ambiguity that matters: a bare integer could be seconds or milliseconds.
 * The split is at 1e11 — 1973 in ms, or year 5138 in seconds. No real candle
 * file sits near that boundary, so the rule is safe and, crucially, it is
 * stated here rather than left to chance.
 *
 * @param {string} raw
 * @returns {number|null} epoch ms, or null when unparseable
 */
function parseTime(raw) {
  const s = cleanCell(raw);
  if (!s) return null;

  // Pure integer / decimal: epoch seconds or milliseconds.
  if (/^-?\d+(\.\d+)?$/.test(s)) {
    const n = Number(s);
    if (!Number.isFinite(n) || n <= 0) return null;
    if (n >= 1e14) return Math.round(n / 1000); // microseconds
    if (n >= 1e11) return Math.round(n);        // milliseconds
    if (n >= 1e8) return Math.round(n * 1000);  // seconds
    return null;                                 // too small to be a date
  }

  // ISO-8601 or "YYYY-MM-DD HH:mm:ss" (space instead of T).
  // Treat timezone-less exchange timestamps as UTC, never local device time.
  const iso = s.includes('T') ? s : s.replace(' ', 'T');
  const normalizedIso = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(iso) ? iso : `${iso}Z`;
  const ms = Date.parse(normalizedIso);
  if (Number.isFinite(ms)) return ms;

  // "YYYY-MM-DD" alone.
  const d = Date.parse(`${s}T00:00:00Z`);
  return Number.isFinite(d) ? d : null;
}

/** Pick the separator that yields the most columns on the first data line. */
function detectSeparator(line) {
  const candidates = [',', ';', '\t', '|'];
  let best = ',';
  let bestCount = 0;
  for (const sep of candidates) {
    const n = line.split(sep).length;
    if (n > bestCount) { bestCount = n; best = sep; }
  }
  return bestCount >= 2 ? best : ',';
}

/** Map a header row to canonical column indices. Returns null if unusable. */
function mapHeader(cells) {
  const lower = cells.map((c) => cleanCell(c).toLowerCase());
  const map = {};
  for (const [canon, aliases] of Object.entries(COLUMN_ALIASES)) {
    const idx = lower.findIndex((h) => aliases.includes(h));
    if (idx >= 0) map[canon] = idx;
  }
  // A header is only a header if it names at least time + close.
  if (map.t === undefined || map.c === undefined) return null;
  return map;
}

/**
 * Read a candle CSV from disk.
 *
 * @param {string} file
 * @param {object} [opts]
 * @param {string} [opts.symbol]   label for the report
 * @param {number} [opts.from]     epoch ms lower bound (inclusive)
 * @param {number} [opts.to]       epoch ms upper bound (inclusive)
 * @returns {{bars: Array, report: object}}
 */
function readCsvFile(file, opts = {}) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return {
      bars: [],
      report: {
        ok: false, file, symbol: opts.symbol || null, rows: 0, accepted: 0, rejected: 0,
        duplicates: 0, outOfOrder: 0, gaps: 0, intervalMs: null, firstAt: null, lastAt: null,
        problems: [{ code: 'unreadable', detail: e.message }],
      },
    };
  }
  return parseCsv(text, { ...opts, file });
}

/**
 * Parse candle CSV text.
 *
 * @param {string} text
 * @param {object} [opts]
 * @returns {{bars: Array, report: object}}
 */
function parseCsv(text, opts = {}) {
  const problems = [];
  const report = {
    ok: true,
    file: opts.file || null,
    symbol: opts.symbol || null,
    rows: 0,
    accepted: 0,
    rejected: 0,
    duplicates: 0,
    outOfOrder: 0,
    gaps: 0,
    intervalMs: null,
    firstAt: null,
    lastAt: null,
    problems,
  };

  if (typeof text !== 'string' || !text.trim()) {
    report.ok = false;
    problems.push({ code: 'empty', detail: 'file is empty' });
    return { bars: [], report };
  }

  const rawLines = text.split(/\r?\n/);
  const lines = rawLines.filter((l) => l.trim() !== '');
  if (!lines.length) {
    report.ok = false;
    problems.push({ code: 'empty', detail: 'no non-blank lines' });
    return { bars: [], report };
  }

  const sep = detectSeparator(lines[0]);
  const firstCells = lines[0].split(sep).map(cleanCell);

  // Header detection: a header names columns; a data row starts with a number.
  let columns = null;
  let startLine = 0;
  const headerMap = mapHeader(firstCells);
  if (headerMap) {
    columns = headerMap;
    startLine = 1;
  } else if (parseTime(firstCells[0]) === null) {
    // First cell is neither a timestamp nor a recognised header name.
    report.ok = false;
    problems.push({
      code: 'bad_header',
      detail: `first line is neither a header nor a data row: "${lines[0].slice(0, 80)}"`,
    });
    return { bars: [], report };
  } else {
    // No header: assume the canonical order, but only if the width fits.
    if (firstCells.length < 5) {
      report.ok = false;
      problems.push({
        code: 'too_few_columns',
        detail: `expected at least 5 columns (t,o,h,l,c), got ${firstCells.length}`,
      });
      return { bars: [], report };
    }
    columns = {};
    DEFAULT_ORDER.forEach((k, i) => { columns[k] = i; });
  }

  const bars = [];
  const seen = new Set();
  let prevT = null;
  let outOfOrder = 0;
  let duplicates = 0;
  let rejected = 0;
  const rejectReasons = new Map();

  for (let i = startLine; i < lines.length; i++) {
    report.rows++;
    const cells = lines[i].split(sep);
    const t = parseTime(cells[columns.t]);
    const o = parseNumber(cells[columns.o]);
    const h = parseNumber(cells[columns.h]);
    const l = parseNumber(cells[columns.l]);
    const c = parseNumber(cells[columns.c]);
    const v = columns.v !== undefined ? parseNumber(cells[columns.v]) : 0;

    let reason = null;
    if (t === null) reason = 'bad_time';
    else if (o === null || h === null || l === null || c === null) reason = 'bad_price';
    else if (!(o > 0) || !(h > 0) || !(l > 0) || !(c > 0)) reason = 'non_positive_price';
    else if (h < l) reason = 'high_below_low';
    else if (c > h * 1.0000001 || c < l * 0.9999999) reason = 'close_outside_range';

    if (reason) {
      rejected++;
      rejectReasons.set(reason, (rejectReasons.get(reason) || 0) + 1);
      continue;
    }

    // Dedupe by a set, not by `prevT`: the twin of a duplicate is often NOT the
    // adjacent row in a file that is also out of order, and comparing only with
    // the previous timestamp silently keeps both copies.
    if (seen.has(t)) { duplicates++; continue; }
    if (prevT !== null && t < prevT) outOfOrder++;

    seen.add(t);
    bars.push({ t, o, h, l, c, v: Number.isFinite(v) ? v : 0 });
    prevT = t;
  }

  report.rejected = rejected;
  report.duplicates = duplicates;
  report.outOfOrder = outOfOrder;

  if (rejected) {
    problems.push({
      code: 'rejected_rows',
      detail: `${rejected} row(s) discarded: ${[...rejectReasons.entries()].map(([k, n]) => `${k}×${n}`).join(', ')}`,
    });
  }
  if (duplicates) {
    problems.push({ code: 'duplicates', detail: `${duplicates} duplicate timestamp(s) dropped (first kept)` });
  }
  if (outOfOrder) {
    problems.push({ code: 'out_of_order', detail: `${outOfOrder} row(s) arrived out of order; series sorted ascending` });
  }

  if (!bars.length) {
    report.ok = false;
    problems.push({ code: 'no_valid_rows', detail: 'no row survived validation' });
    return { bars: [], report };
  }

  // Sort ascending. A stable sort keeps the first of any equal timestamps.
  bars.sort((a, b) => a.t - b.t);

  // Time-range filter.
  let out = bars;
  if (Number.isFinite(opts.from) || Number.isFinite(opts.to)) {
    const from = Number.isFinite(opts.from) ? opts.from : -Infinity;
    const to = Number.isFinite(opts.to) ? opts.to : Infinity;
    out = bars.filter((b) => b.t >= from && b.t <= to);
    if (!out.length) {
      report.ok = false;
      problems.push({ code: 'empty_range', detail: 'no candle falls inside the requested range' });
      return { bars: [], report };
    }
  }

  // Interval + gap detection. The median diff is the nominal interval; a diff
  // of more than 1.5× that is a hole in the series.
  const diffs = [];
  for (let i = 1; i < out.length; i++) diffs.push(out[i].t - out[i - 1].t);
  if (diffs.length) {
    const sorted = diffs.slice().sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    report.intervalMs = median;
    let gaps = 0;
    let missing = 0;
    for (const d of diffs) {
      if (median > 0 && d > median * 1.5) {
        gaps++;
        missing += Math.max(0, Math.round(d / median) - 1);
      }
    }
    report.gaps = gaps;
    if (gaps) {
      problems.push({
        code: 'gaps',
        detail: `${gaps} gap(s) in the series, ~${missing} candle(s) missing (nominal interval ${median}ms)`,
      });
    }
  }

  report.accepted = out.length;
  report.firstAt = out[0].t;
  report.lastAt = out[out.length - 1].t;
  report.ok = report.accepted > 0;

  return { bars: out, report };
}

/** Human-readable one-block summary of a parse report. */
function formatReport(report) {
  const lines = [];
  const tag = report.ok ? 'OK' : 'FAILED';
  lines.push(`[${tag}] ${report.symbol || report.file || 'csv'}`);
  lines.push(`  rows=${report.rows} accepted=${report.accepted} rejected=${report.rejected} ` +
    `duplicates=${report.duplicates} outOfOrder=${report.outOfOrder} gaps=${report.gaps}`);
  if (report.firstAt) {
    lines.push(`  range ${new Date(report.firstAt).toISOString()} → ${new Date(report.lastAt).toISOString()}` +
      `  interval=${report.intervalMs}ms`);
  }
  for (const p of report.problems) lines.push(`  ! ${p.code}: ${p.detail}`);
  return lines.join('\n');
}

module.exports = {
  readCsvFile,
  parseCsv,
  parseTime,
  parseNumber,
  detectSeparator,
  mapHeader,
  formatReport,
  COLUMN_ALIASES,
};
