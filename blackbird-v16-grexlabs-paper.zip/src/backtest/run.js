#!/usr/bin/env node
'use strict';
/**
 * BlackBird — offline backtest CLI.
 *
 *   node src/backtest/run.js --file data/candles/BTCUSDT_1h.csv --symbol BTCUSDT
 *   node src/backtest/run.js --dir data/candles --timeframe 1h
 *   node src/backtest/run.js --file x.csv --from 2025-01-01 --to 2025-06-30
 *
 * No network. No keys. No exchange. The only input is CSV on disk.
 *
 * Every run is recorded in the trial registry (K), because a backtest is a
 * test: running twenty of them and reporting the best one is exactly the
 * selection bias the Deflated Sharpe Ratio exists to correct.
 */

const fs = require('node:fs');
const path = require('node:path');
const { loadConfig } = require('../config');
const { readCsvFile, formatReport } = require('./csv');
const { runBacktest } = require('./engine');
const { TrialRegistry } = require('../jev/trials');

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { out._.push(a); continue; }
    const key = a.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) { out[key] = true; continue; }
    out[key] = next;
    i++;
  }
  return out;
}

/** Accept "2025-01-01" or an epoch number. */
function toMs(v) {
  if (v === undefined || v === true) return undefined;
  if (/^\d+$/.test(String(v))) {
    const n = Number(v);
    return n >= 1e11 ? n : n * 1000;
  }
  const ms = Date.parse(String(v).includes('T') ? v : `${v}T00:00:00Z`);
  return Number.isFinite(ms) ? ms : undefined;
}

function fmt(n, d = 2) {
  if (n === null || n === undefined || !Number.isFinite(Number(n))) return '—';
  return Number(n).toFixed(d);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const cfg = loadConfig();

  const from = toMs(args.from);
  const to = toMs(args.to);
  const timeframe = args.timeframe || cfg.data?.timeframe || '1h';

  // Collect input files: one --file, or every .csv in --dir.
  const inputs = [];
  if (args.file) {
    inputs.push({ file: path.resolve(String(args.file)), symbol: args.symbol || null });
  } else if (args.dir) {
    const dir = path.resolve(String(args.dir));
    if (!fs.existsSync(dir)) {
      console.error(`directory not found: ${dir}`);
      process.exit(2);
    }
    for (const f of fs.readdirSync(dir).sort()) {
      if (!/\.csv$/i.test(f)) continue;
      // Symbol from the filename: BTCUSDT_1h.csv -> BTCUSDT
      const symbol = f.replace(/\.csv$/i, '').split(/[_.]/)[0].toUpperCase();
      inputs.push({ file: path.join(dir, f), symbol });
    }
  } else {
    console.error(
      'usage: node src/backtest/run.js --file <candles.csv> [--symbol BTCUSDT] [--from DATE] [--to DATE]\n' +
      '       node src/backtest/run.js --dir <candles-dir> [--timeframe 1h]'
    );
    process.exit(2);
  }

  if (!inputs.length) {
    console.error('no CSV files found');
    process.exit(2);
  }

  console.log('');
  console.log('  BlackBird — offline backtest');
  console.log('  ' + '─'.repeat(70));
  console.log(`  timeframe=${timeframe}  files=${inputs.length}  network=OFF`);
  console.log('');

  const barsBySymbol = {};
  const reports = [];
  let anyProblem = false;

  for (const inp of inputs) {
    const { bars, report } = readCsvFile(inp.file, { symbol: inp.symbol, from, to });
    reports.push(report);
    console.log(formatReport(report));
    console.log('');
    if (!report.ok) { anyProblem = true; continue; }
    if (report.problems.length) anyProblem = true;
    const sym = inp.symbol || path.basename(inp.file, '.csv').toUpperCase();
    barsBySymbol[sym] = bars;
  }

  if (!Object.keys(barsBySymbol).length) {
    console.error('  no usable series — aborting');
    process.exit(1);
  }

  // The equity curve goes where the live engine keeps it, so the lawyer's DSR
  // clause reads a backtest exactly like a live run.
  const dataDir = cfg.runtime?.dataDir || path.join(cfg.root || process.cwd(), 'data');
  const equityFile = path.join(dataDir, 'equity.jsonl');

  const result = runBacktest({
    cfg,
    barsBySymbol,
    equityFile,
    rotatorOverrides: args['no-core'] ? { corePct: 0 } : undefined,
  });

  if (!result.ok) {
    console.error(`  backtest failed: ${result.error}`);
    process.exit(1);
  }

  const s = result.summary;
  console.log('  ' + '─'.repeat(70));
  console.log('  نتیجه');
  console.log('  ' + '─'.repeat(70));
  console.log(`  موجودی اولیه      ${fmt(s.startEquity)}`);
  console.log(`  موجودی نهایی      ${fmt(s.finalEquity)}`);
  console.log(`  بازده             ${fmt(s.returnPct)}%`);
  console.log(`  حداکثر افت        ${fmt(s.maxDrawdownPct)}%`);
  console.log(`  معاملات           ${s.trades}  (برد ${s.wins} / باخت ${s.losses})`);
  console.log(`  نرخ برد           ${s.hitRate === null ? '—' : fmt(s.hitRate) + '%'}`);
  console.log(`  ضریب سود          ${s.profitFactor === null ? '—' : fmt(s.profitFactor)}`);
  console.log(`  کارمزد پرداختی    ${fmt(s.feesPaid)}`);
  console.log(`  شارپ (هر دوره)    ${s.sharpePerPeriod === null ? '—' : fmt(s.sharpePerPeriod, 4)}`);
  console.log(`  کندل‌ها            ${s.bars}  (${s.returns} بازده)`);
  console.log(`  منحنی سرمایه      ${s.equityFile || '—'}`);
  console.log('');

  // Record the run as a trial. A backtest is a test; K must count it.
  let trial = null;
  try {
    const reg = new TrialRegistry({ file: cfg.trials?.file });
    trial = reg.record({
      kind: 'backtest',
      field: 'backtest',
      from: null,
      to: {
        files: inputs.map((i) => path.basename(i.file)),
        symbols: result.symbols,
        timeframe,
        from: from ? new Date(from).toISOString() : null,
        to: to ? new Date(to).toISOString() : null,
        bars: s.bars,
      },
      note: `offline backtest: return ${fmt(s.returnPct)}%, dd ${fmt(s.maxDrawdownPct)}%, trades ${s.trades}`,
      source: 'cli',
      metrics: {
        sharpe: s.sharpePerPeriod,
        n: s.returns,
        returnPct: s.returnPct,
        maxDrawdownPct: s.maxDrawdownPct,
        trades: s.trades,
      },
    });
    if (trial) {
      console.log(`  آزمون ثبت شد: K=${trial.k}  (${cfg.trials?.file})`);
    }
  } catch (e) {
    console.log(`  ⚠ ثبت آزمون ناموفق: ${e.message}`);
  }
  console.log('');

  if (anyProblem) {
    console.log('  ⚠ هشدار: داده‌ی ورودی مشکل داشت — جزئیات بالا. نتیجه را با احتیاط بخوانید.');
    console.log('');
  }

  // Machine-readable output for scripting.
  if (args.json) {
    const out = { summary: s, symbols: result.symbols, reports, trial: trial ? { k: trial.k } : null };
    const jsonPath = path.resolve(String(args.json));
    fs.mkdirSync(path.dirname(jsonPath), { recursive: true });
    fs.writeFileSync(jsonPath, JSON.stringify(out, null, 2), 'utf8');
    console.log(`  JSON: ${jsonPath}`);
  }

  // Publish the summary for the web panel. Best-effort: a read-only data dir
  // must not fail a backtest that already produced its numbers.
  try {
    const { writeLatest } = require('./latest');
    const written = writeLatest(dataDir, {
      ts: Date.now(),
      symbols: result.symbols,
      timeframe,
      files: inputs.map((i) => path.basename(i.file)),
      summary: s,
      trialK: trial ? trial.k : null,
      warnings: reports.flatMap((r) => r.problems.map((p) => `${r.symbol || r.file}: ${p.code}`)),
      fingerprint: cfg.runtime?.configFingerprint || null,
    });
    if (written) console.log(`  پنل: ${written}`);
  } catch { /* panel is optional */ }
  console.log('');

  process.exit(0);
}

if (require.main === module) main();

module.exports = { parseArgs, toMs };
