'use strict';
/**
 * BlackBird — last backtest summary, for the panel.
 *
 * The CLI writes one small JSON file after each run; the panel reads it. No
 * shared memory between the two processes, and nothing to keep in sync.
 *
 * The read is defensive on purpose: the status endpoint must answer even if the
 * file is missing, half-written, or corrupt. A dashboard that 500s because a
 * report file was truncated is worse than a dashboard that says "none yet".
 */

const fs = require('node:fs');
const path = require('node:path');

const MAX_AGE_MS = 30 * 24 * 3600 * 1000;

/**
 * Synthetic filesystems where `mkdirSync(..., {recursive:true})` HANGS on Linux
 * instead of throwing — /proc never reports the directory as created, so the
 * call blocks forever. A bad dataDir would freeze the process with no error.
 * Same guard as src/jev/trials.js and src/core/equity-curve.js.
 */
const FORBIDDEN_ROOTS = ['/proc', '/sys', '/dev'];

function ensureDir(dir) {
  const abs = path.resolve(dir);
  for (const root of FORBIDDEN_ROOTS) {
    if (abs === root || abs.startsWith(`${root}/`)) {
      throw new Error(`refusing to write under ${root} (synthetic filesystem)`);
    }
  }
  fs.mkdirSync(abs, { recursive: true });
}

/** Where the CLI writes and the panel reads. */
function latestPath(dataDir) {
  return path.join(dataDir || path.join(process.cwd(), 'data'), 'backtest', 'latest.json');
}

/** Write the result of a run. Returns the path, or null if it could not write. */
function writeLatest(dataDir, payload) {
  const file = latestPath(dataDir);
  try {
    ensureDir(path.dirname(file));
    fs.writeFileSync(file, JSON.stringify(payload, null, 2), 'utf8');
    return file;
  } catch {
    return null;
  }
}

/**
 * Read the last summary for the panel.
 * @returns {object|null} null when there is nothing usable
 */
function readLatest(dataDir) {
  const file = latestPath(dataDir);
  try {
    if (!fs.existsSync(file)) return null;
    const st = fs.statSync(file);
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw);
    if (!data || !data.summary) return null;
    return {
      ts: data.ts || st.mtimeMs,
      ageMs: Math.max(0, Date.now() - (data.ts || st.mtimeMs)),
      stale: Date.now() - (data.ts || st.mtimeMs) > MAX_AGE_MS,
      symbols: data.symbols || [],
      timeframe: data.timeframe || null,
      files: data.files || [],
      summary: data.summary,
      trialK: data.trialK ?? null,
      warnings: data.warnings || [],
      fingerprint: data.fingerprint || null,
    };
  } catch {
    return null;
  }
}

module.exports = { latestPath, writeLatest, readLatest, MAX_AGE_MS };
