'use strict';
/**
 * BlackBird — offline backtest engine.
 *
 * WHAT THIS IS
 * ------------
 * The same Rotator, the same Portfolio, the same risk accounting and the same
 * fee model that run live — driven by a CSV instead of an exchange. Nothing is
 * reimplemented: the strategy object is the production one, so a backtest that
 * looks good is a statement about the code that will actually trade.
 *
 * WHAT IT IS NOT
 * --------------
 * It is not a second strategy implementation. If the backtest and the live
 * engine ever disagree, that is a bug in one of them, not a "backtest mode".
 *
 * NO NETWORK
 * ----------
 * There is no fetch, no socket, no exchange adapter in this file. The only
 * input is `bars`. That is enforced by the tests, which run with the network
 * modules stubbed out.
 *
 * FILL MODEL
 * ----------
 * A market order fills at the bar's close, adjusted by the configured slippage
 * and charged the taker fee. This is deliberately pessimistic-but-simple:
 *
 *   - it does NOT assume you get the bar's open (you decided on the close)
 *   - it does NOT assume zero impact
 *   - it does NOT fill limit orders intrabar (there is no intrabar data)
 *
 * A backtest that fills at the open of the next bar would look better and be
 * less honest, because the signal is computed from the close.
 */

const path = require('node:path');
const { Portfolio, Position } = require('../exec/portfolio');
const { Rotator } = require('../strategy/rotator');
const { Ring } = require('../core/util');
const { EquityCurve } = require('../core/equity-curve');

const DEFAULTS = {
  startEquity: 5000,
  // Slippage applied to every fill, in basis points, on top of the taker fee.
  slippageBps: 1.5,
  // How many bars of history the feed exposes at each step. The rotator asks
  // for `maxLook + 60`; a smaller window makes `ready()` false forever.
  windowBars: 2000,
};

/** A feed that looks like MarketFeed to the rotator, backed by a bar array. */
class CsvFeed {
  constructor(symbol, bars, cfg) {
    this.symbol = symbol;
    this.all = bars;
    this.cfg = cfg;
    this.cursor = 0; // index of the last CLOSED bar
    this.bars = new Ring(Math.max(400, bars.length + 10));
    this.quoteSource = 'csv';
    this.gapCount = 0;
    this.isStale = false;
    this.ticker = null;
    this.depth = null;
  }

  /** Advance to bar index i: everything up to and including i is "closed". */
  seek(i) {
    this.cursor = i;
    this.bars = new Ring(Math.max(400, this.all.length + 10));
    const from = Math.max(0, i - (this.cfg?.windowBars || DEFAULTS.windowBars) + 1);
    for (let k = from; k <= i; k++) this.bars.push(this.all[k]);
    const b = this.all[i];
    if (b) {
      this.ticker = { symbol: this.symbol, bid: b.c, ask: b.c, last: b.c, ts: b.t };
      this.depth = { bids: [[b.c, 1e6]], asks: [[b.c, 1e6]], ts: b.t };
    }
  }

  book() {
    const b = this.all[this.cursor];
    if (!b) return null;
    return {
      bid: b.c,
      ask: b.c,
      mid: b.c,
      spreadBps: 0,
      bidNotional: 1e6,
      askNotional: 1e6,
      depthUsd: 2e6,
      quoteAgeMs: 0,
      depthTs: b.t,
    };
  }

  snapshot() { return null; }
}

/** A hub over CsvFeeds, with the two methods the rotator uses. */
class CsvHub {
  constructor(feeds) {
    this.feeds = feeds;
  }
  get(symbol) { return this.feeds.get(symbol); }
  all() { return [...this.feeds.values()]; }
  seek(i) { for (const f of this.feeds.values()) f.seek(i); }
}

/**
 * A broker that fills at the current bar's close.
 *
 * Mirrors PaperBroker's return shape exactly, so the rotator cannot tell the
 * difference — which is the point.
 */
class CsvBroker {
  constructor({ cfg, hub, log }) {
    this.cfg = cfg;
    this.hub = hub;
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.fills = [];
    this.openOrders = new Map();
    this.mode = 'backtest';
  }

  submit(order) {
    const feed = this.hub.get(order.symbol);
    const book = feed?.book();
    if (!book) return { status: 'rejected', reason: 'no_book' };

    const slipBps = Number(this.cfg?.backtest?.slippageBps ?? DEFAULTS.slippageBps);
    const dir = order.side === 'buy' ? 1 : -1;
    const price = book.mid * (1 + dir * (slipBps / 10000));
    const qty = Number(order.qty);
    if (!(qty > 0) || !(price > 0)) return { status: 'rejected', reason: 'bad_order' };

    const notional = price * qty;
    const fee = (notional * Number(this.cfg?.fees?.takerBps ?? 10)) / 10000;
    const fill = {
      status: 'filled',
      orderId: order.orderId || `bt_${this.fills.length + 1}`,
      symbol: order.symbol,
      side: order.side,
      qty,
      price,
      notional,
      fee,
      feeKind: 'taker',
      slippageBps: slipBps,
      tag: order.tag,
      ts: feed.all[feed.cursor]?.t || 0,
    };
    this.fills.push(fill);
    return fill;
  }

  onTick() { return []; }
  expire() { return []; }
  cancel() { return false; }
  cancelAll() {}
  stats() { return { mode: 'backtest', openOrders: 0, fills: this.fills.length }; }
}

/**
 * Risk accounting for replay.
 *
 * BUG THIS FIXES
 * --------------
 * This used to be a stub: equity, peak, settle, and nothing else. It had no
 * `check()` and no `halted`, so the rotator's own gate (`if (typeof
 * this.risk.check === 'function')`) silently did nothing and `rebalance()`
 * never saw a halt. A 12-month replay therefore reported a 15.64% drawdown
 * while the configured kill switch was 15% — the backtest was measuring a bot
 * that does not exist, and it looked worse than the real one would.
 *
 * The limits below are the SAME ones src/risk/risk.js enforces live:
 *   - kill switch on drawdown from peak (hard halt, no auto-resume)
 *   - daily loss cap (soft halt, lifts at the next UTC day)
 *   - consecutive-loss cooldown
 *   - per-symbol / net exposure caps in check()
 *
 * The clock is the bar's own timestamp, not wall-clock: a replay must see the
 * day boundaries the market saw.
 */
class BacktestRisk {
  constructor(startEquity, cfg = {}, clock = () => Date.now()) {
    this.cfg = cfg || {};
    this.clock = clock;
    this.state = {
      equity: startEquity,
      dayStartEquity: startEquity,
      counters: { trades: 0, wins: 0, losses: 0, lossesStreak: 0, tradesToday: 0 },
      cooldowns: {},
    };
    this.peakEquity = startEquity;
    this.halted = false;
    this.haltKind = null;
    this.haltReason = null;
    this.resumeAt = 0;
    this._day = Math.floor(clock() / 86400000);
  }

  get r() {
    return this.cfg.risk || {};
  }

  drawdownPct() {
    return this.peakEquity > 0 ? ((this.peakEquity - this.state.equity) / this.peakEquity) * 100 : 0;
  }

  /**
   * Drawdown on marked equity. Mirrors RiskManager.markToMarket so the replay
   * and the live engine agree on when the kill switch fires.
   */
  markToMarket(equityMtm) {
    if (this.halted) return false;
    const eq = Number(equityMtm);
    if (!Number.isFinite(eq) || eq <= 0) return false;
    if (eq > this.peakEquity) this.peakEquity = eq;
    const dd = this.peakEquity > 0 ? ((this.peakEquity - eq) / this.peakEquity) * 100 : 0;
    const limit = Number(this.r.killSwitchDrawdownPct) * 100;
    if (Number.isFinite(limit) && dd >= limit) {
      // `kind: 'drawdown'` is what makes the halt resumable. Without it the
      // halt defaulted to 'hard' and evaluateResume() refused to look at it,
      // so the replay locked itself out for the rest of the year.
      const coolMs = Number(this.r.drawdownCooldownMs) || 24 * 3600 * 1000;
      this.halt(`drawdown(mtm) ${dd.toFixed(2)}% >= ${limit.toFixed(2)}%`, {
        kind: 'drawdown',
        resumeAt: this.clock() + coolMs,
      });
      return true;
    }
    return false;
  }

  dailyPnlPct() {
    const start = Number(this.state.dayStartEquity);
    if (!Number.isFinite(start) || start <= 0) return 0;
    return ((this.state.equity - start) / start) * 100;
  }

  halt(reason, opts = {}) {
    if (this.halted) return;
    this.halted = true;
    this.haltReason = reason;
    this.haltKind = opts.kind || 'hard';
    this.resumeAt = opts.resumeAt || 0;
  }

  resume() {
    this.halted = false;
    this.haltReason = null;
    this.haltKind = null;
    this.resumeAt = 0;
  }

  /**
   * Charter §8 resume contract, mirrored from RiskManager.evaluateResume:
   * a cooling period, then a health check, then a flat-or-recovered book.
   * Never a bare timer.
   */
  evaluateResume(ctx = {}) {
    if (!this.halted || this.haltKind !== 'drawdown') return false;
    if (!this.resumeAt || this.clock() < this.resumeAt) return false;
    if (ctx.dataOk === false) return false;
    const open = Number(ctx.openPositions) || 0;
    const resumeDd = Number(this.r.resumeDrawdownPct);
    const eq = Number(ctx.equityMtm);
    const dd = Number.isFinite(eq) && this.peakEquity > 0
      ? ((this.peakEquity - eq) / this.peakEquity) * 100
      : this.drawdownPct();
    const recovered = Number.isFinite(resumeDd) && dd <= resumeDd * 100;
    if (open > 0 && !recovered) return false;
    this.resume();
    this.resumeScale = Number(this.r.resumeScale) || 0.5;
    return true;
  }

  /** A daily pause lifts itself at the next UTC day; a hard halt does not. */
  maybeAutoResume(ts = this.clock()) {
    if (!this.halted || this.haltKind === 'hard') return false;
    if (!this.resumeAt || ts < this.resumeAt) return false;
    // A drawdown halt needs the full re-evaluation, not just the clock.
    if (this.haltKind === 'drawdown') return false;
    this.resume();
    return true;
  }

  /** Roll the daily book when the bar's own date changes. */
  rollDay(ts = this.clock()) {
    const day = Math.floor(ts / 86400000);
    if (day === this._day) return false;
    this._day = day;
    this.state.dayStartEquity = this.state.equity;
    this.state.counters.tradesToday = 0;
    this.maybeAutoResume(ts);
    return true;
  }

  settle({ pnl, win }) {
    const s = this.state;
    const c = s.counters;
    s.equity += Number(pnl) || 0;
    c.trades++;
    c.tradesToday++;
    if (win) {
      c.wins++;
      c.lossesStreak = 0;
    } else {
      c.losses++;
      c.lossesStreak++;
    }
    if (s.equity > this.peakEquity) this.peakEquity = s.equity;

    const killPct = Number(this.r.killSwitchDrawdownPct);
    if (Number.isFinite(killPct) && this.drawdownPct() >= killPct * 100) {
      // Same resume contract as markToMarket: a realised-drawdown halt must be
      // resumable too. Without `kind: 'drawdown'` it defaulted to 'hard' and
      // evaluateResume() ignored it, so the replay locked itself out for good.
      const coolMs = Number(this.r.drawdownCooldownMs) || 24 * 3600 * 1000;
      this.halt(`drawdown ${this.drawdownPct().toFixed(2)}% >= ${(killPct * 100).toFixed(2)}%`, {
        kind: 'drawdown',
        resumeAt: this.clock() + coolMs,
      });
    }
    const dayPct = Number(this.r.maxDailyLossPct);
    if (Number.isFinite(dayPct) && this.dailyPnlPct() <= -dayPct * 100) {
      const nextDay = (Math.floor(this.clock() / 86400000) + 1) * 86400000;
      this.halt(`daily loss ${this.dailyPnlPct().toFixed(2)}% >= ${(dayPct * 100).toFixed(2)}%`, {
        kind: 'daily',
        resumeAt: nextDay,
      });
    }
    const maxStreak = Number(this.r.maxConsecutiveLosses);
    if (Number.isFinite(maxStreak) && maxStreak > 0 && c.lossesStreak >= maxStreak) {
      s.cooldowns.__global = this.clock() + (Number(this.r.cooldownAfterLossMs) || 0);
    }
    return s.equity;
  }

  /**
   * The entry gate the rotator calls. Same shape as the live Risk.check():
   * { ok, reason }. A halt, a daily cap, a cooldown or an exposure breach all
   * refuse the entry.
   */
  check(order = {}, portfolio = null) {
    if (this.halted) return { ok: false, reason: `halted:${this.haltReason}` };
    const cd = this.state.cooldowns.__global;
    if (cd && this.clock() < cd) return { ok: false, reason: 'cooldown' };

    const maxTrades = Number(this.r.maxDailyTrades);
    if (Number.isFinite(maxTrades) && maxTrades > 0 && this.state.counters.tradesToday >= maxTrades) {
      return { ok: false, reason: 'max_daily_trades' };
    }

    const equity = Number(this.state.equity) || 0;
    const notional = Math.abs(Number(order.notional) || 0);
    if (notional <= 0) return { ok: false, reason: 'bad_notional' };

    const minNotional = Number(this.r.minNotionalUsd);
    if (Number.isFinite(minNotional) && notional < minNotional) {
      return { ok: false, reason: 'below_min_notional' };
    }

    if (portfolio && typeof portfolio.totalExposure === 'function') {
      const maxGross = Number(this.r.maxNetExposurePct);
      if (Number.isFinite(maxGross) && maxGross > 0) {
        const after = portfolio.totalExposure() + notional;
        if (after > equity * maxGross) return { ok: false, reason: 'max_net_exposure' };
      }
    }
    return { ok: true };
  }

  snapshot() {
    return {
      equity: this.state.equity,
      peakEquity: this.peakEquity,
      drawdownPct: this.drawdownPct(),
      dailyPnlPct: this.dailyPnlPct(),
      halted: this.halted,
      haltReason: this.haltReason,
    };
  }
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/**
 * Run a backtest over pre-parsed bars.
 *
 * @param {object} p
 * @param {object} p.cfg            the full engine config (fees, strategy, risk)
 * @param {Object<string, Array>} p.barsBySymbol
 * @param {object} [p.log]
 * @param {string} [p.equityFile]   where to append the equity curve
 * @param {object} [p.rotatorOverrides]  e.g. { corePct: 0, variants: [...] }
 * @param {number} [p.startEquity]
 * @param {Function} [p.intelAt]  (ts) => { riskMultiplier, blackout, reason }
 * @returns {object} result
 */
function runBacktest({ cfg, barsBySymbol, log, equityFile, rotatorOverrides, startEquity, intelAt } = {}) {
  const lg = log || quietLog();
  const symbols = Object.keys(barsBySymbol || {}).filter((s) => Array.isArray(barsBySymbol[s]) && barsBySymbol[s].length);
  if (!symbols.length) {
    return { ok: false, error: 'no bars', trades: [], returns: [], equity: [], summary: null };
  }

  // Align on the shortest series so every symbol has a bar at every step.
  const len = Math.min(...symbols.map((s) => barsBySymbol[s].length));
  if (len < 2) {
    return { ok: false, error: 'need at least 2 bars', trades: [], returns: [], equity: [], summary: null };
  }

  const equity0 = Number(startEquity ?? cfg?.risk?.startEquity ?? DEFAULTS.startEquity);

  // Build a config copy with the rotator overrides applied. The production
  // Rotator reads cfg.strategy.rotator, so this is the only knob needed.
  const btCfg = JSON.parse(JSON.stringify(cfg || {}));
  btCfg.strategy = btCfg.strategy || {};
  btCfg.strategy.mode = 'rotator';
  btCfg.strategy.rotator = { ...(btCfg.strategy.rotator || {}), ...(rotatorOverrides || {}) };
  btCfg.symbols = symbols;
  btCfg.backtest = { ...(btCfg.backtest || {}), slippageBps: Number(btCfg?.backtest?.slippageBps ?? DEFAULTS.slippageBps) };
  btCfg.fees = btCfg.fees || { makerBps: 7.5, takerBps: 10 };
  btCfg.risk = { ...(btCfg.risk || {}), startEquity: equity0 };
  btCfg.data = { ...(btCfg.data || {}), staleQuoteMs: 1e9, intervalMs: 3600000 };

  const feeds = new Map();
  for (const s of symbols) feeds.set(s, new CsvFeed(s, barsBySymbol[s], { windowBars: DEFAULTS.windowBars }));
  const hub = new CsvHub(feeds);
  const broker = new CsvBroker({ cfg: btCfg, hub, log: lg });
  const portfolio = new Portfolio(lg);
  // The clock is the bar's own timestamp: a replay must see the day boundaries
  // the market saw, not the wall clock of the machine running the test.
  const barClock = () => feeds.get(symbols[0]).all[feeds.get(symbols[0]).cursor]?.t || 0;
  const risk = new BacktestRisk(equity0, btCfg, barClock);

  const store = {
    state: { equity: equity0, orbital: [], orbitalBucket: null },
    append() {},
    saveState() {},
  };

  const rotator = new Rotator({
    cfg: btCfg,
    log: lg,
    store,
    risk,
    portfolio,
    broker,
    hub,
    bus: { emit() {} },
    // The clock is the bar's own timestamp: the strategy must see the time it
    // would have seen live, not wall-clock time.
    now: () => feeds.get(symbols[0]).all[feeds.get(symbols[0]).cursor]?.t || 0,
  });
  // Skip the boot-retry loop: in replay we know exactly when to start.
  rotator.booted = true;
  rotator.lastBucket = null;

  // ------------------------------------------------------------------ intel
  // Market intel, when supplied, is a PURE FUNCTION OF THE BAR CLOCK. That is
  // the whole point: the replay must see the news it would have seen at that
  // bar, never the news of today.
  //
  // Two hooks, and both can only ever make the book SMALLER:
  //
  //   externalScale  the rotator clamps this to 0..1, so a news bias can
  //                  reduce exposure and can never raise it.
  //   risk.check     a blackout refuses a NEW entry. It never closes an open
  //                  position, because a headline is not a reason to dump a
  //                  position at a bad price.
  //
  // With `intelAt` absent, nothing is wired and the run is the plain baseline.
  let intelStats = null;
  if (typeof intelAt === 'function') {
    intelStats = { calls: 0, blackouts: 0, reductions: 0, minMultiplier: 1 };
    rotator.externalScale = () => {
      const v = intelAt(barClock());
      intelStats.calls++;
      const m = v && Number.isFinite(v.riskMultiplier) ? v.riskMultiplier : 1;
      if (m < 1) intelStats.reductions++;
      if (m < intelStats.minMultiplier) intelStats.minMultiplier = m;
      return m;
    };
    const baseCheck = risk.check.bind(risk);
    risk.check = (order = {}, pf = null) => {
      const v = intelAt(barClock());
      if (v && v.blackout) {
        intelStats.blackouts++;
        return { ok: false, reason: 'intel_blackout' };
      }
      return baseCheck(order, pf);
    };
  }

  const equitySeries = [];
  const trades = [];
  const closed = [];
  const origClose = rotator._close.bind(rotator);
  rotator._close = (sym, reason) => {
    const t = origClose(sym, reason);
    if (t) { trades.push(t); closed.push(t); }
    return t;
  };

  for (let i = 0; i < len; i++) {
    hub.seek(i);
    // Roll the daily book on the bar's own date, so the daily loss cap and the
    // daily trade cap are measured per market day rather than never.
    try { risk.rollDay(barClock()); } catch { /* ignore */ }
    try {
      rotator.onBar();
    } catch (e) {
      lg.warn(`backtest bar ${i} failed: ${e.message}`);
    }
    // The disaster stop lives in onTick, not onBar. Without this call a replay
    // let a position run straight through its stop and be closed days later by
    // a rebalance, which under-reported risk badly. Feed the bar's own close as
    // the tick: it is the worst price we can honestly claim to have seen.
    try {
      for (const p of portfolio.openPositions()) {
        const b = barsBySymbol[p.symbol]?.[i];
        if (!b) continue;
        rotator.onTick({ symbol: p.symbol, bid: b.c, ask: b.c, last: b.c, ts: b.t });
      }
    } catch (e) {
      lg.warn(`backtest tick ${i} failed: ${e.message}`);
    }
    // Mark open positions to the bar close so equity is honest at every step.
    for (const p of portfolio.openPositions()) {
      const b = barsBySymbol[p.symbol]?.[i];
      if (b) p.mark(b.c);
    }
    const eq = risk.state.equity + portfolio.unrealisedTotal();
    // The kill switch must see the marked equity, exactly as the live engine
    // does. Without this the replay measured a bot with no drawdown limit.
    try { risk.markToMarket(eq); } catch { /* ignore */ }
    // Charter §8: the halt must be able to lift after re-evaluation, otherwise
    // the replay measures a bot that locks itself out forever.
    try {
      risk.evaluateResume({
        equityMtm: eq,
        openPositions: portfolio.openPositions().length,
        dataOk: true,
      });
    } catch { /* ignore */ }
    equitySeries.push({ t: barsBySymbol[symbols[0]][i].t, equity: Math.round(eq * 100) / 100 });
  }

  // Close everything at the last bar so the final equity is realised, not
  // marked. A backtest that ends with open positions reports a number nobody
  // could actually withdraw.
  for (const p of [...portfolio.openPositions()]) {
    try { rotator._close(p.symbol, 'end_of_data'); } catch { /* ignore */ }
  }
  const finalEquity = risk.state.equity;

  // Returns from the equity series.
  const returns = [];
  for (let i = 1; i < equitySeries.length; i++) {
    const prev = equitySeries[i - 1].equity;
    if (prev > 0) returns.push((equitySeries[i].equity - prev) / prev);
  }

  // Max drawdown on the equity series.
  let peak = equitySeries.length ? equitySeries[0].equity : equity0;
  let maxDd = 0;
  let maxDdAt = null;
  for (const s of equitySeries) {
    if (s.equity > peak) peak = s.equity;
    const dd = peak > 0 ? (1 - s.equity / peak) * 100 : 0;
    if (dd > maxDd) { maxDd = dd; maxDdAt = s.t; }
  }

  // Persist the curve where the live engine keeps it, so the lawyer's DSR
  // clause can read a backtest's returns exactly like a live run's.
  let curveFile = null;
  if (equityFile) {
    try {
      const curve = new EquityCurve({ file: equityFile, log: lg, sampleIntervalMs: 0 });
      for (const s of equitySeries) curve.sample(s.equity, s.t, true);
      curveFile = equityFile;
    } catch (e) {
      lg.warn(`backtest equity curve write failed: ${e.message}`);
    }
  }

  const wins = closed.filter((t) => t.win).length;
  const grossProfit = closed.filter((t) => t.pnl > 0).reduce((a, t) => a + t.pnl, 0);
  const grossLoss = Math.abs(closed.filter((t) => t.pnl < 0).reduce((a, t) => a + t.pnl, 0));
  const fees = broker.fills.reduce((a, f) => a + f.fee, 0);

  const summary = {
    startEquity: equity0,
    finalEquity: Math.round(finalEquity * 100) / 100,
    returnPct: Math.round(((finalEquity / equity0) - 1) * 10000) / 100,
    maxDrawdownPct: Math.round(maxDd * 100) / 100,
    maxDrawdownAt: maxDdAt,
    trades: closed.length,
    wins,
    losses: closed.length - wins,
    hitRate: closed.length ? Math.round((wins / closed.length) * 10000) / 100 : null,
    profitFactor: grossLoss > 0 ? Math.round((grossProfit / grossLoss) * 100) / 100 : null,
    feesPaid: Math.round(fees * 100) / 100,
    fills: broker.fills.length,
    bars: len,
    firstAt: equitySeries.length ? equitySeries[0].t : null,
    lastAt: equitySeries.length ? equitySeries[equitySeries.length - 1].t : null,
    sharpePerPeriod: sharpe(returns),
    returns: returns.length,
    equityFile: curveFile,
    intel: intelStats,
  };

  return {
    ok: true,
    symbols,
    trades: closed,
    fills: broker.fills,
    returns,
    equity: equitySeries,
    summary,
    rotatorStats: rotator.snapshot(),
  };
}

/** Per-period Sharpe (not annualised — the DSR formula wants per-period). */
function sharpe(returns, rfPerPeriod = 0) {
  const r = (returns || []).filter((x) => Number.isFinite(x));
  if (r.length < 2) return null;
  const mean = r.reduce((a, b) => a + b, 0) / r.length;
  const sd = Math.sqrt(r.reduce((a, b) => a + (b - mean) ** 2, 0) / (r.length - 1));
  if (!(sd > 0)) return null;
  return Math.round(((mean - rfPerPeriod) / sd) * 10000) / 10000;
}

module.exports = {
  runBacktest,
  CsvFeed,
  CsvHub,
  CsvBroker,
  BacktestRisk,
  sharpe,
  DEFAULTS,
};
