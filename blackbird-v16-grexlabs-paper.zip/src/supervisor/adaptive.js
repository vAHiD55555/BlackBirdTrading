'use strict';

/**
 * Optional model-assisted supervisor.
 *
 * The model is an analyst, never an execution authority. It may suggest a
 * small, allow-listed policy patch; every value is range-checked and risk can
 * only become tighter. The patch is applied in memory and journaled so it can
 * be audited or rolled back on restart.
 */
const { now } = require('../core/util');
const { sendConfiguredTelegram } = require('../notify/telegram');

const ALLOWED = new Map([
  ['strategy.minVolPercentile', [0.25, 0.85]],
  ['strategy.maxSpreadBps', [2, 20]],
  ['strategy.breadthMin', [0.5, 0.8]],
  ['strategy.pullbackRsiMin', [25, 45]],
  ['strategy.pullbackRsiMax', [55, 75]],
  ['strategy.rrTarget', [1.4, 4]],
  ['strategy.rotator.volTargetPct', [20, 60]],
  ['strategy.rotator.rebalanceHours', [24, 336]],
  ['strategy.rotator.perPositionPct', [4, 12]],
  ['risk.maxPositionPct', [0.05, 0.2]],
  ['risk.maxOpenPositions', [2, 8]],
  ['risk.maxNetExposurePct', [0.25, 0.7]],
  ['risk.killSwitchDrawdownPct', [0.05, 0.12]],
]);

/**
 * Turn a fetch/network failure into something a human can act on.
 *
 * `fetch failed` on its own is useless: it is the same string whether the host
 * is down, the port is closed, DNS is broken, or the request timed out. The
 * real cause is on `error.cause`, and on a free host it is almost always
 * ECONNREFUSED (nothing listening) — which is exactly what the operator needs
 * to read.
 */
function describeFetchError(e) {
  if (!e) return 'unknown error';
  if (e.name === 'AbortError') return 'timed out';
  const cause = e.cause || {};
  const code = cause.code || e.code;
  const map = {
    ECONNREFUSED: 'connection refused — nothing is listening on that address',
    ENOTFOUND: 'host not found (DNS)',
    ETIMEDOUT: 'connection timed out',
    ECONNRESET: 'connection reset',
    EHOSTUNREACH: 'host unreachable',
    ENETUNREACH: 'network unreachable',
  };
  if (code && map[code]) return map[code];
  if (code) return code;
  // Node's fetch wraps the real cause in `error.cause` and leaves the outer
  // message as the useless "fetch failed". Prefer the cause's own message, and
  // only fall back to the outer one when there is nothing better — otherwise we
  // reproduce exactly the string this function exists to replace.
  if (cause.message && cause.message !== e.message) return cause.message;
  if (e.message && e.message !== 'fetch failed') return e.message;
  return 'network error (no detail available)';
}

const getPath = (obj, path) => path.split('.').reduce((x, k) => x?.[k], obj);
const setPath = (obj, path, value) => {
  const parts = path.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) cur = cur[parts[i]];
  cur[parts[parts.length - 1]] = value;
};

function extractJson(text) {
  const raw = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('model returned no JSON object');
  return JSON.parse(raw.slice(start, end + 1));
}

class AdaptiveSupervisor {
  constructor({ cfg, engine, log, store }) {
    this.cfg = cfg;
    this.engine = engine;
    this.log = log;
    this.store = store;
    this.lastRunAt = 0;
    this.lastResult = null;
    this.inFlight = false;
    this.stats = { runs: 0, applied: 0, rejected: 0, errors: 0 };
    // A model endpoint that is simply not there is the NORMAL case on a free
    // host: no local Ollama, no API key. That is not an error condition, it is
    // the expected state, so we probe once and then stay quiet instead of
    // writing `fetch failed` to the log on every cycle forever.
    this.unreachable = false;
    this.disabledReason = null;
    this.consecutiveErrors = 0;
    this.probed = false;
  }

  get enabled() { return Boolean(this.cfg.supervisor?.enabled) && !this.disabledReason; }

  snapshot() {
    return {
      enabled: this.enabled,
      configured: Boolean(this.cfg.supervisor?.enabled),
      disabledReason: this.disabledReason,
      unreachable: this.unreachable,
      lastRunAt: this.lastRunAt,
      lastResult: this.lastResult,
      ...this.stats,
    };
  }

  /**
   * Is the configured endpoint actually there? One cheap request, once.
   *
   * This is what turns "fetch failed every cycle" into a single honest line at
   * boot. Any HTTP answer — even a 404 — proves something is listening; we are
   * testing reachability, not the model.
   */
  async probe() {
    if (this.probed) return !this.unreachable;
    this.probed = true;
    const s = this.cfg.supervisor || {};
    if (!s.enabled) {
      this.disabledReason = 'disabled in config';
      return false;
    }
    if (!s.url) {
      this.disabledReason = 'no supervisor.url configured';
      this.log.info('adaptive supervisor: off — no endpoint configured (this is the default)');
      return false;
    }
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), Math.min(s.timeoutMs || 15000, 5000));
      try {
        await fetch(s.url, { method: 'GET', signal: ctl.signal });
      } finally {
        clearTimeout(timer);
      }
      this.log.info(`adaptive supervisor: endpoint reachable at ${s.url}`);
      return true;
    } catch (e) {
      this.unreachable = true;
      this.disabledReason = `endpoint unreachable (${describeFetchError(e)})`;
      this.log.info(
        `adaptive supervisor: off — ${s.url} is not reachable from this host ` +
          `(${describeFetchError(e)}). The engine runs normally without it. ` +
          'Set SUPERVISOR_URL to an OpenAI-compatible endpoint to enable it.'
      );
      return false;
    }
  }

  _prompt() {
    const status = this.engine.status();
    return JSON.stringify({
      task: 'Review this paper-trading system and propose at most one conservative policy adjustment.',
      constraints: [
        'Return JSON only: {"action":"hold"} or {"action":"patch","path":"...","value":number,"reason":"..."}.',
        'Use only the allow-listed paths supplied by the caller.',
        'Never change exchange, symbols, mode, credentials, execution, or kill switches.',
        'Prefer hold when evidence is weak; do not optimize for trade frequency.',
      ],
      allowListedPaths: [...ALLOWED.keys()],
      observed: {
        strategy: status.strategy,
        risk: status.risk,
        riskXray: status.riskXray,
        rotator: status.rotator,
        trader: status.trader,
        lastReport: status.lastReport,
      },
    });
  }

  async _callModel(prompt) {
    const s = this.cfg.supervisor;
    const body = {
      model: s.model,
      temperature: 0,
      messages: [
        { role: 'system', content: 'You are a conservative quantitative risk reviewer. Output valid JSON only.' },
        { role: 'user', content: prompt },
      ],
    };
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), s.timeoutMs || 15000);
    try {
      const res = await fetch(s.url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(s.apiKey ? { authorization: `Bearer ${s.apiKey}` } : {}) },
        body: JSON.stringify(body),
        signal: ctl.signal,
      });
      if (!res.ok) throw new Error(`supervisor HTTP ${res.status}`);
      const json = await res.json();
      return json.choices?.[0]?.message?.content || json.response || json.output_text;
    } finally {
      clearTimeout(timer);
    }
  }

  _validate(decision) {
    if (!decision || decision.action === 'hold') return { action: 'hold', reason: decision?.reason || 'model_hold' };
    if (decision.action !== 'patch' || !ALLOWED.has(decision.path)) throw new Error('patch path is not allow-listed');
    if (typeof decision.value !== 'number' || !Number.isFinite(decision.value)) throw new Error('patch value must be finite');
    const [lo, hi] = ALLOWED.get(decision.path);
    if (decision.value < lo || decision.value > hi) throw new Error(`patch outside safe range ${lo}..${hi}`);
    const old = Number(getPath(this.cfg, decision.path));
    if (!Number.isFinite(old)) throw new Error('current config value is not numeric');
    // Adaptive changes may tighten safety, but never loosen a live guard.
    const isRisk = decision.path.startsWith('risk.') ||
      decision.path.endsWith('perPositionPct') || decision.path.endsWith('volTargetPct');
    const tighter = decision.path.includes('max') ? decision.value <= old : true;
    if (isRisk && !tighter) throw new Error('risk patch may only tighten a limit');
    return { action: 'patch', path: decision.path, old, value: decision.value, reason: String(decision.reason || 'model_patch').slice(0, 300) };
  }

  _committeeReview(decision) {
    if (decision.action !== 'patch') return { approved: true, quorum: 'hold', votes: [] };
    const status = this.engine.status();
    const stale = (status.market || []).filter((m) => Number(m.quoteAgeMs) > (this.cfg.data.staleQuoteMs || 20000));
    const riskVote = decision.path.startsWith('risk.') || decision.path.endsWith('perPositionPct') || decision.path.endsWith('volTargetPct')
      ? decision.value <= decision.old ? 'approve' : 'reject'
      : 'approve';
    const dataVote = stale.length ? 'reject' : 'approve';
    const recentCritical = (status.auditors?.recent || []).some((f) => f.level === 'critical');
    const executionVote = status.risk?.halted || (status.jev?.p99 > this.cfg.jevExec.maxLatencyMs * 2) || recentCritical
      ? 'reject' : 'approve';
    const votes = [
      { officer: 'risk', vote: riskVote, reason: riskVote === 'approve' ? 'within risk direction' : 'would loosen risk' },
      { officer: 'data', vote: dataVote, reason: dataVote === 'approve' ? 'feeds fresh' : `${stale.length} stale feed(s)` },
      { officer: 'execution', vote: executionVote, reason: executionVote === 'approve' ? 'execution healthy' : 'halt/latency/audit issue' },
    ];
    return { approved: votes.every((v) => v.vote === 'approve'), quorum: `${votes.filter((v) => v.vote === 'approve').length}/3`, votes };
  }

  async run(force = false) {
    if (!this.enabled || this.inFlight) {
      return { skipped: true, reason: this.enabled ? 'in_flight' : (this.disabledReason || 'disabled') };
    }
    // First call decides whether the endpoint exists at all. If it does not, we
    // switch off here and never touch the network again.
    if (!this.probed) {
      await this.probe();
      if (!this.enabled) return { skipped: true, reason: this.disabledReason };
    }
    const interval = this.cfg.supervisor.intervalMs || 21600000;
    if (!force && now() - this.lastRunAt < interval) return { skipped: true, reason: 'interval' };
    this.inFlight = true;
    this.lastRunAt = now();
    this.stats.runs++;
    try {
      const decision = this._validate(extractJson(await this._callModel(this._prompt())));
      const committee = this._committeeReview(decision);
      decision.committee = committee;
      if (!committee.approved) {
        this.stats.rejected++;
        this.lastResult = { ...decision, action: 'rejected_by_committee' };
        this.store.append('adaptive_rejected', { ...decision, ts: now(), source: this.cfg.supervisor.model });
        sendConfiguredTelegram(this.cfg, 'alert', `🛡️ کمیتهٔ کنترل تغییر ناظر را رد کرد\n${decision.path}\nدلیل: ${committee.votes.map((v) => `${v.officer}=${v.reason}`).join(' | ')}`).catch(() => {});
        return this.lastResult;
      }
      if (decision.action === 'patch') {
        setPath(this.cfg, decision.path, decision.value);
        if (this.engine.rotator && decision.path.startsWith('strategy.rotator.')) this.engine.rotator.rc[decision.path.split('.').pop()] = decision.value;
        this.stats.applied++;
        this.store.append('adaptive_patch', { ...decision, ts: now(), source: this.cfg.supervisor.model });
        sendConfiguredTelegram(this.cfg, 'alert', `🧠✅ کمیتهٔ سه‌نفره تغییر ناظر را تأیید کرد\n${decision.path}: ${decision.old} → ${decision.value}\n${decision.reason}`).catch(() => {});
      }
      this.lastResult = decision;
      return decision;
    } catch (e) {
      this.stats.errors++;
      this.consecutiveErrors++;
      const reason = describeFetchError(e);
      this.lastResult = { action: 'error', reason };

      // A dead endpoint is not a bug to shout about. After a few failures we
      // stop trying entirely, so the log gets one line and then silence — the
      // engine keeps trading without the optional reviewer.
      const maxErrors = Number(this.cfg.supervisor?.maxConsecutiveErrors) || 3;
      if (this.consecutiveErrors >= maxErrors) {
        this.disabledReason = `endpoint failed ${this.consecutiveErrors}x (${reason})`;
        this.log.warn(
          `adaptive supervisor: disabling after ${this.consecutiveErrors} failures (${reason}). ` +
            'The engine continues without it; fix SUPERVISOR_URL and restart to re-enable.'
        );
      } else if (this.consecutiveErrors === 1) {
        this.log.warn(`adaptive supervisor: ${reason} — will retry, then disable if it keeps failing`);
      } else {
        this.log.debug(`adaptive supervisor: still failing (${this.consecutiveErrors}/${maxErrors}): ${reason}`);
      }
      return this.lastResult;
    } finally {
      this.inFlight = false;
    }
  }

  async reviewExternalPatch(candidate, source = 'dashboard') {
    if (!this.enabled) return { action: 'rejected', reason: 'supervisor_disabled' };
    try {
      const requested = this._validate({ action: 'patch', path: candidate.path, value: Number(candidate.value), reason: candidate.reason });
      const model = this._validate(extractJson(await this._callModel(`${this._prompt()}\nCandidate requested by ${source}: ${JSON.stringify(requested)}\nApprove it only by returning the exact same path/value, otherwise return hold.`)));
      if (model.action !== 'patch' || model.path !== requested.path || model.value !== requested.value) {
        return { action: 'rejected_by_model', reason: model.reason || 'model_hold', model };
      }
      const committee = this._committeeReview(requested);
      if (!committee.approved) return { action: 'rejected_by_committee', committee, model };
      setPath(this.cfg, requested.path, requested.value);
      if (this.engine.rotator && requested.path.startsWith('strategy.rotator.')) this.engine.rotator.rc[requested.path.split('.').pop()] = requested.value;
      this.stats.applied++;
      const result = { ...requested, action: 'applied', source, model, committee, ts: now() };
      this.lastResult = result;
      this.store.append('dashboard_patch_applied', result);
      return result;
    } catch (e) {
      this.stats.rejected++;
      return { action: 'rejected', reason: e.message };
    }
  }
}

module.exports = { AdaptiveSupervisor, ALLOWED };
