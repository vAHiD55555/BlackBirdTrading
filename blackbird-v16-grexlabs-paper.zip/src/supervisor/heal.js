'use strict';
/**
 * BlackBird — self-healing supervisor.
 *
 * The engine already degrades instead of crashing, repairs its own hash chain
 * and retries dead feeds. This layer is the part that *acts* when a condition
 * keeps failing, and escalates to a model only when a model can add something
 * a fixed rule cannot.
 *
 * SAFETY CONTRACT (enforced in code, not by prompt):
 *   1. Actions come from a closed allow-list. A model that answers anything
 *      else gets `noop` — its text is never executed.
 *   2. Every allowed action can only REDUCE risk: pause new entries, cut the
 *      gross book, or move to another data venue. None of them can open,
 *      enlarge or resume anything.
 *   3. A halt is sticky. This module never calls risk.resume* and never
 *      touches equity, position sizing, keys or the kill switch.
 *   4. Actions are rate-limited (max per hour, per-action cooldown) so a flapping
 *      feed cannot turn into a switch storm.
 *   5. Rules decide first. The model is asked only for the cases rules cannot
 *      distinguish, and a timeout/unparseable answer falls back to the rule.
 *   6. Everything is journaled: every incident and every action, with reason.
 *
 * What it watches
 *   feeds_down      every symbol's feed degraded for longer than feedOutageMs
 *   no_progress     no closed candle and no tick for longer than staleProgressMs
 *
 * Public surface
 *   tick()            cheap, self-throttled; call it from the engine clock
 *   noteProgress()    engine calls this on every bar/tick that proves liveness
 *   entriesPaused     engine reads this before opening anything
 *   scale             multiplier the engine applies to exposure (<= 1)
 *   snapshot()        for /status and the report
 */
const { now } = require('../core/util');

const DEFAULT = {
  enabled: true,
  checkEveryMs: 15000,
  feedOutageMs: 5 * 60 * 1000,
  staleProgressMs: 20 * 60 * 1000,
  maxActionsPerHour: 4,
  actionCooldownMs: 5 * 60 * 1000,
  pauseEntriesMinutes: 30,
  reduceGrossFactor: 0.5,
  fallbackExchanges: ['mexc', 'bitget', 'bybit', 'binance', 'hyperliquid'],
  model: {
    enabled: false,
    baseUrl: '',
    model: '',
    chatPath: '/chat/completions',
    apiKeyEnv: 'ADVISOR_API_KEY',
    timeoutMs: 15000,
  },
};

/** The only actions that exist. Anything else is refused, whatever asked. */
const ALLOWED = new Set(['noop', 'switch_venue', 'reduce_gross', 'pause_entries']);

const LEVEL_ORDER = ['noop', 'reduce_gross', 'pause_entries', 'switch_venue'];

function models(cfg) {
  const m = (cfg && cfg.model) || {};
  return { ...DEFAULT.model, ...m };
}

class Healer {
  constructor({ cfg, log, engine, store, clock = now, fetchImpl = null } = {}) {
    this.cfg = cfg;
    this.log = log;
    this.engine = engine;
    this.store = store;
    this.clock = clock;
    this.fetchImpl = fetchImpl || (typeof fetch === 'function' ? fetch : null);

    const given = (cfg && cfg.heal) || {};
    this.o = {
      ...DEFAULT,
      ...given,
      model: models({ model: given.model }),
    };

    this.enabled = Boolean(this.o.enabled);
    this.lastCheckAt = 0;
    this.lastProgressAt = clock();
    this.startedAt = clock();

    this.incidents = {};        // code -> firstSeenAt
    this.actionLog = [];        // {ts, action, reason, source, incident}
    this.scale = 1;
    this.entriesPausedUntil = 0;
    this.pausedReason = null;
    this._lastActionAt = {};
    this._unavailableVenues = new Map(); // id -> ts of last failure
    this.lastDecision = null;
  }

  /** The engine proves liveness here: a closed candle or a fresh tick. */
  noteProgress() {
    this.lastProgressAt = this.clock();
  }

  get entriesPaused() {
    return this.clock() < this.entriesPausedUntil;
  }

  tick() {
    if (!this.enabled) return null;
    const t = this.clock();
    if (t - this.lastCheckAt < this.o.checkEveryMs) return null;
    this.lastCheckAt = t;
    try {
      return this.check();
    } catch (e) {
      // A self-healing layer that throws is worse than one that does nothing.
      this.log.error(`heal check failed: ${e.message}`);
      return null;
    }
  }

  /** Returns the incident codes seen, whether or not an action was taken. */
  async check() {
    const found = this._detect();
    for (const inc of found) {
      if (!this.incidents[inc.code]) {
        this.incidents[inc.code] = this.clock();
        this.log.warn(`heal incident: ${inc.code}`, { detail: inc.detail });
        this._journal('heal_incident', { code: inc.code, detail: inc.detail });
      }
    }
    // Clear incidents that no longer hold, so a later recurrence can act again.
    for (const code of Object.keys(this.incidents)) {
      if (!found.some((f) => f.code === code)) delete this.incidents[code];
    }
    if (!found.length) return { incidents: [], action: null };

    const incident = this._prioritise(found);
    // An outage is recorded the moment it is seen, but acted on only once it has
    // lasted long enough to be an outage rather than a reconnect.
    const age = this.clock() - (this.incidents[incident.code] || this.clock());
    if (age < this._minAgeMs(incident.code)) {
      return { incidents: found.map((f) => f.code), action: null, pending: true, incident };
    }
    const decision = await this._decide(incident);
    const applied = await this._apply(decision, incident);
    return { incidents: found.map((f) => f.code), action: applied, incident };
  }

  _detect() {
    const t = this.clock();
    const out = [];
    const engine = this.engine || {};
    const hub = engine.hub;

    if (hub && hub.healthy === false && hub.degraded && hub.degraded.size) {
      out.push({
        code: 'feeds_down',
        detail: `${hub.degraded.size}/${this.cfg.symbols.length} feeds degraded: ${[...hub.degraded].join(',')}`,
        symbols: [...hub.degraded],
      });
    }

    if (t - this.lastProgressAt >= this.o.staleProgressMs) {
      out.push({
        code: 'no_progress',
        detail: `no candle or tick for ${Math.round((t - this.lastProgressAt) / 1000)}s`,
      });
    }
    return out;
  }

  /** How long an incident must persist before it is acted on. */
  _minAgeMs(code) {
    if (code === 'feeds_down') return Number(this.o.feedOutageMs) || 0;
    return 0;
  }

  /** Feed outage outranks a quiet tape: no data at all is the worse failure. */
  _prioritise(list) {
    const rank = { feeds_down: 2, no_progress: 1 };
    return [...list].sort((a, b) => (rank[b.code] || 0) - (rank[a.code] || 0))[0];
  }

  /** The deterministic answer. Runs first, and is the fallback for the model. */
  ruleAction(incident) {
    if (!incident) return { action: 'noop', reason: 'no incident' };
    if (incident.code === 'feeds_down') {
      const venue = this._nextVenue();
      if (venue) return { action: 'switch_venue', reason: `primary feed dead -> ${venue}`, venue };
      return { action: 'pause_entries', reason: 'all feeds dead and no fallback venue is allowed' };
    }
    if (incident.code === 'no_progress') {
      return { action: 'pause_entries', reason: 'engine produced no candle or tick; stop opening until it does' };
    }
    return { action: 'noop', reason: 'unrecognised incident' };
  }

  _nextVenue() {
    const current = (this.cfg.exchange || '').toLowerCase();
    const witness = (this.cfg.witnessExchange || '').toLowerCase();
    for (const raw of this.o.fallbackExchanges || []) {
      const id = String(raw).toLowerCase();
      if (!id || id === current || id === witness) continue;
      // A venue that failed recently is not a fallback, it is a repeat.
      const failedAt = this._unavailableVenues.get(id) || 0;
      if (this.clock() - failedAt < this.o.actionCooldownMs * 4) continue;
      return id;
    }
    return null;
  }

  /**
   * Ask the model only when it is configured and reachable. Its answer is
   * parsed, allow-listed and re-checked; any deviation is a `noop`.
   */
  async _decide(incident) {
    const rule = this.ruleAction(incident);
    const m = this.o.model;
    if (!m.enabled || !m.baseUrl || !this.fetchImpl) {
      this.lastDecision = { ...rule, source: 'rule' };
      return this.lastDecision;
    }
    const key = process.env[m.apiKeyEnv || 'ADVISOR_API_KEY'];
    // A keyless endpoint (Pollinations) is legitimate: the old guard demanded a
    // key unconditionally, so the one provider that needs none could never be
    // used. Only a provider that actually requires a key is blocked here.
    const keyless = /pollinations\.ai/i.test(String(m.baseUrl || ''));
    if (!key && !keyless) {
      this.lastDecision = { ...rule, source: 'rule', note: `missing ${m.apiKeyEnv}` };
      return this.lastDecision;
    }
    try {
      const answer = await this._askModel(incident, rule, m, key);
      const checked = this._validate(answer, incident);
      this.lastDecision = { ...checked, source: checked.action === rule.action ? 'model' : 'model' };
      return this.lastDecision;
    } catch (e) {
      this.log.warn(`advisor unavailable (${e.message}); using the rule`);
      this.lastDecision = { ...rule, source: 'rule_fallback' };
      return this.lastDecision;
    }
  }

  async _askModel(incident, rule, m, key) {
    const status = typeof this.engine?.health === 'function' ? this.engine.health() : {};
    const prompt = [
      'You are the incident advisor for a paper-trading bot. You cannot trade.',
      'Choose exactly one action from: noop, switch_venue, reduce_gross, pause_entries.',
      'Every action may only reduce risk. Never propose resuming, enlarging, or changing keys.',
      `Incident: ${JSON.stringify({ code: incident.code, detail: incident.detail })}`,
      `Rule engine suggests: ${JSON.stringify({ action: rule.action, venue: rule.venue || null })}`,
      `State: ${JSON.stringify({
        exchange: this.cfg.exchange,
        witness: this.cfg.witnessExchange,
        fallbacks: this.o.fallbackExchanges,
        ratios: status,
        halted: Boolean(this.engine?.risk?.halted),
      })}`,
      'Reply with JSON only: {"action":"...","venue":"<id or null>","reason":"<one short sentence>"}',
    ].join('\n');

    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), Number(m.timeoutMs) || 15000);
    try {
      const res = await this.fetchImpl(`${String(m.baseUrl).replace(/\/$/, '')}${m.chatPath || '/chat/completions'}`, {
        method: 'POST',
        signal: ac.signal,
        headers: {
          'content-type': 'application/json',
          ...(key ? { authorization: `Bearer ${key}` } : {}),
        },
        body: JSON.stringify({
          model: m.model || 'openai',
          temperature: 0,
          max_tokens: 160,
          messages: [
            { role: 'system', content: 'You return one JSON object and nothing else.' },
            { role: 'user', content: prompt },
          ],
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = await res.json();
      const text = body?.choices?.[0]?.message?.content || '';
      const json = JSON.parse(String(text).replace(/^```(?:json)?|```$/g, '').trim());
      return json;
    } finally {
      clearTimeout(timer);
    }
  }

  _validate(answer, incident) {
    const fallback = this.ruleAction(incident);
    if (!answer || typeof answer !== 'object') return { action: 'noop', reason: 'model gave no object' };
    const action = String(answer.action || '').toLowerCase();
    if (!ALLOWED.has(action)) return { action: 'noop', reason: `model proposed a non-allowed action (${action})` };

    if (action === 'switch_venue') {
      const venue = String(answer.venue || '').toLowerCase();
      const current = (this.cfg.exchange || '').toLowerCase();
      const witness = (this.cfg.witnessExchange || '').toLowerCase();
      const allowed = (this.o.fallbackExchanges || []).map((v) => String(v).toLowerCase());
      if (!venue || venue === current || venue === witness || !allowed.includes(venue)) {
        return { action: fallback.action === 'switch_venue' ? 'switch_venue' : 'noop', reason: 'model venue is not an allowed independent fallback', venue: fallback.venue };
      }
      return { action, venue, reason: String(answer.reason || 'model chose a venue switch').slice(0, 200) };
    }
    return { action, reason: String(answer.reason || 'model chose ' + action).slice(0, 200) };
  }

  async _apply(decision, incident) {
    const source = decision.source;
    const reason = decision.reason;
    let action = decision.action;
    if (!ALLOWED.has(action)) action = 'noop';
    const t = this.clock();
    if (action === 'noop') {
      this.lastDecision = { action, reason, source };
      return this.lastDecision;
    }

    const hourAgo = t - 3600000;
    this.actionLog = this.actionLog.filter((a) => a.ts >= hourAgo);
    if (this.actionLog.length >= this.o.maxActionsPerHour) {
      this.log.warn('heal action suppressed: hourly cap reached', { would: action });
      return { action: 'noop', reason: 'hourly action cap reached', source };
    }
    const last = this._lastActionAt[action] || 0;
    if (t - last < this.o.actionCooldownMs) {
      return { action: 'noop', reason: `cooldown on ${action}`, source };
    }

    let outcome;
    try {
      if (action === 'switch_venue') {
        const venue = decision.venue || this.ruleAction(incident).venue || null;
        if (!venue) throw new Error('no fallback venue available');
        outcome = await this.engine.switchVenue(venue, reason);
        if (outcome && outcome.ok === false) this._unavailableVenues.set(venue, t);
      } else if (action === 'reduce_gross') {
        this.scale = Math.min(this.scale, Math.max(0.1, Math.min(1, Number(this.o.reduceGrossFactor) || 0.5)));
        outcome = { ok: true, scale: this.scale };
      } else if (action === 'pause_entries') {
        this.entriesPausedUntil = t + Math.max(60000, (Number(this.o.pauseEntriesMinutes) || 30) * 60000);
        this.pausedReason = reason;
        outcome = { ok: true, until: this.entriesPausedUntil };
      }
    } catch (e) {
      this.log.error(`heal action ${action} failed: ${e.message}`);
      outcome = { ok: false, error: e.message };
      if (action === 'switch_venue' && decision.venue) this._unavailableVenues.set(decision.venue, t);
    }

    this._lastActionAt[action] = t;
    const entry = { ts: t, action, reason, source, outcome, incident: incident?.code || null };
    this.actionLog.push(entry);
    this.lastDecision = { action, reason, source, outcome };
    this.log.warn(`self-heal: ${action}`, { reason, source, outcome });
    this._journal('heal_action', entry);
    return this.lastDecision;
  }

  _journal(type, data) {
    try { this.store?.append(type, data); } catch { /* the journal is best-effort here */ }
  }

  snapshot() {
    return {
      enabled: this.enabled,
      scale: this.scale,
      entriesPaused: this.entriesPaused,
      pausedUntil: this.entriesPausedUntil || null,
      pausedReason: this.pausedReason,
      incidents: Object.keys(this.incidents),
      actionsLastHour: this.actionLog.filter((a) => a.ts >= this.clock() - 3600000).length,
      lastDecision: this.lastDecision,
      model: { enabled: Boolean(this.o.model.enabled), configured: Boolean(this.o.model.baseUrl) },
      lastProgressSec: Math.round((this.clock() - this.lastProgressAt) / 1000),
    };
  }
}

module.exports = { Healer, DEFAULT, ALLOWED };
