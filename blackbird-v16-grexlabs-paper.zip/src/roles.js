'use strict';
/**
 * Roles — named jobs, not independent agents.
 *
 * BlackBird (conventional): a few physical models, several personas.
 * AngryBird: ONE primary model holding several named roles; the prompt says so
 * plainly, so the model never believes the other roles are separate parties.
 * The overseer ("قاضی‌القضات") is a different, hidden party — that is the point
 * of the protocol, and it is the only role mapped to a different model.
 *
 * Which provider/model answers which role is a SECRET. It comes from
 * ROLE_MAP_JSON (or the Worker that fronts the models), is held in memory, and
 * never reaches /api/public/*, logs, or the repository.
 */
const ROLE_SETS = Object.freeze({
  blackbird: Object.freeze(['scout', 'technical_analyst', 'risk_judge', 'devils_advocate', 'rules_auditor', 'sentinel']),
  angrybird: Object.freeze(['trader', 'analyst', 'risk_officer', 'skeptic', 'scribe']),
});
const OVERSEER_ALIAS = 'قاضی‌القضات';

function parseRoleMap(raw) {
  if (!raw) return { map: {}, error: null };
  try {
    const m = JSON.parse(raw);
    if (!m || typeof m !== 'object' || Array.isArray(m)) return { map: {}, error: 'ROLE_MAP_JSON must be an object' };
    const out = {};
    for (const [role, v] of Object.entries(m)) {
      if (v && typeof v.provider === 'string' && typeof v.model === 'string') out[role] = { provider: v.provider, model: v.model };
    }
    return { map: out, error: null };
  } catch { return { map: {}, error: 'ROLE_MAP_JSON is not valid JSON' }; }
}

class RoleBook {
  constructor({ profile, env = process.env }) {
    this.profile = profile;
    this.roles = [...(ROLE_SETS[profile] || [])];
    const { map, error } = parseRoleMap(env.ROLE_MAP_JSON);
    // Non-enumerable + toJSON: the map cannot leak through JSON.stringify, util.inspect-style
    // spreads or Object.keys, only through the explicit server-side resolve().
    Object.defineProperty(this, '_map', { value: map, enumerable: false, writable: false });
    this.mapError = error;
  }
  toJSON() { return { profile: this.profile, roles: this.roles }; }
  /** Server-side only. Never serialise the result. */
  resolve(role) { return this._map[role] || null; }
  /** Names only — safe for any public surface. */
  publicRoles() { return this.roles.map((r) => ({ role: r })); }
  /** True when all roles of this profile share one underlying model. */
  singleModel() {
    const keys = this.roles.map((r) => this._map[r]).filter(Boolean).map((m) => `${m.provider}/${m.model}`);
    return keys.length > 0 && new Set(keys).size === 1;
  }
  preamble(role) {
    if (!this.roles.includes(role)) throw new Error(`unknown role "${role}" for profile ${this.profile}`);
    const base = `You are acting in the role "${role}".`;
    if (this.profile !== 'angrybird') return `${base} Other roles may be played by other personas of the same or different models; judge claims on evidence.`;
    return `${base} IMPORTANT: every other named role in this team (${this.roles.filter((r) => r !== role).join(', ')}) is played by the SAME model as you, ` +
      'as a different job — they are masks, not independent agents, and they cannot independently confirm anything you say. ' +
      'Your proposals are advice only: capital limits, the kill switch and order controls are enforced by deterministic code, not by you.';
  }
}

module.exports = { ROLE_SETS, OVERSEER_ALIAS, RoleBook, parseRoleMap };
