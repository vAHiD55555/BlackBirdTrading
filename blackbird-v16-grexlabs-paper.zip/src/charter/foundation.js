'use strict';
/**
 * Foundation charter — the two principles, and the part of them code can enforce.
 *
 *   1. No party may act arbitrarily against another, or collude with another.
 *   2. Every process serves project progress, sustainable profitability,
 *      resource efficiency and ecosystem survival.
 *
 * Principle 2 is a purpose, not a predicate: no function can prove it. It is
 * carried here as data so every ruling and report cites it, and it is enforced
 * indirectly through the hard limits (capital, drawdown, kill switch).
 * Principle 1 is enforceable and is enforced below, as separation of duties.
 */
const PRINCIPLES = Object.freeze([
  Object.freeze({ id: 1, text: 'No party may act arbitrarily against another party or collude with another party.' }),
  Object.freeze({ id: 2, text: 'Every process serves project progress, sustainable profitability, resource efficiency and ecosystem survival.' }),
]);

const DUTIES = Object.freeze(['actor', 'overseer', 'approver', 'evaluator']);

/**
 * assignment: { actor, overseer, approver, evaluator } -> agent id (string).
 * Rules:
 *  - the overseer is never the actor;
 *  - the approver is never the actor (nobody approves their own action);
 *  - the evaluator of performance is never the one being evaluated (the actor);
 *  - no single agent may hold all of overseer + approver + evaluator for someone else's
 *    work as a bloc: the three oversight duties need at least two distinct holders.
 */
function checkSeparationOfDuties(assignment) {
  const violations = [];
  const a = assignment || {};
  for (const d of DUTIES) if (!a[d]) violations.push(`missing duty: ${d}`);
  if (violations.length) return { ok: false, violations };
  if (a.overseer === a.actor) violations.push('overseer must not be the actor');
  if (a.approver === a.actor) violations.push('approver must not be the actor (self-approval)');
  if (a.evaluator === a.actor) violations.push('evaluator must not be the actor (self-assessment)');
  if (new Set([a.overseer, a.approver, a.evaluator]).size < 2) {
    violations.push('oversight duties (overseer, approver, evaluator) need at least two distinct holders');
  }
  return { ok: violations.length === 0, violations };
}

/** A request is approved by someone other than its proposer and its subject. */
function checkApproval({ proposer, approver, subject }) {
  const violations = [];
  if (!proposer || !approver) violations.push('proposer and approver are required');
  if (proposer && approver && proposer === approver) violations.push('approver equals proposer');
  if (subject && approver && subject === approver) violations.push('approver is the subject of the decision');
  return { ok: violations.length === 0, violations };
}

module.exports = { PRINCIPLES, DUTIES, checkSeparationOfDuties, checkApproval };
