'use strict';
/**
 * BlackBird — core utilities.
 * Zero dependencies. Kept allocation-light: much of this runs on the JEV hot
 * path (signal -> decision -> order).
 */
const crypto = require('node:crypto');

const now = () => Date.now();

const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);

function round(x, d = 2) {
  const f = 10 ** d;
  return Math.round(x * f) / f;
}

/** Floor to a tick size without binary-float drift. */
function floorStep(x, step) {
  if (!step) return x;
  const decimals = (String(step).split('.')[1] || '').length;
  const f = 10 ** decimals;
  return Math.floor((x * f) / (step * f)) / (1 / step) || Math.floor(x / step) * step;
}

const mean = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0);

function stdev(a) {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(a.reduce((s, v) => s + (v - m) ** 2, 0) / (a.length - 1));
}

function emaLast(values, period) {
  if (!values.length) return 0;
  const k = 2 / (period + 1);
  let prev = values[0];
  for (let i = 1; i < values.length; i++) prev = values[i] * k + prev * (1 - k);
  return prev;
}

function rollingMean(values, period) {
  const out = new Array(values.length).fill(NaN);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

function percentileRank(arr, value) {
  if (!arr.length) return 0;
  let below = 0;
  for (let i = 0; i < arr.length; i++) if (arr[i] < value) below++;
  return below / arr.length;
}

function quantile(arr, q) {
  if (!arr.length) return 0;
  const a = arr.slice().sort((x, y) => x - y);
  const pos = (a.length - 1) * q;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return a[lo] + (a[hi] - a[lo]) * (pos - lo);
}

const uuid = (p = '') => (p ? `${p}_` : '') + crypto.randomBytes(8).toString('hex');
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/** Deterministic JSON so hashes are reproducible across machines. */
function canonical(v) {
  if (v === undefined) return 'null';
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  // JSON.stringify drops undefined values, so they must not take part in the
  // hash either — otherwise an entry hashes differently after a reload.
  const keys = Object.keys(v).filter((k) => v[k] !== undefined).sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
}

/** Tamper-evident chain link. */
const chainHash = (prev, payload) => sha256(`${prev || 'GENESIS'}|${canonical(payload)}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const iso = (ts = Date.now()) => new Date(ts).toISOString();

function dayKey(ts = Date.now(), tzOffsetMin = 0) {
  return new Date(ts + tzOffsetMin * 60000).toISOString().slice(0, 10);
}

const pct = (a, b) => (b ? ((a - b) / b) * 100 : 0);
const bps = (a, b) => (b ? ((a - b) / b) * 10000 : 0);

function safeJson(text, fallback = null) {
  try {
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

/** Bounded FIFO, O(1) push, no array shifting. */
class Ring {
  constructor(cap) {
    this.cap = cap;
    this.buf = new Array(cap);
    this.start = 0;
    this.size = 0;
  }
  push(v) {
    this.buf[(this.start + this.size) % this.cap] = v;
    if (this.size < this.cap) this.size++;
    else this.start = (this.start + 1) % this.cap;
  }
  get(i) {
    return i < 0 || i >= this.size ? undefined : this.buf[(this.start + i) % this.cap];
  }
  last(n = 1) {
    const out = [];
    for (let i = Math.max(0, this.size - n); i < this.size; i++) out.push(this.get(i));
    return out;
  }
  toArray() {
    return this.last(this.size);
  }
  get length() {
    return this.size;
  }
}

class Ewma {
  constructor(alpha = 0.02) {
    this.alpha = alpha;
    this.value = 0;
    this.n = 0;
  }
  update(x) {
    const a = Math.abs(x);
    this.value = this.n === 0 ? a : this.alpha * a + (1 - this.alpha) * this.value;
    this.n++;
    return this.value;
  }
}

module.exports = {
  now, clamp, round, floorStep, mean, stdev, emaLast, rollingMean,
  percentileRank, quantile, uuid, sha256, chainHash, canonical,
  sleep, iso, dayKey, pct, bps, safeJson, Ring, Ewma,
};
