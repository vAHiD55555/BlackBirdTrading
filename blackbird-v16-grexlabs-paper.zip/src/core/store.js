'use strict';
/**
 * BlackBird — persistence.
 *
 * Everything the engine believes must survive a restart of a free host that
 * recycles containers whenever it feels like it. Two artefacts:
 *
 *  data/journal.jsonl  append-only, hash-chained  -> tamper-evident history
 *  data/state.json     rolling snapshot           -> fast resume
 *
 * The hash chain is what the witness/auditor layers use to prove that the
 * trader did not rewrite its own past.
 */
const fs = require('node:fs');
const path = require('node:path');
const { chainHash, uuid, now } = require('./util');

class Store {
  constructor(cfg, log) {
    this.cfg = cfg;
    this.log = log;
    this.stateFile = cfg.runtime.stateFile;
    this.journalFile = cfg.runtime.journalFile;
    this.seq = 0;
    this.lastHash = 'GENESIS';
    this.state = null;
    this._dirty = false;
    this._ensure();
    this._repairChain();
    this._loadTail();
  }

  /**
   * A journal written by an older build (or interrupted mid-write) can fail
   * verification. Losing the bot forever because of one bad line is worse than
   * losing the line: keep the valid prefix, archive the rest next to it, and
   * continue on a clean chain — loudly.
   */
  _repairChain() {
    let raw;
    try { raw = fs.readFileSync(this.journalFile, 'utf8').trim(); } catch { return; }
    if (!raw) return;
    const lines = raw.split('\n');
    let prev = 'GENESIS';
    for (let i = 0; i < lines.length; i++) {
      let e = null;
      try { e = JSON.parse(lines[i]); } catch { e = null; }
      const ok = e && e.prev === prev &&
        chainHash(prev, { seq: e.seq, ts: e.ts, type: e.type, data: e.data, prev: e.prev }) === e.hash;
      if (ok) { prev = e.hash; continue; }

      const keep = lines.slice(0, i);
      const drop = lines.slice(i);
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const broken = this.journalFile.replace(/\.jsonl$/, '-broken-' + stamp + '.jsonl');
      try {
        fs.writeFileSync(broken, drop.join('\n') + '\n');
        fs.writeFileSync(this.journalFile, keep.length ? keep.join('\n') + '\n' : '');
      } catch (err) {
        this.log.error('journal repair failed: ' + err.message);
        return;
      }
      this.log.warn('journal chain repaired', { kept: keep.length, archived: drop.length, brokenAt: i, archivedFile: broken });
      return;
    }
  }

  _ensure() {
    for (const f of [this.stateFile, this.journalFile]) {
      fs.mkdirSync(path.dirname(f), { recursive: true });
      if (!fs.existsSync(f)) fs.writeFileSync(f, '');
    }
    fs.mkdirSync(this.cfg.runtime.logDir, { recursive: true });
  }

  _loadTail() {
    try {
      const raw = fs.readFileSync(this.journalFile, 'utf8').trim();
      if (!raw) return;
      const lines = raw.split('\n');
      const last = JSON.parse(lines[lines.length - 1]);
      this.seq = (last.seq || 0) + 1;
      this.lastHash = last.hash;
      this.log.info('journal recovered', { entries: lines.length, lastHash: last.hash.slice(0, 12) });
    } catch (e) {
      this.log.warn(`journal tail unreadable, starting a fresh chain: ${e.message}`);
    }
  }

  /** Append one event to the tamper-evident chain. */
  append(type, data) {
    const entry = {
      seq: this.seq,
      ts: now(),
      type,
      data,
    };
    entry.prev = this.lastHash;
    entry.hash = chainHash(this.lastHash, entry);
    this.lastHash = entry.hash;
    this.seq++;
    try {
      fs.appendFileSync(this.journalFile, JSON.stringify(entry) + '\n');
    } catch (e) {
      this.log.error(`journal write failed: ${e.message}`);
    }
    return entry;
  }

  /** Verify the whole chain; returns {ok, brokenAt, count}. */
  verifyChain() {
    try {
      const raw = fs.readFileSync(this.journalFile, 'utf8').trim();
      if (!raw) return { ok: true, count: 0 };
      const lines = raw.split('\n');
      let prev = 'GENESIS';
      for (let i = 0; i < lines.length; i++) {
        const e = JSON.parse(lines[i]);
        const expect = chainHash(prev, { seq: e.seq, ts: e.ts, type: e.type, data: e.data, prev: e.prev });
        if (expect !== e.hash || e.prev !== prev) return { ok: false, brokenAt: i, count: lines.length };
        prev = e.hash;
      }
      return { ok: true, count: lines.length };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  readJournal({ limit = 500, type = null } = {}) {
    try {
      const raw = fs.readFileSync(this.journalFile, 'utf8').trim();
      if (!raw) return [];
      let lines = raw.split('\n').slice(-Math.max(limit * 3, 600));
      let out = [];
      for (const l of lines) {
        try {
          const e = JSON.parse(l);
          if (!type || e.type === type) out.push(e);
        } catch { /* skip torn line */ }
      }
      return out.slice(-limit);
    } catch {
      return [];
    }
  }

  // ---- state ---------------------------------------------------------------
  defaultState() {
    return {
      version: 1,
      bootId: uuid('boot'),
      startedAt: now(),
      equity: this.cfg.risk.startEquity,
      peakEquity: this.cfg.risk.startEquity, // survives restarts; see RiskManager
      dayStartEquity: this.cfg.risk.startEquity, // anchor for the daily loss limit
      cash: this.cfg.risk.startEquity,
      realizedPnl: 0,
      feesPaid: 0,
      positions: [],
      counters: {
        day: new Date().toISOString().slice(0, 10),
        tradesToday: 0,
        lossesStreak: 0,
        wins: 0,
        losses: 0,
        trades: 0,
        grossProfit: 0,
        grossLoss: 0,
      },
      cooldowns: {},
      lastReportAt: 0,
      reportedRounds: 0,
      learned: {},
      halted: false,
      haltReason: null,
      lastHeartbeat: 0,
    };
  }

  loadState() {
    try {
      const raw = fs.readFileSync(this.stateFile, 'utf8');
      const s = JSON.parse(raw);
      this.state = { ...this.defaultState(), ...s };
      this.state.counters = { ...this.defaultState().counters, ...(s.counters || {}) };
      this.state.positions = Array.isArray(s.positions) ? s.positions : [];
      // Migration for state files written before these two keys existed.
      // Without it the merge above hands back `startEquity` as the day anchor,
      // so a bot that is merely down since inception reports that whole loss as
      // TODAY's loss and halts itself on the first boot after the upgrade.
      // The honest anchor for a day we have no record of is the current equity.
      if (!Number.isFinite(Number(s.dayStartEquity))) {
        this.state.dayStartEquity = this.state.equity;
      }
      if (!Number.isFinite(Number(s.peakEquity))) {
        this.state.peakEquity = this.state.equity;
      }
      this.log.info('state restored', {
        equity: this.state.equity,
        positions: this.state.positions.length,
        trades: this.state.counters.trades,
      });
    } catch {
      this.state = this.defaultState();
      this.log.info('fresh state created', { equity: this.state.equity });
    }
    return this.state;
  }

  saveState(extra = {}) {
    this.state = { ...this.state, ...extra };
    try {
      const tmp = `${this.stateFile}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(this.state, null, 2));
      fs.renameSync(tmp, this.stateFile); // atomic-ish: sdcard-safe
      this._dirty = false;
    } catch (e) {
      this.log.error(`state save failed: ${e.message}`);
    }
  }

  /** Roll the daily counters when the UTC day changes. */
  rollDay(dayKey) {
    if (this.state.counters.day === dayKey) return false;
    this.state.counters = { ...this.state.counters, day: dayKey, tradesToday: 0 };
    this.append('day_roll', { day: dayKey });
    return true;
  }
}

module.exports = { Store };
