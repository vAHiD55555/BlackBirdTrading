'use strict';
/**
 * BlackBird — structured logger.
 * Writes JSONL to data/logs/engine-YYYY-MM-DD.jsonl and a compact human line to
 * stdout (free hosts show stdout in the panel, so it must stay readable).
 */
const fs = require('node:fs');
const path = require('node:path');

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };

class Logger {
  constructor({ dir, level = 'info', name = 'engine', mirrorConsole = true } = {}) {
    this.level = LEVELS[level] ?? LEVELS.info;
    this.name = name;
    this.mirrorConsole = mirrorConsole;
    this.dir = dir;
    this.stream = null;
    this._day = null;
    if (dir) {
      try {
        fs.mkdirSync(dir, { recursive: true });
        this._open();
      } catch (e) {
        this.mirrorConsole = true;
        console.error(`[logger] cannot open log dir ${dir}: ${e.message}`);
      }
    }
  }

  _open() {
    const day = new Date().toISOString().slice(0, 10);
    if (this._day === day && this.stream) return;
    this._day = day;
    if (this.stream) {
      try { this.stream.end(); } catch { /* ignore */ }
    }
    this.stream = fs.createWriteStream(path.join(this.dir, `${this.name}-${day}.jsonl`), { flags: 'a' });
    this.stream.on('error', () => { this.stream = null; });
  }

  child(name) {
    const c = Object.create(this);
    c.name = name;
    return c;
  }

  _write(level, msg, fields) {
    if ((LEVELS[level] ?? 20) < this.level) return;
    const rec = { ts: new Date().toISOString(), level, src: this.name, msg, ...(fields || {}) };
    try {
      this._open();
      if (this.stream) this.stream.write(JSON.stringify(rec) + '\n');
    } catch { /* logging must never crash the engine */ }
    if (this.mirrorConsole) {
      const extra = fields && Object.keys(fields).length ? ' ' + JSON.stringify(fields) : '';
      const line = `${rec.ts.slice(11, 19)} ${level.toUpperCase().padEnd(5)} [${this.name}] ${msg}${extra}`;
      if (level === 'error' || level === 'warn') console.error(line);
      else console.log(line);
    }
  }

  debug(m, f) { this._write('debug', m, f); }
  info(m, f) { this._write('info', m, f); }
  warn(m, f) { this._write('warn', m, f); }
  error(m, f) { this._write('error', m, f); }

  close() {
    if (this.stream) { try { this.stream.end(); } catch { /* ignore */ } this.stream = null; }
  }
}

module.exports = { Logger, LEVELS };
