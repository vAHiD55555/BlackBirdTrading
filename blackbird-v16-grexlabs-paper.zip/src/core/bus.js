'use strict';
/**
 * BlackBird — tiny synchronous event bus.
 * Synchronous on purpose: the JEV hot path must not hop through the microtask
 * queue between "signal" and "order".
 */
class Bus {
  constructor(log) {
    this.log = log;
    this.handlers = new Map();
    this.history = [];
    this.maxHistory = 200;
  }

  on(topic, fn) {
    if (!this.handlers.has(topic)) this.handlers.set(topic, new Set());
    this.handlers.get(topic).add(fn);
    return () => this.handlers.get(topic)?.delete(fn);
  }

  once(topic, fn) {
    const off = this.on(topic, (payload) => {
      off();
      fn(payload);
    });
    return off;
  }

  emit(topic, payload) {
    const set = this.handlers.get(topic);
    this.history.push({ t: Date.now(), topic, payload });
    if (this.history.length > this.maxHistory) this.history.shift();
    if (!set) return 0;
    let n = 0;
    for (const fn of set) {
      n++;
      try {
        fn(payload);
      } catch (e) {
        this.log.error(`handler for "${topic}" threw: ${e.message}`, { stack: e.stack?.split('\n')[1] });
      }
    }
    return n;
  }

  recent(topic, n = 20) {
    return this.history.filter((h) => !topic || h.topic === topic).slice(-n);
  }
}

module.exports = { Bus };
