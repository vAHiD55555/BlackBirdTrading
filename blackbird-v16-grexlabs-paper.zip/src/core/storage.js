'use strict';
/**
 * BlackBird — storage layer.
 *
 * On a free hosting plan the filesystem is usually ephemeral: it survives a
 * request, sometimes a restart, and is wiped on redeploy. That is fine for logs
 * and fatal for the observation ledger, which is the whole point of the
 * training data.
 *
 * This module gives the rest of the code one interface and hides the difference:
 *
 *   local   — plain files under dataDir. Fast, no network, lost on redeploy.
 *   remote  — an HTTP endpoint (any free object store: Cloudflare R2 free tier,
 *             Supabase storage, a GitHub gist, your own box). Slower, survives.
 *
 * The choice is `STORAGE_DRIVER` in the environment. `auto` (the default) probes
 * the local filesystem once at boot and warns loudly if it looks ephemeral, so
 * the operator finds out at startup rather than after losing a month of data.
 *
 * Nothing here throws on a storage failure: a trading engine must not stop
 * because a log could not be uploaded.
 */

const fs = require('node:fs');
const path = require('node:path');

const DEFAULTS = {
  driver: 'auto',        // auto | local | remote
  dataDir: null,         // resolved by the caller
  remoteUrl: null,       // base URL of the object store
  remoteToken: null,     // bearer token, from env only
  probeOnBoot: true,
};

/**
 * Heuristics for "this filesystem will not survive a redeploy".
 * Deliberately conservative: a false warning is cheap, a silent data loss is not.
 */
const EPHEMERAL_MARKERS = [
  '/tmp/',
  '/var/tmp/',
  '/app/',          // common container workdir
  '/home/node/',
  '/workspace/',    // sandbox
];

class Storage {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]  cfg.storage
   * @param {object} [opts.log]
   * @param {object} [opts.env]
   */
  constructor({ cfg = {}, log, env } = {}) {
    const e = env || process.env;
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.env = e;

    this.driver = String(e.STORAGE_DRIVER || this.cfg.driver || 'auto').toLowerCase();
    this.dataDir = e.DATA_DIR || this.cfg.dataDir || path.join(process.cwd(), 'data');
    this.remoteUrl = e.STORAGE_URL || this.cfg.remoteUrl || null;
    this.remoteToken = e.STORAGE_TOKEN || this.cfg.remoteToken || null;

    this.ephemeral = null;   // null = not probed yet
    this.warnings = [];
    this.stats = { writes: 0, reads: 0, failures: 0, remoteWrites: 0 };
  }

  /** Resolve `auto` into a concrete driver, and probe the filesystem. */
  init() {
    if (this.cfg.probeOnBoot) this.probe();

    if (this.driver === 'auto') {
      // Remote only when it is actually configured; otherwise local.
      this.driver = this.remoteUrl ? 'remote' : 'local';
    }

    if (this.driver === 'remote' && !this.remoteUrl) {
      this.warn('STORAGE_DRIVER=remote but STORAGE_URL is empty — falling back to local');
      this.driver = 'local';
    }

    this.log.info(`storage: driver=${this.driver} dataDir=${this.dataDir}` +
      (this.ephemeral ? ' (EPHEMERAL filesystem)' : ''));
    return this;
  }

  warn(msg) {
    this.warnings.push({ at: Date.now(), message: msg });
    if (this.warnings.length > 50) this.warnings.shift();
    this.log.warn(`storage: ${msg}`);
  }

  /**
   * Is the data directory on a filesystem that will be wiped?
   * Returns true/false, or null when it cannot be determined.
   */
  probe() {
    if (this.ephemeral !== null) return this.ephemeral;

    const dir = path.resolve(this.dataDir);
    const looksEphemeral = EPHEMERAL_MARKERS.some((m) => `${dir}/`.includes(m));

    // A marker is a hint, not proof. Confirm by writing a probe file and
    // checking it is still there — cheap, and it catches a read-only mount.
    let writable = false;
    try {
      fs.mkdirSync(dir, { recursive: true });
      const probeFile = path.join(dir, '.storage-probe');
      fs.writeFileSync(probeFile, String(Date.now()));
      writable = fs.existsSync(probeFile);
      fs.unlinkSync(probeFile);
    } catch (e) {
      this.warn(`data directory is not writable: ${e.message}`);
      writable = false;
    }

    this.ephemeral = looksEphemeral || !writable;

    if (this.ephemeral && this.driver !== 'remote') {
      this.warn(
        `data directory ${dir} looks ephemeral — the observation ledger will be lost on redeploy. ` +
        'Set STORAGE_DRIVER=remote and STORAGE_URL to keep it.'
      );
    }
    return this.ephemeral;
  }

  /** Absolute path for a logical key, e.g. 'observations/2026-11-07.jsonl'. */
  pathFor(key) {
    return path.join(this.dataDir, key);
  }

  /**
   * Write a file. Local always; remote additionally when configured.
   * @returns {Promise<boolean>}
   */
  async write(key, content) {
    let ok = false;
    try {
      const full = this.pathFor(key);
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, content, 'utf8');
      this.stats.writes++;
      ok = true;
    } catch (e) {
      this.stats.failures++;
      this.warn(`local write failed for ${key}: ${e.message}`);
    }

    if (this.driver === 'remote' && this.remoteUrl) {
      try {
        const res = await fetch(`${this.remoteUrl.replace(/\/+$/, '')}/${key}`, {
          method: 'PUT',
          headers: {
            'content-type': 'application/octet-stream',
            ...(this.remoteToken ? { authorization: `Bearer ${this.remoteToken}` } : {}),
          },
          body: content,
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        this.stats.remoteWrites++;
      } catch (e) {
        this.stats.failures++;
        this.warn(`remote write failed for ${key}: ${e.message}`);
      }
    }
    return ok;
  }

  /** Read a file, local first, then remote. Returns null when absent. */
  async read(key) {
    try {
      const full = this.pathFor(key);
      if (fs.existsSync(full)) {
        this.stats.reads++;
        return fs.readFileSync(full, 'utf8');
      }
    } catch (e) {
      this.warn(`local read failed for ${key}: ${e.message}`);
    }

    if (this.driver === 'remote' && this.remoteUrl) {
      try {
        const res = await fetch(`${this.remoteUrl.replace(/\/+$/, '')}/${key}`, {
          headers: this.remoteToken ? { authorization: `Bearer ${this.remoteToken}` } : {},
        });
        if (res.ok) { this.stats.reads++; return await res.text(); }
      } catch (e) {
        this.warn(`remote read failed for ${key}: ${e.message}`);
      }
    }
    return null;
  }

  /** Dashboard view. */
  snapshot() {
    return {
      driver: this.driver,
      dataDir: this.dataDir,
      ephemeral: this.ephemeral,
      remoteConfigured: Boolean(this.remoteUrl),
      warnings: this.warnings.slice(-5),
      ...this.stats,
    };
  }
}

module.exports = { Storage, DEFAULTS, EPHEMERAL_MARKERS };
