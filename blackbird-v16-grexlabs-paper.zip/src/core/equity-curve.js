'use strict';
/**
 * BlackBird — equity curve and per-period returns.
 *
 * WHY
 * ---
 * The Deflated Sharpe Ratio needs a return series. The project had none: the
 * risk module keeps a single `equity` number and a peak, which is enough for a
 * drawdown but not for a Sharpe. Without returns, DSR is uncomputable — and an
 * uncomputable DSR is exactly the "قابل محاسبه نیست" the lawyer must report.
 *
 * So this module records equity samples and derives returns from them. It is
 * deliberately dumb: append a sample, compute differences. No smoothing, no
 * interpolation, no filling of gaps. A gap in the samples is a gap in the
 * returns, and the lawyer will see a shorter T — which is honest.
 *
 * SAMPLING
 * --------
 * Samples are taken on a fixed cadence (`sampleIntervalMs`, default 1h) and
 * persisted to `<dataDir>/equity.jsonl`. On restart the curve is reloaded, so
 * T survives a crash. The file is capped: old samples are dropped from the
 * head once it exceeds `maxSamples`, because an unbounded file on a free tier
 * is a way to fill the disk.
 *
 * RETURNS
 * -------
 *   r_t = (E_t - E_{t-1}) / E_{t-1}
 *
 * Simple returns, not log: the DSR formula is derived for simple returns.
 */

const fs = require('node:fs');
const path = require('node:path');

/**
 * Create a directory, refusing paths on special filesystems.
 *
 * `fs.mkdirSync('/proc/x', {recursive:true})` HANGS on Linux rather than
 * throwing, so a bad dataDir would freeze the engine silently. See the same
 * guard in src/jev/trials.js.
 */
const FORBIDDEN_ROOTS = ['/proc', '/sys', '/dev'];

function ensureDir(dir) {
  const abs = path.resolve(dir);
  for (const root of FORBIDDEN_ROOTS) {
    if (abs === root || abs.startsWith(`${root}/`)) {
      throw new Error(`refusing to write under ${root} (synthetic filesystem)`);
    }
  }
  fs.mkdirSync(abs, { recursive: true });
}

const DEFAULTS = {
  sampleIntervalMs: 60 * 60 * 1000, // 1h
  maxSamples: 5000,                 // ~7 months at 1h
  minSamplesForStats: 30,           // below this, a Sharpe is noise
};

class EquityCurve {
  constructor({ file, log, clock, sampleIntervalMs, maxSamples } = {}) {
    this.file = file || path.join(process.cwd(), 'data', 'equity.jsonl');
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.clock = clock || (() => Date.now());
    // `||` would swallow a legitimate 0 (sample on every call), so the
    // fallback is explicit. 0 is a valid setting, not a missing one.
    this.sampleIntervalMs = Number.isFinite(Number(sampleIntervalMs))
      ? Math.max(0, Number(sampleIntervalMs))
      : DEFAULTS.sampleIntervalMs;
    this.maxSamples = Number.isFinite(Number(maxSamples)) && Number(maxSamples) > 0
      ? Number(maxSamples)
      : DEFAULTS.maxSamples;

    this.samples = [];   // [{t, equity}]
    this._loaded = false;
    this._lastSampleAt = 0;
    this.stats = { loaded: 0, appended: 0, dropped: 0, failed: 0, lastError: null };

    // Load eagerly. `samples` is a plain array, so a caller that reads it
    // without calling load() would otherwise see an empty curve after a
    // restart — a silent data loss that looks like "no history yet".
    this.load();
  }

  load() {
    if (this._loaded) return this.samples;
    this._loaded = true;
    try {
      if (!fs.existsSync(this.file)) return this.samples;
      const text = fs.readFileSync(this.file, 'utf8');
      for (const line of text.split('\n')) {
        if (!line.trim()) continue;
        try {
          const s = JSON.parse(line);
          if (Number.isFinite(s?.t) && Number.isFinite(s?.equity) && s.equity > 0) {
            this.samples.push({ t: s.t, equity: s.equity });
          }
        } catch { /* torn line */ }
      }
      this.samples.sort((a, b) => a.t - b.t);
      this._lastSampleAt = this.samples.length ? this.samples[this.samples.length - 1].t : 0;
      this.stats.loaded = this.samples.length;
    } catch (e) {
      this.stats.lastError = e.message;
      this.log.warn(`equity curve load failed: ${e.message}`);
    }
    return this.samples;
  }

  /**
   * Record an equity sample.
   *
   * @param {number} equity
   * @param {number} [ts]
   * @param {boolean} [force]  bypass the cadence check (used on shutdown)
   * @returns {boolean} whether a sample was written
   */
  sample(equity, ts = this.clock(), force = false) {
    this.load();
    const e = Number(equity);
    if (!Number.isFinite(e) || e <= 0) return false;
    if (!force && this._lastSampleAt && ts - this._lastSampleAt < this.sampleIntervalMs) return false;

    // A duplicate timestamp would create a zero-length period; skip it.
    if (this.samples.length && this.samples[this.samples.length - 1].t === ts) return false;

    try {
      ensureDir(path.dirname(this.file));
      fs.appendFileSync(this.file, `${JSON.stringify({ t: ts, equity: Math.round(e * 100) / 100 })}\n`, 'utf8');
      this.samples.push({ t: ts, equity: e });
      this._lastSampleAt = ts;
      this.stats.appended++;
      this._trim();
      return true;
    } catch (err) {
      this.stats.failed++;
      this.stats.lastError = err.message;
      this.log.warn(`equity curve write failed: ${err.message}`);
      return false;
    }
  }

  /** Drop the oldest samples once the cap is exceeded, and rewrite the file. */
  _trim() {
    if (this.samples.length <= this.maxSamples) return;
    const drop = this.samples.length - this.maxSamples;
    this.samples = this.samples.slice(drop);
    this.stats.dropped += drop;
    try {
      const body = this.samples.map((s) => JSON.stringify(s)).join('\n') + '\n';
      fs.writeFileSync(this.file, body, 'utf8');
    } catch (e) {
      this.stats.lastError = e.message;
      this.log.warn(`equity curve trim failed: ${e.message}`);
    }
  }

  /**
   * Per-period simple returns.
   * @returns {number[]}
   */
  returns() {
    this.load();
    const out = [];
    for (let i = 1; i < this.samples.length; i++) {
      const prev = this.samples[i - 1].equity;
      const cur = this.samples[i].equity;
      if (!(prev > 0)) continue;
      out.push((cur - prev) / prev);
    }
    return out;
  }

  /** Everything the lawyer needs to compute DSR, or an honest "not enough". */
  performance() {
    this.load();
    const r = this.returns();
    return {
      returns: r,
      T: r.length,
      samples: this.samples.length,
      firstAt: this.samples.length ? this.samples[0].t : null,
      lastAt: this.samples.length ? this.samples[this.samples.length - 1].t : null,
      enough: r.length >= DEFAULTS.minSamplesForStats,
      minSamplesForStats: DEFAULTS.minSamplesForStats,
    };
  }

  snapshot() {
    this.load();
    const p = this.performance();
    return {
      samples: p.samples,
      T: p.T,
      enough: p.enough,
      firstAt: p.firstAt,
      lastAt: p.lastAt,
      file: this.file,
      ...this.stats,
    };
  }
}

module.exports = { EquityCurve, DEFAULTS };
