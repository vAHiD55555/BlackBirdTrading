'use strict';
/**
 * BlackBird — the brief (لایحه).
 *
 * A periodic report to the owner of the capital: what state the company is in,
 * what is costing money, and what to do about it.
 *
 * Two renderings of the same object: `toText` for the terminal and the log,
 * `toHtml` for the panel. Both are pure functions of the brief, so the panel and
 * the CLI can never disagree.
 */

const { countBySeverity, totalAnnualImpact } = require('./findings');

const SEV_FA = { critical: 'بحرانی', warn: 'هشدار', info: 'اطلاع', ok: 'سالم' };
const SEV_ICON = { critical: '🔴', warn: '🟡', info: '🔵', ok: '🟢' };

/**
 * Build the brief object from an audit result.
 *
 * @param {object} audit  { at, clauses, findings, gaps, errors, snapshotAt }
 * @param {object} [opts] { equity, benchmarkAnnualPct }
 */
function buildBrief(audit, opts = {}) {
  const findings = audit.findings || [];
  const counts = countBySeverity(findings);
  const annual = totalAnnualImpact(findings);

  const worst = findings.reduce((acc, f) => {
    const rank = { critical: 3, warn: 2, info: 1, ok: 0 };
    return (rank[f.severity] || 0) > (rank[acc] || 0) ? f.severity : acc;
  }, 'ok');

  const measurable = (audit.clauses || []).filter((c) => c.measurable).length;
  const total = (audit.clauses || []).length;

  return {
    at: audit.at || Date.now(),
    headline: headlineFor(worst, counts, annual),
    status: worst,
    counts,
    annualImpactUsd: Math.round(annual * 100) / 100,
    equity: opts.equity ?? null,
    benchmarkAnnualPct: opts.benchmarkAnnualPct ?? null,
    coverage: { measurable, total, pct: total ? Math.round((measurable / total) * 100) : 0 },
    clauses: audit.clauses || [],
    findings: findings,
    gaps: audit.gaps || [],
    errors: audit.errors || [],
    recommendations: (audit.findings || [])
      .filter((f) => f.severity === 'critical' || f.severity === 'warn')
      .map((f) => ({ clause: f.clause, text: f.recommendation, severity: f.severity })),
  };
}

function headlineFor(worst, counts, annual) {
  if (worst === 'critical') {
    return `${counts.critical} تخلف بحرانی — برآورد زیان سالانه ${fmtUsd(annual)}`;
  }
  if (worst === 'warn') {
    return `${counts.warn} هشدار بهره‌وری — برآورد زیان سالانه ${fmtUsd(annual)}`;
  }
  return 'همه‌ی شروط منشور در محدوده‌ی سالم';
}

function fmtUsd(n) {
  if (!Number.isFinite(n)) return '—';
  const abs = Math.abs(n);
  if (abs >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(2)}`;
}

function fmtVal(v, unit) {
  if (v === null || v === undefined) return '—';
  if (typeof v !== 'number') return String(v);
  return `${v}${unit === '%' ? '٪' : unit ? ` ${unit}` : ''}`;
}

/** Terminal rendering. */
function toText(brief) {
  const L = [];
  const line = '─'.repeat(66);

  L.push('');
  L.push('⚖️  لایحه‌ی وکیل — BlackBird');
  L.push(line);
  L.push(`  ${SEV_ICON[brief.status] || ''} ${brief.headline}`);
  L.push(`  پوشش سنجش: ${brief.coverage.measurable}/${brief.coverage.total} شرط (${brief.coverage.pct}٪)`);
  if (brief.equity != null) L.push(`  سرمایه: ${fmtUsd(brief.equity)}`);
  L.push(line);

  L.push('');
  L.push('  شروط منشور:');
  for (const c of brief.clauses) {
    const icon = SEV_ICON[c.severity] || '·';
    const val = c.measurable ? fmtVal(c.value, c.unit) : 'قابل‌سنجش نیست';
    const th = c.threshold
      ? ` (آستانه: ${c.threshold.warn}${c.unit === '%' ? '٪' : ''})`
      : '';
    L.push(`   ${icon} ${c.title.padEnd(30)} ${String(val).padStart(14)}${th}`);
  }

  if (brief.findings.length) {
    L.push('');
    L.push('  یافته‌ها:');
    for (const f of brief.findings) {
      L.push(`   ${SEV_ICON[f.severity]} [${f.id}] ${f.title} — ${SEV_FA[f.severity]}`);
      if (f.impactEstimate?.annualUsd) {
        L.push(`      برآورد زیان سالانه: ${fmtUsd(f.impactEstimate.annualUsd)}`);
        if (f.impactEstimate.basis) L.push(`      مبنا: ${f.impactEstimate.basis}`);
      }
      if (f.recommendation) L.push(`      پیشنهاد: ${f.recommendation}`);
    }
  }

  if (brief.gaps.length) {
    L.push('');
    L.push('  شکاف داده (قابل‌سنجش نیست):');
    for (const g of brief.gaps) {
      L.push(`   🔵 ${g.title}: ${(g.evidence.missing || []).join(', ') || 'داده موجود نیست'}`);
    }
  }

  if (brief.errors.length) {
    L.push('');
    L.push('  خطا در سنجش:');
    for (const e of brief.errors) {
      L.push(`   ⚠️  ${e.title}: ${e.evidence.error}`);
    }
  }

  L.push('');
  L.push(line);
  L.push('  این ابزار پایش داخلی است، نه مشاوره‌ی حقوقی یا مالی.');
  L.push(line);
  L.push('');

  return L.join('\n');
}

/** Panel rendering: a compact object the dashboard can drop into the DOM. */
function toPanel(brief) {
  return {
    at: brief.at,
    headline: brief.headline,
    status: brief.status,
    counts: brief.counts,
    annualImpactUsd: brief.annualImpactUsd,
    coverage: brief.coverage,
    clauses: brief.clauses.map((c) => ({
      id: c.id,
      title: c.title,
      value: c.value,
      unit: c.unit,
      threshold: c.threshold,
      severity: c.severity,
      measurable: c.measurable,
      formula: c.formula,
    })),
    findings: brief.findings.slice(0, 20).map((f) => ({
      id: f.id,
      clause: f.clause,
      title: f.title,
      severity: f.severity,
      impactUsd: f.impactEstimate?.annualUsd ?? null,
      recommendation: f.recommendation,
    })),
    gaps: brief.gaps.map((g) => ({ clause: g.clause, title: g.title, missing: g.evidence.missing })),
    errors: brief.errors.map((e) => ({ clause: e.clause, title: e.title, error: e.evidence.error })),
  };
}

module.exports = { buildBrief, toText, toPanel, fmtUsd, SEV_FA, SEV_ICON };
