'use strict';
/**
 * BlackBird — findings.
 *
 * A finding is a structured complaint: which clause was breached, what the
 * evidence is, how much it is estimated to cost, and what to do about it.
 *
 * The `impactEstimate` is the part that makes a finding worth acting on. A
 * finding that says "capital utilisation is low" is an opinion. A finding that
 * says "capital utilisation is 8%, which costs about $X/year at the benchmark
 * rate" is an argument.
 *
 * Every estimate is derived from the same measured value the clause produced —
 * never a separate guess — and carries its own `basis` string so the reader can
 * see exactly how the number was reached.
 */

const SEVERITY_ORDER = { ok: 0, info: 1, warn: 2, critical: 3 };

let seq = 0;

/**
 * Build a finding.
 *
 * @param {object} p
 * @param {string} p.clause        clause id
 * @param {string} p.title
 * @param {'warn'|'critical'} p.severity
 * @param {object} p.evidence      { value, threshold, unit, formula }
 * @param {object} [p.impactEstimate] { usd, annualUsd, basis }
 * @param {string} p.recommendation
 * @param {string} [p.id]
 * @returns {object}
 */
function makeFinding({
  clause,
  title,
  severity,
  evidence,
  impactEstimate = null,
  recommendation,
  id,
}) {
  seq += 1;
  return {
    id: id || `F-${String(seq).padStart(4, '0')}`,
    clause,
    title,
    severity: SEVERITY_ORDER[severity] !== undefined ? severity : 'warn',
    evidence: evidence || {},
    impactEstimate,
    recommendation: recommendation || '',
    at: Date.now(),
  };
}

/** A clause that could not be measured. This is a data gap, not a breach. */
function makeGap({ clause, title, missing, note }) {
  seq += 1;
  return {
    id: `G-${String(seq).padStart(4, '0')}`,
    clause,
    title,
    severity: 'info',
    kind: 'data_gap',
    evidence: { missing: missing || [], note: note || '' },
    impactEstimate: null,
    recommendation: `داده‌ی لازم برای سنجش «${title}» موجود نیست: ${(missing || []).join(', ')}`,
    at: Date.now(),
  };
}

/** A clause whose measurement threw. Also not a breach — a defect. */
function makeError({ clause, title, error }) {
  seq += 1;
  return {
    id: `E-${String(seq).padStart(4, '0')}`,
    clause,
    title,
    severity: 'warn',
    kind: 'measurement_error',
    evidence: { error: String(error && error.message ? error.message : error).slice(0, 300) },
    impactEstimate: null,
    recommendation: `سنجش «${title}» خطا داد و باید بررسی شود؛ بقیه‌ی audit ادامه یافت.`,
    at: Date.now(),
  };
}

/** Sort worst-first, then by estimated impact. */
function sortFindings(findings) {
  return [...findings].sort((a, b) => {
    const s = (SEVERITY_ORDER[b.severity] || 0) - (SEVERITY_ORDER[a.severity] || 0);
    if (s !== 0) return s;
    const ai = Math.abs(a.impactEstimate?.annualUsd || 0);
    const bi = Math.abs(b.impactEstimate?.annualUsd || 0);
    return bi - ai;
  });
}

/** Total estimated annual loss across findings that carry an estimate. */
function totalAnnualImpact(findings) {
  return findings.reduce((a, f) => a + Math.abs(f.impactEstimate?.annualUsd || 0), 0);
}

function countBySeverity(findings) {
  const out = { critical: 0, warn: 0, info: 0, ok: 0 };
  for (const f of findings) out[f.severity] = (out[f.severity] || 0) + 1;
  return out;
}

module.exports = {
  makeFinding,
  makeGap,
  makeError,
  sortFindings,
  totalAnnualImpact,
  countBySeverity,
  SEVERITY_ORDER,
};
