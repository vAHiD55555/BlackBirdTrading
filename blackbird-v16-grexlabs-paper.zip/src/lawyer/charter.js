'use strict';
/**
 * BlackBird — the company charter.
 *
 * "Maximum productivity given current conditions" is a slogan until it is
 * written as numbers. This file is that translation: a list of clauses, each
 * one a pure function from a snapshot to a measured value, a threshold, and a
 * verdict.
 *
 * Design rules:
 *
 *   1. Every clause is MEASURED, never estimated. If the data a clause needs is
 *      absent, the clause returns `measurable: false` and the lawyer records a
 *      data gap. It never invents a number to fill the hole.
 *   2. Every clause is a pure function of its input. No clock, no network, no
 *      randomness. Two audits of the same snapshot must agree exactly, or the
 *      finding cannot be defended.
 *   3. Every clause states its formula in `formula`, in words, so the number on
 *      the dashboard can be checked by hand.
 *   4. A clause that throws is recorded as `error`, and the rest of the audit
 *      continues. One broken measurement must not blind the whole report.
 *
 * Severity is derived from how far past the threshold the value sits, not from
 * a hardcoded label, so a small breach is a warning and a large one is critical.
 */

/**
 * Clause definition shape:
 * {
 *   id, title, unit, direction,
 *   formula,          // human-readable, shown in the report
 *   needs: [..],      // snapshot fields this clause reads
 *   measure(snapshot, thresholds) -> number | null
 *   threshold: { warn, critical }   // direction decides which side is bad
 * }
 *
 * direction: 'lower-is-worse' | 'higher-is-worse'
 */

const CLAUSES = [
  // ---------------------------------------------------------------- 1. capital use
  {
    id: 'capital_utilisation',
    title: 'نرخ استفاده از سرمایه',
    unit: '%',
    direction: 'lower-is-worse',
    formula:
      'grossNotional / equity × 100 — چه درصدی از موجودی واقعاً در معرض بازار است. ' +
      'پایین بودنش یعنی سرمایه بیکار مانده و فرصت از دست می‌رود.',
    needs: ['risk.equity', 'positions[].notional'],
    measure(snap) {
      const equity = num(snap?.risk?.equity);
      const positions = arr(snap?.positions);
      if (!Number.isFinite(equity) || equity <= 0) return null;
      if (!positions.length) return 0;
      const gross = positions.reduce((a, p) => a + Math.abs(num(p.notional) || 0), 0);
      if (!Number.isFinite(gross)) return null;
      return round((gross / equity) * 100, 2);
    },
    threshold: { warn: 25, critical: 10 },
  },

  // ------------------------------------------------------------ 2. opportunity cost
  {
    id: 'opportunity_cost',
    title: 'هزینه‌ی فرصت سرمایه‌ی بیکار',
    unit: '%/سال',
    direction: 'higher-is-worse',
    formula:
      'idlePct × benchmarkAnnualPct / 100 — بازدهی که سرمایه‌ی بیکار در بازده مرجع از دست می‌دهد. ' +
      'idlePct = 100 − نرخ استفاده از سرمایه.',
    needs: ['risk.equity', 'positions[].notional', 'benchmarkAnnualPct'],
    measure(snap, th) {
      const equity = num(snap?.risk?.equity);
      const positions = arr(snap?.positions);
      const bench = num(th?.benchmarkAnnualPct);
      if (!Number.isFinite(equity) || equity <= 0) return null;
      if (!Number.isFinite(bench)) return null;
      const gross = positions.reduce((a, p) => a + Math.abs(num(p.notional) || 0), 0);
      const usedPct = Math.min(100, (gross / equity) * 100);
      const idlePct = Math.max(0, 100 - usedPct);
      return round((idlePct * bench) / 100, 2);
    },
    threshold: { warn: 8, critical: 20 },
  },

  // ------------------------------------------------------------- 3. cost efficiency
  {
    id: 'cost_efficiency',
    title: 'کارایی هزینه',
    unit: '%',
    direction: 'higher-is-worse',
    formula:
      '(fees + slippage) / grossProfit × 100 — چه سهمی از سود ناخالص صرف هزینه‌ی معامله می‌شود. ' +
      'اگر سود ناخالص صفر یا منفی باشد، قابل‌سنجش نیست.',
    needs: ['fees.total', 'slippage.total', 'pnl.grossProfit'],
    measure(snap) {
      const fees = num(snap?.fees?.total);
      const slip = num(snap?.slippage?.total);
      const gross = num(snap?.pnl?.grossProfit);
      if (!Number.isFinite(fees) || !Number.isFinite(gross)) return null;
      if (gross <= 0) return null; // no profit to spend costs against
      const cost = fees + (Number.isFinite(slip) ? slip : 0);
      return round((cost / gross) * 100, 2);
    },
    threshold: { warn: 35, critical: 60 },
  },

  // ------------------------------------------------------------ 4. time productivity
  {
    id: 'time_productivity',
    title: 'بهره‌وری زمان',
    unit: '%',
    direction: 'higher-is-worse',
    formula:
      'blockedMs / (blockedMs + activeMs) × 100 — چه سهمی از زمان صرف انتظار/بلاک‌شدن شده ' +
      'به‌جای فعالیت. بلاک شامل halt، cooldown و veto است.',
    needs: ['time.activeMs', 'time.blockedMs'],
    measure(snap) {
      const active = num(snap?.time?.activeMs);
      const blocked = num(snap?.time?.blockedMs);
      if (!Number.isFinite(active) || !Number.isFinite(blocked)) return null;
      const total = active + blocked;
      if (total <= 0) return null;
      return round((blocked / total) * 100, 2);
    },
    threshold: { warn: 30, critical: 55 },
  },

  // --------------------------------------------------------- 5. risk-adjusted return
  {
    id: 'risk_adjusted_return',
    title: 'تناسب ریسک با بازده',
    unit: 'R',
    direction: 'lower-is-worse',
    formula:
      'netPnl / riskConsumed — بازده به ازای هر واحد ریسک مصرف‌شده. ' +
      'riskConsumed = مجموع فاصله‌ی ورود تا استاپ همه‌ی معاملات (به دلار).',
    needs: ['pnl.net', 'risk.consumedUsd'],
    measure(snap) {
      const net = num(snap?.pnl?.net);
      const risk = num(snap?.risk?.consumedUsd);
      if (!Number.isFinite(net) || !Number.isFinite(risk) || risk <= 0) return null;
      return round(net / risk, 3);
    },
    threshold: { warn: 0.05, critical: -0.1 },
  },

  // ---------------------------------------------------------------- 6. concentration
  {
    id: 'concentration',
    title: 'تمرکز سرمایه',
    unit: '%',
    direction: 'higher-is-worse',
    formula:
      'max(singleSymbolPct, singleDirectionPct) — بزرگ‌ترین وزن یک دارایی یا یک جهت ' +
      'نسبت به **موجودی**. مخرج equity است، نه کل ناخالص: اگر مخرج ناخالص باشد هر ' +
      'کتاب تماماً لانگ همیشه ۱۰۰٪ نشان می‌دهد و شاخص بی‌معنا می‌شود. ' +
      'آستانه‌ی جهت عمداً بالا است چون این استراتژی ذاتاً جهت‌دار است؛ تمرکز خطرناک ' +
      'یعنی یک دارایی یا یک جهت تقریباً تمام سرمایه را ببرد.',
    needs: ['risk.equity', 'positions[].notional', 'positions[].side'],
    measure(snap) {
      const equity = num(snap?.risk?.equity);
      const positions = arr(snap?.positions);
      if (!Number.isFinite(equity) || equity <= 0) return null;
      if (!positions.length) return null;

      const bySymbol = new Map();
      const bySide = new Map();
      for (const p of positions) {
        const n = Math.abs(num(p.notional) || 0);
        const s = String(p.symbol || '?');
        const side = String(p.side || 'long').toLowerCase();
        bySymbol.set(s, (bySymbol.get(s) || 0) + n);
        bySide.set(side, (bySide.get(side) || 0) + n);
      }
      const maxSym = Math.max(...bySymbol.values());
      const maxSide = Math.max(...bySide.values());
      return round((Math.max(maxSym, maxSide) / equity) * 100, 2);
    },
    threshold: { warn: 70, critical: 90 },
  },

  // ------------------------------------------------------- 7. operational health
  {
    id: 'operational_health',
    title: 'سلامت عملیاتی',
    unit: '%',
    direction: 'higher-is-worse',
    formula:
      'moduleErrorRate × 0.5 + missedCycleRate × 0.3 + latencyPenalty × 0.2 — ' +
      'ترکیب نرخ خطای ماژول‌ها، چرخه‌های ازدست‌رفته و تأخیر بالاتر از بودجه.',
    needs: ['modules[].errorCount', 'cycles.expected', 'cycles.missed', 'latency.p99Ms'],
    measure(snap, th) {
      const modules = arr(snap?.modules);
      const expected = num(snap?.cycles?.expected);
      const missed = num(snap?.cycles?.missed);
      const p99 = num(snap?.latency?.p99Ms);
      const budget = num(th?.latencyBudgetMs);

      if (!modules.length && !Number.isFinite(expected)) return null;

      const totalErrors = modules.reduce((a, m) => a + (num(m.errorCount) || 0), 0);
      const errorRate = modules.length ? Math.min(1, totalErrors / (modules.length * 10)) : 0;

      const missedRate = Number.isFinite(expected) && expected > 0
        ? Math.min(1, (num(missed) || 0) / expected)
        : 0;

      let latencyPenalty = 0;
      if (Number.isFinite(p99) && Number.isFinite(budget) && budget > 0) {
        latencyPenalty = Math.min(1, Math.max(0, (p99 - budget) / budget));
      }

      return round((errorRate * 0.5 + missedRate * 0.3 + latencyPenalty * 0.2) * 100, 2);
    },
    threshold: { warn: 20, critical: 40 },
  },

  // ------------------------------------------------------------- 8. charter compliance
  {
    id: 'charter_compliance',
    title: 'انطباق با سقف‌های منشور',
    unit: 'تخلف',
    direction: 'higher-is-worse',
    formula:
      'تعداد سقف‌هایی که نقض شده‌اند: maxPositionPct، maxOpenPositions، ' +
      'maxSymbolExposurePct، maxNetExposurePct، killSwitchDrawdownPct.',
    needs: ['risk.*', 'positions[]', 'limits.*'],
    measure(snap) {
      const limits = snap?.limits;
      if (!limits || typeof limits !== 'object') return null;
      const equity = num(snap?.risk?.equity);
      const positions = arr(snap?.positions);
      if (!Number.isFinite(equity) || equity <= 0) return null;

      let breaches = 0;

      // position count
      if (Number.isFinite(num(limits.maxOpenPositions)) && positions.length > num(limits.maxOpenPositions)) {
        breaches++;
      }

      // per-symbol exposure
      if (Number.isFinite(num(limits.maxSymbolExposurePct))) {
        const bySymbol = new Map();
        for (const p of positions) {
          const s = String(p.symbol || '?');
          bySymbol.set(s, (bySymbol.get(s) || 0) + Math.abs(num(p.notional) || 0));
        }
        for (const n of bySymbol.values()) {
          if ((n / equity) * 100 > num(limits.maxSymbolExposurePct)) { breaches++; break; }
        }
      }

      // net exposure
      if (Number.isFinite(num(limits.maxNetExposurePct))) {
        let net = 0;
        for (const p of positions) {
          const n = Math.abs(num(p.notional) || 0);
          net += String(p.side || 'long').toLowerCase() === 'short' ? -n : n;
        }
        if ((Math.abs(net) / equity) * 100 > num(limits.maxNetExposurePct)) breaches++;
      }

      // drawdown kill switch
      const dd = num(snap?.risk?.drawdownPct);
      if (Number.isFinite(dd) && Number.isFinite(num(limits.killSwitchDrawdownPct))) {
        if (dd > num(limits.killSwitchDrawdownPct)) breaches++;
      }

      return breaches;
    },
    threshold: { warn: 1, critical: 2 },
  },

  // ------------------------------------------------- 9. deflated Sharpe (DSR)
  {
    id: 'deflated_sharpe',
    title: 'شارپ تعدیل‌شده (DSR)',
    unit: 'احتمال',
    direction: 'lower-is-worse',
    formula:
      'DSR = Φ( (SR − SR0)·√(T−1) / √(1 − γ₃·SR + ((γ₄−1)/4)·SR²) ) ' +
      'که در آن SR0 = √V[SR]·((1−γ)·Φ⁻¹(1−1/K) + γ·Φ⁻¹(1−1/(K·e))). ' +
      'SR شارپ مشاهده‌شده (به ازای هر دوره، نه سالانه)، K تعداد آزمون‌ها، T تعداد مشاهده، ' +
      'γ₃ چولگی، γ₄ کشیدگی (نه کشیدگی مازاد)، V[SR] واریانس شارپ بین آزمون‌ها. ' +
      'این شرط می‌پرسد: با توجه به اینکه این بهترین نتیجه از K آزمون است، چقدر مطمئنیم edge واقعی است؟ ' +
      'اگر سری بازده یا K یا واریانس شارپ موجود نباشد، قابل‌سنجش نیست — عدد جعلی ساخته نمی‌شود.',
    needs: ['performance.returns[]', 'performance.K', 'performance.varSharpe'],
    measure(snap, th) {
      const perf = snap?.performance;
      if (!perf || typeof perf !== 'object') return null;

      const returns = arr(perf.returns).map((x) => num(x)).filter((x) => Number.isFinite(x));
      const K = num(perf.K);
      const varSharpe = num(perf.varSharpe);

      // Every input is required. A DSR computed from a guessed K is a lie.
      if (returns.length < 3) return null;
      if (!Number.isFinite(K) || K < 1) return null;
      if (!Number.isFinite(varSharpe) || varSharpe < 0) return null;

      const { deflatedSharpeFromReturns } = require('./dsr');
      const r = deflatedSharpeFromReturns({
        returns,
        K,
        varSharpe,
        rfPerPeriod: num(perf.rfPerPeriod) || 0,
      });
      if (!r.computable) return null;
      return round(r.dsr, 4);
    },
    // The acceptance threshold is configurable (lawyer.dsrThreshold); this is
    // only the fallback when the config does not set one.
    threshold: { warn: 0.95, critical: 0.80 },
  },

  // --------------------------------------- 10. strategist report integrity
  {
    id: 'strategist_integrity',
    title: 'صحت گزارش استراتژیست',
    unit: 'مورد',
    direction: 'higher-is-worse',
    formula:
      'تعداد نقض‌های یافت‌شده در گزارش استراتژیست: ادعای وضعیت نادرست (سبز در حالی که افت از آستانه گذشته یا موتور متوقف است)، ' +
      'اقدام بحرانی بدون رکورد متناظر در دفتر مجوز، تعداد اقدام در ساعت بیش از سقف، ' +
      'اورلی Crisis که از TTL خود گذشته، یا ضریب ریسک بزرگ‌تر از ۱. ' +
      'استراتژیست درباره‌ی خودش گزارش می‌دهد؛ گزارش یک ادعاست، نه مدرک. این بند ادعا را با اعداد موتور مقایسه می‌کند. ' +
      'اگر استراتژیست خاموش باشد، بند قابل اندازه‌گیری نیست (نه اینکه صفر باشد).',
    needs: ['strategist.enabled', 'strategist.severity', 'strategist.authority.audit[]'],
    measure(snap, th) {
      const s = snap?.strategist;
      // Off means "nothing to judge", which is not the same as "judged clean".
      if (!s || !s.enabled) return null;

      const violations = [];
      const risk = snap?.risk || {};
      const dd = num(risk.drawdownPct);
      const kill = num(th?.killSwitchDrawdownPct);

      // A false green is worse than a false red: nobody inspects a green.
      if (String(s.severity) === 'green') {
        if (Number.isFinite(dd) && Number.isFinite(kill) && kill > 0 && dd >= kill * 0.8) {
          violations.push(`green while drawdown is ${dd.toFixed(2)}% (kill switch ${(kill * 100).toFixed(1)}%)`);
        }
        if (risk.halted) violations.push('green while the risk engine is halted');
      }

      const audit = arr(s.authority?.audit);
      const appliedIds = new Set(audit.filter((a) => a && a.applied).map((a) => a.id));
      for (const rec of arr(s.recent)) {
        if (rec?.type !== 'self_execution') continue;
        if (!rec.authority || !appliedIds.has(rec.authority)) {
          violations.push(`self-execution "${rec.action}" without an audit entry`);
        }
      }

      const m = num(s.overlay?.multiplier);
      if (Number.isFinite(m) && m > 1) violations.push(`overlay multiplier ${m} exceeds 1`);

      const max = num(th?.maxActionsPerHour);
      if (Number.isFinite(max)) {
        const since = (num(snap?.at) ?? Date.now()) - 3600000;
        const lastHour = audit.filter((a) => a && a.applied && num(a.at) != null && num(a.at) >= since).length;
        if (lastHour > max) violations.push(`${lastHour} crisis actions in the last hour (max ${max})`);
      }

      return violations.length;
    },
    // maxActionsPerHour and killSwitchDrawdownPct are injected from config by
    // the lawyer, so the clause measures against the live limits, not copies.
    threshold: { warn: 1, critical: 2 },
  },
];

// ------------------------------------------------------------------- helpers
function num(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function arr(v) {
  return Array.isArray(v) ? v : [];
}

function round(v, d = 2) {
  if (!Number.isFinite(v)) return null;
  const f = 10 ** d;
  return Math.round(v * f) / f;
}

/**
 * Severity from distance past the threshold.
 * A breach of 1.5× the gap to critical is critical; anything past warn is warn.
 */
function severityFor(value, threshold, direction) {
  if (!Number.isFinite(value) || !threshold) return 'ok';
  const warn = num(threshold.warn);
  const critical = num(threshold.critical);
  if (!Number.isFinite(warn)) return 'ok';

  if (direction === 'lower-is-worse') {
    if (Number.isFinite(critical) && value <= critical) return 'critical';
    // `<=` on warn: a value sitting exactly on the warn line is a warning.
    if (value <= warn) return 'warn';
    return 'ok';
  }
  // higher-is-worse
  if (Number.isFinite(critical) && value >= critical) return 'critical';
  // `>=` on warn, not `>`: a clause whose warn threshold is a count (e.g. one
  // charter breach) must fire when the count reaches it, not only past it.
  if (value >= warn) return 'warn';
  return 'ok';
}

/** Default thresholds, overridable per clause from config. */
function defaultThresholds() {
  const out = {};
  for (const c of CLAUSES) out[c.id] = { ...c.threshold };
  return out;
}

module.exports = {
  CLAUSES,
  severityFor,
  defaultThresholds,
  num,
  arr,
  round,
};
