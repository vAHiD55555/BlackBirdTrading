'use strict';
/**
 * BlackBird — Deflated Sharpe Ratio.
 *
 * THE PROBLEM
 * -----------
 * You try 400 configurations. The best one shows a Sharpe of 2.0. Is that an
 * edge, or is it the maximum of 400 draws from a distribution whose true mean
 * is zero? Under the null, the expected maximum Sharpe of K independent trials
 * grows with K — at K=400 it is already around 2.0. So a Sharpe of 2.0 from 400
 * trials is exactly what "no edge at all" looks like.
 *
 * THE FIX (Bailey & López de Prado, 2014)
 * ---------------------------------------
 * Deflated Sharpe Ratio asks: given that this is the best of K trials, what is
 * the probability the true Sharpe exceeds zero?
 *
 *   SR0 = sqrt(V[SR]) * ( (1-γ)·Z⁻¹(1 - 1/K) + γ·Z⁻¹(1 - 1/(K·e)) )
 *
 *   DSR = Z( (SR - SR0) · sqrt(T-1) / sqrt(1 - γ₃·SR + ((γ₄-1)/4)·SR²) )
 *
 *   SR    observed Sharpe, PER PERIOD (not annualised)
 *   SR0   expected maximum Sharpe under the null, from K trials
 *   V[SR] variance of the Sharpe ratios across the K trials
 *   T     number of return observations
 *   γ₃    skewness of returns
 *   γ₄    kurtosis of returns (NOT excess — normal = 3)
 *   γ     Euler–Mascheroni ≈ 0.5772
 *   Z, Z⁻¹ standard normal CDF and its inverse
 *
 * DSR is a probability in [0,1]. 0.95 means "95% confident the edge is real
 * after accounting for how hard we looked".
 *
 * WHAT THIS MODULE REFUSES TO DO
 * ------------------------------
 * It will not invent inputs. No return series, no K, or no variance across
 * trials → it returns `computable: false` with the exact reason. A fabricated
 * DSR is worse than no DSR: it is a false certificate of significance.
 *
 * Sources:
 *   Bailey, D. & López de Prado, M. (2014), "The Deflated Sharpe Ratio:
 *     Correcting for Selection Bias, Backtest Overfitting and Non-Normality",
 *     Journal of Portfolio Management 40(5).
 *   Bailey, Borwein, López de Prado & Zhu (2014), "Pseudo-Mathematics and
 *     Financial Charlatanism", Notices of the AMS 61(5).
 */

const EULER_GAMMA = 0.5772156649015329;

// ---------------------------------------------------------------------------
// Normal distribution: CDF and inverse
// ---------------------------------------------------------------------------

/**
 * Standard normal CDF, via Abramowitz & Stegun 7.1.26 on erf.
 * Absolute error < 1.5e-7, which is far below any decision threshold here.
 */
function normCdf(x) {
  if (!Number.isFinite(x)) return x > 0 ? 1 : 0;
  const sign = x < 0 ? -1 : 1;
  const z = Math.abs(x) / Math.SQRT2;
  // erf(z) — Abramowitz & Stegun 7.1.26
  const t = 1 / (1 + 0.3275911 * z);
  const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-z * z);
  return 0.5 * (1 + sign * y);
}

/**
 * Inverse standard normal (quantile), Acklam's rational approximation.
 * Relative error < 1.15e-9 across the whole range.
 */
function normInv(p) {
  if (!(p > 0 && p < 1)) {
    if (p === 0) return -Infinity;
    if (p === 1) return Infinity;
    return NaN;
  }
  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
    1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
    6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
    -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
    3.754408661907416e+00];

  const pLow = 0.02425;
  const pHigh = 1 - pLow;
  let q;
  let r;

  if (p < pLow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  if (p > pHigh) {
    q = Math.sqrt(-2 * Math.log(1 - p));
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  q = p - 0.5;
  r = q * q;
  return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
    (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}

// ---------------------------------------------------------------------------
// Return-series statistics
// ---------------------------------------------------------------------------

/**
 * Per-period Sharpe ratio.
 *
 * @param {number[]} returns
 * @param {number} [rfPerPeriod] risk-free per period (default 0)
 * @returns {number|null}
 */
function sharpe(returns, rfPerPeriod = 0) {
  const r = (returns || []).filter((x) => Number.isFinite(x));
  if (r.length < 2) return null;
  const mean = r.reduce((a, b) => a + b, 0) / r.length;
  const variance = r.reduce((a, b) => a + (b - mean) ** 2, 0) / (r.length - 1);
  const sd = Math.sqrt(variance);
  if (!(sd > 0)) return null;
  return (mean - rfPerPeriod) / sd;
}

/** Population skewness (γ₃). Normal = 0. */
function skewness(returns) {
  const r = (returns || []).filter((x) => Number.isFinite(x));
  const n = r.length;
  if (n < 3) return null;
  const mean = r.reduce((a, b) => a + b, 0) / n;
  const m2 = r.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
  const m3 = r.reduce((a, b) => a + (b - mean) ** 3, 0) / n;
  if (!(m2 > 0)) return null;
  return m3 / m2 ** 1.5;
}

/** Population kurtosis (γ₄), NOT excess. Normal = 3. */
function kurtosis(returns) {
  const r = (returns || []).filter((x) => Number.isFinite(x));
  const n = r.length;
  if (n < 4) return null;
  const mean = r.reduce((a, b) => a + b, 0) / n;
  const m2 = r.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
  const m4 = r.reduce((a, b) => a + (b - mean) ** 4, 0) / n;
  if (!(m2 > 0)) return null;
  return m4 / (m2 * m2);
}

// ---------------------------------------------------------------------------
// The expected maximum Sharpe under the null
// ---------------------------------------------------------------------------

/**
 * SR0 — the Sharpe you would expect the BEST of K zero-edge trials to show.
 *
 * @param {number} K        number of trials
 * @param {number} varSr    variance of the Sharpe ratios across those trials
 * @returns {number|null}
 */
function expectedMaxSharpe(K, varSr) {
  const k = Number(K);
  const v = Number(varSr);
  if (!Number.isFinite(k) || k < 1) return null;
  if (!Number.isFinite(v) || v < 0) return null;
  if (k === 1) return 0; // one trial: no selection, no inflation

  const sd = Math.sqrt(v);
  const a = normInv(1 - 1 / k);
  const b = normInv(1 - 1 / (k * Math.E));
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
  return sd * ((1 - EULER_GAMMA) * a + EULER_GAMMA * b);
}

// ---------------------------------------------------------------------------
// DSR
// ---------------------------------------------------------------------------

/**
 * Deflated Sharpe Ratio.
 *
 * @param {object} p
 * @param {number} p.sharpe        observed per-period Sharpe
 * @param {number} p.K             number of trials
 * @param {number} p.T             number of return observations
 * @param {number} [p.skew]        γ₃ (default 0)
 * @param {number} [p.kurt]        γ₄, NOT excess (default 3)
 * @param {number} [p.varSharpe]   variance of Sharpe across trials
 * @returns {{computable: boolean, dsr: number|null, sr0: number|null, reason?: string, inputs?: object}}
 */
function deflatedSharpe({ sharpe: sr, K, T, skew = 0, kurt = 3, varSharpe } = {}) {
  const missing = [];
  if (!Number.isFinite(sr)) missing.push('sharpe');
  if (!Number.isFinite(Number(K)) || Number(K) < 1) missing.push('K (trial count)');
  if (!Number.isFinite(Number(T)) || Number(T) < 3) missing.push('T (return observations)');
  if (!Number.isFinite(Number(varSharpe)) || Number(varSharpe) < 0) missing.push('varSharpe (variance of Sharpe across trials)');

  if (missing.length) {
    return {
      computable: false,
      dsr: null,
      sr0: null,
      reason: `قابل محاسبه نیست: ${missing.join('، ')} موجود نیست`,
      missing,
    };
  }

  const k = Number(K);
  const t = Number(T);
  const v = Number(varSharpe);
  const g3 = Number.isFinite(Number(skew)) ? Number(skew) : 0;
  const g4 = Number.isFinite(Number(kurt)) ? Number(kurt) : 3;

  const sr0 = expectedMaxSharpe(k, v);
  if (!Number.isFinite(sr0)) {
    return { computable: false, dsr: null, sr0: null, reason: 'قابل محاسبه نیست: SR0 محاسبه نشد', missing: ['sr0'] };
  }

  // Denominator: the standard error of the Sharpe, corrected for non-normality.
  const denomSq = 1 - g3 * sr + ((g4 - 1) / 4) * sr * sr;
  if (!(denomSq > 0)) {
    return {
      computable: false,
      dsr: null,
      sr0,
      reason: 'قابل محاسبه نیست: مخرج فرمول منفی شد (چولگی/کشیدگی با شارپ ناسازگار است)',
      missing: ['valid denominator'],
    };
  }

  const z = ((sr - sr0) * Math.sqrt(t - 1)) / Math.sqrt(denomSq);
  const dsr = normCdf(z);

  return {
    computable: true,
    dsr,
    sr0,
    z,
    inputs: { sharpe: sr, K: k, T: t, skew: g3, kurt: g4, varSharpe: v },
  };
}

/**
 * Convenience: compute DSR straight from a return series.
 *
 * @param {object} p
 * @param {number[]} p.returns
 * @param {number} p.K
 * @param {number} [p.varSharpe]
 * @param {number} [p.rfPerPeriod]
 */
function deflatedSharpeFromReturns({ returns, K, varSharpe, rfPerPeriod = 0 } = {}) {
  const r = (returns || []).filter((x) => Number.isFinite(x));
  if (r.length < 3) {
    return { computable: false, dsr: null, sr0: null, reason: 'قابل محاسبه نیست: سری بازده کوتاه‌تر از ۳ مشاهده است', missing: ['returns'] };
  }
  const sr = sharpe(r, rfPerPeriod);
  if (!Number.isFinite(sr)) {
    return { computable: false, dsr: null, sr0: null, reason: 'قابل محاسبه نیست: انحراف معیار بازده‌ها صفر است', missing: ['sharpe'] };
  }
  return deflatedSharpe({
    sharpe: sr,
    K,
    T: r.length,
    skew: skewness(r) ?? 0,
    kurt: kurtosis(r) ?? 3,
    varSharpe,
  });
}

/**
 * Variance of Sharpe ratios across trials.
 * @param {number[]} sharpes
 */
function varianceOfSharpes(sharpes) {
  const s = (sharpes || []).filter((x) => Number.isFinite(x));
  if (s.length < 2) return null;
  const mean = s.reduce((a, b) => a + b, 0) / s.length;
  return s.reduce((a, b) => a + (b - mean) ** 2, 0) / (s.length - 1);
}

module.exports = {
  deflatedSharpe,
  deflatedSharpeFromReturns,
  expectedMaxSharpe,
  varianceOfSharpes,
  sharpe,
  skewness,
  kurtosis,
  normCdf,
  normInv,
  EULER_GAMMA,
};
