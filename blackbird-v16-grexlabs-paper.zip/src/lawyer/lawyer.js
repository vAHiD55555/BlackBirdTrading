'use strict';
/**
 * BlackBird — the lawyer (وکیل).
 *
 * The lawyer does not trade, does not set risk, and does not decide anything.
 * It represents the owner of the capital: it audits whether the system is
 * actually operating at maximum productivity given current conditions, and when
 * it is not, it files a complaint with evidence and a number attached.
 *
 * Three things it can do, in increasing order of force:
 *
 *   audit(snapshot)   measure every clause, produce findings
 *   object(issue)     file a formal objection (recorded, sent to jev)
 *   recommend()       propose a concrete change
 *
 * And one thing it can do only when explicitly allowed:
 *
 *   a critical finding + autoObject:true  ->  a veto that jev honours
 *
 * Independence is the point. The lawyer runs whether jev is on, off, or broken.
 * It reads the snapshot directly and never asks jev for permission to have an
 * opinion. Its findings are pushed TO jev, not requested FROM it.
 *
 * Fail-safe: a clause that throws is recorded as a measurement error and the
 * audit continues. The lawyer never throws out of `audit()`.
 */

const { CLAUSES, severityFor, defaultThresholds, num, arr, round } = require('./charter');
const {
  makeFinding, makeGap, makeError, sortFindings, totalAnnualImpact, countBySeverity,
} = require('./findings');
const { buildBrief, toText, toPanel } = require('./report');
const { review: reviewStrategist } = require('./strategist-audit');

const DEFAULTS = {
  enabled: false,
  auditIntervalMs: 15 * 60 * 1000,
  clauses: {},              // per-clause threshold overrides
  severityThreshold: 'warn', // minimum severity that becomes a finding
  autoObject: false,        // may a critical finding veto?
  benchmarkAnnualPct: 5,    // reference yield for idle capital
  latencyBudgetMs: 2000,
  maxFindings: 200,
  // Deflated Sharpe acceptance threshold. Configurable, never hardcoded.
  dsrThreshold: 0.95,
  // Strategist review inputs. The lawyer needs the strategist's own cadence and
  // limits to judge whether its report is honest; these are passed in from the
  // engine so there is one source of truth for each number.
  strategistIntervalMs: 210000,
  strategistMaxActionsPerHour: 6,
  strategistOverlayTtlMs: 30 * 60 * 1000,
};

const SEV_RANK = { ok: 0, info: 1, warn: 2, critical: 3 };

class Lawyer {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]     cfg.lawyer
   * @param {object} [opts.log]
   * @param {object} [opts.ledger]  a Ledger instance (optional)
   * @param {object} [opts.jev]     a Jev instance (optional, for findings)
   * @param {function} [opts.clock]
   */
  constructor({ cfg = {}, log, ledger, jev, clock } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.ledger = ledger || null;
    this.jev = jev || null;
    this.clock = clock || (() => Date.now());

    this.thresholds = { ...defaultThresholds(), ...(this.cfg.clauses || {}) };

    this.lastAudit = null;
    this.lastBrief = null;
    this.openFindings = [];
    this.objections = [];
    this.alerts = [];
    this._timer = null;

    this.stats = {
      audits: 0, findings: 0, critical: 0, warnings: 0,
      gaps: 0, errors: 0, objections: 0, vetoes: 0, failedAudits: 0,
    };
  }

  get enabled() {
    return Boolean(this.cfg.enabled);
  }

  /** Minimum severity that becomes a finding. */
  get floor() {
    return SEV_RANK[this.cfg.severityThreshold] ?? SEV_RANK.warn;
  }

  // ------------------------------------------------------------------ audit
  /**
   * Measure every clause against a snapshot.
   *
   * NEVER throws. A clause that fails is recorded and skipped.
   *
   * @param {object} snapshot
   * @returns {object} { at, clauses, findings, gaps, errors }
   */
  audit(snapshot) {
    const at = this.clock();
    const clauses = [];
    const findings = [];
    const gaps = [];
    const errors = [];

    for (const def of CLAUSES) {
      const th = this._thresholdFor(def);
      let value = null;
      let measurable = false;

      try {
        value = def.measure(snapshot, { ...th, ...this._globalThresholds() });
        measurable = Number.isFinite(value);
      } catch (e) {
        // One broken measurement must not blind the whole report.
        const err = makeError({ clause: def.id, title: def.title, error: e });
        errors.push(err);
        this.stats.errors++;
        clauses.push({
          id: def.id, title: def.title, unit: def.unit, formula: def.formula,
          value: null, threshold: th, severity: 'info', measurable: false, error: e.message,
        });
        continue;
      }

      if (!measurable) {
        // No data: say so. Never invent a number.
        const gap = makeGap({
          clause: def.id,
          title: def.title,
          missing: def.needs,
          note: 'داده‌ی ورودی این شرط در snapshot موجود نیست',
        });
        gaps.push(gap);
        this.stats.gaps++;
        clauses.push({
          id: def.id, title: def.title, unit: def.unit, formula: def.formula,
          value: null, threshold: th, severity: 'info', measurable: false,
        });
        continue;
      }

      const severity = severityFor(value, th, def.direction);
      clauses.push({
        id: def.id, title: def.title, unit: def.unit, formula: def.formula,
        value, threshold: th, severity, measurable: true, direction: def.direction,
      });

      if (SEV_RANK[severity] >= this.floor && severity !== 'ok') {
        const finding = this._findingFor(def, value, th, severity, snapshot);
        findings.push(finding);
        this.stats.findings++;
        if (severity === 'critical') this.stats.critical++;
        else if (severity === 'warn') this.stats.warnings++;
      }
    }

    const sorted = sortFindings(findings).slice(0, this.cfg.maxFindings);
    const result = { at, clauses, findings: sorted, gaps, errors };

    // The strategist reports on itself; the lawyer checks the report. This is
    // the only place a self-report is treated as a claim rather than a fact.
    try {
      const rev = reviewStrategist(snapshot?.strategist, snapshot, {
        now: at,
        intervalMs: this.cfg.strategistIntervalMs,
        maxActionsPerHour: this.cfg.strategistMaxActionsPerHour,
        overlayTtlMs: this.cfg.strategistOverlayTtlMs,
        limits: snapshot?.limits,
      });
      result.strategistReview = rev;
      this.stats.strategistChecks = (this.stats.strategistChecks || 0) + rev.checked;
      for (const f of rev.findings) {
        if (SEV_RANK[f.severity] >= this.floor && f.severity !== 'ok' && f.severity !== 'info') {
          const finding = makeFinding({
            clause: 'strategist_integrity',
            title: 'صحت گزارش استراتژیست',
            severity: f.severity,
            evidence: { code: f.code, message: f.message, ...(f.evidence || {}) },
            impactEstimate: { annualUsd: null, basis: f.message },
            recommendation: 'گزارش استراتژیست با اعداد موتور نمی‌خواند؛ پیش از ادامه‌ی معامله بررسی شود.',
          });
          result.findings.push(finding);
          this.stats.findings++;
          if (f.severity === 'critical') this.stats.critical++;
          else this.stats.warnings++;
        }
      }
      result.findings = sortFindings(result.findings).slice(0, this.cfg.maxFindings);
    } catch (e) {
      // A broken review must not blind the rest of the audit.
      this.log.warn(`lawyer strategist review failed: ${e.message}`);
    }

    this.lastAudit = result;
    this.stats.audits++;

    // Open findings = everything currently breaching, worst first.
    this.openFindings = sorted;

    // Record it for the next generation.
    this._record(result, snapshot);

    // Tell jev, so the next decision can account for it.
    this._notifyJev(result);

    // The one power that can stop a trade, and only when explicitly granted.
    this._maybeObject(result);

    return result;
  }

  /**
   * Resolve a clause's thresholds.
   *
   * Precedence: per-clause config override > the clause's own default. The
   * DSR clause additionally reads `lawyer.dsrThreshold`, because that number is
   * a policy decision the operator should be able to set in one place rather
   * than buried in a nested object.
   */
  _thresholdFor(def) {
    const base = this.thresholds[def.id] || def.threshold || {};
    if (def.id === 'deflated_sharpe') {
      const t = num(this.cfg.dsrThreshold);
      if (Number.isFinite(t)) {
        // Keep the critical band proportional: a threshold of 0.99 should not
        // leave critical at 0.80, or every mild miss becomes an emergency.
        return { ...base, warn: t, critical: Math.max(0, t - 0.15) };
      }
    }
    return base;
  }

  _globalThresholds() {
    return {
      benchmarkAnnualPct: num(this.cfg.benchmarkAnnualPct),
      latencyBudgetMs: num(this.cfg.latencyBudgetMs),
      dsrThreshold: num(this.cfg.dsrThreshold),
      // Strategist limits, read from live config so the clause and the
      // authority can never drift apart.
      maxActionsPerHour: num(this.cfg.strategistMaxActionsPerHour),
      killSwitchDrawdownPct: num(this.cfg.killSwitchDrawdownPct),
    };
  }

  /**
   * Turn a breach into a finding with a defensible impact estimate.
   * The estimate is derived from the measured value, never guessed separately.
   */
  _findingFor(def, value, th, severity, snapshot) {
    const equity = num(snapshot?.risk?.equity) || 0;
    const bench = num(this.cfg.benchmarkAnnualPct) || 0;
    let impact = null;
    let recommendation = '';

    switch (def.id) {
      case 'capital_utilisation': {
        // Idle capital × benchmark = the yield being left on the table.
        const idlePct = Math.max(0, 100 - value);
        const annual = (equity * idlePct * bench) / 10000;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${idlePct.toFixed(1)}٪ سرمایه بیکار × بازده مرجع ${bench}٪ × ${equity.toFixed(0)}$`,
        };
        recommendation = `سرمایه‌ی بیکار را کم کنید: یا تعداد پوزیشن را بالا ببرید یا اندازه‌ی هر پوزیشن را. هدف: بالای ${th.warn}٪.`;
        break;
      }
      case 'opportunity_cost': {
        const annual = (equity * value) / 100;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${value}٪ بازده ازدست‌رفته × ${equity.toFixed(0)}$`,
        };
        recommendation = 'هزینه‌ی فرصت بالاست؛ سرمایه‌ی راکد را به کار بگیرید یا بازده مرجع را بازبینی کنید.';
        break;
      }
      case 'cost_efficiency': {
        const gross = num(snapshot?.pnl?.grossProfit) || 0;
        const excessPct = Math.max(0, value - th.warn);
        const annual = (gross * excessPct) / 100;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${excessPct.toFixed(1)}٪ هزینه‌ی مازاد × سود ناخالص ${gross.toFixed(0)}$`,
        };
        recommendation = 'کارمزد/اسلیپیج بالاست: سفارش‌ها را کوچک‌تر و با limit بفرستید، یا جفت‌های نقدشونده‌تر انتخاب کنید.';
        break;
      }
      case 'time_productivity': {
        const annual = (equity * (value / 100) * bench) / 100;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${value}٪ زمان بلاک × بازده مرجع ${bench}٪ × ${equity.toFixed(0)}$`,
        };
        recommendation = 'زمان بلاک زیاد است: علت halt/cooldown/veto را بررسی کنید و مدت آن را کوتاه کنید.';
        break;
      }
      case 'risk_adjusted_return': {
        const risk = num(snapshot?.risk?.consumedUsd) || 0;
        const target = th.warn;
        const annual = Math.max(0, (target - value) * risk);
        impact = {
          annualUsd: round(annual, 2),
          basis: `کمبود ${(target - value).toFixed(3)}R × ریسک مصرف‌شده ${risk.toFixed(0)}$`,
        };
        recommendation = 'بازده به ازای ریسک پایین است: استاپ‌ها را دقیق‌تر بگذارید یا از معاملات کم‌بازده صرف‌نظر کنید.';
        break;
      }
      case 'concentration': {
        const excessPct = Math.max(0, value - th.warn);
        const annual = (equity * excessPct * bench) / 10000;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${excessPct.toFixed(1)}٪ تمرکز مازاد × ${equity.toFixed(0)}$`,
        };
        recommendation = 'تمرکز را کم کنید: سقف وزن هر دارایی و هر جهت را رعایت کنید.';
        break;
      }
      case 'operational_health': {
        const annual = (equity * (value / 100) * bench) / 100;
        impact = {
          annualUsd: round(annual, 2),
          basis: `${value}٪ افت عملیاتی × بازده مرجع ${bench}٪ × ${equity.toFixed(0)}$`,
        };
        recommendation = 'خطاهای ماژول و چرخه‌های ازدست‌رفته را رفع کنید؛ تأخیر را زیر بودجه نگه دارید.';
        break;
      }
      case 'charter_compliance': {
        impact = {
          annualUsd: null,
          basis: `${value} سقف نقض شده — ریسک نقض منشور قابل قیمت‌گذاری نیست`,
        };
        recommendation = 'سقف‌های نقض‌شده را فوراً بازگردانید؛ این تخلف انطباقی است، نه بهینه‌سازی.';
        break;
      }
      case 'deflated_sharpe': {
        // The impact of a false edge is the capital you would deploy on it.
        // We price it as the equity at risk, not as a yield: a strategy that
        // only looks profitable is a way to lose the whole book, not a way to
        // earn a little less.
        const K = num(snapshot?.performance?.K);
        const T = arr(snapshot?.performance?.returns).length;
        impact = {
          annualUsd: null,
          basis:
            `DSR=${value} < آستانه ${th.warn} — با K=${K ?? '؟'} آزمون و T=${T} مشاهده، ` +
            'این شارپ از آنچه شانس به‌تنهایی تولید می‌کند قابل تفکیک نیست',
        };
        recommendation =
          'این edge اثبات نشده است: یا نمونه را بلندتر کنید (T بیشتر)، یا تعداد آزمون‌ها را کم کنید، ' +
          'یا استراتژی را با داده‌ی خارج از نمونه بسنجید. تا آن زمان اندازه‌ی پوزیشن را کوچک نگه دارید.';
        break;
      }
      default:
        recommendation = `مقدار ${value} از آستانه ${th.warn} عبور کرده است.`;
    }

    return makeFinding({
      clause: def.id,
      title: def.title,
      severity,
      evidence: {
        value,
        threshold: th,
        unit: def.unit,
        formula: def.formula,
        direction: def.direction,
      },
      impactEstimate: impact,
      recommendation,
    });
  }

  // -------------------------------------------------------------- objections
  /**
   * File a formal objection. Recorded, and pushed to jev as a veto request.
   *
   * @param {object} issue  a finding, or { clause, reason, severity }
   * @returns {object} the objection
   */
  object(issue) {
    const obj = {
      id: `O-${String(this.objections.length + 1).padStart(4, '0')}`,
      at: this.clock(),
      clause: issue?.clause || 'unspecified',
      severity: issue?.severity || 'warn',
      reason: issue?.reason || issue?.recommendation || 'اعتراض وکیل',
      findingId: issue?.id || null,
      veto: false,
    };
    this.objections.push(obj);
    this.stats.objections++;
    if (this.objections.length > 100) this.objections.shift();

    this.log.warn(`lawyer objection ${obj.id}: ${obj.clause} — ${obj.reason}`);
    return obj;
  }

  /**
   * The only path by which the lawyer can stop a trade.
   *
   * Requires BOTH: autoObject enabled in config, AND a critical finding.
   * A warning never vetoes. This is deliberately hard to trigger.
   */
  _maybeObject(result) {
    if (!this.cfg.autoObject) return;
    const critical = result.findings.filter((f) => f.severity === 'critical');
    if (!critical.length) return;

    for (const f of critical) {
      const obj = this.object({
        clause: f.clause,
        severity: 'critical',
        reason: f.recommendation,
        id: f.id,
      });
      obj.veto = true;
      this.stats.vetoes++;
      this.alerts.push({
        at: obj.at,
        kind: 'veto',
        clause: f.clause,
        message: `وتوی وکیل: ${f.title} — ${f.recommendation}`,
      });
    }
    if (this.alerts.length > 50) this.alerts = this.alerts.slice(-50);
  }

  /** Does the lawyer currently hold a veto? jev asks this before trading. */
  get vetoActive() {
    if (!this.cfg.autoObject) return false;
    return this.objections.some((o) => o.veto && this.clock() - o.at < 60 * 60 * 1000);
  }

  /** The reason for the active veto, for the log. */
  get vetoReason() {
    const o = [...this.objections].reverse().find((x) => x.veto);
    return o ? `${o.clause}: ${o.reason}` : null;
  }

  // ------------------------------------------------------------- recommend
  /** Concrete proposals, worst finding first. */
  recommend() {
    const findings = this.openFindings.length
      ? this.openFindings
      : (this.lastAudit?.findings || []);
    return findings
      .filter((f) => f.severity === 'critical' || f.severity === 'warn')
      .map((f) => ({
        clause: f.clause,
        severity: f.severity,
        action: f.recommendation,
        estimatedAnnualUsd: f.impactEstimate?.annualUsd ?? null,
      }));
  }

  /** The current brief, rebuilt from the last audit. */
  brief() {
    if (!this.lastAudit) return null;
    const b = buildBrief(this.lastAudit, {
      equity: this._lastEquity,
      benchmarkAnnualPct: this.cfg.benchmarkAnnualPct,
    });
    this.lastBrief = b;
    return b;
  }

  // ---------------------------------------------------------------- plumbing
  _record(result, snapshot) {
    if (!this.ledger || !this.ledger.enabled) return;
    try {
      this.ledger.write({
        type: 'lawyer.audit',
        cycleId: `L${result.at.toString(36)}`,
        input: snapshot,
        clauses: result.clauses.map((c) => ({
          id: c.id, value: c.value, threshold: c.threshold,
          severity: c.severity, measurable: c.measurable,
        })),
        findings: result.findings.map((f) => ({
          id: f.id, clause: f.clause, severity: f.severity,
          impactUsd: f.impactEstimate?.annualUsd ?? null,
          recommendation: f.recommendation,
        })),
        gaps: result.gaps.map((g) => ({ clause: g.clause, missing: g.evidence.missing })),
        errors: result.errors.map((e) => ({ clause: e.clause, error: e.evidence.error })),
        recommendations: this.recommend(),
      });
    } catch (e) {
      this.log.warn(`lawyer ledger write failed: ${e.message}`);
    }
  }

  /** Push findings to jev. Never throws, never blocks. */
  _notifyJev(result) {
    if (!this.jev) return;
    try {
      const critical = result.findings.filter((f) => f.severity === 'critical');
      if (!critical.length) return;
      if (typeof this.jev.onLawyerFindings === 'function') {
        this.jev.onLawyerFindings(critical, this);
      } else if (this.jev.bus && typeof this.jev.bus.emit === 'function') {
        this.jev.bus.emit('lawyer.findings', { findings: critical, veto: this.vetoActive });
      }
    } catch (e) {
      this.log.warn(`lawyer could not notify jev: ${e.message}`);
    }
  }

  /** Run one audit and remember the equity for the brief. */
  run(snapshot) {
    // Reading equity can itself throw on a hostile snapshot (a getter, a proxy).
    // The audit must survive that, so the read is guarded separately.
    try {
      this._lastEquity = num(snapshot?.risk?.equity);
    } catch {
      this._lastEquity = null;
    }
    try {
      return this.audit(snapshot);
    } catch (e) {
      // audit() is written not to throw; this is the belt to that suspenders.
      this.stats.failedAudits++;
      this.log.error(`lawyer audit failed: ${e.message}`);
      return { at: this.clock(), clauses: [], findings: [], gaps: [], errors: [] };
    }
  }

  /** Start the periodic audit. Returns false when disabled. */
  start(getSnapshot) {
    if (!this.enabled) return false;
    if (this._timer) return true;
    // 60s is the floor: an audit is a full pass over every clause, and running
    // it more often than once a minute would spend the CPU on measurement
    // rather than on trading.
    const interval = Math.max(60000, Number(this.cfg.auditIntervalMs) || DEFAULTS.auditIntervalMs);
    const runOnce = () => {
      try {
        const snap = typeof getSnapshot === 'function' ? getSnapshot() : null;
        if (snap) this.run(snap);
      } catch (e) {
        this.log.warn(`lawyer periodic audit failed: ${e.message}`);
      }
    };
    this._timer = setInterval(runOnce, interval);
    if (this._timer.unref) this._timer.unref();
    this.log.info(`lawyer: auditing every ${Math.round(interval / 1000)}s`);
    // Audit once at boot. Waiting a full interval means the strategist can
    // report a dozen times before anyone checks whether those reports are
    // true — and the first audit is the one that catches a bad first cycle.
    runOnce();
    return true;
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }

  /** Dashboard view. */
  snapshot() {
    const b = this.lastBrief || (this.lastAudit ? this.brief() : null);
    return {
      enabled: this.enabled,
      autoObject: Boolean(this.cfg.autoObject),
      auditIntervalMs: this.cfg.auditIntervalMs,
      severityThreshold: this.cfg.severityThreshold,
      vetoActive: this.vetoActive,
      vetoReason: this.vetoReason,
      lastAuditAt: this.lastAudit?.at || null,
      brief: b ? toPanel(b) : null,
      strategistReview: this.lastAudit?.strategistReview
        ? {
            ok: this.lastAudit.strategistReview.ok,
            worst: this.lastAudit.strategistReview.worst || 'ok',
            checked: this.lastAudit.strategistReview.checked,
            findings: (this.lastAudit.strategistReview.findings || []).slice(0, 10),
          }
        : null,
      openFindings: this.openFindings.slice(0, 20).map((f) => ({
        id: f.id, clause: f.clause, title: f.title, severity: f.severity,
        impactUsd: f.impactEstimate?.annualUsd ?? null,
      })),
      objections: this.objections.slice(-10),
      alerts: this.alerts.slice(-10),
      ...this.stats,
    };
  }

  /** Terminal rendering of the current brief. */
  text() {
    const b = this.brief();
    return b ? toText(b) : 'هنوز audit ای انجام نشده است.';
  }
}

module.exports = { Lawyer, DEFAULTS, toText, toPanel, buildBrief };
