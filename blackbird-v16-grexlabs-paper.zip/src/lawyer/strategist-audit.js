'use strict';
/**
 * BlackBird — the lawyer's review of the strategist.
 *
 * The strategist reports on itself every 3m30s. A self-report is a claim, not
 * evidence. This module checks the claim against the engine's own numbers and
 * files a finding when they disagree.
 *
 * What it checks, and why each one matters:
 *
 *   1. SEVERITY HONESTY. If the strategist says "green" while the drawdown is
 *      past the kill switch, the report is wrong — and a wrong green is worse
 *      than a wrong red, because nobody looks at a green.
 *   2. AUTHORITY COMPLIANCE. Every self-execution must appear in the authority's
 *      audit trail with a matching id. An action with no audit entry is an
 *      unsupervised change to the book.
 *   3. RATE LIMIT. More actions in an hour than the authority allows means the
 *      limit was bypassed, whatever the audit says.
 *   4. OVERLAY EXPIRY. A crisis overlay that outlives its TTL is a permanent,
 *      invisible change to the strategy.
 *   5. SILENCE. A strategist that has not reported for many intervals is not
 *      "calm", it is dead — and a dead strategist looks exactly like a calm one.
 *
 * Every check returns a finding with the measured value and the threshold, so
 * the operator can verify it by hand. Nothing here estimates.
 */

const SEV = { ok: 0, info: 1, warn: 2, critical: 3 };

function num(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function arr(v) {
  return Array.isArray(v) ? v : [];
}

/**
 * Review one strategist snapshot against the engine status.
 *
 * @param {object} strategist  engine.status().strategist
 * @param {object} status      the full engine status
 * @param {object} [opts]      { now, intervalMs, maxActionsPerHour, overlayTtlMs }
 * @returns {{findings: Array, ok: boolean, checked: number}}
 */
function review(strategist, status, opts = {}) {
  const findings = [];
  const now = num(opts.now) ?? Date.now();
  const intervalMs = num(opts.intervalMs) ?? 210000;
  const maxActions = num(opts.maxActionsPerHour) ?? 6;
  const ttl = num(opts.overlayTtlMs) ?? 30 * 60 * 1000;

  const add = (severity, code, message, evidence) => {
    findings.push({ severity, code, message, evidence: evidence || null, at: now });
  };

  if (!strategist) {
    add('info', 'strategist_absent', 'the strategist is not constructed in this build');
    return { findings, ok: true, checked: 0 };
  }

  if (!strategist.enabled) {
    add('info', 'strategist_disabled', 'the strategist is off (STRATEGIST_ENABLED not set)');
    return { findings, ok: true, checked: 0 };
  }

  let checked = 0;

  // ------------------------------------------------- 1. severity honesty
  const claimed = String(strategist.severity || 'unknown');
  const risk = status?.risk || {};
  const limits = opts.limits || {};
  const dd = num(risk.drawdownPct);
  const killPct = num(limits.killSwitchDrawdownPct) != null ? num(limits.killSwitchDrawdownPct) * 100 : null;

  if (claimed === 'green' && dd != null && killPct != null && killPct > 0 && dd >= killPct * 0.8) {
    checked++;
    add('critical', 'strategist_false_green',
      `the strategist reports green while drawdown is ${dd.toFixed(2)}% — ${((dd / killPct) * 100).toFixed(0)}% of the kill switch`,
      { claimed, drawdownPct: dd, killSwitchPct: killPct });
  } else if (claimed === 'green' && risk.halted) {
    checked++;
    add('critical', 'strategist_false_green',
      'the strategist reports green while the risk engine is halted',
      { claimed, halted: true, haltReason: risk.haltReason || null });
  } else if (claimed !== 'unknown') {
    checked++;
  }

  // ------------------------------------------- 2. authority compliance
  const authority = strategist.authority || {};
  const audit = arr(authority.audit);
  const applied = audit.filter((a) => a && a.applied);
  const recent = arr(strategist.recent);
  const executions = recent.filter((r) => r && r.type === 'self_execution');

  for (const ex of executions) {
    checked++;
    const id = ex.authority;
    const match = applied.find((a) => a.id === id);
    if (!match) {
      add('critical', 'strategist_unlogged_action',
        `self-execution "${ex.action}" has no matching entry in the authority audit trail (id ${id || 'missing'})`,
        { action: ex.action, authorityId: id || null });
    } else if (match.action !== ex.action) {
      add('critical', 'strategist_action_mismatch',
        `the report says "${ex.action}" but the audit trail records "${match.action}" for ${id}`,
        { reported: ex.action, audited: match.action, authorityId: id });
    }
  }

  // ------------------------------------------------------ 3. rate limit
  const lastHour = applied.filter((a) => num(a.at) != null && now - num(a.at) <= 3600000);
  checked++;
  if (lastHour.length > maxActions) {
    add('critical', 'strategist_rate_limit',
      `${lastHour.length} crisis actions in the last hour, above the limit of ${maxActions}`,
      { actionsLastHour: lastHour.length, maxActionsPerHour: maxActions });
  }

  // --------------------------------------------------- 4. overlay expiry
  const overlay = strategist.overlay;
  if (overlay) {
    checked++;
    const expiresAt = num(overlay.expiresAt);
    if (expiresAt != null && now > expiresAt + 60000) {
      add('critical', 'strategist_overlay_stuck',
        `a crisis overlay is still active ${Math.round((now - expiresAt) / 1000)}s past its expiry — the strategy is silently altered`,
        { expiresAt, actions: arr(overlay.actions) });
    }
    const m = num(overlay.multiplier);
    if (m != null && m > 1) {
      add('critical', 'strategist_overlay_raises_risk',
        `the crisis overlay multiplier is ${m} — a crisis action may never raise exposure`,
        { multiplier: m });
    }
  }

  // ------------------------------------------------------------ 5. silence
  const lastCycleAt = num(strategist.lastCycleAt);
  const startedAt = num(strategist.startedAt);
  checked++;
  if (lastCycleAt == null) {
    // A strategist that was started a moment ago has not had time to report.
    // Flagging it as "never ran" at boot is a false alarm on every single
    // restart, and a warning that always fires is a warning nobody reads.
    const graceMs = intervalMs * 2;
    const age = startedAt != null ? now - startedAt : null;
    if (age == null || age > graceMs) {
      add('warn', 'strategist_never_ran', 'the strategist is enabled but has not completed a single cycle');
    }
  } else if (now - lastCycleAt > intervalMs * 4) {
    add('warn', 'strategist_silent',
      `the strategist has not reported for ${Math.round((now - lastCycleAt) / 1000)}s (${Math.round((now - lastCycleAt) / intervalMs)} intervals)`,
      { lastCycleAt, intervalMs });
  }

  // ------------------------------------------- 6. refusals are evidence
  const refused = arr(authority.audit).filter((a) => a && a.applied === false);
  if (refused.length >= 3) {
    checked++;
    add('warn', 'strategist_repeated_refusals',
      `the authority refused ${refused.length} strategist actions — the strategist is asking for things it may not do`,
      { refusals: refused.slice(-3).map((r) => ({ action: r.action, reason: r.reason })) });
  }

  const worst = findings.reduce((w, f) => (SEV[f.severity] > SEV[w] ? f.severity : w), 'ok');
  return { findings, ok: SEV[worst] < SEV.warn, worst, checked };
}

module.exports = { review, SEV };
