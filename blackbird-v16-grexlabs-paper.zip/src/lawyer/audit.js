#!/usr/bin/env node
'use strict';
/**
 * BlackBird — manual lawyer audit.
 *
 *   node src/lawyer/audit.js              audit the live engine state
 *   node src/lawyer/audit.js --json       machine-readable
 *   node src/lawyer/audit.js --demo       audit a synthetic snapshot (no engine)
 *
 * For debugging by hand: run it, read the brief, see which clause is red and
 * what it is estimated to cost.
 */

const path = require('node:path');
const { Lawyer } = require('./lawyer');
const { toText } = require('./report');

const argv = process.argv.slice(2);
const JSON_OUT = argv.includes('--json');
const DEMO = argv.includes('--demo');

/** A snapshot that exercises every clause with plausible numbers. */
function demoSnapshot() {
  return {
    risk: {
      equity: 5000,
      drawdownPct: 0.4,
      consumedUsd: 900,
    },
    positions: [
      { symbol: 'BNB', side: 'long', notional: 500 },
      { symbol: 'AVAX', side: 'long', notional: 500 },
      { symbol: 'XRP', side: 'long', notional: 500 },
      { symbol: 'SOL', side: 'long', notional: 500 },
      { symbol: 'DOGE', side: 'long', notional: 500 },
      { symbol: 'ADA', side: 'long', notional: 500 },
    ],
    pnl: { net: 13.82, grossProfit: 42.1 },
    fees: { total: 6.4 },
    slippage: { total: 3.1 },
    time: { activeMs: 5 * 3600 * 1000, blockedMs: 1 * 3600 * 1000 },
    cycles: { expected: 72, missed: 2 },
    latency: { p99Ms: 1400 },
    modules: [
      { name: 'rotator', errorCount: 0 },
      { name: 'risk', errorCount: 0 },
      { name: 'portfolio', errorCount: 1 },
      { name: 'broker', errorCount: 0 },
      { name: 'witness', errorCount: 0 },
      { name: 'auditor', errorCount: 0 },
      { name: 'reporter', errorCount: 0 },
    ],
    limits: {
      maxOpenPositions: 8,
      maxSymbolExposurePct: 25,
      maxNetExposurePct: 100,
      killSwitchDrawdownPct: 12,
    },
  };
}

/** Try to read the live engine; fall back to demo with a clear note. */
function liveSnapshot() {
  try {
    const { loadConfig } = require('../config');
    const cfg = loadConfig();
    // The engine is not started here on purpose: an audit must not boot a
    // trading loop. If a state file exists, use it.
    const fs = require('node:fs');
    const statePath = path.join(cfg?.runtime?.dataDir || 'data', 'state.json');
    if (fs.existsSync(statePath)) {
      const raw = JSON.parse(fs.readFileSync(statePath, 'utf8'));
      return { snapshot: raw, source: statePath };
    }
    return { snapshot: null, source: null };
  } catch (e) {
    return { snapshot: null, source: null, error: e.message };
  }
}

function main() {
  let snapshot;
  let source;

  if (DEMO) {
    snapshot = demoSnapshot();
    source = 'demo';
  } else {
    const live = liveSnapshot();
    if (live.snapshot) {
      snapshot = live.snapshot;
      source = live.source;
    } else {
      snapshot = demoSnapshot();
      source = 'demo (no live state found)';
    }
  }

  const lawyer = new Lawyer({
    cfg: { enabled: true, autoObject: false, benchmarkAnnualPct: 5 },
    log: { info() {}, warn() {}, error() {}, debug() {} },
  });

  const result = lawyer.run(snapshot);
  const brief = lawyer.brief();

  if (JSON_OUT) {
    console.log(JSON.stringify({ source, brief, audit: result }, null, 2));
    return;
  }

  console.log(`\nمنبع snapshot: ${source}`);
  console.log(toText(brief));
}

main();
