#!/usr/bin/env node
'use strict';
/**
 * BlackBird Trader — entry point.
 *
 *   node src/index.js                  paper trading with live market data
 *   node src/index.js --exit-after=60  stop after N seconds
 *   node src/index.js --report-now     write a report right after boot
 *
 * If startup fails, a readable banner + crash.log are produced so the failure
 * is diagnosable from a hosting panel console.
 */
const fs = require('node:fs');
const path = require('node:path');

const argv = process.argv.slice(2);
const flag = (name) => argv.includes(`--${name}`);
const opt = (name, dflt) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.split('=')[1] : dflt;
};

function banner(extra) {
  const v = process.versions.node;
  console.log('');
  console.log('  ╔══════════════════════════════════════════════╗');
  console.log('  ║   🐦  B L A C K B I R D   T R A D E R        ║');
  console.log(`  ║   node v${String(v).padEnd(38)}║`);
  console.log(`  ║   ${String(extra).padEnd(42)}║`);
  console.log('  ╚══════════════════════════════════════════════╝');
  console.log('');
}

function fatal(title, err) {
  const msg = err && err.message ? err.message : String(err);
  console.log('');
  console.log('  ✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖');
  console.log('  ✖  ' + title);
  console.log('  ✖  ' + msg);
  if (err && err.problems) for (const p of err.problems) console.log('  ✖   - ' + p);
  console.log('  ✖');
  console.log('  ✖  برای تشخیص دقیق‌تر این را در کنسول اجرا کنید:');
  console.log('  ✖      node doctor.js');
  console.log('  ✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖✖');
  try {
    const log = path.join(__dirname, '..', 'crash.log');
    fs.appendFileSync(
      log,
      `\n[${new Date().toISOString()}] ${title}: ${msg}\nnode ${process.version}\ncwd ${process.cwd()}\n${err && err.stack ? err.stack : ''}\n`
    );
    console.log(`\n  (جزئیات در crash.log ذخیره شد)`);
  } catch { /* ignore */ }
}

async function main() {
  const major = Number(process.versions.node.split('.')[0]);
  banner(`paper mode | ${major < 18 ? 'نسخه‌ی قدیمی Node' : 'ok'}`);

  let engine;
  try {
    const { Engine } = require('./engine');
    engine = new Engine();
    await engine.init();
  } catch (e) {
    fatal('STARTUP FAILED — راه‌اندازی شکست خورد', e);
    process.exitCode = 2;
    // keep the process alive briefly so the panel shows the message
    setTimeout(() => process.exit(2), 1500);
    return;
  }

  engine.start();
  if (flag('report-now')) setTimeout(() => engine.forceReport(), 5000);

  const shutdown = async (sig) => {
    console.log(`\n[${sig}] stopping…`);
    try { await engine.stop(sig); } catch { /* ignore */ }
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (e) => {
    engine.log.error(`unhandled rejection: ${e?.message || e}`);
  });
  process.on('uncaughtException', (e) => {
    engine.log.error(`uncaught exception: ${e.message}`, { stack: e.stack?.split('\n').slice(0, 4) });
    fatal('UNCAUGHT EXCEPTION — خطای پیش‌بینی‌نشده', e);
  });

  const reportAfter = Number(opt('report-after', 0));
  if (reportAfter > 0) setTimeout(() => { engine.log.info('forced report'); engine.forceReport(); }, reportAfter * 1000);

  const exitAfter = Number(opt('exit-after', 0));
  if (exitAfter > 0) setTimeout(() => shutdown(`exit-after=${exitAfter}s`), exitAfter * 1000);
}

main();
