'use strict';
/**
 * Operator probes — run from the AUTHENTICATED panel only, never from the public page.
 *
 * Each result is { id, label, level: green|yellow|red, cause, latencyMs, fix }.
 * `fix` is an action or a pointer to our own docs; it is never a secret.
 * The model probe is cheap by default (configuration only). A live call to a
 * model provider costs quota, so it needs an explicit { live: true } and is
 * limited to one run per 30 seconds per process.
 */
const LIVE_MIN_GAP_MS = 30 * 1000;
let lastLiveAt = 0;

const SECRET_SHAPES = [/\bsk-[A-Za-z0-9_-]{8,}/g, /\bgsk_[A-Za-z0-9]{8,}/g, /\bAIza[0-9A-Za-z_-]{16,}/g, /\bBearer\s+[A-Za-z0-9._-]{8,}/gi, /(key|token|secret)=([^&\s]+)/gi, /https?:\/\/[^\s"']+/g];
function redact(msg) {
  let s = String(msg || '').slice(0, 300);
  for (const re of SECRET_SHAPES) s = s.replace(re, '[redacted]');
  return s;
}

function dataProbe(engine) {
  const h = engine.health ? engine.health() : null;
  if (!h) return [{ id: 'data', label: 'داده بازار', level: 'red', cause: 'موتور مقداردهی نشده است', latencyMs: null, fix: 'چند ثانیه صبر کنید و دوباره بسنجید' }];
  if (h.booting) return [{ id: 'data', label: 'داده بازار', level: 'yellow', cause: 'سیستم هنوز در حال راه‌اندازی است', latencyMs: null, fix: 'پس از اتمام راه‌اندازی دوباره بسنجید' }];
  if (!h.dataOk) return [{ id: 'data', label: 'داده بازار', level: 'red', cause: `هیچ داده‌ای از «${h.exchange}» نمی‌رسد`, latencyMs: null, fix: 'بررسی شبکه/مسدودی (کد 451/403) — DEPLOY-BOTKEEP.md' }];
  if (h.feedsDegraded > 0) return [{ id: 'data', label: 'داده بازار', level: 'yellow', cause: `${h.feedsDegraded} از ${h.feedsTotal} منبع مشکل دارد: ${h.degradedSymbols.slice(0, 5).join(', ')}`, latencyMs: null, fix: 'موتور در پس‌زمینه دوباره تلاش می‌کند؛ اگر ادامه یافت لاگ را ببینید' }];
  return [{ id: 'data', label: 'داده بازار', level: 'green', cause: 'همه‌ی منابع فعال‌اند', latencyMs: null, fix: '—' }];
}

function levelFor(r) {
  if (!r.ok) return 'red';
  if (!r.validJson || (r.latencyMs !== null && r.latencyMs > 8000)) return 'yellow';
  return 'green';
}

async function modelProbe(engine, { live = false, deps = {} } = {}) {
  const roles = engine.roles;
  const out = [];
  if (roles && roles.mapError) out.push({ id: 'rolemap', label: 'نگاشت نقش‌ها', level: 'red', cause: roles.mapError, latencyMs: null, fix: 'قالب ROLE_MAP_JSON را اصلاح کنید' });
  const rolesList = roles ? roles.roles : [];
  for (const role of rolesList) {
    const m = roles.resolve(role);
    out.push({ id: `role:${role}`, label: `نقش ${role}`, level: m ? 'green' : 'yellow', cause: m ? 'نگاشت تعریف شده است' : 'برای این نقش مدلی تعریف نشده است', latencyMs: null, fix: m ? '—' : 'نگاشت را در ROLE_MAP_JSON (یا Worker) اضافه کنید' });
  }
  if (!live) return out;
  const t = Date.now();
  if (t - lastLiveAt < LIVE_MIN_GAP_MS) {
    out.push({ id: 'live', label: 'تست زنده مدل', level: 'yellow', cause: 'برای حفظ سهمیه، تست زنده هر ۳۰ ثانیه یک‌بار مجاز است', latencyMs: null, fix: 'کمی بعد دوباره تلاش کنید' });
    return out;
  }
  lastLiveAt = t;
  const createProvider = deps.createProvider || require('../jev/providers').createProvider;
  const seen = new Set();
  for (const role of rolesList) {
    const m = roles.resolve(role);
    if (!m) continue;
    const k = `${m.provider}/${m.model}`;
    if (seen.has(k)) continue; // one call per distinct model, however many roles share it
    seen.add(k);
    const started = Date.now();
    try {
      const p = createProvider({ provider: m.provider, model: m.model, timeoutMs: 15000 }, { env: process.env });
      await p.complete({ messages: [{ role: 'user', content: 'Reply with the JSON {"ok":true}' }], model: m.model, timeoutMs: 15000 });
      const ms = Date.now() - started;
      out.push({ id: `live:${role}`, label: `تست زنده (${role})`, level: ms > 8000 ? 'yellow' : 'green', cause: ms > 8000 ? 'پاسخ کند است' : 'پاسخ دریافت شد', latencyMs: ms, fix: ms > 8000 ? 'مسیر جایگزین یا مدل سریع‌تر را بررسی کنید' : '—' });
    } catch (e) {
      out.push({ id: `live:${role}`, label: `تست زنده (${role})`, level: 'red', cause: redact(e.message), latencyMs: Date.now() - started, fix: 'کلید/سهمیه/شبکه را بررسی کنید — JEV.md' });
    }
  }
  return out;
}

async function runProbe(engine, { target = 'data', live = false, deps } = {}) {
  if (target === 'data') return dataProbe(engine);
  if (target === 'models') return modelProbe(engine, { live, deps });
  return null;
}

module.exports = { runProbe, redact, levelFor, dataProbe };
