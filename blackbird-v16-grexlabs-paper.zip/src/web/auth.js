'use strict';

const crypto = require('node:crypto');

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function verifyTelegramInitData(initData, botToken, allowedUserIds = []) {
  if (!initData || !botToken) return { ok: false, reason: 'missing_init_data' };
  const p = new URLSearchParams(initData);
  const hash = p.get('hash');
  const authDate = Number(p.get('auth_date'));
  if (!hash || !Number.isFinite(authDate) || Math.abs(Date.now() / 1000 - authDate) > 86400) return { ok: false, reason: 'expired_or_invalid_init_data' };
  p.delete('hash');
  const check = [...p.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = crypto.createHmac('sha256', secret).update(check).digest('hex');
  if (!safeEqual(expected, hash)) return { ok: false, reason: 'bad_telegram_signature' };
  let user = null;
  try { user = p.get('user') ? JSON.parse(p.get('user')) : null; } catch { return { ok: false, reason: 'bad_telegram_user' }; }
  const allowed = allowedUserIds.map(String).filter(Boolean);
  if (!allowed.length || !user?.id || !allowed.includes(String(user.id))) return { ok: false, reason: 'telegram_user_not_allowed' };
  return { ok: true, user };
}

function authorizeControl(req, cfg) {
  const expected = process.env.ADMIN_TOKEN || process.env.SERVER_TOKEN || cfg.server?.token;
  const supplied = req.headers['x-admin-token'] || String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (expected && safeEqual(supplied, expected)) return { ok: true, method: 'token' };
  const initData = req.headers['x-telegram-init-data'];
  const t = cfg.notifications?.telegram;
  const verified = verifyTelegramInitData(initData, t?.botToken, t?.controlUserIds || []);
  return verified.ok ? { ok: true, method: 'telegram', user: verified.user } : { ok: false, reason: 'control_auth_required' };
}

module.exports = { authorizeControl, verifyTelegramInitData };
