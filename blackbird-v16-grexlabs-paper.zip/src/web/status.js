'use strict';
/**
 * BlackBird — HTTP status panel.
 * Free hosts often need a bound port, and the user needs to see the engine from
 * a phone. The public side serves allow-listed, read-only telemetry; everything
 * operational (full status, reports, probes, control) requires an admin token or a
 * verified Telegram Mini App identity on every request. See src/web/public.js.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { authorizeControl } = require('./auth');

function readBody(req, limit = 16384) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => { body += chunk; if (body.length > limit) reject(new Error('request too large')); });
    req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('invalid JSON')); } });
    req.on('error', reject);
  });
}

/**
 * Work out the address a human can actually open, or return null when we
 * genuinely cannot know it.
 *
 * Inside a container the public hostname is not discoverable: SERVER_IP is the
 * node's *private* address (Pterodactyl docs are explicit that it is not the
 * public IP when the node sits behind NAT), and the panel's domain is not
 * exposed to the process. So we only print a URL when the operator has told us
 * one, and otherwise we print a clearly-marked placeholder. Guessing a hostname
 * would be worse than admitting we do not know it.
 */
function resolvePublicUrl(port) {
  const explicit = String(process.env.BB_PUBLIC_URL || '').trim();
  if (explicit) {
    const base = explicit.replace(/\/+$/, '');
    // If the operator gave a bare host, append the port; if they gave a full URL
    // with a path, leave it alone.
    return /^https?:\/\//i.test(base) ? base : `http://${base}:${port}`;
  }
  // A platform that publishes a full URL (Render, Railway, Fly, Heroku) sets
  // one of these. Use it when present — it is authoritative, not a guess.
  for (const key of ['PUBLIC_URL', 'RENDER_EXTERNAL_URL', 'RAILWAY_PUBLIC_DOMAIN', 'FLY_APP_NAME']) {
    const v = String(process.env[key] || '').trim();
    if (!v) continue;
    if (/^https?:\/\//i.test(v)) return v.replace(/\/+$/, '');
    if (key === 'FLY_APP_NAME') return `https://${v}.fly.dev`;
    return `https://${v}`;
  }
  return null;
}

const { PublicView } = require('./public');
const { RateLimiter } = require('./ratelimit');
const { runProbe } = require('./probe');

const ASSET_TYPES = {
  'base.css': 'text/css; charset=utf-8',
  'gesture.js': 'application/javascript; charset=utf-8',
  'welcome.js': 'application/javascript; charset=utf-8',
  'dashboard.js': 'application/javascript; charset=utf-8',
  'ops.js': 'application/javascript; charset=utf-8',
};
// Binary assets are served as Buffers, never as utf8 text: reading a JPEG with
// 'utf8' corrupts every byte above 0x7f and the browser shows a broken image.
// The list is an allow-list for the same reason the text assets are: a public
// route must never be able to read an arbitrary path off disk.
const BINARY_ASSETS = {
  'img/logo.jpg': 'image/jpeg',
  'img/emblem.png': 'image/png',
  'img/emblem-512.png': 'image/png',
  'img/nandark.jpg': 'image/jpeg',
  'img/lockup-wide.jpg': 'image/jpeg',
  'img/icon-180.png': 'image/png',
  'img/favicon-32.png': 'image/png',
  'img/favicon-64.png': 'image/png',
};
const assetCache = new Map();
function readStatic(rel) {
  if (!assetCache.has(rel)) assetCache.set(rel, fs.readFileSync(path.join(__dirname, rel), 'utf8'));
  return assetCache.get(rel);
}
function readStaticBinary(rel) {
  if (!assetCache.has(rel)) assetCache.set(rel, fs.readFileSync(path.join(__dirname, rel)));
  return assetCache.get(rel);
}

// One strict CSP for every response: scripts only from our own origin (no inline,
// no third-party host), nothing can be framed, nothing posts anywhere but here.
const CSP = "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";

function clientIp(req) {
  if (process.env.TRUST_PROXY) {
    const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xff) return xff;
  }
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

/**
 * Route map (see docs/PUBLIC-DASHBOARD.md):
 *
 *   PUBLIC, GET/HEAD only, no credentials, allow-listed data:
 *     /  /assets/*  /api/public/summary  /api/public/detail/:section
 *     /health  /healthz  /readyz  /ops (the login shell: it carries no data)
 *
 *   OPERATIONS, authenticated on EVERY request (token or verified Telegram identity):
 *     /ops/status  /ops/report/latest(.md)  /ops/probe  /ops/evidence
 *     /control/state  /control/propose        and the legacy /status, /report/latest(.md)
 *
 * Nothing on the public side can reach a write or control path, and nothing the
 * entrance gesture does has any bearing on who may call the operations side.
 */
function startServer(engine) {
  const cfg = engine.cfg;
  const view = new PublicView({ engine, log: engine.log.child ? engine.log.child('public') : engine.log });
  const publicLimiter = new RateLimiter({ limit: 240, windowMs: 60 * 1000 });
  const authFailures = new RateLimiter({ limit: 10, windowMs: 60 * 1000 });

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const isHead = req.method === 'HEAD';
    // A response that ends while the request body is still unread makes Node
    // destroy the socket: the caller sees "socket hang up" instead of our status
    // code, and (because the socket dies mid-stream) the NEXT request the client
    // reuses that connection for never reaches the server at all. That is why a
    // read-only guard looked like a crash from outside. Reading the body to the
    // end first lets the 405/401 answer arrive and the connection stay usable.
    // Handlers that read the body themselves have already ended the stream, so
    // waiting on 'end' resolves immediately for them.
    const drain = () =>
      new Promise((resolve) => {
        if (req.readableEnded) return resolve();
        const done = () => resolve();
        req.once('end', done);
        req.once('error', done);
        try { req.resume(); } catch { resolve(); }
      });
    const send = (code, body, type = 'application/json', extra = {}) => {
      return drain().then(() => {
        res.writeHead(code, {
          'content-type': type,
          'cache-control': 'no-store',
          'x-content-type-options': 'nosniff',
          'x-frame-options': 'DENY',
          'referrer-policy': 'no-referrer',
          'cross-origin-resource-policy': 'same-origin',
          'permissions-policy': 'camera=(), microphone=(), geolocation=()',
          'content-security-policy': CSP,
          ...extra,
        });
        if (isHead) return res.end();
        if (Buffer.isBuffer(body)) return res.end(body);
        res.end(typeof body === 'string' ? body : JSON.stringify(body, null, 2));
      });
    };
    const ip = clientIp(req);

    // ---- authenticated operations ------------------------------------------------
    const requireAuth = () => {
      if (authFailures.blocked(ip)) { send(429, { error: 'too many failed attempts' }, 'application/json', { 'retry-after': '60' }); return null; }
      const auth = authorizeControl(req, cfg);
      if (!auth.ok) { authFailures.hit(ip); send(401, { error: 'authentication required' }); return null; }
      return auth;
    };

    try {
      const p = url.pathname;
      const isOps = p === '/status' || p === '/report/latest' || p === '/report/latest.md' || p.startsWith('/ops/') || p.startsWith('/control/');
      if (isOps) {
        const auth = requireAuth();
        if (!auth) return;
        if (p === '/status' || p === '/ops/status') return req.method === 'GET' ? send(200, engine.status()) : send(405, { error: 'method not allowed' }, 'application/json', { allow: 'GET' });
        if (p === '/report/latest' || p === '/ops/report/latest') {
          const f = path.join(cfg.reporter.dir, 'latest.json');
          if (!fs.existsSync(f)) return send(404, { error: 'no report yet' });
          return send(200, fs.readFileSync(f, 'utf8'), 'application/json');
        }
        if (p === '/report/latest.md' || p === '/ops/report/latest.md') {
          const f = path.join(cfg.reporter.dir, 'latest.md');
          if (!fs.existsSync(f)) return send(404, 'no report yet', 'text/plain');
          return send(200, fs.readFileSync(f, 'utf8'), 'text/markdown; charset=utf-8');
        }
        if (p === '/ops/evidence') {
          if (!engine.evidence) return send(404, { error: 'no evidence chain' });
          return send(200, { head: engine.evidence.head(), verify: engine.evidence.verify() });
        }
        if (p === '/ops/probe') {
          if (req.method !== 'POST') return send(405, { error: 'method not allowed' }, 'application/json', { allow: 'POST' });
          const body = await readBody(req);
          const results = await runProbe(engine, { target: String(body.target || 'data'), live: body.live === true });
          if (!results) return send(400, { error: 'unknown probe target' });
          return send(200, { results });
        }
        if (p === '/control/state' || p === '/control/propose') {
          if (p === '/control/state' && req.method === 'GET') return send(200, { auth: auth.method, supervisor: engine.supervisor?.snapshot(), config: { strategy: cfg.strategy, risk: cfg.risk } });
          if (p === '/control/propose' && req.method === 'POST') {
            const body = await readBody(req);
            if (typeof body.path !== 'string' || !Number.isFinite(Number(body.value))) return send(400, { error: 'path and numeric value required' });
            const result = await engine.supervisor.reviewExternalPatch({ path: body.path, value: Number(body.value), reason: body.reason }, auth.method);
            return send(result.action === 'applied' ? 200 : 409, result);
          }
          return send(405, { error: 'method not allowed' });
        }
        return send(404, { error: 'not found' });
      }

      // ---- public: GET/HEAD only ---------------------------------------------------
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return send(405, { error: 'public routes are read-only' }, 'application/json', { allow: 'GET, HEAD' });
      }
      const lim = publicLimiter.hit(ip);
      if (!lim.ok) return send(429, { error: 'rate limit' }, 'application/json', { 'retry-after': String(lim.retryAfterSec) });

      if (p === '/' || p === '/index.html') return send(200, readStatic('dashboard.html'), 'text/html; charset=utf-8');
      if (p === '/ops') return send(200, readStatic('ops.html'), 'text/html; charset=utf-8');
      if (p.startsWith('/assets/')) {
        const name = p.slice('/assets/'.length);
        if (Object.prototype.hasOwnProperty.call(BINARY_ASSETS, name)) {
          return send(200, readStaticBinary(path.join('assets', name)), BINARY_ASSETS[name], { 'cache-control': 'public, max-age=86400' });
        }
        if (!Object.prototype.hasOwnProperty.call(ASSET_TYPES, name)) return send(404, { error: 'not found' });
        return send(200, readStatic(path.join('assets', name)), ASSET_TYPES[name], { 'cache-control': 'no-cache' });
      }
      // Browsers ask for /favicon.ico unprompted; answer it with the real icon
      // instead of a 404 so the tab never shows a blank page glyph.
      if (p === '/favicon.ico') {
        return send(200, readStaticBinary(path.join('assets', 'img/favicon-64.png')), 'image/png', { 'cache-control': 'public, max-age=86400' });
      }
      if (p === '/api/public/summary') return send(200, view.summary());
      if (p.startsWith('/api/public/detail/')) {
        const d = view.detail(decodeURIComponent(p.slice('/api/public/detail/'.length)));
        return d ? send(200, d) : send(404, { error: 'unknown section' });
      }
      if (p === '/health') return send(200, { ok: true, uptimeSec: Math.round(process.uptime()) });
      // /healthz is the platform probe: no engine work, no disk. It answers "is the
      // process alive and listening", NOT "is the bot healthy" — a blocked exchange
      // must not become a restart loop. /readyz is the honest one.
      if (p === '/healthz') return send(200, { ok: true, up: Math.round(process.uptime()) });
      if (p === '/readyz') {
        const h = engine.health ? engine.health() : null;
        if (!h) return send(503, { ok: false, reason: 'engine not initialised' });
        if (h.booting) return send(503, { ok: false, reason: 'booting', ...h });
        if (!h.dataOk) return send(503, { ok: false, reason: 'no market data', degraded: h.degradedSymbols, ...h });
        return send(200, { ok: true, ...h });
      }
      return send(404, { error: 'not found' });
    } catch (e) {
      // Never echo internals to a client; the operator reads the log.
      engine.log.error(`http handler error: ${e.message}`);
      return send(e.message === 'request too large' || e.message === 'invalid JSON' ? 400 : 500, { error: e.message === 'request too large' || e.message === 'invalid JSON' ? e.message : 'internal error' });
    }
  });

  // ---- bind address -------------------------------------------------------
  // PORT comes from the platform on any managed host; no port is imposed: with nothing set the OS assigns one and the log prints it.
  //
  // HOST is a trap. Many PaaS providers (Heroku, Render, Railway, Fly, and most
  // Docker hosts) set HOST to the *public hostname* of the app, e.g.
  // "myapp.example.com". Passing that to server.listen() makes Node try to
  // resolve it as a local interface and fail with ENOTFOUND — the process stays
  // alive, the port is never bound, and the dashboard is unreachable from
  // outside while the logs look almost healthy. Only a literal bindable address
  // is accepted here; anything else falls back to 0.0.0.0.
  const BINDABLE = /^(0\.0\.0\.0|127\.0\.0\.1|::|::1|localhost|\[::\])$/;
  const rawHost = String(process.env.BB_HOST || process.env.HOST || '').trim();
  let host = cfg.server.host || '0.0.0.0';
  if (rawHost) {
    if (BINDABLE.test(rawHost)) {
      host = rawHost === 'localhost' ? '127.0.0.1' : rawHost;
    } else {
      engine.log.warn(
        `ignoring HOST="${rawHost}" — it is not a bindable address (a PaaS sets HOST to the public ` +
          `hostname). Binding 0.0.0.0 instead. Use BB_HOST to override deliberately.`
      );
      host = '0.0.0.0';
    }
  }

  // ---- port resolution ----------------------------------------------------
  // A managed host proxies exactly ONE port to the outside world and tells the
  // container which one it is. Getting this wrong is the difference between a
  // reachable dashboard and a bot that looks healthy but answers nobody.
  //
  //   PORT         — Docker / Heroku / Render / Railway / Fly
  //   SERVER_PORT  — Pterodactyl & Wings (Botkeep, KataBump, most game panels).
  //                  Wings sets it to the server's *primary allocation*, and
  //                  Botkeep's own docs say: "For HTTP access, listen on
  //                  0.0.0.0 and SERVER_PORT, then configure Domains."
  //   BB_PORT      — our explicit override, wins over both.
  //   (none)       — port 0: the OS assigns one and the log prints it.
  //
  // Precedence: BB_PORT > PORT > SERVER_PORT > config.json.
  const PORT_SOURCES = [
    ['BB_PORT', process.env.BB_PORT],
    ['PORT', process.env.PORT],
    ['SERVER_PORT', process.env.SERVER_PORT],
  ];
  let listenPort = cfg.server.port;
  let portSource = 'config.json';
  for (const [name, raw] of PORT_SOURCES) {
    if (raw === undefined || String(raw).trim() === '') continue;
    const n = Number(String(raw).trim());
    if (Number.isInteger(n) && n >= 1 && n <= 65535) {
      listenPort = n;
      portSource = name;
      break;
    }
    engine.log.warn(`ignoring ${name}="${raw}" — not a valid TCP port (1-65535)`);
  }
  if (portSource === 'config.json') portSource = `config.json (${listenPort})`;

  // A host that injects SERVER_PORT but not PORT is the Pterodactyl case. Say so
  // once, at info level, so the operator can see which variable was honoured.
  if (portSource === 'SERVER_PORT') {
    engine.log.info(`using SERVER_PORT=${listenPort} (Pterodactyl/Wings primary allocation)`);
  }

  // ---- listen with retry --------------------------------------------------
  // A swallowed EADDRINUSE used to leave the process running with no listener:
  // the platform's health check fails, it restarts, the old socket is still in
  // TIME_WAIT, and the loop repeats forever. Retry a few times, then exit
  // non-zero so the supervisor restarts us cleanly instead of hanging.
  let attempt = 0;
  const maxAttempts = 5;
  const tryListen = () => {
    attempt++;
    server.listen(listenPort, host);
  };

  // A client that writes bytes after the headers without a Content-Length or a
  // transfer-encoding is malformed: Node parses those bytes as the start of the
  // next request and raises a clientError. Answering explicitly (instead of
  // leaving the socket to time out) makes the failure legible to the caller and
  // keeps a single bad client from holding a connection open.
  server.on('clientError', (err, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
    engine.log.warn(`http client error: ${err.code || ''} ${err.message}`);
  });

  server.on('listening', () => {
    const addr = server.address();
    const bound = addr?.port ?? listenPort;
    engine.log.info(`status panel on http://${host}:${bound} (attempt ${attempt}, port from ${portSource})`);

    // ---- the address a human can actually open ------------------------------
    // The old line printed a fixed address unconditionally, which is
    // wrong twice over on a managed host: the port is not a fixed number, and the host is
    // not something we can guess. Print what we actually know, and say plainly
    // when we do not know the public hostname.
    const publicUrl = resolvePublicUrl(bound);
    if (publicUrl) {
      engine.log.info(`  open from outside:  ${publicUrl}`);
    } else {
      engine.log.info(`  open from outside:  http://<your-server-ip>:${bound}/`);
      engine.log.info(
        '  (the public hostname is not knowable from inside the container — on Botkeep use the ' +
          'Domains tab, or set BB_PUBLIC_URL to have this line print the real address)'
      );
    }
  });

  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && attempt < maxAttempts) {
      const wait = 500 * attempt;
      engine.log.warn(`port ${listenPort} busy (attempt ${attempt}/${maxAttempts}) — retrying in ${wait}ms`);
      setTimeout(tryListen, wait);
      return;
    }
    if (e.code === 'EACCES') {
      engine.log.error(
        `cannot bind port ${listenPort}: permission denied. Ports below 1024 need root — ` +
          `set PORT to something >= 1024 (e.g. PORT=3000).`
      );
    } else {
      engine.log.error(`status server failed permanently: ${e.code || ''} ${e.message}`);
    }
    // No listener means no dashboard and no health check: fail loudly.
    process.exitCode = 3;
    setTimeout(() => process.exit(3), 500);
  });

  tryListen();
  return server;
}

module.exports = { startServer };
