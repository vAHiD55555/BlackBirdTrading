'use strict';
/** Tiny fixed-window limiter, per key. Memory-bounded (old windows are swept). */
class RateLimiter {
  constructor({ limit, windowMs, clock = Date.now, maxKeys = 5000 }) {
    Object.assign(this, { limit, windowMs, clock, maxKeys });
    this.hits = new Map();
  }
  /** Count one event; returns { ok, retryAfterSec }. */
  hit(key) {
    const t = this.clock();
    let e = this.hits.get(key);
    if (!e || t - e.start >= this.windowMs) {
      if (this.hits.size >= this.maxKeys) this._sweep(t);
      e = { start: t, n: 0 };
      this.hits.set(key, e);
    }
    e.n += 1;
    if (e.n > this.limit) return { ok: false, retryAfterSec: Math.max(1, Math.ceil((e.start + this.windowMs - t) / 1000)) };
    return { ok: true, retryAfterSec: 0 };
  }
  /** Is this key already over the limit (without counting)? */
  blocked(key) {
    const e = this.hits.get(key);
    return Boolean(e && this.clock() - e.start < this.windowMs && e.n > this.limit);
  }
  _sweep(t) { for (const [k, e] of this.hits) if (t - e.start >= this.windowMs) this.hits.delete(k); if (this.hits.size >= this.maxKeys) this.hits.clear(); }
}
module.exports = { RateLimiter };
