/* Operator panel client. The token lives in this tab's memory only. */
(function () {
  'use strict';
  var tok = document.getElementById('tok');
  var rows = document.getElementById('results');
  var ICON = { green: '✓ سبز', yellow: '▲ زرد', red: '✖ قرمز' };
  function el(tag, text, cls) { var e = document.createElement(tag); e.textContent = text === null || text === undefined ? '—' : String(text); if (cls) e.className = cls; return e; }
  function show(list) {
    rows.textContent = '';
    list.forEach(function (r) {
      var tr = document.createElement('tr');
      tr.appendChild(el('td', r.label));
      tr.appendChild(el('td', ICON[r.level] || r.level, r.level === 'green' ? 'l-ok' : r.level === 'yellow' ? 'l-watch' : 'l-alert'));
      tr.appendChild(el('td', r.cause));
      tr.appendChild(el('td', r.latencyMs === null ? '—' : r.latencyMs + ' ms'));
      tr.appendChild(el('td', r.fix));
      rows.appendChild(tr);
    });
  }
  function run(target, live) {
    fetch('/ops/probe', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + tok.value }, body: JSON.stringify({ target: target, live: Boolean(live) }) })
      .then(function (r) { if (r.status === 401) throw new Error('توکن نادرست است'); if (r.status === 429) throw new Error('تلاش بیش از حد؛ کمی صبر کنید'); if (!r.ok) throw new Error('خطا ' + r.status); return r.json(); })
      .then(function (j) { show(j.results || []); })
      .catch(function (e) { show([{ label: 'خطا', level: 'red', cause: e.message, latencyMs: null, fix: '—' }]); });
  }
  document.getElementById('probeData').addEventListener('click', function () { run('data'); });
  document.getElementById('probeModels').addEventListener('click', function () { run('models'); });
  document.getElementById('probeLive').addEventListener('click', function () { run('models', true); });
})();
