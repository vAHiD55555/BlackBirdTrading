/*
 * OpenShell — Welcome Canvas (entrance preview).
 * Dark blue/green field, particles, touch ripple / pull / swirl, centred glass
 * panel with the gesture hint. Runs until a valid entrance (gesture or the quiet
 * button/keyboard path), then stops completely.
 *
 * Cost control: DPR capped at 2, particle count scales with area, 30 fps on
 * low-core devices, paused while the tab is hidden, and a single static frame
 * under prefers-reduced-motion. All text is set with textContent.
 */
(function () {
  'use strict';
  var canvas = document.getElementById('welcome-canvas');
  var overlay = document.getElementById('welcome');
  if (!canvas || !overlay) return;
  var ctx = canvas.getContext('2d');
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lowPower = (navigator.hardwareConcurrency || 4) <= 4;
  var frameGap = lowPower ? 1000 / 30 : 1000 / 60;

  var W = 0, H = 0, dpr = 1, parts = [], ripples = [], ptr = null, raf = 0, last = 0, running = true;

  function size() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = overlay.clientWidth; H = overlay.clientHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.max(30, Math.min(140, Math.round((W * H) / 14000)));
    if (lowPower) n = Math.round(n * 0.6);
    parts = [];
    for (var i = 0; i < n; i++) parts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3, r: 1 + Math.random() * 1.8, hue: Math.random() < .62 ? 42 : 205 });
    if (reduced) draw(0);
  }

  function step(dt) {
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (ptr) { // pull toward the touch point, with a gentle swirl around it
        var dx = ptr.x - p.x, dy = ptr.y - p.y, d2 = dx * dx + dy * dy + 400, f = Math.min(60 / d2, .03);
        p.vx += dx * f + (-dy) * f * .6; p.vy += dy * f + dx * f * .6;
      }
      p.vx *= .985; p.vy *= .985;
      p.x += p.vx * dt * .06; p.y += p.vy * dt * .06;
      if (p.x < 0) p.x = W; else if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H; else if (p.y > H) p.y = 0;
    }
    for (var k = ripples.length - 1; k >= 0; k--) { ripples[k].r += dt * .12; ripples[k].a -= dt * .0011; if (ripples[k].a <= 0) ripples.splice(k, 1); }
  }

  function draw() {
    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#050a14'); g.addColorStop(1, '#0b1526');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      ctx.beginPath(); ctx.fillStyle = 'hsla(' + p.hue + ',72%,66%,.72)'; ctx.arc(p.x, p.y, p.r, 0, 6.283); ctx.fill();
    }
    ctx.lineWidth = 1;
    for (var a = 0; a < parts.length; a += 3) for (var b = a + 1; b < parts.length && b < a + 6; b++) {
      var dx = parts[a].x - parts[b].x, dy = parts[a].y - parts[b].y, d = dx * dx + dy * dy;
      if (d < 9000) { ctx.strokeStyle = 'rgba(197,160,89,' + (0.20 * (1 - d / 9000)).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(parts[a].x, parts[a].y); ctx.lineTo(parts[b].x, parts[b].y); ctx.stroke(); }
    }
    for (var k = 0; k < ripples.length; k++) { ctx.strokeStyle = 'rgba(232,200,126,' + ripples[k].a.toFixed(3) + ')'; ctx.beginPath(); ctx.arc(ripples[k].x, ripples[k].y, ripples[k].r, 0, 6.283); ctx.stroke(); }
  }

  function loop(t) {
    if (!running) return;
    raf = requestAnimationFrame(loop);
    if (document.hidden || t - last < frameGap) return; // background tab: do nothing
    var dt = Math.min(t - last, 64); last = t;
    step(dt); draw();
  }

  function stop() { running = false; cancelAnimationFrame(raf); window.removeEventListener('resize', onResize); }
  var rs = 0; function onResize() { clearTimeout(rs); rs = setTimeout(size, 150); }

  // ---- input: visual effects + stroke collection for the gesture gate
  var stroke = null;
  var gate = window.BBGesture.createGate({ onUnlock: function () { enter('gesture'); } });
  function rel(e) { var r = overlay.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  overlay.addEventListener('pointerdown', function (e) {
    if (e.target.closest && e.target.closest('button')) return;
    if (stroke) return; // a second finger is not a swipe
    var p = rel(e); stroke = { id: e.pointerId, points: [{ x: p.x, y: p.y, t: e.timeStamp }], w: W, h: H };
    if (!reduced) { ptr = p; ripples.push({ x: p.x, y: p.y, r: 4, a: .5 }); }
  });
  overlay.addEventListener('pointermove', function (e) {
    if (!stroke || e.pointerId !== stroke.id) return;
    var p = rel(e); stroke.points.push({ x: p.x, y: p.y, t: e.timeStamp });
    if (stroke.points.length > 400) stroke.points.splice(1, 1); // bounded memory
    if (!reduced) ptr = p;
  });
  function end(e) {
    if (!stroke || e.pointerId !== stroke.id) return;
    var p = rel(e); stroke.points.push({ x: p.x, y: p.y, t: e.timeStamp });
    var s = stroke; stroke = null; ptr = null;
    var r = gate.feed(s);
    hint(r.event);
  }
  overlay.addEventListener('pointerup', end);
  overlay.addEventListener('pointercancel', function (e) { if (stroke && e.pointerId === stroke.id) { stroke = null; ptr = null; gate.reset(); } });

  var hintEl = document.getElementById('welcome-hint');
  var steps = document.querySelectorAll('[data-step]');
  function hint(ev) {
    var msg = {
      a_ok: 'عالی؛ حالا از گوشه‌ی بالا-راست به گوشه‌ی پایین-چپ بکشید.',
      a_repeat: 'حرکت دوم را انجام دهید: بالا-راست ← پایین-چپ.',
      wrong_order: 'ترتیب برعکس بود؛ اول از چپ به راست بکشید.',
      invalid: 'حرکت شناخته نشد؛ دوباره از چپ به راست بکشید.',
      timeout_or_overlap: 'زمان تمام شد؛ از اول شروع کنید.',
    }[ev];
    if (msg && hintEl) hintEl.textContent = msg;
    for (var i = 0; i < steps.length; i++) steps[i].setAttribute('data-done', String((gate.state === 'a_done' && steps[i].dataset.step === 'a') || gate.state === 'unlocked'));
  }

  // ---- entering the dashboard
  var entered = false;
  function enter(via) {
    if (entered) return; entered = true;
    stop();
    overlay.hidden = true;
    try { sessionStorage.setItem('bb_entered', '1'); } catch (e) { /* storage may be unavailable */ }
    document.body.classList.add('entered');
    document.dispatchEvent(new CustomEvent('bb:enter', { detail: { via: via } }));
  }
  var btn = document.getElementById('welcome-enter');
  if (btn) btn.addEventListener('click', function () { enter('button'); }); // quiet, non-gesture path
  document.addEventListener('keydown', function (e) { if (!entered && e.key === 'Enter' && e.target === document.body) enter('keyboard'); });
  window.__bbEnter = enter;

  var already = false; try { already = sessionStorage.getItem('bb_entered') === '1'; } catch (e) { /* ignore */ }
  if (already) { enter('session'); return; }

  window.addEventListener('resize', onResize);
  size();
  if (!reduced) raf = requestAnimationFrame(loop);
})();
