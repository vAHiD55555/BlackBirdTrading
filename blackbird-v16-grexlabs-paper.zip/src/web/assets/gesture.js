/*
 * Entrance gesture — pure logic, no DOM, so it can be unit-tested in Node and
 * reused in the browser unchanged.
 *
 *   Step A: swipe left -> right (nearly horizontal, long enough).
 *   Step B: diagonal swipe from the top-right corner to the bottom-left corner.
 *   A then B, in that order, B starting within MAX_GAP_MS of A's end.
 *
 * THIS IS NOT AUTHENTICATION. It is an entrance affordance for the preview: it
 * decides when the welcome canvas gives way to the (public, read-only) dashboard.
 * Nothing secret sits behind it, and none must ever be placed behind it.
 *
 * A stroke is { points: [{x, y, t}], w, h } in CSS pixels; coordinates are
 * normalised by w/h here, so phone and desktop share one set of thresholds.
 * Directions are SCREEN directions (left/right), independent of page RTL.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BBGesture = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var T = {
    MIN_TRAVEL: 0.06, // shorter strokes are accidental touches: ignored, they neither advance nor reset
    A_MIN_DX: 0.45, // fraction of width
    A_MAX_DY: 0.16, // fraction of height
    A_MAX_BACKTRACK: 0.08, // a swipe that doubles back is a scribble, not a swipe
    B_START_X: 0.6, B_START_Y: 0.4, // start region: top-right
    B_END_X: 0.4, B_END_Y: 0.6, // end region: bottom-left
    B_MAX_DEVIATION: 0.2, // max distance from the ideal TR->BL line, in units of the diagonal
    MIN_MS: 90, MAX_MS_A: 1600, MAX_MS_B: 2200, // too fast = synthetic/jitter, too slow = not a swipe
    MAX_GAP_MS: 4000, // time allowed between the end of A and the start of B
  };

  function norm(stroke) {
    var pts = (stroke && stroke.points) || [];
    var w = stroke && stroke.w, h = stroke && stroke.h;
    if (pts.length < 2 || !(w > 0) || !(h > 0)) return null;
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (!isFinite(p.x) || !isFinite(p.y) || !isFinite(p.t)) return null;
      out.push({ x: p.x / w, y: p.y / h, t: p.t });
    }
    return out;
  }

  function travel(n) { var a = n[0], b = n[n.length - 1]; return Math.hypot(b.x - a.x, b.y - a.y); }

  /** 'tap' | 'A' | 'B' | 'invalid' */
  function classify(stroke) {
    var n = norm(stroke);
    if (!n) return 'invalid';
    var a = n[0], b = n[n.length - 1];
    if (travel(n) < T.MIN_TRAVEL) return 'tap';
    var dur = b.t - a.t;

    // ---- A: left -> right
    var dx = b.x - a.x, dy = Math.abs(b.y - a.y);
    if (dx >= T.A_MIN_DX && dy <= T.A_MAX_DY && dur >= T.MIN_MS && dur <= T.MAX_MS_A) {
      var back = 0, maxX = a.x, vertical = 0;
      for (var i = 1; i < n.length; i++) {
        if (n[i].x > maxX) maxX = n[i].x;
        back = Math.max(back, maxX - n[i].x);
        vertical = Math.max(vertical, Math.abs(n[i].y - a.y));
      }
      if (back <= T.A_MAX_BACKTRACK && vertical <= T.A_MAX_DY * 1.6) return 'A';
    }

    // ---- B: top-right corner region -> bottom-left corner region, roughly straight
    if (a.x >= T.B_START_X && a.y <= T.B_START_Y && b.x <= T.B_END_X && b.y >= T.B_END_Y && dur >= T.MIN_MS && dur <= T.MAX_MS_B) {
      // ideal line from the top-right corner (1,0) to the bottom-left corner (0,1): x + y = 1
      var diag = Math.SQRT2, worst = 0;
      for (var j = 0; j < n.length; j++) worst = Math.max(worst, Math.abs(n[j].x + n[j].y - 1) / diag);
      if (worst <= T.B_MAX_DEVIATION) return 'B';
    }
    return 'invalid';
  }

  /**
   * Stateful gate. feed(stroke) after each finished stroke.
   * Returns { state: 'idle'|'a_done'|'unlocked', event }.
   * Wrong order, a malformed stroke, or waiting too long resets to 'idle'.
   */
  function createGate(opts) {
    opts = opts || {};
    var onUnlock = opts.onUnlock || function () {};
    var maxGap = opts.maxGapMs || T.MAX_GAP_MS;
    var state = 'idle', aEnd = 0;

    function reset() { state = 'idle'; aEnd = 0; }

    function feed(stroke) {
      if (state === 'unlocked') return { state: state, event: 'ignored' };
      var kind = classify(stroke);
      if (kind === 'tap') return { state: state, event: 'tap_ignored' };
      var startT = stroke && stroke.points && stroke.points[0] ? stroke.points[0].t : 0;
      var endT = stroke && stroke.points && stroke.points.length ? stroke.points[stroke.points.length - 1].t : 0;

      if (state === 'idle') {
        if (kind === 'A') { state = 'a_done'; aEnd = endT; return { state: state, event: 'a_ok' }; }
        reset();
        return { state: state, event: kind === 'B' ? 'wrong_order' : 'invalid' };
      }
      // state === 'a_done'
      if (startT < aEnd || startT - aEnd > maxGap) { reset(); return { state: state, event: 'timeout_or_overlap' }; }
      if (kind === 'B') { state = 'unlocked'; onUnlock(); return { state: state, event: 'unlocked' }; }
      if (kind === 'A') { aEnd = endT; return { state: state, event: 'a_repeat' }; } // still waiting for B
      reset();
      return { state: state, event: 'invalid' };
    }

    return { feed: feed, reset: reset, get state() { return state; } };
  }

  return { classify: classify, createGate: createGate, THRESHOLDS: T };
});
