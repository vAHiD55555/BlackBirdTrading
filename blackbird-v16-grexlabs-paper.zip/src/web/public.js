'use strict';
/**
 * Public telemetry — the ONLY data the public dashboard can ever receive.
 *
 * Design: an allow-list projection. This module reads engine.status() but copies
 * out a handful of named numbers and enumerated codes; it never forwards an
 * object, an error string, a config value or a free-text field. Anything not
 * named here cannot reach a browser, whatever engine.status() learns to contain
 * in the future (it already contains provider/model identity, key-env names,
 * supervisor/strategist/lawyer internals and the full config view).
 *
 * Defence in depth: every payload is scanned by a tripwire for secret-shaped
 * strings, the values of secret-looking environment variables, and model/provider
 * identity words. A hit replaces the payload with an "unknown" one and logs that
 * it happened (never the value).
 *
 * Honesty rule: absent, stale, unparseable or failed => "unknown"/"stale",
 * never "ok". A broken status path must not look like a healthy bot.
 */

const SCHEMA = 1;
const STALE_AFTER_MS = 30 * 1000; // older than this the page must say so
const CACHE_TTL_MS = 3 * 1000; // one rebuild per 3s however many visitors

const LEVEL_RANK = { alert: 3, watch: 2, unknown: 1, ok: 0 };
const worst = (...levels) => levels.reduce((a, b) => (LEVEL_RANK[b] > LEVEL_RANK[a] ? b : a), 'ok');

const num = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : null);
const round = (x, d = 2) => (num(x) === null ? null : Math.round(x * 10 ** d) / 10 ** d);

// -------------------------------------------------------------------- tripwire
const SECRET_SHAPES = [
  /\bsk-[A-Za-z0-9_-]{12,}/, /\bgsk_[A-Za-z0-9]{12,}/, /\bAIza[0-9A-Za-z_-]{20,}/, /\bghp_[A-Za-z0-9]{20,}/,
  /\bxox[abp]-[A-Za-z0-9-]{10,}/, /\bBearer\s+[A-Za-z0-9._-]{12,}/i, /\b\d{6,}:[A-Za-z0-9_-]{20,}/, // telegram bot token
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /\b0x[0-9a-fA-F]{40,}\b/,
];
// Words that would reveal which model/provider plays a role. Exchanges are not here: market venue is public.
const IDENTITY_WORDS = /\b(openai|anthropic|gemini|groq|openrouter|mistral|cohere|deepseek|claude|gpt-?\d|llama|qwen|ollama|workers[- ]ai|apiKeyEnv|ROLE_MAP|provider|supervisor_url|admin[_-]?token)\b/i;

function secretEnvValues(env = process.env) {
  const out = [];
  for (const [k, v] of Object.entries(env)) {
    if (!/(KEY|TOKEN|SECRET|PASS|PRIVATE|SEED|MNEMONIC|WEBHOOK)/i.test(k)) continue;
    const s = String(v || '').trim();
    if (s.length >= 6) out.push(s);
  }
  return out;
}

/** Returns null when clean, otherwise a short reason code (never the offending text). */
function tripwire(payload, env = process.env) {
  const text = JSON.stringify(payload);
  for (const re of SECRET_SHAPES) if (re.test(text)) return 'secret_shape';
  if (IDENTITY_WORDS.test(text)) return 'identity_word';
  for (const v of secretEnvValues(env)) if (text.includes(v)) return 'env_secret_value';
  return null;
}

// ---------------------------------------------------------------- projections
const LEVEL_WORD = { ok: 'سالم', watch: 'نیازمند توجه', alert: 'خطر', unknown: 'نامشخص' };
const LEVEL_ICON = { ok: '✓', watch: '▲', alert: '✖', unknown: '?' }; // shape differs per level: colour is never the only cue

function unknownView(profile, reason) {
  const now = Date.now();
  return {
    schema: SCHEMA, generatedAt: now, profile, freshness: { state: 'unknown', ageSec: null },
    overall: { level: 'unknown', headline: 'وضعیت فعلاً مشخص نیست', code: reason },
    cards: [{ id: 'overall', title: 'وضعیت کلی', level: 'unknown', icon: LEVEL_ICON.unknown, word: LEVEL_WORD.unknown, message: 'داده‌ی معتبر در دسترس نیست. این به معنی سالم بودن نیست.', detail: null }],
  };
}

function project(status, { profile, court }) {
  const now = Date.now();
  if (!status || status.booting || !status.risk) {
    return { ...unknownView(profile, 'booting'), overall: { level: 'unknown', headline: 'سیستم در حال راه‌اندازی است', code: 'booting' } };
  }
  const risk = status.risk;
  const health = status.health || {};
  const market = Array.isArray(status.market) ? status.market : [];
  const lim = status.limits || {};

  // ---- health: is the data real and recent?
  const ages = market.map((m) => num(m.quoteAgeMs)).filter((v) => v !== null);
  const freshestMs = ages.length ? Math.min(...ages) : null;
  const dataStale = freshestMs === null || freshestMs > 60 * 1000;
  let healthLevel = 'ok';
  let healthMsg = 'همه‌ی منابع داده فعال‌اند.';
  if (health.dataOk !== true) { healthLevel = 'alert'; healthMsg = 'داده‌ی بازار دریافت نمی‌شود؛ تصمیم‌ها بر پایه‌ی داده‌ی معتبر نیستند.'; }
  else if (dataStale) { healthLevel = 'watch'; healthMsg = 'داده‌ی بازار کهنه است.'; }
  else if ((num(health.feedsDegraded) || 0) > 0) { healthLevel = 'watch'; healthMsg = `${health.feedsDegraded} از ${health.feedsTotal} منبع داده مشکل دارد.`; }

  // ---- money
  const equity = num(risk.equityMtm) ?? num(risk.equity);
  const daily = num(risk.dailyPnlPct);
  const dd = num(risk.drawdownPct);
  const ddLimit = num(lim.killSwitchDrawdownPct) !== null ? lim.killSwitchDrawdownPct * 100 : null;
  const dayLimit = num(lim.maxDailyLossPct) !== null ? lim.maxDailyLossPct * 100 : null;
  let moneyLevel = 'ok';
  let moneyMsg = 'سرمایه در محدوده‌ی عادی است.';
  if (equity === null || dd === null || daily === null) { moneyLevel = 'unknown'; moneyMsg = 'ارقام مالی در دسترس نیست.'; }
  else if (risk.halted) { moneyLevel = 'alert'; moneyMsg = 'معاملات به‌خاطر کنترل ریسک متوقف شده است.'; }
  else if (ddLimit !== null && dd >= ddLimit * 0.8) { moneyLevel = 'alert'; moneyMsg = 'افت سرمایه نزدیک به حد توقف است.'; }
  else if ((ddLimit !== null && dd >= ddLimit * 0.5) || (dayLimit !== null && daily <= -dayLimit * 0.6)) { moneyLevel = 'watch'; moneyMsg = 'افت سرمایه یا زیان امروز قابل توجه است.'; }

  // ---- performance
  const trades = num(risk.tradesTotal);
  const wins = num(risk.wins);
  let perfLevel = 'ok';
  let perfMsg = 'عملکرد در محدوده‌ی عادی است.';
  if (trades === null) { perfLevel = 'unknown'; perfMsg = 'آمار عملکرد در دسترس نیست.'; }
  else if (trades < 10) { perfLevel = 'unknown'; perfMsg = 'هنوز معامله‌ی کافی برای قضاوت وجود ندارد.'; }
  else if (daily !== null && daily < 0) { perfLevel = 'watch'; perfMsg = 'امروز نتیجه منفی است.'; }

  // ---- warnings and risks (court shown only as coarse phase and card count)
  const warnings = [];
  let warnLevel = 'ok';
  if (risk.halted) { warnings.push('معاملات متوقف است.'); warnLevel = 'alert'; }
  if (court && court.closing) { warnings.push('فصل در مرحله‌ی اختتام است.'); warnLevel = 'alert'; }
  else if (court && court.yellowCards > 0) { warnings.push('یک هشدار نظارتی فعال است.'); warnLevel = worst(warnLevel, 'watch'); }
  if (healthLevel !== 'ok') { warnings.push(healthMsg); warnLevel = worst(warnLevel, healthLevel); }
  if (num(risk.lossesStreak) !== null && risk.lossesStreak >= 3) { warnings.push('چند ضرر پیاپی ثبت شده است.'); warnLevel = worst(warnLevel, 'watch'); }
  if (!warnings.length) warnings.push('هشدار فعالی وجود ندارد.');

  // ---- strengths / weaknesses (deterministic, at most two each)
  const strengths = [];
  const weaknesses = [];
  if (dd !== null && ddLimit !== null && dd < ddLimit * 0.25) strengths.push('افت سرمایه کم است.');
  if (healthLevel === 'ok') strengths.push('داده‌ی بازار تازه و کامل است.');
  if (num(risk.lossesStreak) === 0) strengths.push('ضرر پیاپی ندارد.');
  if (dd !== null && ddLimit !== null && dd >= ddLimit * 0.5) weaknesses.push('افت سرمایه از نیمه‌ی حد مجاز گذشته است.');
  if (healthLevel !== 'ok') weaknesses.push('کیفیت داده‌ی بازار کاهش یافته است.');
  if (daily !== null && daily < 0) weaknesses.push('نتیجه‌ی امروز منفی است.');
  if (trades !== null && trades < 10) weaknesses.push('نمونه‌ی معاملات هنوز کوچک است.');

  const overallLevel = worst(healthLevel, moneyLevel, warnLevel);
  const headline = {
    ok: 'همه‌چیز در محدوده‌ی عادی است',
    watch: 'چند مورد نیاز به توجه دارد',
    alert: 'خطر فعال است؛ جزئیات را ببینید',
    unknown: 'بخشی از وضعیت نامشخص است',
  }[overallLevel];

  // ---- the watch (دیده‌بان): is it looking, and did it find anything?
  // Shown as its own card because "nothing changed" is a real answer an operator
  // needs to be able to read: it means the watch ran and found nothing better,
  // not that it is broken.
  const watch = status.watch || null;
  let watchLevel = 'unknown';
  let watchMsg = 'دیده‌بان در دسترس نیست.';
  if (watch) {
    if (!watch.enabled) { watchLevel = 'ok'; watchMsg = 'دیده‌بان خاموش است.'; }
    else if (watch.errors > 0 && !watch.lastRunAt) { watchLevel = 'watch'; watchMsg = 'دیده‌بان نتوانست با صرافی ارتباط بگیرد.'; }
    else if (!watch.lastRunAt) { watchLevel = 'unknown'; watchMsg = 'دیده‌بان هنوز یک چرخه را کامل نکرده است.'; }
    else if (watch.last && Array.isArray(watch.last.swaps) && watch.last.swaps.length) {
      watchLevel = 'watch';
      watchMsg = `${watch.last.swaps.length} پیشنهاد جابه‌جایی در انتظار تصمیم است.`;
    } else { watchLevel = 'ok'; watchMsg = 'دیده‌بان فعال است؛ گزینهٔ بهتری از دارایی‌های فعلی پیدا نشد.'; }
  }

  // ---- the apprentice (کارآموز): is it learning, and is anyone refusing to answer?
  // A violation is the interesting number: it means an actor acted without being
  // able to say why, which is exactly what the apprentice exists to surface.
  const appr = status.apprentice || null;
  let apprLevel = 'unknown';
  let apprMsg = 'کارآموز در دسترس نیست.';
  if (appr) {
    if (!appr.enabled) { apprLevel = 'ok'; apprMsg = 'کارآموز خاموش است.'; }
    else if (appr.violations > 0) {
      apprLevel = 'watch';
      apprMsg = `${appr.violations} پاسخ بدون دلیل ثبت شده است؛ ${appr.answered} پاسخ سالم.`;
    } else if (appr.records === 0) { apprLevel = 'unknown'; apprMsg = 'کارآموز هنوز چیزی یاد نگرفته است.'; }
    else { apprLevel = 'ok'; apprMsg = `${appr.records} مشاهده ثبت شده؛ هیچ پاسخ بی‌دلیلی وجود ندارد.`; }
  }

  // ---- market intel (اخبار): is the world quiet, or is an event imminent?
  const intel = status.intel || null;
  let intelLevel = 'unknown';
  let intelMsg = 'هوش بازار در دسترس نیست.';
  if (intel) {
    // Which feeds actually answered, and from where. A feed that fell through
    // to its RSS mirror is reported as such — the card must not imply GDELT
    // answered when it did not.
    const feeds = intel.feeds || {};
    const names = Object.keys(feeds);
    const okFeeds = names.filter((n) => feeds[n] && feeds[n].ok);
    const fbFeeds = okFeeds.filter((n) => feeds[n].source === 'fallback');
    const badFeeds = names.filter((n) => feeds[n] && !feeds[n].ok);
    const srcNote = okFeeds.length
      ? `منابع: ${okFeeds.length}/${names.length}` +
        (fbFeeds.length ? ` (${fbFeeds.length} از پشتیبان)` : '') +
        (badFeeds.length ? ` · ناموفق: ${badFeeds.join(', ')}` : '')
      : '';

    if (!intel.enabled) { intelLevel = 'ok'; intelMsg = 'هوش بازار خاموش است (هیچ منبع خبری تنظیم نشده).'; }
    else if (!intel.last) { intelLevel = 'unknown'; intelMsg = 'هنوز خبری خوانده نشده است.'; }
    else if (intel.last.blackout) {
      intelLevel = 'watch';
      intelMsg = `پنجرهٔ توقف فعال است: ${intel.last.blackoutReason || 'رویداد مهم نزدیک'}`;
    } else if (intel.last.extreme) {
      intelLevel = 'watch';
      intelMsg = `لحن بازار شدید است (${intel.last.tone})؛ ریسک کاهش می‌یابد.`;
    } else if (intel.last.items === 0) {
      intelLevel = 'watch';
      intelMsg = `هیچ خبری خوانده نشد؛ ${badFeeds.length ? `خطا: ${badFeeds.map((n) => `${n}=${feeds[n].error}`).join(' · ')}` : 'منابع خالی بودند.'}`;
    } else {
      intelLevel = 'ok';
      intelMsg = `${intel.last.items} خبر خوانده شد؛ جوّ بازار عادی است.` + (srcNote ? ` — ${srcNote}` : '');
    }
  }

  const card = (id, title, level, message, detail) => ({ id, title, level, icon: LEVEL_ICON[level], word: LEVEL_WORD[level], message, detail });
  const cards = [
    card('health', 'سلامت سیستم', healthLevel, healthMsg, 'health'),
    card('money', 'وضعیت مالی', moneyLevel, moneyMsg, 'risk'),
    card('performance', 'عملکرد', perfLevel, perfMsg, 'performance'),
    card('warnings', 'هشدارها و خطرها', warnLevel, warnings[0], 'health'),
    card('watch', 'دیده‌بان', watchLevel, watchMsg, null),
    card('intel', 'هوش بازار', intelLevel, intelMsg, null),
    card('apprentice', 'کارآموز', apprLevel, apprMsg, null),
    card('strengths', 'قدرت‌ها', strengths.length ? 'ok' : 'unknown', strengths[0] || 'هنوز نکته‌ی قوت روشنی ثبت نشده است.', null),
    card('weaknesses', 'ضعف‌ها', weaknesses.length ? 'watch' : 'ok', weaknesses[0] || 'ضعف مهمی دیده نمی‌شود.', null),
  ].sort((a, b) => LEVEL_RANK[b.level] - LEVEL_RANK[a.level]); // most severe first

  return {
    schema: SCHEMA,
    generatedAt: now,
    profile,
    freshness: { state: dataStale ? 'stale' : 'fresh', ageSec: freshestMs === null ? null : Math.round(freshestMs / 1000) },
    overall: { level: overallLevel, headline, code: overallLevel },
    figures: {
      equity: round(equity), dailyPnlPct: round(daily), drawdownPct: round(dd),
      trades: trades, winRatePct: trades > 0 && wins !== null ? round((wins / trades) * 100, 1) : null,
    },
    lists: { strengths, weaknesses, warnings },
    cards,
  };
}

function detail(status, section, { profile }) {
  const base = { schema: SCHEMA, generatedAt: Date.now(), profile, section };
  if (!status || status.booting || !status.risk) return { ...base, state: 'unknown', rows: [] };
  const r = status.risk;
  const lim = status.limits || {};
  switch (section) {
    case 'risk':
      return { ...base, state: 'ok', rows: [
        ['ارزش پرتفوی', round(r.equityMtm ?? r.equity)], ['سود/زیان امروز (٪)', round(r.dailyPnlPct)],
        ['افت از اوج (٪)', round(r.drawdownPct)], ['حد توقف افت (٪)', num(lim.killSwitchDrawdownPct) !== null ? round(lim.killSwitchDrawdownPct * 100) : null],
        ['حد زیان روزانه (٪)', num(lim.maxDailyLossPct) !== null ? round(lim.maxDailyLossPct * 100) : null], ['معاملات متوقف است؟', r.halted ? 'بله' : 'خیر'],
      ] };
    case 'performance':
      return { ...base, state: 'ok', rows: [
        ['کل معاملات', num(r.tradesTotal)], ['معاملات امروز', num(r.tradesToday)], ['بردها', num(r.wins)], ['باخت‌ها', num(r.losses)], ['باخت پیاپی', num(r.lossesStreak)],
      ] };
    case 'health': {
      const h = status.health || {};
      return { ...base, state: 'ok', rows: [
        ['منابع فعال', num(h.feedsTotal) !== null && num(h.feedsDegraded) !== null ? h.feedsTotal - h.feedsDegraded : null], ['منابع دارای مشکل', num(h.feedsDegraded)],
        ['داده معتبر است؟', h.dataOk === true ? 'بله' : 'خیر'], ['مدت کار (دقیقه)', num(h.uptimeSec) !== null ? Math.round(h.uptimeSec / 60) : null],
      ] };
    }
    case 'market':
      return { ...base, state: 'ok', columns: ['نماد', 'قیمت', 'رژیم', 'اسپرد (bps)', 'سن داده (ثانیه)'],
        rows: (Array.isArray(status.market) ? status.market : []).slice(0, 40).map((m) => [
          String(m.symbol || '').replace(/[^A-Z0-9._-]/gi, '').slice(0, 20), round(m.price, 6), ['trend', 'muddy', 'n/a', 'range', 'chop'].includes(m.regime) ? m.regime : 'n/a',
          round(m.spreadBps, 1), num(m.quoteAgeMs) !== null ? Math.round(m.quoteAgeMs / 1000) : null,
        ]) };
    case 'positions': {
      const pos = status.rotator && Array.isArray(status.rotator.positions) ? status.rotator.positions : [];
      return { ...base, state: 'ok', columns: ['نماد', 'جهت', 'سود/زیان'],
        rows: pos.slice(0, 40).map((p) => [String(p.symbol || '').replace(/[^A-Z0-9._-]/gi, '').slice(0, 20), p.side === 'short' ? 'کوتاه' : 'بلند', round(p.pnl)]) };
    }
    default:
      return null;
  }
}

const SECTIONS = ['risk', 'performance', 'health', 'market', 'positions'];

class PublicView {
  /** @param {{engine: object, log?: object, env?: object}} o */
  constructor({ engine, log = null, env = process.env }) {
    this.engine = engine;
    this.log = log;
    this.env = env;
    this._cache = new Map(); // key -> { at, value }
    this._lastGood = null;
  }
  get profile() {
    const p = (this.engine.cfg && this.engine.cfg.profile) || { label: 'BlackBird' };
    return { label: p.label, mode: this.engine.cfg && this.engine.cfg.mode === 'live' ? 'live' : 'paper' };
  }
  _guard(payload, what) {
    const hit = tripwire(payload, this.env);
    if (!hit) return payload;
    if (this.log) this.log.error(`public payload "${what}" blocked by tripwire (${hit}) — served as unknown`);
    return what === 'summary' ? unknownView(this.profile, 'blocked') : { schema: SCHEMA, generatedAt: Date.now(), profile: this.profile, section: what, state: 'unknown', rows: [] };
  }
  _cached(key, build) {
    const hit = this._cache.get(key);
    const t = Date.now();
    if (hit && t - hit.at < CACHE_TTL_MS) return hit.value;
    const value = build();
    this._cache.set(key, { at: t, value });
    return value;
  }
  summary() {
    return this._cached('summary', () => {
      let out;
      try {
        const status = this.engine.status();
        const court = this.engine.court ? this.engine.court.publicView() : null;
        out = this._guard(project(status, { profile: this.profile, court }), 'summary');
        this._lastGood = out;
      } catch (e) {
        if (this.log) this.log.warn(`public summary failed: ${e.message}`);
        // Never recycle an old "ok" as if it were current: keep its ORIGINAL timestamp
        // and mark it stale, so the page's own age check trips.
        out = this._lastGood
          ? { ...this._lastGood, freshness: { state: 'stale', ageSec: null }, overall: { level: 'unknown', headline: 'به‌روزرسانی ناموفق بود؛ داده قدیمی است', code: 'refresh_failed' } }
          : unknownView(this.profile, 'error');
      }
      return out;
    });
  }
  detail(section) {
    if (!SECTIONS.includes(section)) return null;
    return this._cached(`detail:${section}`, () => {
      try {
        return this._guard(detail(this.engine.status(), section, { profile: this.profile }), section);
      } catch {
        return { schema: SCHEMA, generatedAt: Date.now(), profile: this.profile, section, state: 'unknown', rows: [] };
      }
    });
  }
}

module.exports = { PublicView, project, detail, tripwire, SECTIONS, STALE_AFTER_MS, LEVEL_WORD, LEVEL_ICON };
