'use strict';
/**
 * Sleeve 3 — funding / basis carry (delta-neutral).
 *
 * Why this one: it is the only edge in this repo that does not depend on price
 * direction at all. Perpetual futures pay funding every 8h; when funding is
 * persistently positive, longs pay shorts. Holding spot long + perp short
 * collects that payment while the price exposure cancels out. It is the highest
 * Sharpe-per-unit-of-attention strategy available to a small account, and it is
 * the one that keeps earning when momentum and mean reversion are both flat.
 *
 * What this module does NOT do: it does not place the hedge. It computes the
 * carry, ranks the universe, and returns a target book plus the exact hedge
 * ratio. Execution stays with the broker so the paper/live boundary is in one
 * place — a carry sleeve that silently opens a naked perp short is how accounts
 * die, so the hedge leg is explicit in the output.
 *
 * Honest accounting: the edge is `fundingBps * intervalsPerDay * 365` minus
 * both legs' fees and the basis slippage. If that is not clearly positive, the
 * sleeve returns nothing rather than a thin, fee-eaten trade.
 */

const { clamp } = require('../../core/util');

const INTERVALS_PER_DAY = 3; // 8h funding
const DAYS_PER_YEAR = 365;

/**
 * Annualised carry from a funding rate expressed in bps per 8h interval.
 * Positive funding => shorts are paid => spot-long/perp-short earns.
 */
function annualisedCarryPct(fundingBpsPerInterval) {
  const perDay = fundingBpsPerInterval * INTERVALS_PER_DAY;
  return (perDay / 10000) * DAYS_PER_YEAR * 100;
}

/**
 * @param {Object<string, {fundingBps:number, mark?:number, index?:number, nextFundingMs?:number}>} fundingBySymbol
 * @param {object} opts
 * @returns {Array<{sym, dir, pct, hedge, reason, carryPct, netCarryPct}>}
 */
function signals(fundingBySymbol, opts = {}) {
  const o = {
    minCarryPct: 8, // annualised, before costs
    maxPicks: 3,
    basePct: 10,
    roundTripFeeBps: 10, // both legs, taker, in and out
    basisSlippageBps: 6,
    holdDays: 30, // assumed holding period for amortising entry/exit cost
    ...opts,
  };

  const out = [];
  for (const sym of Object.keys(fundingBySymbol || {})) {
    const f = fundingBySymbol[sym];
    if (!f || !Number.isFinite(Number(f.fundingBps))) continue;

    const fundingBps = Number(f.fundingBps);
    const carryPct = annualisedCarryPct(fundingBps);

    // Cost amortised over the assumed hold: entry+exit on both legs.
    const costPct = ((o.roundTripFeeBps + o.basisSlippageBps) / 10000) * 100 * (DAYS_PER_YEAR / o.holdDays);
    const netCarryPct = Math.abs(carryPct) - costPct;

    if (netCarryPct < o.minCarryPct) continue;

    // Positive funding: short the perp, long the spot. Negative: the reverse
    // (long perp, short spot) — rarer, and only when the venue allows it.
    const dir = fundingBps > 0 ? -1 : 1;
    const hedge = fundingBps > 0 ? 'spot_long' : 'spot_short';

    out.push({
      sym,
      dir, // direction of the PERP leg
      hedge, // the leg that cancels the price exposure
      pct: o.basePct,
      carryPct: Math.round(carryPct * 100) / 100,
      netCarryPct: Math.round(netCarryPct * 100) / 100,
      reason: `carry ${carryPct.toFixed(1)}%/yr (funding ${fundingBps}bps/8h), net ${netCarryPct.toFixed(1)}% after costs`,
    });
  }

  out.sort((a, b) => b.netCarryPct - a.netCarryPct);
  return out.slice(0, o.maxPicks);
}

/**
 * Hedge ratio for a delta-neutral pair. Returns the spot quantity that exactly
 * offsets `perpQty` at the given prices, so the caller never has to guess.
 */
function hedgeQty({ perpQty, perpPrice, spotPrice }) {
  if (!(perpQty > 0) || !(perpPrice > 0) || !(spotPrice > 0)) return 0;
  return (perpQty * perpPrice) / spotPrice;
}

/** Net delta of a carry pair, in quote currency. Zero means truly neutral. */
function netDelta({ perpQty, perpPrice, spotQty, spotPrice, perpDir = -1 }) {
  return perpQty * perpPrice * perpDir + spotQty * spotPrice;
}

module.exports = { signals, annualisedCarryPct, hedgeQty, netDelta, INTERVALS_PER_DAY };
