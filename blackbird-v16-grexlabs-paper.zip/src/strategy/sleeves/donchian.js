'use strict';
/**
 * Sleeve 1 — Donchian breakout with ATR trailing and volatility-scaled size.
 *
 * Why this one: crypto spends most of its time ranging and a minority of its
 * time trending hard. A channel breakout is the cheapest way to be present for
 * the second part without predicting it — you pay a small number of false
 * starts and one trend pays for all of them. It is the classic "cut losses,
 * let winners run" shape, expressed in three numbers.
 *
 * Rules (all on closed bars, no look-ahead):
 *   long   when close > highest high of the previous `lookback` bars
 *   short  when close < lowest  low  of the previous `lookback` bars
 *   filter optional EMA trend agreement, and an ATR expansion floor so a
 *          breakout in dead volatility is ignored
 *   size   basePct scaled by targetVol / realisedVol, clamped
 *   stop   entry -/+ atrMult * ATR (the rotator applies it as the disaster stop)
 *
 * The channel deliberately EXCLUDES the current bar. Including it makes the
 * breakout condition true by construction (close can never exceed a high that
 * contains it), which is the single most common bug in this family.
 */

const { clamp } = require('../../core/util');

function emaLast(values, period) {
  if (!values.length) return NaN;
  const k = 2 / (period + 1);
  let prev = values[0];
  for (let i = 1; i < values.length; i++) prev = values[i] * k + prev * (1 - k);
  return prev;
}

function atrLast(bars, period = 14) {
  const n = bars.length;
  if (n < period + 2) return NaN;
  let sum = 0;
  for (let i = n - period; i < n; i++) {
    const tr = Math.max(
      bars[i].h - bars[i].l,
      Math.abs(bars[i].h - bars[i - 1].c),
      Math.abs(bars[i].l - bars[i - 1].c)
    );
    sum += tr;
  }
  return sum / period;
}

/** Annualised realised volatility from hourly closes. */
function realisedVol(closes, hoursPerYear = 24 * 365) {
  if (closes.length < 30) return NaN;
  const rets = [];
  for (let i = 1; i < closes.length; i++) {
    if (closes[i - 1] > 0) rets.push(closes[i] / closes[i - 1] - 1);
  }
  if (rets.length < 20) return NaN;
  const m = rets.reduce((a, b) => a + b, 0) / rets.length;
  const v = rets.reduce((a, b) => a + (b - m) ** 2, 0) / (rets.length - 1);
  return Math.sqrt(v) * Math.sqrt(hoursPerYear);
}

/**
 * @param {Object<string, Array<{t,o,h,l,c,v}>>} barsBySymbol
 * @param {object} opts
 * @returns {Array<{sym, dir, pct, reason, stopAtr}>}
 */
function signals(barsBySymbol, opts = {}) {
  const o = {
    lookback: 55,
    basePct: 8,
    atrMult: 2.5,
    atrPeriod: 14,
    emaPeriod: 200,
    requireEma: true,
    minAtrPct: 0.15, // ignore breakouts in dead volatility (ATR as % of price)
    targetVolPct: 45,
    volFloor: 0.4,
    volCap: 1.5,
    maxPicks: 4,
    ...opts,
  };

  const out = [];
  for (const sym of Object.keys(barsBySymbol)) {
    const bars = barsBySymbol[sym];
    if (!Array.isArray(bars) || bars.length < Math.max(o.lookback + 2, o.emaPeriod + 2)) continue;

    const i = bars.length - 1;
    const close = bars[i].c;
    if (!(close > 0)) continue;

    // channel over the bars BEFORE the current one
    let hi = -Infinity;
    let lo = Infinity;
    for (let k = i - o.lookback; k < i; k++) {
      if (bars[k].h > hi) hi = bars[k].h;
      if (bars[k].l < lo) lo = bars[k].l;
    }
    if (!Number.isFinite(hi) || !Number.isFinite(lo)) continue;

    const atr = atrLast(bars, o.atrPeriod);
    if (!Number.isFinite(atr) || atr <= 0) continue;
    const atrPct = (atr / close) * 100;
    if (atrPct < o.minAtrPct) continue;

    let dir = 0;
    if (close > hi) dir = 1;
    else if (close < lo) dir = -1;
    if (!dir) continue;

    if (o.requireEma) {
      const closes = bars.map((b) => b.c);
      const e = emaLast(closes, o.emaPeriod);
      if (Number.isFinite(e)) {
        if (dir > 0 && close < e) continue; // long only above the long average
        if (dir < 0 && close > e) continue; // short only below it
      }
    }

    const vol = realisedVol(bars.map((b) => b.c).slice(-240));
    const target = o.targetVolPct / 100;
    const scale = Number.isFinite(vol) && vol > 0
      ? clamp(target / vol, o.volFloor, o.volCap)
      : 1;

    out.push({
      sym,
      dir,
      pct: o.basePct * scale,
      stopAtr: o.atrMult,
      reason: `donchian ${o.lookback}h ${dir > 0 ? 'breakout' : 'breakdown'} (atr ${atrPct.toFixed(2)}%, volScale ${scale.toFixed(2)})`,
    });
  }

  // strongest breakouts first: distance beyond the channel, in ATR units
  out.sort((a, b) => b.pct - a.pct);
  return out.slice(0, o.maxPicks);
}

module.exports = { signals, atrLast, realisedVol, emaLast };
