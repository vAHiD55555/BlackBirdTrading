'use strict';
/**
 * Sleeve 2 — volatility-regime mean reversion (Bollinger + RSI + z-score).
 *
 * Why this one: it is the natural complement to momentum. Momentum earns in
 * trends and bleeds in chop; mean reversion earns in chop and bleeds in trends.
 * Running both with a regime switch is the cheapest way to raise the Sharpe of
 * the book without adding a new prediction — you are not forecasting, you are
 * choosing which of two known edges is currently being paid.
 *
 * The gate is the whole point. Mean reversion is only allowed when the market
 * is NOT trending: ADX below a ceiling and price inside the channel. Without
 * that gate this sleeve is a trend-fighting machine that looks great in a
 * backtest and dies in a real breakout.
 *
 * Rules (closed bars only):
 *   long   close <= lower band AND rsi <= rsiBuy AND z <= -zEntry
 *   short  close >= upper band AND rsi >= rsiSell AND z >= +zEntry
 *   gate   adx < adxMax AND |z| < zHardStop (never fade a runaway move)
 *   exit   the caller uses the mid band as target and the band edge as stop
 */

const { clamp } = require('../../core/util');

function sma(values, period) {
  if (values.length < period) return NaN;
  let s = 0;
  for (let i = values.length - period; i < values.length; i++) s += values[i];
  return s / period;
}

function stdev(values, period) {
  if (values.length < period) return NaN;
  const m = sma(values, period);
  let s = 0;
  for (let i = values.length - period; i < values.length; i++) s += (values[i] - m) ** 2;
  return Math.sqrt(s / period);
}

function rsiLast(closes, period = 14) {
  if (closes.length < period + 1) return NaN;
  let gain = 0;
  let loss = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d;
    else loss -= d;
  }
  if (loss === 0) return 100;
  const rs = gain / loss;
  return 100 - 100 / (1 + rs);
}

/** Wilder ADX — the trend-strength gate. */
function adxLast(bars, period = 14) {
  const n = bars.length;
  if (n < period * 2 + 1) return NaN;
  const tr = [];
  const plusDM = [];
  const minusDM = [];
  for (let i = 1; i < n; i++) {
    const up = bars[i].h - bars[i - 1].h;
    const down = bars[i - 1].l - bars[i].l;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(
      bars[i].h - bars[i].l,
      Math.abs(bars[i].h - bars[i - 1].c),
      Math.abs(bars[i].l - bars[i - 1].c)
    ));
  }
  // Wilder smoothing
  let atr = tr.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let pdi = plusDM.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let mdi = minusDM.slice(0, period).reduce((a, b) => a + b, 0) / period;
  const dx = [];
  for (let i = period; i < tr.length; i++) {
    atr = (atr * (period - 1) + tr[i]) / period;
    pdi = (pdi * (period - 1) + plusDM[i]) / period;
    mdi = (mdi * (period - 1) + minusDM[i]) / period;
    const sum = pdi + mdi;
    dx.push(sum > 0 ? (Math.abs(pdi - mdi) / sum) * 100 : 0);
  }
  if (dx.length < period) return NaN;
  let adx = dx.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < dx.length; i++) adx = (adx * (period - 1) + dx[i]) / period;
  return adx;
}

/**
 * @param {Object<string, Array<{t,o,h,l,c,v}>>} barsBySymbol
 * @param {object} opts
 * @returns {Array<{sym, dir, pct, reason, target, stop}>}
 */
function signals(barsBySymbol, opts = {}) {
  const o = {
    period: 20,
    stdMult: 2.0,
    rsiPeriod: 14,
    rsiBuy: 30,
    rsiSell: 70,
    zEntry: 1.8,
    zHardStop: 3.5,
    adxPeriod: 14,
    adxMax: 22, // above this the market is trending: do not fade it
    basePct: 6,
    maxPicks: 3,
    ...opts,
  };

  const out = [];
  for (const sym of Object.keys(barsBySymbol)) {
    const bars = barsBySymbol[sym];
    if (!Array.isArray(bars) || bars.length < Math.max(o.period + 2, o.adxPeriod * 2 + 2)) continue;

    const closes = bars.map((b) => b.c);
    const close = closes[closes.length - 1];
    if (!(close > 0)) continue;

    const mid = sma(closes, o.period);
    const sd = stdev(closes, o.period);
    if (!Number.isFinite(mid) || !Number.isFinite(sd) || sd <= 0) continue;

    const z = (close - mid) / sd;
    const rsi = rsiLast(closes, o.rsiPeriod);
    const adx = adxLast(bars, o.adxPeriod);
    if (!Number.isFinite(rsi)) continue;

    // The gate: no mean reversion in a trend, and never fade a runaway move.
    if (Number.isFinite(adx) && adx > o.adxMax) continue;
    if (Math.abs(z) > o.zHardStop) continue;

    let dir = 0;
    if (z <= -o.zEntry && rsi <= o.rsiBuy) dir = 1;
    else if (z >= o.zEntry && rsi >= o.rsiSell) dir = -1;
    if (!dir) continue;

    // Size down as the stretch grows: a 3-sigma move is a worse bet than a
    // 1.8-sigma one, not a better one.
    const stretch = clamp(Math.abs(z) / o.zEntry, 1, 2);
    const pct = o.basePct / stretch;

    out.push({
      sym,
      dir,
      pct,
      target: mid, // revert to the mean
      stop: dir > 0 ? mid - o.stdMult * sd : mid + o.stdMult * sd,
      reason: `mean-revert z=${z.toFixed(2)} rsi=${rsi.toFixed(1)} adx=${Number.isFinite(adx) ? adx.toFixed(1) : 'n/a'}`,
    });
  }

  out.sort((a, b) => b.pct - a.pct);
  return out.slice(0, o.maxPicks);
}

module.exports = { signals, adxLast, rsiLast, sma, stdev };
