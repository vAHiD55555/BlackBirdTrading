'use strict';
/**
 * BlackBird — Rotator (the "Orbital" strategy, v3).
 *
 * Instead of hunting single-bar patterns, the rotator ranks the whole universe
 * by relative momentum and holds a small book of the strongest longs against
 * the weakest shorts, rebalanced on a fixed weekly cadence.
 *
 * Why this shape:
 *   - it is a *portfolio* strategy: the edge comes from cross-sectional
 *     dispersion, which is much more stable than any single symbol's pattern
 *   - weekly holding keeps the fee budget small (taker 5bps + slip 1.5bps)
 *   - both directions mean it does not depend on a bull market
 *   - three variants with different lookbacks are blended, so no single
 *     parameter can dominate the book
 *
 * Risk overlays applied at rebalance time:
 *   - volatility targeting: exposure ∝ target vol / realised vol (capped)
 *   - drawdown throttle: exposure steps down as the equity curve falls
 *   - disaster stop: 6 ATR, checked on every quote
 */
const { now } = require('../core/util');
const { Position } = require('../exec/portfolio');
const donchian = require('./sleeves/donchian');
const meanrev = require('./sleeves/meanrev');
const carry = require('./sleeves/carry');

const HOUR = 3600000;
const DAY = 86400000;

// ---------------------------------------------------------------- indicators
function ema(values, n) {
  const out = new Array(values.length).fill(NaN);
  const a = 2 / (n + 1);
  let prev = NaN;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= n) sum -= values[i - n];
    if (i === n - 1) prev = sum / n;
    else if (i >= n) prev = values[i] * a + prev * (1 - a);
    out[i] = prev;
  }
  return out;
}

function atrSeries(bars, n = 14) {
  const len = bars.length;
  const out = new Array(len).fill(NaN);
  if (len < n + 2) return out;
  const tr = new Array(len).fill(0);
  for (let i = 1; i < len; i++) {
    tr[i] = Math.max(bars[i].h - bars[i].l, Math.abs(bars[i].h - bars[i - 1].c), Math.abs(bars[i].l - bars[i - 1].c));
  }
  let sum = 0;
  for (let i = 1; i < len; i++) {
    sum += tr[i];
    if (i > n) sum -= tr[i - n];
    if (i >= n) out[i] = sum / n;
  }
  return out;
}

class Rotator {
  constructor({ cfg, log, store, risk, portfolio, broker, hub, bus, now: nowFn }) {
    this.cfg = cfg;
    this.log = log;
    this.store = store;
    this.risk = risk;
    this.portfolio = portfolio;
    this.broker = broker;
    this.hub = hub;
    this.bus = bus;
    this.now = nowFn || now; // injectable clock (historical replay)

    const rc = cfg.strategy.rotator || {};
    this.rc = Object.assign(
      {
        rebalanceHours: 168,
        perPositionPct: 11,
        maxGrossPct: 150,
        disasterStopAtr: 6,
        // Trailing stop. The disaster stop never moves, so a trade could be up
        // 3 ATR and still lose 6 ATR — the fixture run showed three winners
        // (MFE +35/+45/+75) closing near zero. Once the trade is `trailStartAtr`
        // in profit, the stop follows at `trailDistanceAtr` behind the best
        // price, and it only ever moves toward less risk.
        trailEnabled: true,
        trailStartAtr: 2,
        trailDistanceAtr: 2,
        gateSymbol: 'BTCUSDT',
        volTargetPct: 45,
        volFloor: 0.3,
        volCap: 1.6,
        ddSteps: [0.08, 0.6, 0.15, 0.35, 0.22, 0.2],
        maxPositions: 8,
        minNotionalUsd: 15,
        // "always invested" core: a small long sleeve that never goes flat in a
        // bull market, so the book is not empty between rotations.
        corePct: 30,
        coreTop: 2,
        coreLookHours: 720,
        coreGateSymbol: 'BTCUSDT',
        variants: [
          { lookHours: 72, top: 2, neutral: true, gate: false },
          { lookHours: 168, top: 2, neutral: true, gate: true },
          { lookHours: 168, skipHours: 24, top: 3, neutral: true, gate: true },
        ],
        // ---- the three added sleeves -------------------------------------
        // Each is off unless asked for, so an existing deployment keeps the
        // exact book it had. Turn one on and it contributes to the same target
        // book, under the same gross cap and the same risk officer.
        sleeves: {
          donchian: { enabled: false, lookback: 55, basePct: 8, atrMult: 2.5, maxPicks: 4 },
          meanrev: { enabled: false, period: 20, zEntry: 1.8, adxMax: 22, basePct: 6, maxPicks: 3 },
          carry: { enabled: false, minCarryPct: 8, basePct: 10, maxPicks: 3 },
        },
      },
      rc
    );
    this.variants = this.rc.variants;
    this.maxLook = Math.max(
      this.rc.corePct > 0 ? this.rc.coreLookHours + 10 : 0,
      ...this.variants.map((v) => (v.lookHours || 168) + (v.skipHours || 0))
    );
    this.gateGate = null;
    this._staleSince = new Map(); // stale-quote exit policy (§25.4)

    this.lastBucket = null;
    this.lastDayKey = '';
    this.dailyEquity = [];
    this.volScale = 1;
    this.ddScale = 1;
    this.stats = {
      rebalances: 0,
      opens: 0,
      closes: 0,
      resizes: 0,
      stops: 0,
      skipped: 0,
      lastRebalanceAt: null,
      lastError: null,
      lastScale: 1,
      lastTargets: null,
    };
  }

  /** Rebuild the book from the persisted state so a restart does not churn. */
  restore() {
    const saved = (this.store.state && this.store.state.orbital) || [];
    let n = 0;
    for (const p of saved) {
      try {
        const pos = new Position({
          symbol: p.symbol, side: p.side, qty: p.qty, entry: p.entry, fee: p.fee,
          notional: p.notional, strategy: p.strategy || 'ORBITAL', tp: p.tp, sl: p.sl,
          timeStopAt: 0, context: p.context, rationale: p.rationale,
        });
        if (p.openedAt) pos.openedAt = p.openedAt;
        this.portfolio.open(pos);
        n++;
      } catch (e) {
        this.log.warn(`could not restore ${p.symbol}: ${e.message}`);
      }
    }
    if (n) this.log.info(`restored ${n} orbital positions from state`);
    if (typeof this.store.state.orbitalBucket === 'number') this.lastBucket = this.store.state.orbitalBucket;
    return n;
  }

  /** Write the live book into the state file (survives restarts). */
  persist() {
    try {
      this.store.state.orbitalBucket = this.lastBucket;
      this.store.state.orbital = this.portfolio.openPositions().filter((p) => p.strategy === 'ORBITAL').map((p) => ({
        symbol: p.symbol, side: p.side, qty: p.qty, entry: p.entry, fee: p.entryFee,
        notional: p.notional, strategy: p.strategy, tp: p.tp, sl: p.sl,
        openedAt: p.openedAt, context: p.context, rationale: p.rationale,
      }));
    } catch (e) {
      this.log.debug(`persist failed: ${e.message}`);
    }
  }

  // ------------------------------------------------------------- data access
  _bars(sym) {
    const feed = this.hub.get(sym);
    if (!feed) return [];
    return feed.bars.toArray();
  }

  ready() {
    const need = Math.ceil(this.maxLook / 1) + 60;
    for (const sym of this.cfg.symbols) {
      if (this._bars(sym).length < need) return false;
    }
    return true;
  }

  // --------------------------------------------------------- overlay state
  /** Record one equity sample per UTC day for the volatility estimator. */
  _sampleEquity() {
    // Use the injected clock, not the wall clock: a historical replay must not
    // collapse every simulated day into today's date.
    const day = new Date(this.now()).toISOString().slice(0, 10);
    if (day === this.lastDayKey) return;
    this.lastDayKey = day;
    this.dailyEquity.push(this.risk.state.equity + this.portfolio.unrealisedTotal());
    if (this.dailyEquity.length > 120) this.dailyEquity.shift();
  }

  /** Exposure multiplier from realised vol and current drawdown. */
  overlay() {
    let vol = 1;
    const n = this.dailyEquity.length;
    if (n >= 20) {
      const rets = [];
      for (let i = n - 20; i < n; i++) {
        const a = this.dailyEquity[i - 1];
        if (a > 0) rets.push(this.dailyEquity[i] / a - 1);
      }
      if (rets.length >= 15) {
        const m = rets.reduce((a, b) => a + b, 0) / rets.length;
        const sd = Math.sqrt(rets.reduce((a, b) => a + (b - m) ** 2, 0) / rets.length) * Math.sqrt(365);
        const target = this.rc.volTargetPct / 100;
        vol = Math.max(this.rc.volFloor, Math.min(this.rc.volCap, target / Math.max(sd, 1e-6)));
      }
    }
    let dd = 1;
    const peak = this.risk.peakEquity || this.risk.state.equity;
    const cur = peak > 0 ? 1 - this.risk.state.equity / peak : 0;
    const s = this.rc.ddSteps;
    for (let i = 0; i < s.length; i += 2) {
      if (cur >= s[i]) dd = s[i + 1];
    }
    this.volScale = vol;
    this.ddScale = dd;
    // An external scale (the strategist's crisis overlay) can only ever REDUCE
    // this number. It is applied last and clamped to 0..1, so no external
    // module can raise exposure through this hook.
    let ext = 1;
    try {
      if (typeof this.externalScale === 'function') {
        const v = Number(this.externalScale());
        if (Number.isFinite(v)) ext = Math.min(1, Math.max(0, v));
      }
    } catch { ext = 1; }
    this.externalScaleValue = ext;
    return vol * dd * ext;
  }

  // ---------------------------------------------------------------- signals
  /**
   * Rank the universe by skip-period momentum and return the picks.
   * Identical maths to research/strategies.js xsMomentum, kept in sync by tests.
   */
  variantPicks(v, barsBySymbol) {
    const look = Math.max(2, Math.round((v.lookHours || 168)));
    const skip = Math.max(0, Math.round(v.skipHours || 0));
    const top = Math.max(1, v.top || 2);
    const neutral = v.neutral !== false;

    const rows = [];
    for (const sym of Object.keys(barsBySymbol)) {
      const bars = barsBySymbol[sym];
      const i = bars.length - 1;
      if (i - look - skip < 1) continue;
      const c = bars[i - skip].c;
      const prev = bars[i - skip - look].c;
      if (!(c > 0) || !(prev > 0)) continue;
      rows.push({ sym, r: (c / prev - 1) * 100 });
    }
    rows.sort((a, b) => b.r - a.r);

    const gateOk = (dir) => {
      if (!v.gate) return true;
      const g = barsBySymbol[this.rc.gateSymbol];
      // Charter §6.1/§25.2: missing or insufficient gate history must NOT be
      // read as "gate passed". Longs are refused; shorts do not use the gate.
      if (!g || g.length < 220) return dir < 0;
      const closes = g.map((b) => b.c);
      const e = ema(closes, 200);
      const up = closes[closes.length - 1] > e[e.length - 1];
      return dir > 0 ? up : true;
    };

    const picks = [];
    for (let k = 0; k < top && k < rows.length; k++) if (gateOk(1)) picks.push({ sym: rows[k].sym, dir: 1, rank: k + 1 });
    if (neutral) {
      for (let k = 0; k < top && k < rows.length; k++) {
        const x = rows[rows.length - 1 - k];
        if (gateOk(-1)) picks.push({ sym: x.sym, dir: -1, rank: k + 1 });
      }
    }
    return picks;
  }

  /**
   * The core sleeve: hold the strongest names by a long lookback, always long,
   * rebalanced with the same weekly clock. This is what keeps the book from
   * being empty for days — it is a position, not extra trading.
   */
  corePicks(barsBySymbol) {
    if (!(this.rc.corePct > 0)) return [];
    const look = this.rc.coreLookHours || 720;
    const top = this.rc.coreTop || 2;
    const rows = [];
    for (const sym of Object.keys(barsBySymbol)) {
      const bars = barsBySymbol[sym];
      const i = bars.length - 1;
      if (i - look < 1) continue;
      const c = bars[i].c, prev = bars[i - look].c;
      if (!(c > 0) || !(prev > 0)) continue;
      rows.push({ sym, r: (c / prev - 1) * 100 });
    }
    rows.sort((a, b) => b.r - a.r);

    // regime gate on the gate symbol's own long average
    const g = barsBySymbol[this.rc.coreGateSymbol];
    if (g && g.length > look) {
      const closes = g.map((b) => b.c);
      const avg = closes.slice(-look).reduce((a, b) => a + b, 0) / look;
      if (closes[closes.length - 1] < avg) return []; // bear market: core stays in cash
    }
    const per = this.rc.corePct / top;
    return rows.slice(0, top).map((x) => ({ sym: x.sym, dir: 1, pct: per, core: true }));
  }

  /**
   * The three added sleeves, merged into the same signed-notional map.
   *
   * They are deliberately NOT a separate book: a Donchian long and a momentum
   * short on the same symbol must cancel, and the gross cap must see all of it.
   * Anything else would let the sleeves stack leverage behind the operator's
   * back.
   */
  sleevePicks(barsBySymbol, fundingBySymbol) {
    const sc = this.rc.sleeves || {};
    const picks = [];

    if (sc.donchian?.enabled) {
      for (const p of donchian.signals(barsBySymbol, sc.donchian)) {
        picks.push({ sym: p.sym, dir: p.dir, pct: p.pct, sleeve: 'donchian', reason: p.reason, stopAtr: p.stopAtr });
      }
    }
    if (sc.meanrev?.enabled) {
      for (const p of meanrev.signals(barsBySymbol, sc.meanrev)) {
        picks.push({ sym: p.sym, dir: p.dir, pct: p.pct, sleeve: 'meanrev', reason: p.reason, target: p.target, stop: p.stop });
      }
    }
    if (sc.carry?.enabled && fundingBySymbol) {
      for (const p of carry.signals(fundingBySymbol, sc.carry)) {
        picks.push({ sym: p.sym, dir: p.dir, pct: p.pct, sleeve: 'carry', reason: p.reason, hedge: p.hedge });
      }
    }
    return picks;
  }

  /** Merge every variant into one target book: sym -> {dir, notionalPct}. */
  targetBook(barsBySymbol, fundingBySymbol) {
    // Accumulate SIGNED notional: a core long and a variant short on the same
    // symbol cancel out, which is the honest expression of conflicting views.
    const net = new Map();
    const apply = (p) => {
      if (!p || !p.sym) return;
      net.set(p.sym, (net.get(p.sym) || 0) + p.dir * p.pct);
    };

    for (const p of this.corePicks(barsBySymbol)) apply(p);

    for (const v of this.variants) {
      for (const p of this.variantPicks(v, barsBySymbol)) {
        apply({ sym: p.sym, dir: p.dir, pct: this.rc.perPositionPct });
      }
    }

    // the added sleeves share the same book, the same cap and the same risk gate
    this.lastSleevePicks = this.sleevePicks(barsBySymbol, fundingBySymbol);
    for (const p of this.lastSleevePicks) apply(p);

    const out = new Map();
    for (const [sym, signed] of net) {
      if (Math.abs(signed) < 1e-9) continue;      // views cancel -> stay flat
      // one position never exceeds perPositionPct of equity, even when several
      // variants agree on the same symbol (that is the user's sizing rule)
      const pct = Math.min(Math.abs(signed), this.rc.perPositionPct);
      out.set(sym, { dir: signed > 0 ? 1 : -1, pct, strength: Math.abs(signed) / this.rc.perPositionPct });
    }
    return out;
  }

  // ------------------------------------------------------------- execution
  _price(sym) {
    const feed = this.hub.get(sym);
    const book = feed?.book();
    if (!book) return null;
    return book;
  }

  _market(sym, side, qty, tag) {
    return this.broker.submit({ symbol: sym, side, qty, type: 'market', tag });
  }

  _openTarget(sym, target, scale) {
    const book = this._price(sym);
    if (!book || book.quoteAgeMs > this.cfg.data.staleQuoteMs) return null;
    const equity = this.risk.state.equity;
    const notionalWanted = equity * (target.pct / 100) * scale;
    // The gross cap is the rotator's own limit (maxGrossPct), not the tactical
    // book's maxOpenPositions x maxPositionPct. The old expression allowed
    // 8 x 20% = 160% of equity regardless of what maxGrossPct said, so a
    // config asking for 70% gross could still reach 160%.
    const maxTotal = equity * (this.rc.maxGrossPct / 100);
    if (this.portfolio.totalExposure() + notionalWanted > maxTotal) return null;
    const px = target.dir > 0 ? book.ask : book.bid;
    if (!(px > 0)) return null;
    if (notionalWanted < this.rc.minNotionalUsd) return null;
    const qty = notionalWanted / px;

    // Every entry passes the risk officer. Without this the rotator could open
    // while halted, after the daily loss cap, or past the net-exposure limit —
    // the hard limits only ever applied to the tactical path.
    // The replay harness injects a minimal risk stub with no `check()` (it has
    // no daily limits by design), so the gate is applied only when it exists.
    if (typeof this.risk.check === 'function') {
      const gate = this.risk.check(
        { symbol: sym, side: target.dir > 0 ? 'buy' : 'sell', notional: notionalWanted },
        this.portfolio
      );
      if (!gate.ok) {
        this.stats.skipped++;
        this.log.warn(`open ${sym} vetoed by risk: ${gate.reason}`);
        return null;
      }
    }

    const res = this._market(sym, target.dir > 0 ? 'buy' : 'sell', qty, 'rotate:open');
    if (!res || res.status !== 'filled') {
      this.stats.skipped++;
      this.log.warn(`open ${sym} rejected: ${res?.reason || 'unknown'}`);
      return null;
    }
    const bars = this._bars(sym);
    const a = atrSeries(bars, 14);
    const atr = a[a.length - 1] || res.price * 0.01;
    const stopDist = this.rc.disasterStopAtr * atr;
    const pos = new Position({
      symbol: sym,
      side: target.dir > 0 ? 'long' : 'short',
      qty: res.qty,
      entry: res.price,
      fee: res.fee,
      notional: res.notional,
      strategy: 'ORBITAL',
      tp: null,
      sl: target.dir > 0 ? res.price - stopDist : res.price + stopDist,
      timeStopAt: 0,
      context: { variant: 'orbital', atr, pct: target.pct, scale },
      rationale: `cross-sectional momentum rank (${target.dir > 0 ? 'long' : 'short'})`,
      // Stamp the open with the rotator's own clock. In a replay that is the
      // bar's timestamp, so durationMs stays positive and honest.
      openedAt: this.now(),
    });
    this.portfolio.open(pos);
    this.stats.opens++;
    this.persist();
    return pos;
  }

  /**
   * Trade the difference between the position we hold and the exposure the
   * overlay asks for. Without this, a drawdown throttle only sizes NEW
   * positions and the book stays as risky as it was — which is not what the
   * research model measured.
   */
  _resize(sym, target, scale) {
    const pos = this.portfolio.get(sym);
    const book = this._price(sym);
    if (!pos || !book || book.quoteAgeMs > this.cfg.data.staleQuoteMs) return null;
    const px = pos.dir > 0 ? book.bid : book.ask;
    if (!(px > 0)) return null;
    const desired = this.risk.state.equity * (target.pct / 100) * scale;
    const current = pos.qty * px;
    const delta = desired - current;
    const deadband = Math.max(this.rc.minNotionalUsd, desired * 0.25);
    if (Math.abs(delta) < deadband) return null;
    const qty = Math.abs(delta) / px;
    if (qty * px < this.rc.minNotionalUsd) return null;
    const side = delta > 0 ? (pos.dir > 0 ? 'buy' : 'sell') : (pos.dir > 0 ? 'sell' : 'buy');
    // Charter §25.3: growing a position must clear the same gross / symbol / net
    // caps as opening one. risk.check() cannot be used here because its
    // "symbol already open" rule is exactly what a resize is supposed to do.
    if (delta > 0) {
      const cap = this._caps(sym, qty * px, pos.dir * qty * px);
      if (!cap.ok) {
        this.log.warn(`resize ${sym} blocked: ${cap.reason}`);
        return null;
      }
    }
    const res = this._market(sym, side, qty, 'rotate:resize');
    if (!res || res.status !== 'filled') return null;
    if (delta > 0) {
      const newQty = pos.qty + res.qty;
      pos.entry = (pos.entry * pos.qty + res.price * res.qty) / newQty;
      pos.qty = newQty;
      pos.entryFee += res.fee;
      pos.notional = pos.qty * pos.entry;
    } else {
      const closedQty = Math.min(pos.qty, res.qty);
      const before = pos.qty;
      // The entry fee attributable to the closed slice must be charged here.
      // It used to be dropped, so every partial resize booked a slightly better
      // P&L than the book actually earned.
      const entryFeeShare = (pos.entryFee || 0) * (closedQty / Math.max(before, 1e-12));
      const pnl = (res.price - pos.entry) * closedQty * pos.dir - res.fee - entryFeeShare;
      pos.qty = Math.max(0, pos.qty - closedQty);
      pos.entryFee = Math.max(0, (pos.entryFee || 0) - entryFeeShare);
      pos.notional = pos.qty * pos.entry;
      // Route the realised P&L through the risk officer, exactly like a full
      // close. Writing `state.equity += pnl` directly skipped the peak-equity
      // update, the trade counters, the loss streak and the kill switch — a
      // book could bleed out through resizes and never trip a single limit.
      this.risk.settle({
        pnl,
        fee: res.fee,
        notional: res.price * closedQty,
        win: pnl > 0,
        symbol: sym,
        tradeId: `${pos.id}:resize`,
      });
      this.store.append('resize', { symbol: sym, qty: closedQty, price: res.price, pnl });
      if (pos.qty <= 1e-12) {
        this.portfolio.positions.delete(sym);
        this.stats.closes++;
      }
    }
    this.stats.resizes++;
    this.persist();
    return res;
  }

  /**
   * Exposure caps for an addition (a resize up). Returns {ok, reason}.
   * The three ceilings are separate on purpose; a book must satisfy all three:
   *   gross  (rotator maxGrossPct)  — total notional / equity
   *   symbol (risk.maxSymbolExposurePct) — the same name must not dominate
   *   net    (risk.maxNetExposurePct)    — |long - short| / equity
   */
  _caps(sym, addNotional, signedDelta) {
    const equity = Number(this.risk.state.equity) || 0;
    if (!(equity > 0)) return { ok: false, reason: 'no_equity' };
    const gross = (this.portfolio.totalExposure ? this.portfolio.totalExposure() : 0) + addNotional;
    const maxGross = equity * (this.rc.maxGrossPct / 100);
    if (gross > maxGross + 1e-9) {
      return { ok: false, reason: `gross_cap(${gross.toFixed(0)}>${maxGross.toFixed(0)})` };
    }
    const symExp = (this.portfolio.exposureBySymbol ? this.portfolio.exposureBySymbol(sym) : 0) + addNotional;
    const maxSym = equity * (Number(this.cfg.risk.maxSymbolExposurePct) || 0.25);
    if (symExp > maxSym + 1e-9) {
      return { ok: false, reason: `symbol_cap(${symExp.toFixed(0)}>${maxSym.toFixed(0)})` };
    }
    if (typeof this.portfolio.netExposure === 'function') {
      const net = this.portfolio.netExposure() + signedDelta;
      const maxNet = equity * (Number(this.cfg.risk.maxNetExposurePct) || 0.7);
      if (Math.abs(net) > maxNet + 1e-9) {
        return { ok: false, reason: `net_cap(${net.toFixed(0)}>${maxNet.toFixed(0)})` };
      }
    }
    return { ok: true };
  }

  /**
   * Last-resort exit when the book has been stale past the policy window.
   * Charter §25.4: refusing to close because the quote is old is not a policy.
   * The exit uses the last reference price with an adverse slippage haircut and
   * is journaled as an emergency, never as a normal fill.
   */
  _emergencyClose(sym) {
    const pos = this.portfolio.get(sym);
    if (!pos) return null;
    const feed = this.hub && typeof this.hub.get === 'function' ? this.hub.get(sym) : null;
    const last = Number(feed && feed.ticker && (feed.ticker.last || feed.ticker.bid || feed.ticker.ask)) || 0;
    if (!(last > 0)) {
      this.log.error(`emergency exit ${sym} impossible: no reference price at all`);
      return null;
    }
    const slip = 50 / 10000; // 50 bps adverse haircut for a forced exit
    const price = pos.dir > 0 ? last * (1 - slip) : last * (1 + slip);
    const feeBps = Number(this.cfg.fees && this.cfg.fees.takerBps) || 5;
    const fee = price * pos.qty * (feeBps / 10000);
    const trade = this.portfolio.close(sym, {
      price,
      fee,
      feeKind: 'taker',
      reason: 'stale_emergency',
      ts: this.now(),
    });
    if (!trade) return null;
    this.log.error(`emergency exit ${sym} at reference ${last} (stale book)`);
    try { this.store.append('emergency_exit', { symbol: sym, price, reference: last, ts: this.now() }); } catch { /* best effort */ }
    try { this.store.append('trade_closed', trade); } catch { /* best effort */ }
    this.risk.settle({ pnl: trade.pnl, fee, win: trade.win, symbol: sym, tradeId: trade.id });
    this.stats.closes++;
    this.persist();
    if (this.bus) this.bus.emit('trade:closed', trade);
    return trade;
  }

  _close(sym, reason) {
    const pos = this.portfolio.get(sym);
    if (!pos) return null;
    const book = this._price(sym);
    if (!book || book.quoteAgeMs > this.cfg.data.staleQuoteMs) {
      this.log.warn(`cannot close ${sym}: stale book`);
      return null;
    }
    const res = this._market(sym, pos.dir > 0 ? 'sell' : 'buy', pos.qty, `rotate:${reason}`);
    if (!res || res.status !== 'filled') {
      this.log.warn(`close ${sym} rejected: ${res?.reason || 'unknown'}`);
      return null;
    }
    const trade = this.portfolio.close(sym, {
      price: res.price,
      fee: res.fee,
      feeKind: 'taker',
      reason,
      ts: this.now(),
    });
    if (trade) {
      this.store.append('trade_closed', trade);
      this.risk.settle({ pnl: trade.pnl, fee: res.fee, win: trade.win, symbol: sym, tradeId: trade.id });
      this.stats.closes++;
      this.persist();
      if (this.bus) this.bus.emit('trade:closed', trade);
    }
    return trade;
  }

  /**
   * Funding rates for the carry sleeve. Never throws: a venue that does not
   * expose funding simply yields no carry candidates, which is the honest
   * outcome (the sleeve is skipped, not faked).
   */
  async _funding() {
    const out = {};
    const ex = this.hub?.primary;
    if (!ex || typeof ex.funding !== 'function') return out;
    for (const sym of this.cfg.symbols) {
      try {
        const f = await ex.funding(sym);
        if (f && Number.isFinite(Number(f.fundingBps))) out[sym] = f;
      } catch (e) {
        this.log.debug(`funding ${sym} unavailable: ${e.message}`);
      }
    }
    return out;
  }

  /**
   * Full weekly rotation: close what is no longer wanted, open what is.
   *
   * Synchronous on purpose — it is the public contract the tests and the
   * backtest rely on. The carry sleeve needs funding data, which is fetched by
   * the async caller (`onBar`) and passed in; when it is absent the sleeve
   * simply contributes nothing.
   */
  rebalance(fundingBySymbol = null) {
    if (this.risk.halted) {
      this.log.warn('rebalance skipped: risk halted');
      return { skipped: 'halted' };
    }
    const barsBySymbol = {};
    for (const sym of this.cfg.symbols) barsBySymbol[sym] = this._bars(sym);
    const targets = this.targetBook(barsBySymbol, fundingBySymbol);
    const scale = this.overlay();

    // enforce the gross cap by scaling every target down proportionally
    let gross = 0;
    for (const t of targets.values()) gross += t.pct;
    const cap = this.rc.maxGrossPct;
    const capScale = gross > cap ? cap / gross : 1;
    const totalScale = scale * capScale;

    const held = new Set(this.portfolio.ids());
    let closed = 0;
    let resized = 0;
    for (const sym of held) {
      const pos = this.portfolio.get(sym);
      if (pos.strategy !== 'ORBITAL') continue;
      const t = targets.get(sym);
      if (!t || t.dir !== pos.dir) {
        if (this._close(sym, t ? 'flip' : 'rebalance')) closed++;
      }
    }

    // bring held positions in line with the (overlay-scaled) target sizes
    for (const [sym, t] of targets) {
      if (!this.portfolio.hasPosition(sym)) continue;
      if (this.portfolio.get(sym).strategy !== 'ORBITAL') continue;
      if (this._resize(sym, t, totalScale)) resized++;
    }

    let opened = 0;
    const ordered = [...targets.entries()].sort((a, b) => b[1].pct - a[1].pct);
    for (const [sym, t] of ordered) {
      if (this.portfolio.hasPosition(sym)) continue;
      if (this.portfolio.openPositions().length >= this.rc.maxPositions) break;
      if (this._openTarget(sym, t, totalScale)) opened++;
    }

    this.stats.rebalances++;
    this.stats.lastRebalanceAt = this.now();
    this.lastBucket = Math.floor(this.now() / (this.rc.rebalanceHours * HOUR));
    this.persist();
    this.stats.lastScale = Math.round(totalScale * 1000) / 1000;
    this.stats.lastTargets = [...targets.entries()].map(([s, t]) => ({ symbol: s, dir: t.dir, pct: Math.round(t.pct * totalScale * 10) / 10 }));
    this.log.info('rebalance complete', {
      targets: targets.size, closed, opened, resized, scale: this.stats.lastScale,
      equity: Math.round(this.risk.state.equity * 100) / 100,
    });
    this.store.append('rebalance', { targets: this.stats.lastTargets, closed, opened, scale: this.stats.lastScale });
    return { targets: targets.size, closed, opened, resized, scale: totalScale };
  }

  /** Called from the engine clock: builds the first book without waiting for
   *  the next hourly close (order books need a few seconds to warm up). */
  tick() {
    const t = this.now();

    // Stale-quote sweep runs even once the book is booted: an open position on
    // a dead feed must still be able to leave (§25.4).
    this._staleSince = this._staleSince || new Map();
    for (const pos of this.portfolio.openPositions()) {
      const book = this._price(pos.symbol);
      const stale = !book || book.quoteAgeMs > this.cfg.data.staleQuoteMs;
      if (!stale) { this._staleSince.delete(pos.symbol); continue; }
      const since = this._staleSince.get(pos.symbol) || t;
      this._staleSince.set(pos.symbol, since);
      const grace = Number(this.rc.emergencyExitMs) || 15 * 60 * 1000;
      if (t - since >= grace) {
        this._staleSince.delete(pos.symbol);
        this._emergencyClose(pos.symbol);
      }
    }

    if (this.booted) return;
    if (t - (this._lastBootTry || 0) < 5000) return;
    this._lastBootTry = t;
    // onBar is async now (the carry sleeve fetches funding). Swallow the
    // rejection here: a failed rotation must never take down the 1s clock.
    Promise.resolve(this.onBar()).catch((e) => this.log.error(`rotator boot rotation failed: ${e.message}`));
  }

  /** Disaster stops and the boot-time first rotation. */
  async onBar() {
    this._sampleEquity();
    if (!this.ready()) return;
    const bucket = Math.floor(this.now() / (this.rc.rebalanceHours * HOUR));
    // the first book is built with retries: at boot the order books may still
    // be warming up, and we must not wait a whole week for the next attempt.
    if (!this.booted) {
      if (this.lastBucket !== null && this.lastBucket === bucket && this.portfolio.openPositions().length) {
        this.booted = true;
        this.log.info('book restored; this window needs no rebalance');
        return;
      }
      this._bootTries = (this._bootTries || 0) + 1;
      const funding = this.rc.sleeves?.carry?.enabled ? await this._funding() : null;
      const r = this.rebalance(funding);
      const need = r ? r.targets : 0;
      const have = this.portfolio.openPositions().length;
      if (have >= need || this._bootTries >= 40) {
        this.booted = true;
        this.lastBucket = bucket;
      }
      return;
    }
    if (bucket !== this.lastBucket) {
      this.lastBucket = bucket;
      const funding = this.rc.sleeves?.carry?.enabled ? await this._funding() : null;
      this.rebalance(funding);
    }
  }

  onTick(tick) {
    const pos = this.portfolio.get(tick.symbol);
    if (!pos || pos.strategy !== 'ORBITAL') return;
    const px = pos.dir > 0 ? tick.bid : tick.ask;
    if (!(px > 0)) return;

    // Trail first, then test the stop. Trailing only ever tightens, so the
    // order cannot turn a stop that should have fired into a miss.
    this._trail(pos, px);

    const hit = pos.dir > 0 ? px <= pos.sl : px >= pos.sl;
    if (!hit) return;
    this.stats.stops++;
    this.log.warn(`disaster stop ${tick.symbol} @ ${px}`);
    this._close(tick.symbol, 'stop');
  }

  /**
   * Move the stop toward the trade, never away from it.
   *
   * Charter §12 defines a LADDER, not a single distance:
   *   - below 1R the structural stop stays where it was;
   *   - at 1R the stop moves to the entry price (breakeven);
   *   - at 2R at least 1R of profit is locked in;
   *   - after that the stop follows the best price at `trailAtr` behind it.
   *
   * The old implementation jumped straight to a 2-ATR trail from 2 ATR of
   * profit, which is why every winner in the 6-month replay exited as `stop`
   * with a tiny gain: the trail was already above the entry before the trade
   * had earned a full R, so a normal pullback closed it at +0.1%.
   *
   * R is the initial risk in price terms: `disasterStopAtr * atr`, the same
   * distance the disaster stop was placed at. A position with no ATR context
   * is left alone: guessing a distance would be worse than not trailing.
   */
  _trail(pos, px) {
    if (!this.rc.trailEnabled) return;
    const atr = Number(pos.context && pos.context.atr);
    if (!(atr > 0)) return;

    const r = this.rc.disasterStopAtr * atr;
    if (!(r > 0)) return;
    const profit = (px - pos.entry) * pos.dir;
    if (!(profit > 0)) return;

    const beAtR = Number(this.rc.trailBeAtR ?? 1);
    const lockAtR = Number(this.rc.trailLockAtR ?? 2);
    const lockR = Number(this.rc.trailLockR ?? 1);
    const trailAtr = Number(this.rc.trailAtr ?? 1.5);

    let candidate = null;
    if (profit >= lockAtR * r) {
      // Locked-in profit and a live trail, whichever is tighter.
      const locked = pos.entry + pos.dir * lockR * r;
      const trailed = px - pos.dir * trailAtr * atr;
      candidate = pos.dir > 0 ? Math.max(locked, trailed) : Math.min(locked, trailed);
    } else if (profit >= beAtR * r) {
      candidate = pos.entry;
    }
    if (candidate === null) return;

    // Only tighten: a long's stop may only rise, a short's may only fall.
    const tighter = pos.dir > 0 ? candidate > pos.sl : candidate < pos.sl;
    if (!tighter) return;

    pos.sl = candidate;
    this.stats.trails = (this.stats.trails || 0) + 1;
  }

  snapshot() {
    return {
      ready: this.ready(),
      variants: this.variants.length,
      rebalanceHours: this.rc.rebalanceHours,
      volScale: Math.round(this.volScale * 100) / 100,
      ddScale: this.ddScale,
      ...this.stats,
      positions: this.portfolio.openPositions().map((p) => ({
        symbol: p.symbol, side: p.side, qty: Math.round(p.qty * 1e6) / 1e6,
        entry: p.entry, stop: p.sl, pnl: Math.round(p.unrealisedPnl() * 100) / 100,
      })),
    };
  }

  stop() { /* nothing scheduled */ }
}

module.exports = { Rotator, ema, atrSeries };
