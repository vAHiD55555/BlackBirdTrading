'use strict';
/**
 * BlackBird — brain provider adapters.
 *
 * Every provider implements the same tiny interface:
 *
 *   async complete({ messages, model, timeoutMs, signal }) -> string
 *
 * It returns the model's raw text. It does NOT parse, validate, or decide
 * anything — that is schema.js's job, and keeping the two apart is what makes
 * "the model misbehaved" distinguishable from "the network misbehaved".
 *
 * Providers throw on transport failure. The caller catches everything.
 *
 * Three wire protocols cover every provider in catalog.js:
 *   openai     OpenAI / Groq / OpenRouter / Cerebras / Mistral / Ollama
 *   anthropic  Anthropic Messages API
 *   gemini     Google Generative Language API
 *
 * No npm dependency: native fetch only.
 */

const { entry: catalogEntry, resolveKind, isKeyless, isLocalOnly, rejectionReason } = require('./catalog');
const { CloudflareProvider } = require('./cloudflare');

const DEFAULT_TIMEOUT_MS = 20000;

/** AbortSignal that fires after `ms`, plus cleanup so timers do not leak. */
function withTimeout(ms, external) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(new Error(`timeout after ${ms}ms`)), ms);
  const onAbort = () => ctl.abort(external.reason);
  if (external) {
    if (external.aborted) ctl.abort(external.reason);
    else external.addEventListener('abort', onAbort, { once: true });
  }
  return {
    signal: ctl.signal,
    done() {
      clearTimeout(timer);
      if (external) external.removeEventListener('abort', onAbort);
    },
  };
}

async function postJson(url, body, headers, timeoutMs, external) {
  const t = withTimeout(timeoutMs, external);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...headers },
      body: JSON.stringify(body),
      signal: t.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      // Keep the body short: a 4xx from a provider can be a wall of HTML.
      const snippet = text.slice(0, 300).replace(/\s+/g, ' ');
      let host = url;
      try { host = new URL(url).host; } catch { /* keep raw */ }
      throw new Error(`HTTP ${res.status} from ${host}: ${snippet}`);
    }
    try {
      return JSON.parse(text);
    } catch {
      throw new Error(`provider returned non-JSON body: ${text.slice(0, 200)}`);
    }
  } finally {
    t.done();
  }
}

// --------------------------------------------------------------- OpenAI-compatible
/**
 * Works with OpenAI, and with anything that speaks the same dialect:
 * Ollama (/v1/chat/completions), LM Studio, vLLM, OpenRouter, Groq, Cerebras,
 * Mistral, Together.
 */
class OpenAICompatibleProvider {
  constructor({ baseUrl, apiKey, model, timeoutMs, extraHeaders, jsonMode, chatPath, name } = {}) {
    this.name = name || 'openai';
    this.baseUrl = String(baseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '');
    this.apiKey = apiKey || '';
    this.model = model || 'gpt-4o-mini';
    this.timeoutMs = timeoutMs || DEFAULT_TIMEOUT_MS;
    this.extraHeaders = extraHeaders || {};
    this.jsonMode = jsonMode !== false;
    // Most providers live at <base>/chat/completions. Pollinations lives at
    // <base>/openai. One field keeps the adapter honest for both.
    this.chatPath = chatPath || '/chat/completions';
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    const url = `${this.baseUrl}${this.chatPath}`;
    const headers = { ...this.extraHeaders };
    // A local Ollama needs no key; sending an empty Bearer confuses some proxies.
    if (this.apiKey) headers.authorization = `Bearer ${this.apiKey}`;

    const body = {
      model: model || this.model,
      temperature: 0,
      max_tokens: 400,
      messages,
    };
    // Ask for JSON where the provider supports it; harmless where it does not.
    if (this.jsonMode) body.response_format = { type: 'json_object' };

    const json = await postJson(url, body, headers, timeoutMs || this.timeoutMs, signal);

    const content = json?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || !content.trim()) {
      throw new Error('provider returned an empty completion');
    }
    return content;
  }
}

// ------------------------------------------------------------------- Anthropic
class AnthropicProvider {
  constructor({ baseUrl, apiKey, model, timeoutMs, name } = {}) {
    this.name = name || 'anthropic';
    this.baseUrl = String(baseUrl || 'https://api.anthropic.com/v1').replace(/\/+$/, '');
    this.apiKey = apiKey || '';
    this.model = model || 'claude-3-5-haiku-latest';
    this.timeoutMs = timeoutMs || DEFAULT_TIMEOUT_MS;
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    if (!this.apiKey) throw new Error('anthropic provider requires an API key');

    // Anthropic keeps the system prompt out of the message array.
    const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
    const rest = messages.filter((m) => m.role !== 'system');

    const json = await postJson(
      `${this.baseUrl}/messages`,
      {
        model: model || this.model,
        max_tokens: 400,
        temperature: 0,
        system,
        messages: rest,
      },
      {
        'x-api-key': this.apiKey,
        'anthropic-version': '2023-06-01',
      },
      timeoutMs || this.timeoutMs,
      signal
    );

    const parts = Array.isArray(json?.content) ? json.content : [];
    const text = parts.filter((p) => p?.type === 'text').map((p) => p.text).join('');
    if (!text.trim()) throw new Error('anthropic returned an empty completion');
    return text;
  }
}

// ---------------------------------------------------------------------- Gemini
/**
 * Google Generative Language API. The key goes in a header, not the query
 * string, so it never lands in a proxy log or an error message.
 */
class GeminiProvider {
  constructor({ baseUrl, apiKey, model, timeoutMs, name } = {}) {
    this.name = name || 'gemini';
    this.baseUrl = String(baseUrl || 'https://generativelanguage.googleapis.com/v1beta').replace(/\/+$/, '');
    this.apiKey = apiKey || '';
    this.model = model || 'gemini-2.0-flash';
    this.timeoutMs = timeoutMs || DEFAULT_TIMEOUT_MS;
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    if (!this.apiKey) throw new Error('gemini provider requires an API key');

    const sys = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
    const contents = messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: String(m.content) }],
      }));

    const body = {
      contents,
      generationConfig: {
        temperature: 0,
        maxOutputTokens: 400,
        responseMimeType: 'application/json',
      },
    };
    if (sys) body.systemInstruction = { parts: [{ text: sys }] };

    const m = model || this.model;
    const json = await postJson(
      `${this.baseUrl}/models/${encodeURIComponent(m)}:generateContent`,
      body,
      { 'x-goog-api-key': this.apiKey },
      timeoutMs || this.timeoutMs,
      signal
    );

    const cands = Array.isArray(json?.candidates) ? json.candidates : [];
    const text = cands
      .flatMap((c) => (c?.content?.parts || []))
      .map((p) => p?.text || '')
      .join('');
    if (!text.trim()) {
      const blocked = json?.promptFeedback?.blockReason;
      throw new Error(blocked ? `gemini blocked the prompt: ${blocked}` : 'gemini returned an empty completion');
    }
    return text;
  }
}

// ------------------------------------------------------------------------ Mock
/**
 * Deterministic provider for tests and for `provider: "mock"` dry runs.
 *
 * `script` is a queue of behaviours consumed one per call:
 *   { reply: '<text>' }        return this text
 *   { error: 'message' }       throw
 *   { timeout: true }          hang until the caller's timeout aborts
 *   { delayMs: 50, reply: '' } sleep first
 * When the queue is empty it falls back to `defaultReply`.
 */
class MockProvider {
  constructor({ script = [], defaultReply = null, timeoutMs, name } = {}) {
    this.name = name || 'mock';
    this.script = [...script];
    this.defaultReply = defaultReply;
    this.timeoutMs = timeoutMs || DEFAULT_TIMEOUT_MS;
    this.calls = [];
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    this.calls.push({ messages, model, at: Date.now() });
    const step = this.script.length ? this.script.shift() : { reply: this.defaultReply };

    if (step && step.timeout) {
      // Never resolve: the caller's AbortController is what ends this.
      await new Promise((resolve, reject) => {
        const t = setTimeout(resolve, (timeoutMs || this.timeoutMs) + 5000);
        if (signal) {
          if (signal.aborted) { clearTimeout(t); reject(signal.reason || new Error('aborted')); return; }
          signal.addEventListener('abort', () => {
            clearTimeout(t);
            reject(signal.reason || new Error('aborted'));
          }, { once: true });
        }
      });
      throw new Error('mock timeout was not aborted by the caller');
    }

    if (step && step.delayMs) {
      await new Promise((r) => setTimeout(r, step.delayMs));
    }
    if (step && step.error) throw new Error(step.error);
    if (step && typeof step.reply === 'string') return step.reply;
    if (typeof this.defaultReply === 'string') return this.defaultReply;
    throw new Error('mock provider has no scripted reply');
  }
}

// ---------------------------------------------------------------------- factory
const KINDS = {
  openai: OpenAICompatibleProvider,
  anthropic: AnthropicProvider,
  gemini: GeminiProvider,
  cloudflare: CloudflareProvider,
  mock: MockProvider,
};

/**
 * Build a provider from config. The API key is read from the environment by the
 * caller, never stored in config.json.
 *
 * @param {object} cfg   { provider, model, baseUrl, timeoutMs, ... }
 * @param {object} deps  { apiKey, script, defaultReply, env }
 */
function createProvider(cfg = {}, deps = {}) {
  const requested = String(cfg.provider || 'pollinations').toLowerCase();

  // A paid provider is refused with an explanation, not a generic "unknown".
  const why = rejectionReason(requested);
  if (why) throw new Error(why);

  const cat = catalogEntry(requested);
  if (!cat) {
    throw new Error(
      `unknown brain provider "${cfg.provider}" (free: pollinations, cloudflare, ollama, groq, gemini, ` +
      `cerebras, mistral, openrouter, mock)`
    );
  }

  const kind = cat.kind;
  const Ctor = KINDS[kind];
  if (!Ctor) throw new Error(`provider "${requested}" maps to unsupported kind "${kind}"`);

  if (kind === 'mock') {
    return new MockProvider({
      script: deps.script || cfg.script || [],
      defaultReply: deps.defaultReply || cfg.defaultReply || null,
      timeoutMs: cfg.timeoutMs,
      name: cat.key,
    });
  }

  // Key resolution: explicit dep wins, then the catalog's env var, then the
  // legacy JEV_API_KEY. A keyless provider (ollama) gets an empty string.
  let apiKey = deps.apiKey;
  if (apiKey === undefined) {
    const env = deps.env || process.env;
    if (cat.apiKeyEnv && env[cat.apiKeyEnv]) apiKey = String(env[cat.apiKeyEnv]).trim();
    else if (env.JEV_API_KEY) apiKey = String(env.JEV_API_KEY).trim();
    else apiKey = '';
  }

  // Cloudflare needs a second credential (the account id) and reads it itself.
  if (kind === 'cloudflare') {
    return new CloudflareProvider({
      accountId: cfg.accountId,
      apiKey,
      model: cfg.model || (cat.models && cat.models[0]) || undefined,
      baseUrl: cfg.baseUrl || cat.baseUrl,
      timeoutMs: cfg.timeoutMs,
      env: deps.env || process.env,
      name: cat.key,
    });
  }

  return new Ctor({
    baseUrl: cfg.baseUrl || cat.baseUrl,
    apiKey,
    model: cfg.model || (cat.models && cat.models[0]) || undefined,
    timeoutMs: cfg.timeoutMs,
    extraHeaders: cat.extraHeaders,
    jsonMode: cat.jsonMode,
    chatPath: cat.chatPath,
    name: cat.key,
  });
}

module.exports = {
  createProvider,
  OpenAICompatibleProvider,
  AnthropicProvider,
  GeminiProvider,
  CloudflareProvider,
  MockProvider,
  KINDS,
  PROVIDERS: KINDS,
  DEFAULT_TIMEOUT_MS,
  resolveKind,
  isKeyless,
  isLocalOnly,
};
