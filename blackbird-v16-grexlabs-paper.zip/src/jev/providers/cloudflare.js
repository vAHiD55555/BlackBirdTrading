'use strict';
/**
 * BlackBird — Cloudflare Workers AI adapter.
 *
 * Workers AI is the primary model path: a generous free tier, no card, and
 * latency that does not depend on a shared queue of free-tier users.
 *
 * IMPORTANT — two different products, often confused:
 *   Workers        = hosting code at the edge. This project does NOT use it.
 *   Workers AI     = running inference on Cloudflare's GPUs. This is what we use.
 * You need an Account ID and an API token with the "Workers AI: Read" permission.
 * You do NOT need to deploy a Worker.
 *
 * Endpoint:
 *   POST https://api.cloudflare.com/client/v4/accounts/{ACCOUNT_ID}/ai/run/{MODEL}
 *
 * Auth: `Authorization: Bearer <CLOUDFLARE_API_TOKEN>`
 *
 * Response shape (non-streaming):
 *   { result: { response: "..." }, success: true, errors: [], messages: [] }
 *
 * The `response` field is a string for text-generation models. Some models
 * return an object instead (tool calls, or a pre-parsed JSON body); both are
 * handled, and anything else is a hard error rather than a silent empty string.
 */

const DEFAULT_TIMEOUT_MS = 20000;
const DEFAULT_BASE = 'https://api.cloudflare.com/client/v4';

/** Free-tier models. All of these are usable without a paid plan. */
const MODELS = [
  '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
  '@cf/meta/llama-3.1-8b-instruct',
  '@cf/qwen/qwen2.5-coder-32b-instruct',
  '@cf/mistral/mistral-small-3.1-24b-instruct',
  '@cf/google/gemma-3-12b-it',
];

function withTimeout(ms, external) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(new Error(`timeout after ${ms}ms`)), ms);
  const onAbort = () => ctl.abort(external.reason);
  if (external) {
    if (external.aborted) ctl.abort(external.reason);
    else external.addEventListener('abort', onAbort, { once: true });
  }
  return {
    signal: ctl.signal,
    done() {
      clearTimeout(timer);
      if (external) external.removeEventListener('abort', onAbort);
    },
  };
}

/**
 * Map a Cloudflare error body to one readable line.
 * Cloudflare returns { success:false, errors:[{code,message}] } with a 200
 * sometimes, so the body must be checked even when res.ok is true.
 */
function describeError(status, body) {
  const errs = Array.isArray(body?.errors) ? body.errors : [];
  if (errs.length) {
    const first = errs[0];
    return `HTTP ${status} from Cloudflare Workers AI: ${first.code || ''} ${first.message || ''}`.trim();
  }
  if (status === 401 || status === 403) {
    return `HTTP ${status} from Cloudflare Workers AI: token rejected (check CLOUDFLARE_API_TOKEN and the "Workers AI: Read" permission)`;
  }
  if (status === 429) {
    return 'HTTP 429 from Cloudflare Workers AI: daily Neurons quota exhausted or rate limited';
  }
  return `HTTP ${status} from Cloudflare Workers AI`;
}

class CloudflareProvider {
  /**
   * @param {object} opts
   * @param {string} [opts.accountId]  defaults to env CLOUDFLARE_ACCOUNT_ID
   * @param {string} [opts.apiKey]     defaults to env CLOUDFLARE_API_TOKEN
   * @param {string} [opts.model]
   * @param {string} [opts.baseUrl]
   * @param {number} [opts.timeoutMs]
   * @param {object} [opts.env]        injectable environment (tests)
   */
  constructor({ accountId, apiKey, model, baseUrl, timeoutMs, env, name } = {}) {
    const e = env || process.env;
    this.name = name || 'cloudflare';
    this.accountId = accountId || e.CLOUDFLARE_ACCOUNT_ID || '';
    this.apiKey = apiKey || e.CLOUDFLARE_API_TOKEN || '';
    this.model = model || MODELS[0];
    this.baseUrl = String(baseUrl || DEFAULT_BASE).replace(/\/+$/, '');
    this.timeoutMs = timeoutMs || DEFAULT_TIMEOUT_MS;
  }

  /** Both credentials are required; a missing one is a config error, not a retry. */
  get configured() {
    return Boolean(this.accountId && this.apiKey);
  }

  async complete({ messages, model, timeoutMs, signal } = {}) {
    if (!this.accountId) throw new Error('cloudflare provider requires CLOUDFLARE_ACCOUNT_ID');
    if (!this.apiKey) throw new Error('cloudflare provider requires CLOUDFLARE_API_TOKEN');

    const m = model || this.model;
    const url = `${this.baseUrl}/accounts/${encodeURIComponent(this.accountId)}/ai/run/${m}`;

    // Workers AI takes a flat `messages` array; the system prompt is just the
    // first message, which is exactly the shape jev already builds.
    const body = {
      messages: messages.map((x) => ({ role: x.role, content: String(x.content) })),
      temperature: 0,
      max_tokens: 400,
    };

    const t = withTimeout(timeoutMs || this.timeoutMs, signal);
    let res;
    let text;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: t.signal,
      });
      text = await res.text();
    } finally {
      t.done();
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error(`Cloudflare returned non-JSON body: ${String(text).slice(0, 200)}`);
    }

    // Cloudflare can return 200 with success:false. Check the body, not just the status.
    if (!res.ok || json?.success === false) {
      throw new Error(describeError(res.status, json));
    }

    const result = json?.result;
    if (result == null) throw new Error('Cloudflare returned no result');

    // Text models: { response: "..." }. Some return an object already parsed.
    if (typeof result.response === 'string') {
      if (!result.response.trim()) throw new Error('Cloudflare returned an empty completion');
      return result.response;
    }
    if (typeof result === 'string') {
      if (!result.trim()) throw new Error('Cloudflare returned an empty completion');
      return result;
    }
    if (typeof result === 'object') {
      // A pre-parsed object is still a valid answer; hand it back as JSON text
      // so the schema layer sees exactly one code path.
      return JSON.stringify(result);
    }
    throw new Error(`Cloudflare returned an unexpected result type: ${typeof result}`);
  }
}

module.exports = { CloudflareProvider, MODELS, DEFAULT_BASE, describeError };
