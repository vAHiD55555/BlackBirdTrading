'use strict';
/**
 * BlackBird — provider catalog.
 *
 * One table that answers, for every provider jev can talk to:
 *   - which wire protocol it speaks (`kind`)
 *   - where it lives (`baseUrl`)
 *   - which environment variable holds the key (`apiKeyEnv`)
 *   - what the free tier actually allows (`rateLimit`)
 *   - which models are worth trying (`models`)
 *   - where it sits in the fallback order (`priority`)
 *
 * HARD RULE: every entry here must have a permanent free tier. No trial, no
 * card-required, no "free for 14 days". If a provider cannot meet that, it does
 * not belong in this file. See FREE-ONLY.md.
 *
 * The key is NEVER stored here. This file only names the variable; the value is
 * read from process.env at call time.
 *
 * `priority` is the fallback order, lowest first:
 *    5  Pollinations           — keyless AND remote: works on a hosted free tier
 *   10  Cloudflare Workers AI  — generous quota, needs a free token
 *   20  Ollama (local)         — no quota at all, but needs your own hardware
 *                                (NOT usable on a hosted container: 127.0.0.1
 *                                there is the container, with nothing installed)
 *   30  Groq                   — fast, small daily cap
 *   40  Gemini                 — good quality, small daily cap
 *   50  Cerebras               — fast, token-capped
 *   60  Mistral                — small but reliable
 *   90  OpenRouter             — last resort: 50 req/day on free models
 */

const CATALOG = {
  // ------------------------------------------------- Pollinations (keyless, remote)
  // The only provider that needs NO key AND NO local process. That combination
  // is what makes it the right default on a hosted free tier (botkeep.cloud and
  // friends), where 127.0.0.1 is the container itself and nothing is installed
  // there. Anonymous quota is small (one reply per ~45s per IP), which is fine
  // for the handful of calls this project makes per hour.
  pollinations: {
    label: 'Pollinations (keyless)',
    kind: 'openai',
    baseUrl: 'https://text.pollinations.ai',
    // Pollinations exposes its OpenAI-compatible endpoint at /openai, not at
    // /v1/chat/completions. `chatPath` is what lets one adapter serve both.
    chatPath: '/openai',
    apiKeyEnv: null, // no key at all
    free: true,
    cardRequired: false,
    priority: 5, // first: works on any host with no setup
    rateLimit: '1 reply / ~45s per IP (anonymous)',
    signup: 'https://pollinations.ai',
    jsonMode: false,
    models: ['openai', 'openai-fast', 'mistral'],
  },

  // ------------------------------------------------------------- GrexLabs
  // OpenAI-compatible keyless gateway. Use only with redacted, non-secret
  // telemetry; provider availability and model routing are external.
  grex: {
    label: 'GrexLabs (keyless experimental)',
    kind: 'openai',
    baseUrl: 'https://www.grexlabs.in/api/v1',
    chatPath: '/chat/completions',
    apiKeyEnv: null,
    free: true,
    cardRequired: false,
    priority: 7,
    rateLimit: 'provider-defined; apply local rate limits',
    signup: 'https://www.grexlabs.in',
    jsonMode: false,
    models: ['auto:free'],
  },

  // ------------------------------------------------------- Cloudflare Workers AI
  cloudflare: {
    label: 'Cloudflare Workers AI',
    kind: 'cloudflare',
    baseUrl: 'https://api.cloudflare.com/client/v4',
    apiKeyEnv: 'CLOUDFLARE_API_TOKEN',
    extraEnv: ['CLOUDFLARE_ACCOUNT_ID'],
    free: true,
    cardRequired: false,
    priority: 10,
    rateLimit: '10,000 Neurons/day · ~20 req/min (free plan)',
    signup: 'https://dash.cloudflare.com/profile/api-tokens',
    jsonMode: false,
    // Workers AI (inference) is a different product from Workers (hosting).
    // This project only uses the former; you do not deploy a Worker.
    models: [
      '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
      '@cf/meta/llama-3.1-8b-instruct',
      '@cf/qwen/qwen2.5-coder-32b-instruct',
      '@cf/mistral/mistral-small-3.1-24b-instruct',
      '@cf/google/gemma-3-12b-it',
    ],
  },

  // -------------------------------------------------------------------- Ollama
  ollama: {
    label: 'Ollama (local)',
    kind: 'openai',
    baseUrl: 'http://127.0.0.1:11434/v1',
    apiKeyEnv: null, // local: no key at all
    free: true,
    cardRequired: false,
    priority: 20,
    rateLimit: 'unlimited — bounded only by your own hardware',
    signup: 'https://ollama.com/download',
    jsonMode: false,
    // Only meaningful when the process runs on a machine you control. On a
    // hosted container 127.0.0.1 is the container itself, so this provider is
    // unreachable there — that is why it is no longer the default.
    localOnly: true,
    models: ['qwen2.5:7b', 'llama3.1:8b'],
  },

  // ------------------------------------------------------------------- NVIDIA
  // NVIDIA NIM exposes an OpenAI-compatible endpoint. The free developer tier
  // gives a generous credit allowance with no card, which is why it belongs
  // here. It needs a key, so it is never the default on a keyless host.
  nvidia: {
    label: 'NVIDIA NIM',
    kind: 'openai',
    baseUrl: 'https://integrate.api.nvidia.com/v1',
    apiKeyEnv: 'NVIDIA_API_KEY',
    free: true,
    cardRequired: false,
    priority: 25,
    rateLimit: '1,000 free credits on signup (no card)',
    signup: 'https://build.nvidia.com',
    jsonMode: false,
    models: [
      'meta/llama-3.3-70b-instruct',
      'meta/llama-3.1-8b-instruct',
      'mistralai/mistral-small-24b-instruct',
      'nvidia/llama-3.1-nemotron-70b-instruct',
    ],
  },

  // ---------------------------------------------------------------------- Groq
  groq: {
    label: 'Groq',
    kind: 'openai',
    baseUrl: 'https://api.groq.com/openai/v1',
    apiKeyEnv: 'GROQ_API_KEY',
    free: true,
    cardRequired: false,
    priority: 30,
    rateLimit: '~30 req/min · 1,000 req/day per model (free tier)',
    signup: 'https://console.groq.com/keys',
    jsonMode: true,
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'qwen/qwen3-32b'],
  },

  // -------------------------------------------------------------------- Gemini
  gemini: {
    label: 'Google Gemini',
    kind: 'gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    apiKeyEnv: 'GEMINI_API_KEY',
    free: true,
    cardRequired: false,
    priority: 40,
    rateLimit: '~15 req/min · 1,500 req/day (gemini-2.0-flash free tier)',
    signup: 'https://aistudio.google.com/apikey',
    jsonMode: true,
    models: ['gemini-2.0-flash', 'gemini-2.5-flash'],
  },

  // ------------------------------------------------------------------ Cerebras
  cerebras: {
    label: 'Cerebras',
    kind: 'openai',
    baseUrl: 'https://api.cerebras.ai/v1',
    apiKeyEnv: 'CEREBRAS_API_KEY',
    free: true,
    cardRequired: false,
    priority: 50,
    rateLimit: '~30 req/min · 1M tokens/day (free tier)',
    signup: 'https://cloud.cerebras.ai',
    jsonMode: false,
    models: ['llama-3.3-70b'],
  },

  // ------------------------------------------------------------------- Mistral
  mistral: {
    label: 'Mistral',
    kind: 'openai',
    baseUrl: 'https://api.mistral.ai/v1',
    apiKeyEnv: 'MISTRAL_API_KEY',
    free: true,
    cardRequired: false,
    priority: 60,
    rateLimit: '~1 req/sec · 500k tokens/min (free "experiment" tier)',
    signup: 'https://console.mistral.ai/api-keys',
    jsonMode: true,
    models: ['mistral-small-latest'],
  },

  // ---------------------------------------------------------------- OpenRouter
  openrouter: {
    label: 'OpenRouter',
    kind: 'openai',
    baseUrl: 'https://openrouter.ai/api/v1',
    apiKeyEnv: 'OPENROUTER_API_KEY',
    free: true,
    cardRequired: false,
    priority: 90, // last resort: the free daily cap is tiny
    rateLimit: '~20 req/min · 50 req/day (1,000/day after a one-time $10 top-up)',
    signup: 'https://openrouter.ai/keys',
    jsonMode: false,
    // Only `:free` models. Anything without that suffix costs money.
    models: [
      'meta-llama/llama-3.3-70b-instruct:free',
      'qwen/qwen-2.5-72b-instruct:free',
      'deepseek/deepseek-chat-v3-0324:free',
      'google/gemma-3-27b-it:free',
      'mistralai/mistral-small-3.2-24b-instruct:free',
    ],
    extraHeaders: {
      'HTTP-Referer': 'https://github.com/blackbird-trader',
      'X-Title': 'BlackBird jev',
    },
  },

  // ---------------------------------------------------------------------- Mock
  mock: {
    label: 'Mock (offline)',
    kind: 'mock',
    baseUrl: '',
    apiKeyEnv: null,
    free: true,
    cardRequired: false,
    priority: 999,
    rateLimit: 'n/a — no network',
    signup: '',
    jsonMode: false,
    models: ['mock-1'],
  },
};

/**
 * Paid providers are deliberately NOT in the catalog. They are listed here only
 * so an operator who tries one gets a clear explanation instead of "unknown
 * provider", and so the free-only rule is visible in the code.
 */
const PAID_ONLY = {
  anthropic: 'Anthropic has no permanent free tier (trial credits only).',
  openai: 'OpenAI has no permanent free tier (trial credits only).',
};

/** Aliases so `provider: "openai-compatible"` keeps working. */
const ALIASES = {
  'openai-compatible': 'openai',
  google: 'gemini',
  'google-gemini': 'gemini',
  local: 'ollama',
  polli: 'pollinations',
  'pollinations-ai': 'pollinations',
  grexlabs: 'grex',
  grex: 'grex',
  cf: 'cloudflare',
  'workers-ai': 'cloudflare',
  'cloudflare-workers-ai': 'cloudflare',
  nim: 'nvidia',
  'nvidia-nim': 'nvidia',
};

function resolveKind(name) {
  const raw = String(name || '').trim().toLowerCase();
  const key = ALIASES[raw] || raw;
  return CATALOG[key] ? key : null;
}

function entry(name) {
  const key = resolveKind(name);
  return key ? { key, ...CATALOG[key] } : null;
}

/** Every provider that needs no key (pollinations, ollama, mock). */
function isKeyless(name) {
  const e = entry(name);
  return Boolean(e && !e.apiKeyEnv);
}

/**
 * True when the provider can only be reached from the same machine.
 * A hosted container cannot use these, so the fallback chain must skip them
 * instead of burning a timeout on a connection that can never succeed.
 */
function isLocalOnly(name) {
  const e = entry(name);
  return Boolean(e && e.localOnly);
}

/** The env var name for a provider, or null when it needs no key. */
function apiKeyEnvFor(name) {
  const e = entry(name);
  return e ? e.apiKeyEnv : null;
}

/** All free providers, in fallback order. */
function byPriority() {
  return Object.entries(CATALOG)
    .map(([key, v]) => ({ key, ...v }))
    .sort((a, b) => a.priority - b.priority);
}

/** Why a provider is not usable, or null when it is. */
function rejectionReason(name) {
  const raw = String(name || '').trim().toLowerCase();
  if (PAID_ONLY[raw]) return `${raw} is not free: ${PAID_ONLY[raw]}`;
  if (!resolveKind(raw)) return `unknown provider "${name}"`;
  return null;
}

module.exports = {
  CATALOG,
  PAID_ONLY,
  ALIASES,
  resolveKind,
  entry,
  isKeyless,
  isLocalOnly,
  apiKeyEnvFor,
  byPriority,
  rejectionReason,
};
