'use strict';
/**
 * BlackBird — the trial registry (K).
 *
 * WHY THIS EXISTS
 * ---------------
 * Every parameter you tune, every threshold you nudge, every model you add is
 * a test. Run enough tests and one of them will look brilliant by pure chance.
 * A Sharpe of 2.0 sounds excellent — until you learn it was the best of 400
 * configurations, at which point the expected maximum Sharpe of 400 *random*
 * strategies is already around 2.0.
 *
 * Deflated Sharpe Ratio (Bailey & López de Prado, 2014) is the correction. It
 * needs K: how many independent trials produced the number you are looking at.
 * Without K, DSR cannot be computed, and without DSR there is no honest way to
 * say whether an edge is real.
 *
 * So K is not a statistic. It is a discipline: every change that could have
 * produced a different result gets a record, and the counter never resets.
 *
 * STORAGE
 * -------
 *   data/trials.jsonl   append-only, one JSON object per line
 *
 * Append-only on purpose: a mutable counter can be "accidentally" reset, and a
 * reset K is a lie. The file is the source of truth; the in-memory count is
 * derived from it on load.
 *
 * UNREGISTERED TRIALS
 * -------------------
 * A config file edited by hand is a trial nobody recorded. `detectDrift()`
 * compares the current config fingerprint against the last recorded one and
 * reports the gap, so the lawyer can file it as an unregistered trial instead
 * of silently under-counting K.
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const SCHEMA_VERSION = 1;

/** Fields of the config that count as "a test" when they change. */
const TRIAL_FIELDS = [
  'strategy.mode',
  'strategy.rotator.perPositionPct',
  'strategy.rotator.maxGrossPct',
  'strategy.rotator.maxPositions',
  'strategy.rotator.rebalanceHours',
  'strategy.rotator.volTargetPct',
  'strategy.rotator.disasterStopAtr',
  'strategy.rotator.variants',
  'strategy.minVolPercentile',
  'strategy.maxSpreadBps',
  'strategy.minDepthUsd',
  'strategy.rrTarget',
  'strategy.minRR',
  'strategy.slAtrFloor',
  'strategy.slAtrCeil',
  'strategy.minTpBps',
  'strategy.maxTpBps',
  'strategy.pullbackRsiMin',
  'strategy.pullbackRsiMax',
  'strategy.trailAtr',
  'risk.maxPositionPct',
  'risk.maxOpenPositions',
  'risk.maxSymbolExposurePct',
  'risk.maxDailyLossPct',
  'risk.maxDailyTrades',
  'risk.killSwitchDrawdownPct',
  'risk.riskPerTradePct',
  'risk.maxNetExposurePct',
  'fees.makerBps',
  'fees.takerBps',
  'jev.enabled',
  'jev.provider',
  'jev.model',
  'jev.maxRiskMultiplier',
  'jev.consensus.enabled',
  'jev.consensus.models',
  'jev.consensus.quorum',
  'lawyer.enabled',
  'lawyer.autoObject',
  'lawyer.clauses',
  'exchange',
  'symbols',
  'data.timeframe',
];

function getPath(obj, dotted) {
  return dotted.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

/** Stable JSON: sorted keys, so a fingerprint does not depend on key order. */
function stableStringify(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`;
  const keys = Object.keys(v).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${stableStringify(v[k])}`).join(',')}}`;
}

/**
 * Fingerprint the trial-relevant part of a config.
 * @param {object} cfg
 * @returns {{hash: string, values: object}}
 */
function fingerprint(cfg) {
  const values = {};
  for (const f of TRIAL_FIELDS) {
    const v = getPath(cfg, f);
    if (v !== undefined) values[f] = v;
  }
  const hash = crypto.createHash('sha256').update(stableStringify(values)).digest('hex').slice(0, 16);
  return { hash, values };
}

/**
 * Create a directory, refusing paths on special filesystems.
 *
 * `fs.mkdirSync('/proc/anything', {recursive:true})` does not throw — it HANGS
 * on Linux, because /proc is a synthetic filesystem that never reports the
 * directory as created. A misconfigured dataDir would therefore freeze the
 * engine at boot with no error and no log line. Guarding the known synthetic
 * mounts turns that hang into an ordinary, reportable failure.
 */
const FORBIDDEN_ROOTS = ['/proc', '/sys', '/dev'];

function ensureDir(dir) {
  const abs = path.resolve(dir);
  for (const root of FORBIDDEN_ROOTS) {
    if (abs === root || abs.startsWith(`${root}/`)) {
      throw new Error(`refusing to write under ${root} (synthetic filesystem)`);
    }
  }
  fs.mkdirSync(abs, { recursive: true });
}

class TrialRegistry {
  /**
   * @param {object} opts
   * @param {string} [opts.file]   path to trials.jsonl
   * @param {object} [opts.log]
   * @param {function} [opts.clock]
   */
  constructor({ file, log, clock } = {}) {
    this.file = file || path.join(process.cwd(), 'data', 'trials.jsonl');
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.clock = clock || (() => Date.now());

    this.trials = [];
    this._loaded = false;
    this.stats = { loaded: 0, appended: 0, failed: 0, lastError: null };
  }

  /** Read the file once. A torn last line is skipped, never fatal. */
  load() {
    if (this._loaded) return this.trials;
    this._loaded = true;
    try {
      if (!fs.existsSync(this.file)) return this.trials;
      const text = fs.readFileSync(this.file, 'utf8');
      for (const line of text.split('\n')) {
        if (!line.trim()) continue;
        try {
          const rec = JSON.parse(line);
          if (rec && typeof rec === 'object') this.trials.push(rec);
        } catch { /* torn line: skip */ }
      }
      this.stats.loaded = this.trials.length;
    } catch (e) {
      this.stats.lastError = e.message;
      this.log.warn(`trial registry load failed: ${e.message}`);
    }
    return this.trials;
  }

  /** K — the number of recorded trials. Derived from the file, never a counter. */
  get K() {
    this.load();
    return this.trials.length;
  }

  /**
   * Record a trial.
   *
   * @param {object} p
   * @param {string} p.kind        'param_change' | 'backtest' | 'model_change' | 'manual' | 'unregistered'
   * @param {string} [p.field]     dotted config path
   * @param {*} [p.from]           previous value
   * @param {*} [p.to]             new value
   * @param {string} [p.note]
   * @param {string} [p.source]    'engine' | 'cli' | 'operator' | 'drift'
   * @param {object} [p.metrics]   { sharpe, n, skew, kurt } when known
   * @returns {object|null} the record, or null when the write failed
   */
  record({ kind = 'manual', field, from, to, note, source = 'engine', metrics } = {}) {
    this.load();
    const rec = {
      schemaVersion: SCHEMA_VERSION,
      k: this.trials.length + 1, // this trial's ordinal
      ts: this.clock(),
      kind,
      field: field || null,
      from: from === undefined ? null : from,
      to: to === undefined ? null : to,
      note: note || '',
      source,
      metrics: metrics || null,
    };

    try {
      ensureDir(path.dirname(this.file));
      fs.appendFileSync(this.file, `${JSON.stringify(rec)}\n`, 'utf8');
      this.trials.push(rec);
      this.stats.appended++;
      return rec;
    } catch (e) {
      this.stats.failed++;
      this.stats.lastError = e.message;
      this.log.warn(`trial registry write failed: ${e.message}`);
      return null;
    }
  }

  /**
   * Compare a config against the last recorded fingerprint.
   *
   * Returns the fields that changed. If any changed and no trial was recorded
   * for them, they are "unregistered" — the operator edited config.json by hand
   * and K is now under-counted.
   *
   * @param {object} cfg
   * @returns {{changed: Array, unregistered: boolean, lastHash: string|null, hash: string}}
   */
  detectDrift(cfg) {
    this.load();
    const { hash, values } = fingerprint(cfg);
    const last = [...this.trials].reverse().find((t) => t.fingerprint);
    if (!last) {
      return { changed: [], unregistered: false, lastHash: null, hash, values };
    }
    const changed = [];
    for (const f of TRIAL_FIELDS) {
      const a = stableStringify(last.fingerprint[f]);
      const b = stableStringify(values[f]);
      if (a !== b) changed.push({ field: f, from: last.fingerprint[f], to: values[f] });
    }
    return { changed, unregistered: changed.length > 0, lastHash: last.hash || null, hash, values };
  }

  /**
   * Record the current config as a baseline trial, with its fingerprint.
   * Called at boot so the next drift has something to compare against.
   */
  recordBaseline(cfg, note = 'boot baseline') {
    const { hash, values } = fingerprint(cfg);
    const rec = this.record({ kind: 'baseline', note, source: 'engine' });
    if (rec) {
      // The fingerprint is written as a second line so the record stays small
      // and the append-only invariant holds.
      try {
        fs.appendFileSync(this.file, `${JSON.stringify({
          schemaVersion: SCHEMA_VERSION, k: rec.k, ts: rec.ts, kind: 'fingerprint', hash, fingerprint: values,
        })}\n`, 'utf8');
        this.trials.push({ k: rec.k, kind: 'fingerprint', hash, fingerprint: values });
      } catch { /* the baseline record itself is already on disk */ }
    }
    return rec;
  }

  /** Record a drift as an unregistered trial, so K stops under-counting. */
  recordDrift(drift, source = 'drift') {
    if (!drift || !drift.unregistered) return null;
    const rec = this.record({
      kind: 'unregistered',
      note: `config changed outside the registry: ${drift.changed.map((c) => c.field).join(', ')}`,
      source,
    });
    if (rec) {
      try {
        fs.appendFileSync(this.file, `${JSON.stringify({
          schemaVersion: SCHEMA_VERSION, k: rec.k, ts: rec.ts, kind: 'fingerprint',
          hash: drift.hash, fingerprint: drift.values,
        })}\n`, 'utf8');
        this.trials.push({ k: rec.k, kind: 'fingerprint', hash: drift.hash, fingerprint: drift.values });
      } catch { /* ignore */ }
    }
    return rec;
  }

  /** The most recent N trials, newest first. */
  recent(n = 20) {
    this.load();
    return this.trials.filter((t) => t.kind !== 'fingerprint').slice(-n).reverse();
  }

  /** Summary for the panel and the lawyer. */
  snapshot() {
    this.load();
    const real = this.trials.filter((t) => t.kind !== 'fingerprint');
    const byKind = {};
    for (const t of real) byKind[t.kind] = (byKind[t.kind] || 0) + 1;
    return {
      K: real.length,
      file: this.file,
      byKind,
      lastAt: real.length ? real[real.length - 1].ts : null,
      recent: this.recent(10),
      ...this.stats,
    };
  }
}

module.exports = {
  TrialRegistry,
  fingerprint,
  stableStringify,
  TRIAL_FIELDS,
  SCHEMA_VERSION,
};
