'use strict';
/**
 * BlackBird — jev output schemas.
 *
 * The model is an untrusted narrator. Everything it returns is parsed and
 * range-checked here before a single number reaches the risk engine. No npm
 * dependency: a hand-written validator is ~200 lines and cannot be talked into
 * accepting a string where a number belongs.
 *
 * Three shapes, one per role:
 *   decide    { regime, confidence, bias, riskMultiplier, reasoning, veto }
 *   mediate   { resolution, riskMultiplier, reasoning, winner }
 *   supervise { modules:[{name, action, reason}], overall, reasoning }
 */

const REGIMES = ['trend', 'muddy', 'toxic', 'calm'];
const BIASES = ['long', 'short', 'neutral'];
const RESOLUTIONS = ['allow', 'reduce', 'block'];
const ACTIONS = ['ok', 'watch', 'quarantine'];
const OVERALL = ['healthy', 'degraded', 'critical'];

const MAX_REASONING = 600;

function isPlainObject(v) {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function num(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

/**
 * Pull the first JSON object out of a model reply. Models wrap JSON in prose or
 * fences often enough that a bare JSON.parse is not a real parser.
 */
function extractJson(text) {
  if (isPlainObject(text)) return text;
  const raw = String(text == null ? '' : text).trim();
  if (!raw) throw new Error('empty model reply');
  const unfenced = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  try {
    const direct = JSON.parse(unfenced);
    if (isPlainObject(direct)) return direct;
  } catch { /* fall through to brace scan */ }
  const start = unfenced.indexOf('{');
  const end = unfenced.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('model reply contains no JSON object');
  const parsed = JSON.parse(unfenced.slice(start, end + 1));
  if (!isPlainObject(parsed)) throw new Error('model reply JSON is not an object');
  return parsed;
}

function ceiling(opts) {
  const m = Number.isFinite(opts?.maxRiskMultiplier) ? opts.maxRiskMultiplier : 1;
  return clamp(m, 0, 1);
}

// ------------------------------------------------------------------- decide
function validateDecide(raw, opts = {}) {
  const problems = [];
  const maxRiskMultiplier = ceiling(opts);
  const allowVeto = opts.allowVeto !== false;

  let obj;
  try {
    obj = extractJson(raw);
  } catch (e) {
    return { ok: false, value: null, problems: [e.message] };
  }

  const regime = typeof obj.regime === 'string' ? obj.regime.trim().toLowerCase() : null;
  if (!REGIMES.includes(regime)) {
    problems.push(`regime must be one of ${REGIMES.join('|')} (got ${JSON.stringify(obj.regime)})`);
  }

  const confRaw = num(obj.confidence);
  if (confRaw === null) problems.push('confidence must be a number');
  else if (confRaw < 0 || confRaw > 1) problems.push(`confidence must be within 0..1 (got ${confRaw})`);

  const bias = typeof obj.bias === 'string' ? obj.bias.trim().toLowerCase() : null;
  if (!BIASES.includes(bias)) {
    problems.push(`bias must be one of ${BIASES.join('|')} (got ${JSON.stringify(obj.bias)})`);
  }

  const rmRaw = num(obj.riskMultiplier);
  if (rmRaw === null) problems.push('riskMultiplier must be a number');
  else if (rmRaw < 0 || rmRaw > 1) problems.push(`riskMultiplier must be within 0..1 (got ${rmRaw})`);

  const reasoning = typeof obj.reasoning === 'string' ? obj.reasoning.trim() : '';
  if (!reasoning) problems.push('reasoning must be a non-empty string');

  let veto = false;
  if (obj.veto !== undefined && obj.veto !== null) {
    if (typeof obj.veto !== 'boolean') problems.push('veto must be a boolean when present');
    else veto = obj.veto;
  }

  if (problems.length) return { ok: false, value: null, problems };

  return {
    ok: true,
    problems: [],
    value: {
      regime,
      confidence: clamp(confRaw, 0, 1),
      bias,
      // The brain may only ever tighten. The ceiling is the operator's, and it
      // is itself capped at 1 so a bad config cannot turn this into leverage.
      riskMultiplier: clamp(rmRaw, 0, clamp(maxRiskMultiplier, 0, 1)),
      reasoning: reasoning.slice(0, MAX_REASONING),
      veto: veto && allowVeto,
      vetoRequested: veto,
    },
  };
}

// ------------------------------------------------------------------ mediate
function validateMediate(raw, opts = {}) {
  const problems = [];
  const maxRiskMultiplier = ceiling(opts);

  let obj;
  try {
    obj = extractJson(raw);
  } catch (e) {
    return { ok: false, value: null, problems: [e.message] };
  }

  const resolution = typeof obj.resolution === 'string' ? obj.resolution.trim().toLowerCase() : null;
  if (!RESOLUTIONS.includes(resolution)) {
    problems.push(`resolution must be one of ${RESOLUTIONS.join('|')} (got ${JSON.stringify(obj.resolution)})`);
  }

  const rmRaw = num(obj.riskMultiplier);
  if (rmRaw === null) problems.push('riskMultiplier must be a number');
  else if (rmRaw < 0 || rmRaw > 1) problems.push(`riskMultiplier must be within 0..1 (got ${rmRaw})`);

  const reasoning = typeof obj.reasoning === 'string' ? obj.reasoning.trim() : '';
  if (!reasoning) problems.push('reasoning must be a non-empty string');

  const winner = typeof obj.winner === 'string' ? obj.winner.trim().slice(0, 80) : null;

  if (problems.length) return { ok: false, value: null, problems };

  // A "reduce" that does not actually reduce is a contradiction; treat it as
  // allow rather than silently pretending the model said something it did not.
  let rm = clamp(rmRaw, 0, maxRiskMultiplier);
  let res = resolution;
  if (res === 'reduce' && rm >= 1) res = 'allow';
  if (res === 'block') rm = 0;

  return {
    ok: true,
    problems: [],
    value: { resolution: res, riskMultiplier: rm, reasoning: reasoning.slice(0, MAX_REASONING), winner },
  };
}

// ---------------------------------------------------------------- supervise
function validateSupervise(raw, opts = {}) {
  const problems = [];
  const quarantineAllowed = opts.quarantineAllowed !== false;
  const known = Array.isArray(opts.knownModules) ? new Set(opts.knownModules) : null;

  let obj;
  try {
    obj = extractJson(raw);
  } catch (e) {
    return { ok: false, value: null, problems: [e.message] };
  }

  if (!Array.isArray(obj.modules)) {
    return { ok: false, value: null, problems: ['modules must be an array'] };
  }

  const modules = [];
  for (const m of obj.modules) {
    if (!isPlainObject(m)) { problems.push('each module entry must be an object'); continue; }
    const name = typeof m.name === 'string' ? m.name.trim() : '';
    if (!name) { problems.push('module entry is missing a name'); continue; }
    // Never let the model invent a module: an unknown name is a hallucination.
    if (known && !known.has(name)) { problems.push(`unknown module "${name}"`); continue; }
    const action = typeof m.action === 'string' ? m.action.trim().toLowerCase() : null;
    if (!ACTIONS.includes(action)) { problems.push(`module "${name}" has invalid action ${JSON.stringify(m.action)}`); continue; }
    modules.push({
      name,
      action: action === 'quarantine' && !quarantineAllowed ? 'watch' : action,
      reason: typeof m.reason === 'string' ? m.reason.trim().slice(0, 300) : '',
    });
  }

  const overall = typeof obj.overall === 'string' ? obj.overall.trim().toLowerCase() : null;
  if (!OVERALL.includes(overall)) problems.push(`overall must be one of ${OVERALL.join('|')}`);

  const reasoning = typeof obj.reasoning === 'string' ? obj.reasoning.trim().slice(0, MAX_REASONING) : '';

  if (problems.length) return { ok: false, value: null, problems };
  return { ok: true, problems: [], value: { modules, overall, reasoning } };
}

// ---------------------------------------------------------------- fallbacks
/** The decision used whenever jev is off, broken, or out of time. */
function neutralDecision(reason = 'jev_disabled') {
  return {
    regime: 'calm',
    confidence: 0,
    bias: 'neutral',
    riskMultiplier: 1,
    reasoning: reason,
    veto: false,
    vetoRequested: false,
    degraded: true,
    source: 'fallback',
  };
}

function neutralMediation(reason = 'jev_disabled') {
  return { resolution: 'allow', riskMultiplier: 1, reasoning: reason, winner: null, degraded: true, source: 'fallback' };
}

function neutralSupervision(reason = 'jev_disabled') {
  return { modules: [], overall: 'healthy', reasoning: reason, degraded: true, source: 'fallback' };
}

module.exports = {
  validateDecide,
  validateMediate,
  validateSupervise,
  extractJson,
  neutralDecision,
  neutralMediation,
  neutralSupervision,
  REGIMES,
  BIASES,
  RESOLUTIONS,
  ACTIONS,
  OVERALL,
  MAX_REASONING,
};
