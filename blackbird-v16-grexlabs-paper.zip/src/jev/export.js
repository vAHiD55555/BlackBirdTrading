#!/usr/bin/env node
'use strict';
/**
 * BlackBird — observation export.
 *
 *   node src/jev/export.js                    all formats, all days
 *   node src/jev/export.js --day 2026-11-07   one day
 *   node src/jev/export.js --format dpo       only DPO pairs
 *   node src/jev/export.js --format sft       only instruction/response
 *   node src/jev/export.js --out data/training
 *
 * Turns the append-only observation ledger into training data.
 *
 * Two shapes, because they train different things:
 *
 *   SFT  { messages: [...], response: "..." }
 *        "Given this market, what should the decision be?" — teaches the format
 *        and the house style. Cheap, and it works with a single good example
 *        per cycle.
 *
 *   DPO  { prompt, chosen, rejected }
 *        "Between these two answers, which was better?" — teaches preference.
 *        This is the one that actually improves judgement, because it can learn
 *        from a bad decision without needing a perfect one.
 *
 * Where the preference comes from: a cycle's outcome. If the decision made
 * money, the decision is `chosen` and a deliberately loosened variant is
 * `rejected`. If it lost money, the reverse. Cycles with no outcome yet are
 * skipped for DPO — an unlabelled pair teaches nothing.
 */

const fs = require('node:fs');
const path = require('node:path');
const { Ledger } = require('./ledger');

const argv = process.argv.slice(2);
function arg(name, fallback = null) {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : fallback;
}

const DAY = arg('day');
const FORMAT = arg('format', 'all');
const OUT = arg('out', path.join(process.cwd(), 'data', 'training'));

const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  green: '\x1b[32m', yellow: '\x1b[33m', cyan: '\x1b[36m',
};
const useColor = process.stdout.isTTY;
const c = (code, s) => (useColor ? `${code}${s}${C.reset}` : s);

/** Join cycle records with their outcome/quality labels by cycleId. */
function joinRecords(records) {
  const cycles = new Map();
  const outcomes = new Map();
  const quality = new Map();

  for (const r of records) {
    if (r.type === 'outcome') { outcomes.set(r.cycleId, r.outcome || {}); continue; }
    if (r.type === 'quality') { quality.set(r.cycleId, r); continue; }
    if (r.cycleId) cycles.set(r.cycleId, r);
  }

  return [...cycles.values()].map((cy) => ({
    ...cy,
    outcome: outcomes.get(cy.cycleId) || null,
    quality: quality.get(cy.cycleId) || null,
  }));
}

/** The prompt text a model would have seen. */
function promptOf(cycle) {
  const input = cycle.input || {};
  return [
    'Market snapshot (all values computed by the engine, not by you):',
    JSON.stringify(input, null, 2),
    '',
    'Return the JSON object now.',
  ].join('\n');
}

/** The decision as the model should have written it. */
function responseOf(decision) {
  if (!decision) return null;
  return JSON.stringify({
    regime: decision.regime,
    confidence: decision.confidence,
    bias: decision.bias,
    riskMultiplier: decision.riskMultiplier,
    reasoning: decision.reasoning,
    veto: Boolean(decision.veto),
  });
}

/**
 * A deliberately worse answer: same regime, but looser risk and no veto.
 * This is the `rejected` side when the real decision worked.
 */
function loosen(decision) {
  if (!decision) return null;
  return JSON.stringify({
    regime: decision.regime,
    confidence: Math.min(1, (decision.confidence || 0) + 0.2),
    bias: decision.bias,
    riskMultiplier: 1,
    reasoning: 'Momentum looks strong enough; run full size.',
    veto: false,
  });
}

/**
 * A deliberately more cautious answer: same regime, but half risk and a veto.
 * This is the `rejected` side when the real decision lost money.
 */
function tighten(decision) {
  if (!decision) return null;
  return JSON.stringify({
    regime: decision.regime,
    confidence: Math.max(0, (decision.confidence || 0) - 0.2),
    bias: 'neutral',
    riskMultiplier: 0,
    reasoning: 'Conditions are unclear; stand aside.',
    veto: true,
  });
}

function buildSft(cycles) {
  const out = [];
  for (const cy of cycles) {
    const resp = responseOf(cy.decision);
    if (!resp) continue;
    // Only keep decisions that were actually good, when we know.
    if (cy.outcome && cy.outcome.win === false) continue;
    if (cy.quality && cy.quality.verdict === 'rejected') continue;
    out.push({
      messages: [
        { role: 'system', content: 'You are a conservative market-regime analyst. Answer with one JSON object.' },
        { role: 'user', content: promptOf(cy) },
      ],
      response: resp,
      meta: {
        cycleId: cy.cycleId,
        ts: cy.ts,
        regime: cy.decision.regime,
        riskMultiplier: cy.decision.riskMultiplier,
        outcome: cy.outcome ? { pnl: cy.outcome.pnl, win: cy.outcome.win } : null,
      },
    });
  }
  return out;
}

function buildDpo(cycles) {
  const out = [];
  for (const cy of cycles) {
    if (!cy.outcome || typeof cy.outcome.win !== 'boolean') continue;
    const real = responseOf(cy.decision);
    if (!real) continue;

    const chosen = cy.outcome.win ? real : tighten(cy.decision);
    const rejected = cy.outcome.win ? loosen(cy.decision) : real;
    if (chosen === rejected) continue;

    out.push({
      prompt: promptOf(cy),
      chosen,
      rejected,
      meta: {
        cycleId: cy.cycleId,
        ts: cy.ts,
        pnl: cy.outcome.pnl,
        win: cy.outcome.win,
        source: 'outcome',
      },
    });
  }
  return out;
}

function writeJsonl(file, rows) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const body = rows.map((r) => JSON.stringify(r)).join('\n');
  fs.writeFileSync(file, body ? `${body}\n` : '', 'utf8');
  return { file, rows: rows.length, bytes: Buffer.byteLength(body) };
}

function main() {
  const ledger = new Ledger({ cfg: { enabled: true } });
  const records = ledger.read({ day: DAY });

  if (!records.length) {
    console.log(c(C.yellow, `\nno observation records found${DAY ? ` for ${DAY}` : ''} in ${ledger.dir}`));
    console.log(c(C.dim, 'run the engine with jev.ledger.enabled=true first\n'));
    process.exit(0);
  }

  const cycles = joinRecords(records);
  const labelled = cycles.filter((cy) => cy.outcome);
  const judged = cycles.filter((cy) => cy.quality);

  console.log(c(C.bold, '\nBlackBird — observation export'));
  console.log(c(C.dim, `source: ${ledger.dir}${DAY ? ` (${DAY})` : ''}`));
  console.log(`  ${cycles.length} cycles · ${labelled.length} with outcome · ${judged.length} with quality label\n`);

  const written = [];

  if (FORMAT === 'all' || FORMAT === 'sft') {
    const rows = buildSft(cycles);
    const suffix = DAY ? `-${DAY}` : '';
    written.push({ kind: 'sft', ...writeJsonl(path.join(OUT, `sft${suffix}.jsonl`), rows) });
  }

  if (FORMAT === 'all' || FORMAT === 'dpo') {
    const rows = buildDpo(cycles);
    const suffix = DAY ? `-${DAY}` : '';
    written.push({ kind: 'dpo', ...writeJsonl(path.join(OUT, `dpo${suffix}.jsonl`), rows) });
  }

  for (const w of written) {
    const kb = (w.bytes / 1024).toFixed(1);
    console.log(`  ${c(C.green, '✓')} ${c(C.bold, w.kind.toUpperCase())}  ${w.rows} rows  ${kb} KB  ${c(C.dim, w.file)}`);
  }

  if (!labelled.length) {
    console.log(c(C.yellow, '\n  note: no outcomes labelled yet, so DPO is empty.'));
    console.log(c(C.dim, '  label them with ledger.label(cycleId, { pnl, win }) after the horizon passes.'));
  }
  console.log('');
}

main();
