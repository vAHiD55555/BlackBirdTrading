'use strict';
/**
 * BlackBird — jev message bus.
 *
 * A tiny publish/subscribe channel where modules state opinions and jev
 * arbitrates. It is deliberately NOT the engine's existing Bus (core/bus.js):
 * that one carries facts ("a trade closed"). This one carries *claims*
 * ("I think this entry should be blocked") which can be contested.
 *
 * The contract that makes mediation possible:
 *
 *   module  --publish(opinion)-->  bus  --collect-->  jev.mediate()
 *                                     ^                    |
 *                                     +---- verdict -------+
 *
 * An opinion is { module, topic, stance, reason, weight }. Stances are
 * 'allow' | 'block' | 'reduce'. jev reads them, decides, and publishes a
 * verdict that every module can see.
 *
 * No npm dependency, no async, no timers. A bus that can hang is a bus that
 * can deadlock the engine.
 */

const STANCES = ['allow', 'block', 'reduce'];

class JevBus {
  constructor({ log, maxOpinionsPerTopic = 32, ttlMs = 10 * 60 * 1000 } = {}) {
    this.log = log || { debug() {}, warn() {} };
    this.maxOpinionsPerTopic = maxOpinionsPerTopic;
    this.ttlMs = ttlMs;
    this.opinions = new Map(); // topic -> [opinion]
    this.verdicts = new Map(); // topic -> verdict
    this.listeners = new Map(); // event -> [fn]
    this.stats = { published: 0, verdicts: 0, dropped: 0 };
  }

  on(event, fn) {
    if (typeof fn !== 'function') return () => {};
    if (!this.listeners.has(event)) this.listeners.set(event, []);
    this.listeners.get(event).push(fn);
    return () => {
      const arr = this.listeners.get(event) || [];
      const i = arr.indexOf(fn);
      if (i >= 0) arr.splice(i, 1);
    };
  }

  emit(event, payload) {
    const arr = this.listeners.get(event) || [];
    for (const fn of arr) {
      // A listener that throws must not take the bus down with it.
      try { fn(payload); } catch (e) { this.log.warn(`bus listener for "${event}" threw: ${e.message}`); }
    }
  }

  /**
   * A module states an opinion about a topic.
   * @returns {boolean} whether it was accepted
   */
  publish({ module, topic, stance, reason = '', weight = 1 } = {}) {
    if (!module || !topic) return false;
    const s = String(stance || '').toLowerCase();
    if (!STANCES.includes(s)) {
      this.log.warn(`bus: ${module} published invalid stance "${stance}"`);
      return false;
    }
    const list = this.opinions.get(topic) || [];
    // One live opinion per module per topic: a module changing its mind
    // replaces its old claim instead of stacking votes.
    const filtered = list.filter((o) => o.module !== module);
    filtered.push({
      module,
      topic,
      stance: s,
      reason: String(reason).slice(0, 300),
      weight: Number.isFinite(weight) ? weight : 1,
      at: Date.now(),
    });
    if (filtered.length > this.maxOpinionsPerTopic) {
      filtered.shift();
      this.stats.dropped++;
    }
    this.opinions.set(topic, filtered);
    this.stats.published++;
    this.emit('opinion', { module, topic, stance: s });
    return true;
  }

  /** All live opinions for a topic, expired ones pruned. */
  collect(topic) {
    const list = this.opinions.get(topic) || [];
    const cutoff = Date.now() - this.ttlMs;
    const live = list.filter((o) => o.at >= cutoff);
    if (live.length !== list.length) this.opinions.set(topic, live);
    return live;
  }

  /** Does any module object to this topic? Used as a cheap pre-check. */
  hasObjection(topic) {
    return this.collect(topic).some((o) => o.stance === 'block');
  }

  /** jev records its ruling so modules and the dashboard can read it. */
  recordVerdict(topic, verdict) {
    if (!topic || !verdict) return false;
    this.verdicts.set(topic, { ...verdict, topic, at: Date.now() });
    this.stats.verdicts++;
    this.emit('verdict', { topic, verdict });
    return true;
  }

  verdict(topic) {
    return this.verdicts.get(topic) || null;
  }

  /** Clear a topic once the decision it belonged to is over. */
  clear(topic) {
    this.opinions.delete(topic);
    this.verdicts.delete(topic);
  }

  /** Keep the maps from growing without bound in a long-running process. */
  prune() {
    const cutoff = Date.now() - this.ttlMs;
    for (const [topic, list] of this.opinions) {
      const live = list.filter((o) => o.at >= cutoff);
      if (live.length) this.opinions.set(topic, live);
      else this.opinions.delete(topic);
    }
    for (const [topic, v] of this.verdicts) {
      if (v.at < cutoff) this.verdicts.delete(topic);
    }
  }

  snapshot(limit = 10) {
    const recent = [...this.verdicts.values()]
      .sort((a, b) => b.at - a.at)
      .slice(0, limit)
      .map((v) => ({
        topic: v.topic,
        resolution: v.resolution,
        riskMultiplier: v.riskMultiplier,
        winner: v.winner || null,
        reasoning: v.reasoning,
        degraded: Boolean(v.degraded),
        at: v.at,
      }));
    return {
      topics: this.opinions.size,
      verdicts: this.verdicts.size,
      ...this.stats,
      recent,
    };
  }
}

module.exports = { JevBus, STANCES };
