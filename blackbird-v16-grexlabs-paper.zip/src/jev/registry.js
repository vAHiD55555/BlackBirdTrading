'use strict';
/**
 * BlackBird — jev module registry.
 *
 * A single place that knows which modules exist, what version they claim, and
 * whether they look alive. jev's "manager" role reads this; the dashboard reads
 * this; the supervisor prompt is built from this.
 *
 * Design notes:
 *   - Registration is explicit. A module that never registers is invisible, and
 *     invisible is reported as "missing", not as "healthy".
 *   - Health is derived, never self-declared. A module cannot mark itself ok.
 *   - Nothing here throws. A registry that can crash the engine is worse than
 *     no registry at all.
 */

const { now } = require('../core/util');

const STATUS = {
  OK: 'ok',
  WATCH: 'watch',
  QUARANTINED: 'quarantined',
  MISSING: 'missing',
  UNKNOWN: 'unknown',
};

class ModuleRegistry {
  constructor({ log } = {}) {
    this.log = log || { info() {}, warn() {}, debug() {} };
    this.modules = new Map();
    this.quarantined = new Set();
    this.startedAt = now();
  }

  /**
   * @param {string} name
   * @param {object} [opts]
   * @param {string} [opts.version]
   * @param {object} [opts.ref]        the live module object (optional)
   * @param {function} [opts.health]   () => { ok, detail } — optional probe
   * @param {number} [opts.staleMs]    heartbeat older than this is suspicious
   */
  register(name, opts = {}) {
    if (!name || typeof name !== 'string') throw new Error('module name is required');
    const entry = {
      name,
      version: opts.version || '1.0.0',
      ref: opts.ref || null,
      health: typeof opts.health === 'function' ? opts.health : null,
      staleMs: Number.isFinite(opts.staleMs) ? opts.staleMs : 5 * 60 * 1000,
      registeredAt: now(),
      lastBeatAt: now(),
      lastError: null,
      lastErrorAt: null,
      counters: {},
      status: STATUS.UNKNOWN,
    };
    this.modules.set(name, entry);
    this.log.debug(`registry: ${name}@${entry.version} registered`);
    return entry;
  }

  has(name) {
    return this.modules.has(name);
  }

  get(name) {
    return this.modules.get(name) || null;
  }

  names() {
    return [...this.modules.keys()];
  }

  /** A module reports it is alive. Cheap; called from the engine clock. */
  beat(name, counters) {
    const m = this.modules.get(name);
    if (!m) return false;
    m.lastBeatAt = now();
    if (counters && typeof counters === 'object') m.counters = { ...m.counters, ...counters };
    return true;
  }

  /** Record a failure. Repeated failures are what justify quarantine. */
  fail(name, error) {
    const m = this.modules.get(name);
    if (!m) return false;
    m.lastError = String(error && error.message ? error.message : error).slice(0, 300);
    m.lastErrorAt = now();
    m.errorCount = (m.errorCount || 0) + 1;
    return true;
  }

  /** jev (or an operator) stops trusting a module's output. */
  quarantine(name, reason) {
    if (!this.modules.has(name)) return false;
    this.quarantined.add(name);
    const m = this.modules.get(name);
    m.status = STATUS.QUARANTINED;
    m.quarantineReason = reason || 'quarantined';
    m.quarantinedAt = now();
    this.log.warn(`registry: ${name} quarantined — ${m.quarantineReason}`);
    return true;
  }

  release(name) {
    if (!this.quarantined.has(name)) return false;
    this.quarantined.delete(name);
    const m = this.modules.get(name);
    if (m) { m.status = STATUS.UNKNOWN; m.quarantineReason = null; }
    this.log.info(`registry: ${name} released from quarantine`);
    return true;
  }

  isQuarantined(name) {
    return this.quarantined.has(name);
  }

  /**
   * Derive each module's status. Never trusts a self-report.
   * @returns {Array<object>} plain snapshot rows, safe to JSON.stringify
   */
  snapshot() {
    const t = now();
    const rows = [];
    for (const m of this.modules.values()) {
      const staleMs = t - m.lastBeatAt;
      let status = STATUS.OK;
      let detail = null;

      if (this.quarantined.has(m.name)) {
        status = STATUS.QUARANTINED;
        detail = m.quarantineReason;
      } else if (staleMs > m.staleMs) {
        status = STATUS.WATCH;
        detail = `no heartbeat for ${Math.round(staleMs / 1000)}s`;
      } else if (m.health) {
        try {
          const h = m.health();
          if (h && h.ok === false) { status = STATUS.WATCH; detail = h.detail || 'health probe failed'; }
        } catch (e) {
          status = STATUS.WATCH;
          detail = `health probe threw: ${e.message}`;
        }
      }

      rows.push({
        name: m.name,
        version: m.version,
        status,
        detail,
        lastError: m.lastError,
        lastErrorAt: m.lastErrorAt,
        errorCount: m.errorCount || 0,
        staleMs: Math.round(staleMs),
        counters: m.counters,
        quarantined: this.quarantined.has(m.name),
      });
    }
    return rows;
  }

  /** The compact shape the supervisor prompt consumes. */
  promptSnapshot() {
    return {
      asOf: new Date().toISOString(),
      modules: this.snapshot().map((r) => ({
        name: r.name,
        version: r.version,
        status: r.status,
        lastError: r.lastError,
        counters: r.counters,
        staleMs: r.staleMs,
      })),
    };
  }

  /** Aggregate health for the dashboard header. */
  health() {
    const rows = this.snapshot();
    const bad = rows.filter((r) => r.status === STATUS.QUARANTINED || r.status === STATUS.WATCH);
    return {
      total: rows.length,
      ok: rows.filter((r) => r.status === STATUS.OK).length,
      watch: rows.filter((r) => r.status === STATUS.WATCH).length,
      quarantined: rows.filter((r) => r.status === STATUS.QUARANTINED).length,
      overall: bad.length === 0 ? 'healthy' : (rows.some((r) => r.status === STATUS.QUARANTINED) ? 'critical' : 'degraded'),
      modules: rows,
    };
  }
}

module.exports = { ModuleRegistry, STATUS };
