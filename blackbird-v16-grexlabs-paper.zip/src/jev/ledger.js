'use strict';
/**
 * BlackBird — jev observation ledger.
 *
 * Every cycle, every party's view of that cycle is written to disk as one JSONL
 * line. The point is not logging — the engine already logs. The point is
 * building a dataset: inputs, every model's raw opinion, the final decision, and
 * (later) what actually happened.
 *
 * That last part is what makes this worth anything. A record without an outcome
 * is an anecdote. A record with an outcome is a training example.
 *
 * Layout:
 *   data/observations/YYYY-MM-DD.jsonl     one line per cycle
 *   data/observations/YYYY-MM-DD.jsonl.gz  rotated + compressed
 *
 * Guarantees:
 *   - Nothing here throws. A ledger that can crash the engine is worse than no
 *     ledger. Every public method is wrapped.
 *   - No secret ever reaches disk. `redact()` runs on every record, and it is
 *     tested against the shapes keys actually take.
 *   - The directory cannot grow without bound: a daily cap, then gzip, then
 *     deletion of the oldest archives.
 */

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { now } = require('../core/util');

const SCHEMA_VERSION = 1;

const DEFAULTS = {
  enabled: true,
  dir: null, // resolved from cfg.runtime.dataDir by the caller
  maxBytesPerDay: 50 * 1024 * 1024, // 50 MB
  keepDays: 30,
  compressAfterDays: 2,
  maxRecordsPerFile: 200000,
};

// ------------------------------------------------------------------ redaction
/**
 * Patterns that look like credentials. Deliberately broad: a false positive
 * costs a redacted string, a false negative costs a leaked key.
 */
const SECRET_PATTERNS = [
  // Provider keys with recognisable prefixes.
  /\b(sk|pk|rk)-[A-Za-z0-9_-]{16,}\b/g,
  /\bghp_[A-Za-z0-9]{20,}\b/g,
  /\bgh[osu]_[A-Za-z0-9]{20,}\b/g,
  /\bgithub_pat_[A-Za-z0-9_]{20,}\b/g,
  /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g,
  /\bAIza[0-9A-Za-z_-]{30,}\b/g,          // Google API key
  /\bgsk_[A-Za-z0-9]{20,}\b/g,            // Groq
  /\bcsk-[A-Za-z0-9]{20,}\b/g,            // Cerebras
  /\bsk-or-v1-[A-Za-z0-9]{20,}\b/g,       // OpenRouter
  /\bBearer\s+[A-Za-z0-9._-]{16,}/gi,
  // JWT
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g,
];

/** Field names whose values are always secret, whatever they look like. */
const SECRET_KEYS = /^(api[_-]?key|apikey|secret|token|password|passwd|authorization|auth|cookie|session|private[_-]?key|access[_-]?token|refresh[_-]?token|bot[_-]?token)$/i;

const REDACTED = '[REDACTED]';
const MAX_STRING = 2000;
const MAX_DEPTH = 8;

/**
 * Recursively redact a value. Returns a NEW structure; never mutates input.
 *
 * @param {*} value
 * @param {number} [depth]
 * @returns {*}
 */
function redact(value, depth = 0) {
  if (depth > MAX_DEPTH) return '[TRUNCATED_DEPTH]';
  if (value === null || value === undefined) return value;

  if (typeof value === 'string') {
    let s = value;
    for (const re of SECRET_PATTERNS) s = s.replace(re, REDACTED);
    if (s.length > MAX_STRING) s = `${s.slice(0, MAX_STRING)}…[+${s.length - MAX_STRING}]`;
    return s;
  }
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (typeof value === 'bigint') return String(value);
  if (typeof value === 'function') return '[function]';
  if (value instanceof Error) return { name: value.name, message: redact(value.message, depth + 1) };

  if (Array.isArray(value)) {
    // Cap arrays: a 10k-element market array is not a training feature.
    const capped = value.slice(0, 200).map((v) => redact(v, depth + 1));
    if (value.length > 200) capped.push(`[+${value.length - 200} more]`);
    return capped;
  }

  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (SECRET_KEYS.test(k)) { out[k] = REDACTED; continue; }
      out[k] = redact(v, depth + 1);
    }
    return out;
  }
  return String(value);
}

/** True when a string still contains something that looks like a key. */
function containsSecret(value) {
  const s = typeof value === 'string' ? value : JSON.stringify(value);
  if (!s) return false;
  return SECRET_PATTERNS.some((re) => {
    re.lastIndex = 0;
    return re.test(s);
  });
}

// --------------------------------------------------------------------- ledger
class Ledger {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]  cfg.jev.ledger
   * @param {object} [opts.log]
   * @param {string} [opts.dir]  override the directory (tests)
   * @param {function} [opts.clock] injectable clock (tests)
   */
  constructor({ cfg = {}, log, dir, clock } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.clock = clock || (() => Date.now());
    this.dir = dir || this.cfg.dir || path.join(process.cwd(), 'data', 'observations');

    this.stats = {
      written: 0, failed: 0, redacted: 0, rotated: 0, compressed: 0, pruned: 0,
      bytesToday: 0, lastWriteAt: null, lastError: null,
    };
    this._day = null;
    this._bytes = 0;
    this._records = 0;
    this._ready = false;
  }

  get enabled() {
    return this.cfg.enabled !== false;
  }

  /** Create the directory once. Failure disables the ledger, never throws. */
  _ensure() {
    if (this._ready) return true;
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      this._ready = true;
      return true;
    } catch (e) {
      this.stats.lastError = `cannot create ${this.dir}: ${e.message}`;
      this.log.warn(`ledger disabled: ${this.stats.lastError}`);
      return false;
    }
  }

  _dayKey(ts) {
    return new Date(ts).toISOString().slice(0, 10);
  }

  _fileFor(day) {
    return path.join(this.dir, `${day}.jsonl`);
  }

  /**
   * Append one observation record.
   *
   * @param {object} record
   * @returns {boolean} whether it was written
   */
  write(record) {
    if (!this.enabled) return false;
    if (!this._ensure()) return false;

    try {
      const ts = this.clock();
      const day = this._dayKey(ts);

      // Day rollover: reset counters, then rotate old files.
      if (this._day !== day) {
        this._day = day;
        this._bytes = 0;
        this._records = 0;
        this._rotate();
      }

      // Hard daily cap. Dropping records is better than filling the disk.
      if (this._bytes >= this.cfg.maxBytesPerDay) {
        this.stats.lastError = `daily cap reached (${this.cfg.maxBytesPerDay} bytes)`;
        return false;
      }

      const payload = redact({
        schemaVersion: SCHEMA_VERSION,
        ts,
        ...record,
      });

      const line = `${JSON.stringify(payload)}\n`;
      const buf = Buffer.byteLength(line);

      fs.appendFileSync(this._fileFor(day), line, 'utf8');

      this._bytes += buf;
      this._records++;
      this.stats.written++;
      this.stats.bytesToday = this._bytes;
      this.stats.lastWriteAt = ts;
      this.stats.lastError = null;

      // Per-file record cap: rotate early rather than build a 500MB file.
      if (this._records >= this.cfg.maxRecordsPerFile) {
        this._rotate();
      }
      return true;
    } catch (e) {
      this.stats.failed++;
      this.stats.lastError = e.message;
      this.log.warn(`ledger write failed: ${e.message}`);
      return false;
    }
  }

  /**
   * Attach an outcome to an existing record (outcome labelling).
   *
   * JSONL is append-only, so this writes a small `outcome` record that points at
   * the original cycleId. `export.js` joins them. That keeps the log immutable
   * and crash-safe: a half-written outcome can never corrupt the original.
   *
   * @param {string} cycleId
   * @param {object} outcome  { pnl, pnlPct, win, horizonMs, ... }
   * @returns {boolean}
   */
  label(cycleId, outcome) {
    if (!cycleId) return false;
    return this.write({
      type: 'outcome',
      cycleId,
      outcome: outcome || {},
    });
  }

  /**
   * Operator or auditor verdict on a decision.
   * @param {string} cycleId
   * @param {'approved'|'rejected'} verdict
   * @param {string} [note]
   */
  labelQuality(cycleId, verdict, note) {
    if (!cycleId) return false;
    return this.write({
      type: 'quality',
      cycleId,
      verdict: verdict === 'approved' ? 'approved' : 'rejected',
      note: note || '',
    });
  }

  /** Compress yesterday-and-older files, delete beyond keepDays. */
  _rotate() {
    try {
      const files = fs.readdirSync(this.dir);
      const today = this._dayKey(this.clock());
      const cutoff = this.clock() - this.cfg.keepDays * 86400000;
      const compressBefore = this.clock() - this.cfg.compressAfterDays * 86400000;

      for (const f of files) {
        const m = f.match(/^(\d{4}-\d{2}-\d{2})\.jsonl$/);
        if (!m) continue;
        const day = m[1];
        if (day === today) continue;

        const full = path.join(this.dir, f);
        let st;
        try { st = fs.statSync(full); } catch { continue; }

        // Delete anything past the retention window.
        if (st.mtimeMs < cutoff) {
          try { fs.unlinkSync(full); this.stats.pruned++; } catch { /* ignore */ }
          continue;
        }

        // Compress files older than compressAfterDays.
        if (st.mtimeMs < compressBefore) {
          try {
            const raw = fs.readFileSync(full);
            const gz = zlib.gzipSync(raw, { level: 6 });
            fs.writeFileSync(`${full}.gz`, gz);
            fs.unlinkSync(full);
            this.stats.compressed++;
            this.stats.rotated++;
          } catch (e) {
            this.log.warn(`ledger compress failed for ${f}: ${e.message}`);
          }
        }
      }

      // Also prune old .gz archives.
      for (const f of fs.readdirSync(this.dir)) {
        const m = f.match(/^(\d{4}-\d{2}-\d{2})\.jsonl\.gz$/);
        if (!m) continue;
        const full = path.join(this.dir, f);
        try {
          const st = fs.statSync(full);
          if (st.mtimeMs < cutoff) { fs.unlinkSync(full); this.stats.pruned++; }
        } catch { /* ignore */ }
      }
    } catch (e) {
      this.log.warn(`ledger rotate failed: ${e.message}`);
    }
  }

  /** Read back records, optionally filtered. Used by export.js and the panel. */
  read({ day, type, limit } = {}) {
    if (!this._ensure()) return [];
    const out = [];
    try {
      const files = fs.readdirSync(this.dir)
        .filter((f) => /^\d{4}-\d{2}-\d{2}\.jsonl(\.gz)?$/.test(f))
        .filter((f) => !day || f.startsWith(day))
        .sort();

      for (const f of files) {
        const full = path.join(this.dir, f);
        let text;
        try {
          text = f.endsWith('.gz')
            ? zlib.gunzipSync(fs.readFileSync(full)).toString('utf8')
            : fs.readFileSync(full, 'utf8');
        } catch { continue; }

        for (const line of text.split('\n')) {
          if (!line.trim()) continue;
          try {
            const rec = JSON.parse(line);
            if (type && rec.type !== type) continue;
            out.push(rec);
          } catch { /* skip a torn line */ }
        }
      }
    } catch (e) {
      this.log.warn(`ledger read failed: ${e.message}`);
    }
    if (Number.isFinite(limit) && limit > 0) return out.slice(-limit);
    return out;
  }

  /** Counts and sizes for the dashboard. */
  snapshot() {
    const s = {
      enabled: this.enabled,
      dir: this.dir,
      schemaVersion: SCHEMA_VERSION,
      recordsToday: this._records,
      bytesToday: this._bytes,
      maxBytesPerDay: this.cfg.maxBytesPerDay,
      keepDays: this.cfg.keepDays,
      ...this.stats,
      lastRecord: null,
      files: 0,
      totalBytes: 0,
    };
    try {
      if (fs.existsSync(this.dir)) {
        const files = fs.readdirSync(this.dir).filter((f) => /\.jsonl(\.gz)?$/.test(f));
        s.files = files.length;
        for (const f of files) {
          try { s.totalBytes += fs.statSync(path.join(this.dir, f)).size; } catch { /* ignore */ }
        }
      }
      const recent = this.read({ limit: 1 });
      if (recent.length) {
        const r = recent[recent.length - 1];
        s.lastRecord = {
          ts: r.ts,
          type: r.type || 'cycle',
          cycleId: r.cycleId || null,
          regime: r.decision?.regime || null,
          riskMultiplier: r.decision?.riskMultiplier ?? null,
        };
      }
    } catch { /* snapshot must never throw */ }
    return s;
  }
}

module.exports = {
  Ledger,
  DEFAULTS,
  SCHEMA_VERSION,
  redact,
  containsSecret,
  SECRET_PATTERNS,
  SECRET_KEYS,
  REDACTED,
};
