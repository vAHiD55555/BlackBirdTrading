'use strict';
/**
 * BlackBird — jev consensus layer.
 *
 * One model is a single point of failure and a single point of opinion. This
 * module asks several models the same question at the same time and folds their
 * answers into one verdict.
 *
 * The design rules, in order of importance:
 *
 *   1. A failing model never kills the cycle. Every call is wrapped in
 *      allSettled with its own timeout; a dead provider is recorded as failed
 *      and the rest carry on.
 *   2. If nothing valid comes back, the caller gets `null` and falls back to
 *      rule-based behaviour. Silence is not consent.
 *   3. The result is never MORE permissive than the strictest valid vote.
 *      riskMultiplier is the MINIMUM across valid votes, not the mean. A model
 *      that wants to stand down is never outvoted into exposure.
 *   4. Disagreement is information. Wide dispersion lowers confidence and
 *      tightens risk further, because a split jury is a reason to be careful,
 *      not a reason to average.
 *
 * The median is still computed and reported — it is the best single summary of
 * "what the panel thinks" — but it is exposed as `medianRiskMultiplier` and is
 * never the number that reaches the risk engine.
 */

const { createProvider } = require('./providers');
const { validateDecide } = require('./schema');
const { buildContext, buildDecideMessages } = require('./prompt');
const { RateLimiter } = require('./rateLimiter');
const { now } = require('../core/util');

const DEFAULTS = {
  enabled: false,
  models: [],
  quorum: 2,
  timeoutMs: 20000,
  disagreementThreshold: 0.35,
  maxRiskMultiplier: 1,
  allowVeto: true,
};

/** Median of a numeric array. Returns null for an empty array. */
function median(values) {
  const xs = values.filter((v) => Number.isFinite(v)).sort((a, b) => a - b);
  if (!xs.length) return null;
  const mid = Math.floor(xs.length / 2);
  return xs.length % 2 ? xs[mid] : (xs[mid - 1] + xs[mid]) / 2;
}

/** Population standard deviation — the dispersion measure. */
function stdev(values) {
  const xs = values.filter((v) => Number.isFinite(v));
  if (xs.length < 2) return 0;
  const mean = xs.reduce((a, b) => a + b, 0) / xs.length;
  const variance = xs.reduce((a, b) => a + (b - mean) ** 2, 0) / xs.length;
  return Math.sqrt(variance);
}

/** Most frequent value; ties broken by first appearance. */
function mode(values) {
  const counts = new Map();
  for (const v of values) counts.set(v, (counts.get(v) || 0) + 1);
  let best = null;
  let bestN = -1;
  for (const [v, n] of counts) {
    if (n > bestN) { best = v; bestN = n; }
  }
  return best;
}

class Consensus {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]   cfg.jev.consensus
   * @param {object} [opts.log]
   * @param {object} [opts.env]   injectable environment (tests)
   * @param {Array}  [opts.providers] inject providers directly (tests)
   */
  constructor({ cfg = {}, log, env, providers, rateLimiter } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
    this.env = env || process.env;

    // Quota is checked BEFORE the call. A 429 costs a round trip and a degraded
    // cycle; a local counter costs nothing.
    this.rateLimiter = rateLimiter || new RateLimiter({
      cfg: this.cfg.rateLimits || {},
      log: this.log,
      stateFile: this.cfg.rateLimitStateFile || null,
    });

    this.lastResult = null;
    this.lastError = null;
    this.inFlight = null;

    // Per-model rolling stats for the dashboard: latency, failures, last vote.
    this.modelStats = new Map();

    this.stats = {
      runs: 0, ok: 0, failed: 0, quorumMissed: 0,
      modelCalls: 0, modelFailures: 0, modelTimeouts: 0, quotaSkipped: 0,
      disagreements: 0, vetoes: 0,
    };

    this._providers = providers || null;
    this._providerError = null;

    if (!this._providers && this.enabled) {
      try {
        this._providers = this._buildProviders();
      } catch (e) {
        this._providerError = e.message;
        this.log.warn(`consensus providers unavailable: ${e.message}`);
      }
    }
  }

  get enabled() {
    return Boolean(this.cfg.enabled);
  }

  get ceiling() {
    const m = Number(this.cfg.maxRiskMultiplier);
    return Number.isFinite(m) ? Math.min(1, Math.max(0, m)) : 1;
  }

  /** The configured panel, normalised. */
  get models() {
    // Injected providers (tests, or a caller building the panel by hand) are
    // authoritative: they already carry provider/model/weight.
    if (this._providers && this._providers.length) {
      return this._providers.map((m) => ({
        provider: m.provider,
        model: m.model || '',
        weight: Number.isFinite(m.weight) ? m.weight : 1,
      }));
    }
    const list = Array.isArray(this.cfg.models) ? this.cfg.models : [];
    return list
      .filter((m) => m && m.provider)
      .map((m) => ({
        provider: String(m.provider).toLowerCase(),
        model: m.model || '',
        weight: Number.isFinite(m.weight) ? m.weight : 1,
      }));
  }

  /** True when there is a panel and at least one provider object. */
  get ready() {
    if (!this.enabled) return false;
    if (this._providerError) return false;
    if (!this.models.length) return false;
    if (!this._providers || !this._providers.length) return false;
    return true;
  }

  /**
   * Build one provider per configured model. A provider that cannot be built
   * (unknown name, missing key) is skipped with a warning rather than aborting
   * the whole panel — one bad entry in config must not disable the rest.
   */
  _buildProviders() {
    const out = [];
    for (const m of this.models) {
      try {
        const p = createProvider(
          { provider: m.provider, model: m.model, timeoutMs: this.cfg.timeoutMs },
          { env: this.env }
        );
        out.push({ ...m, provider: p });
      } catch (e) {
        this.log.warn(`consensus: skipping ${m.provider}/${m.model}: ${e.message}`);
        this._stat(m).lastError = e.message;
      }
    }
    return out;
  }

  _stat(m) {
    const key = `${m.provider}/${m.model}`;
    if (!this.modelStats.has(key)) {
      this.modelStats.set(key, {
        key, provider: m.provider, model: m.model,
        calls: 0, ok: 0, failed: 0, timeouts: 0,
        lastLatencyMs: null, lastVote: null, lastError: null, lastAt: null,
      });
    }
    return this.modelStats.get(key);
  }

  /**
   * Ask the panel. NEVER throws, NEVER rejects.
   *
   * @param {object} context  engine status or a built context
   * @returns {Promise<object|null>} a decision-shaped object, or null to
   *          signal "no usable consensus — use the rules".
   */
  async decide(context) {
    if (!this.enabled) return null;
    if (!this.ready) {
      this.lastError = this._providerError || 'consensus_not_ready';
      return null;
    }
    // Coalesce: a burst of bars must not become a burst of API bills.
    if (this.inFlight) return this.inFlight;
    this.inFlight = this._run(context).finally(() => { this.inFlight = null; });
    return this.inFlight;
  }

  async _run(context) {
    const started = now();
    this.stats.runs++;

    let ctx;
    try {
      ctx = context && context.market ? context : buildContext(context);
    } catch (e) {
      this.lastError = `context build failed: ${e.message}`;
      this.stats.failed++;
      return null;
    }

    const messages = buildDecideMessages(ctx, {
      maxRiskMultiplier: this.ceiling,
      allowVeto: this.cfg.allowVeto,
    });

    // Every model gets its own timeout. allSettled means one rejection cannot
    // cancel the others — which is the entire point of a panel.
    const settled = await Promise.allSettled(
      this._providers.map((m) => this._askOne(m, messages))
    );

    const votes = [];
    const failures = [];
    for (let i = 0; i < settled.length; i++) {
      const m = this._providers[i];
      const s = settled[i];
      if (s.status === 'fulfilled' && s.value) votes.push(s.value);
      else {
        const err = s.status === 'rejected' ? s.reason : new Error('no vote');
        failures.push({
          provider: m.provider,
          model: m.model,
          error: String(err && err.message ? err.message : err).slice(0, 200),
        });
      }
    }

    const quorum = Math.max(1, Number(this.cfg.quorum) || 1);
    if (votes.length < quorum) {
      this.stats.quorumMissed++;
      this.stats.failed++;
      this.lastError = `quorum not met: ${votes.length}/${quorum} valid votes`;
      this.log.warn(`consensus: ${this.lastError}`);
      this.lastResult = {
        ok: false, reason: 'quorum_not_met', votes: votes.length, quorum,
        failures, at: started, latencyMs: now() - started,
      };
      return null;
    }

    const result = this._fold(votes, failures, { started, quorum });
    this.stats.ok++;
    this.lastError = null;
    this.lastResult = result;
    this.log.info(
      `consensus: ${votes.length}/${this._providers.length} votes, ` +
      `regime=${result.regime} risk×${result.riskMultiplier.toFixed(2)}` +
      (result.veto ? ' VETO' : '') + (result.uncertain ? ' (split)' : '')
    );
    return result;
  }

  /** One model, one call, one validated vote. Rejects on any failure. */
  async _askOne(m, messages) {
    const st = this._stat(m);
    const started = now();
    st.calls++;
    this.stats.modelCalls++;

    // The panel enforces its own deadline rather than trusting the provider to.
    // A provider that ignores `timeoutMs` (or a mock that waits for a signal)
    // would otherwise hang the whole cycle, and one slow model must never cost
    // the others their answer.
    const budget = Number(this.cfg.timeoutMs) || 20000;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(new Error(`timeout after ${budget}ms`)), budget);

    // Quota gate. A provider that is out of budget is skipped without a request.
    // The limiter is keyed by the provider's NAME, not the object: passing the
    // object would stringify to "[object Object]" and silently look unlimited.
    const quotaKey = (m.provider && m.provider.name) || String(m.provider);
    const gate = this.rateLimiter.check(quotaKey);
    if (!gate.ok) {
      clearTimeout(timer);
      st.failed++;
      st.lastError = `quota: ${gate.reason}`;
      this.stats.modelFailures++;
      this.stats.quotaSkipped++;
      throw new Error(`quota: ${gate.reason}`);
    }

    try {
      const raw = await m.provider.complete({
        messages,
        model: m.model,
        timeoutMs: budget,
        signal: ctl.signal,
      });
      // Only a real response burns quota.
      this.rateLimiter.consume(quotaKey);
      const checked = validateDecide(raw, {
        maxRiskMultiplier: this.ceiling,
        allowVeto: this.cfg.allowVeto,
      });
      if (!checked.ok) {
        throw new Error(`invalid output: ${checked.problems.join('; ')}`);
      }
      const latencyMs = now() - started;
      st.ok++;
      st.lastLatencyMs = latencyMs;
      st.lastAt = started;
      st.lastError = null;
      st.lastVote = {
        regime: checked.value.regime,
        confidence: checked.value.confidence,
        bias: checked.value.bias,
        riskMultiplier: checked.value.riskMultiplier,
        veto: checked.value.veto,
      };
      return {
        provider: m.provider,
        model: m.model,
        weight: m.weight,
        latencyMs,
        ...checked.value,
      };
    } catch (e) {
      const latencyMs = now() - started;
      const isTimeout = /timeout|abort/i.test(e?.message || '');
      st.failed++;
      st.lastLatencyMs = latencyMs;
      st.lastAt = started;
      st.lastError = String(e?.message || e).slice(0, 200);
      this.stats.modelFailures++;
      if (isTimeout) { st.timeouts++; this.stats.modelTimeouts++; }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Fold votes into one verdict.
   *
   * riskMultiplier  = MIN across valid votes (the hard rule)
   * regime / bias   = weighted majority
   * veto            = weighted majority
   * confidence      = weighted mean, halved when the panel is split
   */
  _fold(votes, failures, { started, quorum }) {
    const rms = votes.map((v) => v.riskMultiplier);
    const strictest = Math.min(...rms);
    const med = median(rms);
    const dispersion = stdev(rms);

    // Weighted majority for the categorical fields.
    const weightOf = (v) => (Number.isFinite(v.weight) && v.weight > 0 ? v.weight : 1);
    const weightedMode = (field) => {
      const tally = new Map();
      for (const v of votes) {
        const k = v[field];
        tally.set(k, (tally.get(k) || 0) + weightOf(v));
      }
      let best = null;
      let bestW = -1;
      for (const [k, w] of tally) {
        if (w > bestW) { best = k; bestW = w; }
      }
      return best;
    };

    const regime = weightedMode('regime');
    const bias = weightedMode('bias');

    const totalW = votes.reduce((a, v) => a + weightOf(v), 0);
    const vetoW = votes.filter((v) => v.veto).reduce((a, v) => a + weightOf(v), 0);
    const veto = vetoW > totalW / 2;

    const confMean = votes.reduce((a, v) => a + v.confidence * weightOf(v), 0) / totalW;

    const threshold = Number.isFinite(this.cfg.disagreementThreshold)
      ? this.cfg.disagreementThreshold
      : 0.35;
    const uncertain = dispersion > threshold;

    // A split panel is a reason to be careful. Tighten, never loosen.
    let riskMultiplier = strictest;
    let confidence = confMean;
    if (uncertain) {
      this.stats.disagreements++;
      confidence = confMean * 0.5;
      riskMultiplier = Math.min(riskMultiplier, 0.5);
    }
    riskMultiplier = Math.min(this.ceiling, Math.max(0, riskMultiplier));
    if (veto) this.stats.vetoes++;

    // Regime agreement, for the report: how many votes matched the winner.
    const agreeing = votes.filter((v) => v.regime === regime).length;

    const dissent = votes
      .filter((v) => v.regime !== regime || v.veto !== veto)
      .map((v) => ({
        provider: v.provider,
        model: v.model,
        regime: v.regime,
        riskMultiplier: v.riskMultiplier,
        veto: v.veto,
      }));

    const reasoning = this._reasoning({ votes, regime, riskMultiplier, med, dispersion, uncertain, veto, failures });

    return {
      ok: true,
      // Decision-shaped, so Jev can consume it without special-casing.
      regime,
      confidence: Math.min(1, Math.max(0, confidence)),
      bias,
      riskMultiplier,
      reasoning,
      veto,
      vetoRequested: veto,
      degraded: false,
      source: 'consensus',
      model: `${votes.length} models`,
      at: started,
      latencyMs: now() - started,

      // Consensus-specific detail, for the dashboard and the ledger.
      consensus: {
        votes: votes.length,
        quorum,
        failed: failures.length,
        medianRiskMultiplier: med,
        strictestRiskMultiplier: strictest,
        dispersion: Math.round(dispersion * 1000) / 1000,
        uncertain,
        agreement: `${agreeing}/${votes.length}`,
        dissent,
        failures,
        perModel: votes.map((v) => ({
          provider: v.provider,
          model: v.model,
          regime: v.regime,
          confidence: v.confidence,
          bias: v.bias,
          riskMultiplier: v.riskMultiplier,
          veto: v.veto,
          latencyMs: v.latencyMs,
        })),
      },
    };
  }

  _reasoning({ votes, regime, riskMultiplier, med, dispersion, uncertain, veto, failures }) {
    const bits = [];
    bits.push(`${votes.length} model(s) agreed on ${regime}`);
    bits.push(`risk ×${riskMultiplier.toFixed(2)} (strictest of ${votes.length}, median ${med == null ? 'n/a' : med.toFixed(2)})`);
    if (uncertain) bits.push(`panel split (σ=${dispersion.toFixed(2)}) — tightened`);
    if (veto) bits.push('majority veto');
    if (failures.length) bits.push(`${failures.length} model(s) failed`);
    return bits.join('; ').slice(0, 600);
  }

  /** Dashboard view: per-model health plus the last verdict. */
  snapshot() {
    const models = [...this.modelStats.values()].map((s) => ({
      ...s,
      errorRate: s.calls ? Math.round((s.failed / s.calls) * 100) / 100 : 0,
    }));
    const r = this.lastResult;
    return {
      enabled: this.enabled,
      ready: this.ready,
      configured: this.models.length,
      quorum: Number(this.cfg.quorum) || 1,
      disagreementThreshold: this.cfg.disagreementThreshold,
      lastError: this.lastError,
      models,
      quota: this.rateLimiter ? this.rateLimiter.snapshot() : null,
      last: r && r.ok
        ? {
            regime: r.regime,
            confidence: r.confidence,
            riskMultiplier: r.riskMultiplier,
            veto: r.veto,
            uncertain: r.consensus.uncertain,
            dispersion: r.consensus.dispersion,
            agreement: r.consensus.agreement,
            votes: r.consensus.votes,
            failed: r.consensus.failed,
            at: r.at,
            latencyMs: r.latencyMs,
          }
        : (r ? { ok: false, reason: r.reason, votes: r.votes, quorum: r.quorum, at: r.at } : null),
      ...this.stats,
    };
  }
}

module.exports = { Consensus, DEFAULTS, median, stdev, mode };
