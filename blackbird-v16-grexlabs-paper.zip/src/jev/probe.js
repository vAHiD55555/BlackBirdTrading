#!/usr/bin/env node
'use strict';
/**
 * BlackBird — jev provider probe.
 *
 *   node src/jev/probe.js                 probe every provider in the catalog
 *   node src/jev/probe.js groq gemini     probe only these
 *   node src/jev/probe.js --consensus     probe only the configured panel
 *   node src/jev/probe.js --json          machine-readable output
 *
 * For each provider it reports, in this order:
 *   1. is the key present?          (never prints the key, only its length)
 *   2. did the request succeed?     (HTTP status / error text)
 *   3. how long did it take?
 *   4. did the reply parse as valid jev JSON?
 *
 * This is the tool you reach for when the panel says "quorum not met" and you
 * need to know which model is the problem and why.
 */

const path = require('node:path');
const { CATALOG, entry: catalogEntry } = require('./providers/catalog');
const { createProvider } = require('./providers');
const { validateDecide } = require('./schema');
const { buildDecideMessages } = require('./prompt');

const argv = process.argv.slice(2);
const JSON_OUT = argv.includes('--json');
const CONSENSUS_ONLY = argv.includes('--consensus');
const names = argv.filter((a) => !a.startsWith('--'));

const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m',
};
const useColor = process.stdout.isTTY && !JSON_OUT;
const c = (code, s) => (useColor ? `${code}${s}${C.reset}` : s);

/** A tiny, realistic context so the model has something to reason about. */
function probeContext() {
  return {
    asOf: new Date().toISOString(),
    mode: 'paper',
    strategy: 'rotator',
    equity: 5000,
    equityMtm: 5013.82,
    drawdownPct: 0,
    dailyPnlPct: 0.28,
    halted: false,
    haltReason: null,
    openPositions: 6,
    volScale: 1,
    ddScale: 1,
    lastRebalanceAt: null,
    positions: [
      { symbol: 'BNB', side: 'long', entry: 640.2, stop: 601.8, pnl: 0.32 },
      { symbol: 'AVAX', side: 'long', entry: 28.4, stop: 26.1, pnl: -5.51 },
    ],
    market: [
      { symbol: 'BTC', price: 96000, regime: 'muddy', atrPct: 1.8, volPercentile: 0.62, rsi: 54.1, spreadBps: 1.2, depthUsd: 4200000 },
      { symbol: 'ETH', price: 3400, regime: 'muddy', atrPct: 2.4, volPercentile: 0.71, rsi: 48.7, spreadBps: 1.8, depthUsd: 1800000 },
      { symbol: 'SOL', price: 190, regime: 'trend', atrPct: 3.1, volPercentile: 0.83, rsi: 61.2, spreadBps: 2.4, depthUsd: 640000 },
    ],
  };
}

function keyInfo(providerName) {
  const e = catalogEntry(providerName);
  if (!e) return { env: null, present: false, length: 0 };
  if (!e.apiKeyEnv) return { env: null, present: true, length: 0, keyless: true };
  const v = process.env[e.apiKeyEnv];
  return {
    env: e.apiKeyEnv,
    present: Boolean(v && String(v).trim()),
    length: v ? String(v).trim().length : 0,
  };
}

async function probeOne(name, modelOverride) {
  const e = catalogEntry(name);
  if (!e) {
    return { provider: name, ok: false, stage: 'catalog', error: `unknown provider "${name}"` };
  }
  const model = modelOverride || (e.models && e.models[0]) || '';
  const key = keyInfo(name);

  const result = {
    provider: e.key,
    label: e.label,
    model,
    keyEnv: key.env,
    keyPresent: key.present,
    keyLength: key.length,
    keyless: Boolean(key.keyless),
    free: Boolean(e.free),
    rateLimit: e.rateLimit,
    ok: false,
    stage: 'init',
    latencyMs: null,
    error: null,
    validJson: false,
    decision: null,
  };

  if (!key.present && !key.keyless) {
    result.stage = 'key';
    result.error = `missing ${key.env}`;
    return result;
  }

  let provider;
  try {
    provider = createProvider(
      { provider: e.key, model, timeoutMs: 30000 },
      { env: process.env }
    );
  } catch (err) {
    result.stage = 'init';
    result.error = err.message;
    return result;
  }

  const messages = buildDecideMessages(probeContext(), {
    maxRiskMultiplier: 1,
    allowVeto: true,
  });

  const started = Date.now();
  try {
    const raw = await provider.complete({ messages, model, timeoutMs: 30000 });
    result.latencyMs = Date.now() - started;
    result.stage = 'response';
    result.ok = true;

    const checked = validateDecide(raw, { maxRiskMultiplier: 1, allowVeto: true });
    result.validJson = checked.ok;
    if (checked.ok) {
      result.decision = {
        regime: checked.value.regime,
        confidence: checked.value.confidence,
        bias: checked.value.bias,
        riskMultiplier: checked.value.riskMultiplier,
        veto: checked.value.veto,
      };
    } else {
      result.stage = 'schema';
      result.error = checked.problems.join('; ');
      result.rawSnippet = String(raw).slice(0, 200);
    }
  } catch (err) {
    result.latencyMs = Date.now() - started;
    result.stage = 'request';
    result.error = String(err && err.message ? err.message : err).slice(0, 400);
  }
  return result;
}

function printResult(r) {
  const mark = r.ok && r.validJson ? c(C.green, '✓') : r.ok ? c(C.yellow, '~') : c(C.red, '✗');
  const name = `${r.label || r.provider}`.padEnd(18);
  const model = String(r.model || '').slice(0, 42).padEnd(42);

  let line = `${mark} ${c(C.bold, name)} ${c(C.dim, model)}`;

  if (r.stage === 'key') {
    line += c(C.red, `  no key (${r.keyEnv})`);
  } else if (r.ok && r.validJson) {
    const d = r.decision;
    line += c(C.green, `  ${String(r.latencyMs).padStart(5)}ms`) +
      c(C.dim, `  ${d.regime} conf=${d.confidence.toFixed(2)} ×${d.riskMultiplier.toFixed(2)}${d.veto ? ' VETO' : ''}`);
  } else if (r.ok) {
    line += c(C.yellow, `  ${String(r.latencyMs).padStart(5)}ms`) + c(C.yellow, `  bad JSON: ${r.error}`);
  } else {
    line += c(C.red, `  ${r.latencyMs == null ? '   —' : String(r.latencyMs).padStart(5)}ms`) + c(C.red, `  ${r.error}`);
  }
  console.log(line);
}

async function main() {
  let targets;

  if (CONSENSUS_ONLY) {
    // Read the panel straight out of config.json, so the probe tests exactly
    // what the engine will use.
    let cfg;
    try {
      const { loadConfig } = require('../config');
      cfg = loadConfig();
    } catch (e) {
      console.error(`cannot load config: ${e.message}`);
      process.exit(2);
    }
    const models = cfg?.jev?.consensus?.models || [];
    if (!models.length) {
      console.log(c('yellow', 'jev.consensus.models is empty — nothing to probe.'));
      process.exit(0);
    }
    targets = models.map((m) => ({ provider: m.provider, model: m.model }));
  } else if (names.length) {
    targets = names.map((n) => ({ provider: n, model: null }));
  } else {
    targets = Object.keys(CATALOG).map((k) => ({ provider: k, model: null }));
  }

  if (!JSON_OUT) {
    console.log(c(C.bold, '\nBlackBird — jev provider probe'));
    console.log(c(C.dim, `probing ${targets.length} provider(s) · ${new Date().toISOString()}\n`));
  }

  const results = [];
  for (const t of targets) {
    // Sequential on purpose: parallel probes trip free-tier rate limits and
    // then every provider looks broken.
    const r = await probeOne(t.provider, t.model);
    results.push(r);
    if (!JSON_OUT) printResult(r);
  }

  if (JSON_OUT) {
    console.log(JSON.stringify({ at: new Date().toISOString(), results }, null, 2));
    return;
  }

  const usable = results.filter((r) => r.ok && r.validJson);
  const noKey = results.filter((r) => r.stage === 'key');
  const broken = results.filter((r) => r.stage !== 'key' && !(r.ok && r.validJson));

  console.log('');
  console.log(c(C.dim, '─'.repeat(72)));
  console.log(
    `  ${c(C.green, `${usable.length} usable`)} · ` +
    `${c(C.yellow, `${noKey.length} without key`)} · ` +
    `${c(C.red, `${broken.length} failing`)}`
  );
  if (usable.length) {
    console.log(c(C.dim, `  ready: ${usable.map((r) => `${r.provider}/${r.model}`).join(', ')}`));
  }
  if (noKey.length) {
    console.log(c(C.dim, `  set:   ${noKey.map((r) => r.keyEnv).filter(Boolean).join(', ')}`));
  }
  console.log(c(C.dim, '─'.repeat(72)) + '\n');

  process.exit(usable.length ? 0 : 1);
}

main().catch((e) => {
  console.error(`probe crashed: ${e.message}`);
  process.exit(2);
});
