#!/usr/bin/env node
'use strict';
/**
 * BlackBird — trial registry CLI.
 *
 *   node src/jev/trials-cli.js            show K and the recent trials
 *   node src/jev/trials-cli.js list 50    show the last 50
 *   node src/jev/trials-cli.js add ...    record a trial by hand
 *   node src/jev/trials-cli.js drift      check the config for unregistered changes
 *
 * Why a CLI: K must be inspectable. A number you cannot audit is a number you
 * will eventually fudge.
 */

const path = require('node:path');
const { loadConfig } = require('../config');
const { TrialRegistry } = require('./trials');

function fmtTs(ts) {
  if (!ts) return '—';
  return new Date(ts).toISOString().replace('T', ' ').slice(0, 19);
}

function short(v) {
  if (v === null || v === undefined) return '—';
  const s = typeof v === 'string' ? v : JSON.stringify(v);
  return s.length > 40 ? `${s.slice(0, 37)}...` : s;
}

function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0] || 'show';

  const cfg = loadConfig();
  const reg = new TrialRegistry({ file: cfg.trials?.file });

  if (cmd === 'show' || cmd === 'list') {
    const n = Number(argv[1]) || 20;
    const snap = reg.snapshot();
    console.log('');
    console.log('  ╔══════════════════════════════════════════════════════════╗');
    console.log(`  ║  K (تعداد آزمون‌های ثبت‌شده) = ${String(snap.K).padEnd(28)}║`);
    console.log('  ╚══════════════════════════════════════════════════════════╝');
    console.log(`  فایل: ${snap.file}`);
    console.log(`  آخرین ثبت: ${fmtTs(snap.lastAt)}`);
    if (Object.keys(snap.byKind).length) {
      console.log(`  به تفکیک نوع: ${Object.entries(snap.byKind).map(([k, v]) => `${k}=${v}`).join('  ')}`);
    }
    console.log('');
    const rows = reg.recent(n);
    if (!rows.length) {
      console.log('  هنوز هیچ آزمونی ثبت نشده است.');
    } else {
      console.log('  #     زمان                 نوع              فیلد                          از → به');
      console.log('  ' + '─'.repeat(100));
      for (const t of rows) {
        const k = String(t.k).padEnd(5);
        const ts = fmtTs(t.ts).padEnd(20);
        const kind = String(t.kind).padEnd(16);
        const field = String(t.field || '—').padEnd(29);
        const change = t.field ? `${short(t.from)} → ${short(t.to)}` : short(t.note);
        console.log(`  ${k} ${ts} ${kind} ${field} ${change}`);
      }
    }
    console.log('');
    return;
  }

  if (cmd === 'add') {
    // node src/jev/trials-cli.js add <field> <from> <to> [note]
    const [, field, from, to, ...note] = argv;
    if (!field) {
      console.error('usage: trials-cli.js add <field> <from> <to> [note]');
      process.exit(2);
    }
    const rec = reg.record({
      kind: 'param_change',
      field,
      from,
      to,
      note: note.join(' ') || 'recorded from CLI',
      source: 'cli',
    });
    if (!rec) {
      console.error('ثبت نشد — فایل قابل نوشتن نیست.');
      process.exit(1);
    }
    console.log(`ثبت شد: K=${rec.k}  ${field}: ${from} → ${to}`);
    return;
  }

  if (cmd === 'drift') {
    const d = reg.detectDrift(cfg);
    if (!d.lastHash) {
      console.log('هیچ اثر انگشتی ثبت نشده — اولین اجرا. یک baseline ثبت کنید.');
      return;
    }
    if (!d.unregistered) {
      console.log('✅ کانفیگ با آخرین اثر انگشت ثبت‌شده یکسان است. آزمون ثبت‌نشده‌ای وجود ندارد.');
      return;
    }
    console.log('⚠️  آزمون ثبت‌نشده پیدا شد — این فیلدها بیرون از رجیستری تغییر کرده‌اند:');
    for (const c of d.changed) {
      console.log(`   • ${c.field}: ${short(c.from)} → ${short(c.to)}`);
    }
    console.log('');
    console.log('برای ثبت: node src/jev/trials-cli.js add <field> <from> <to>');
    process.exit(1);
  }

  console.error(`دستور ناشناخته: ${cmd}`);
  console.error('دستورها: show | list [n] | add <field> <from> <to> [note] | drift');
  process.exit(2);
}

main();
