'use strict';
/**
 * BlackBird — provider rate limiter.
 *
 * Free tiers are not "unlimited, just slower". They are hard quotas that return
 * 429 the moment you cross them, and a 429 costs a full round trip plus a
 * degraded cycle. So the quota is checked BEFORE the call, not discovered after.
 *
 * Two windows per provider:
 *   perMinute  — a sliding window of timestamps
 *   perDay     — a counter that resets at UTC midnight
 *
 * Counters persist to a small JSON file so a restart does not hand you a fresh
 * quota you do not have. The file is written atomically (tmp + rename) so a
 * crash mid-write cannot corrupt it.
 *
 * When a provider is out of quota, `check()` returns { ok:false, reason } and
 * the caller moves to the next model. It never throws, and it never blocks.
 */

const fs = require('node:fs');
const path = require('node:path');

const DEFAULTS = {
  enabled: true,
  stateFile: null, // resolved by the caller from cfg.runtime.dataDir
  // Per-provider overrides live in cfg.rateLimits[provider].
  limits: {},
};

/**
 * Published free-tier limits. Deliberately conservative: being under the real
 * limit costs a little throughput, being over it costs a 429 and a bad cycle.
 *
 * `perDay` is requests/day unless `unit` says otherwise (Cloudflare counts
 * Neurons, not requests).
 */
const FREE_LIMITS = {
  cloudflare: { perMinute: 20, perDay: 10000, unit: 'neurons', note: '10k Neurons/day free' },
  ollama: { perMinute: 0, perDay: 0, unit: 'requests', note: 'local, unlimited' },
  groq: { perMinute: 25, perDay: 900, unit: 'requests', note: '~30/min, 1000/day' },
  gemini: { perMinute: 12, perDay: 1400, unit: 'requests', note: '15/min, 1500/day' },
  cerebras: { perMinute: 25, perDay: 0, unit: 'requests', note: '30/min, 1M tokens/day' },
  mistral: { perMinute: 50, perDay: 0, unit: 'requests', note: '~1/sec' },
  openrouter: { perMinute: 18, perDay: 45, unit: 'requests', note: '20/min, 50/day' },
  anthropic: { perMinute: 0, perDay: 0, unit: 'requests', note: 'paid' },
  openai: { perMinute: 0, perDay: 0, unit: 'requests', note: 'paid' },
  mock: { perMinute: 0, perDay: 0, unit: 'requests', note: 'offline' },
};

/** 0 means "no limit". */
function isUnlimited(n) {
  return !Number.isFinite(n) || n <= 0;
}

function utcDay(ts = Date.now()) {
  return new Date(ts).toISOString().slice(0, 10);
}

/** Milliseconds until the next UTC midnight. */
function msUntilReset(ts = Date.now()) {
  const d = new Date(ts);
  const next = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
  return next - ts;
}

class RateLimiter {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]   cfg.rateLimits
   * @param {object} [opts.log]
   * @param {string} [opts.stateFile]
   * @param {function} [opts.clock]
   */
  constructor({ cfg = {}, log, stateFile, clock } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.clock = clock || (() => Date.now());
    this.stateFile = stateFile || this.cfg.stateFile || null;

    // provider -> { day, dayCount, minute: [ts...] }
    this.state = {};
    this._loaded = false;
    this._dirty = false;

    this.stats = { allowed: 0, denied: 0, resets: 0, persistFailures: 0 };
  }

  get enabled() {
    return this.cfg.enabled !== false;
  }

  /** Effective limits for a provider: config override, else the published table. */
  limitsFor(provider) {
    const key = String(provider || '').toLowerCase();
    const base = FREE_LIMITS[key] || { perMinute: 0, perDay: 0, unit: 'requests' };
    const over = (this.cfg.limits && this.cfg.limits[key]) || {};
    return {
      perMinute: Number.isFinite(over.perMinute) ? over.perMinute : base.perMinute,
      perDay: Number.isFinite(over.perDay) ? over.perDay : base.perDay,
      unit: over.unit || base.unit,
      note: base.note || '',
    };
  }

  _load() {
    if (this._loaded) return;
    this._loaded = true;
    if (!this.stateFile) return;
    try {
      if (fs.existsSync(this.stateFile)) {
        const raw = JSON.parse(fs.readFileSync(this.stateFile, 'utf8'));
        if (raw && typeof raw === 'object' && raw.providers) {
          this.state = raw.providers;
        }
      }
    } catch (e) {
      // A corrupt counter file must not stop the engine. Start fresh.
      this.log.warn(`rateLimiter: cannot read ${this.stateFile}: ${e.message}`);
      this.state = {};
    }
  }

  /** Atomic write: tmp then rename, so a crash cannot leave half a file. */
  persist() {
    if (!this.stateFile || !this._dirty) return true;
    try {
      const dir = path.dirname(this.stateFile);
      fs.mkdirSync(dir, { recursive: true });
      const tmp = `${this.stateFile}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ savedAt: this.clock(), providers: this.state }), 'utf8');
      fs.renameSync(tmp, this.stateFile);
      this._dirty = false;
      return true;
    } catch (e) {
      this.stats.persistFailures++;
      this.log.warn(`rateLimiter: cannot persist: ${e.message}`);
      return false;
    }
  }

  /** Get (and lazily reset) the bucket for a provider. */
  _bucket(provider) {
    this._load();
    const key = String(provider || '').toLowerCase();
    const today = utcDay(this.clock());
    let b = this.state[key];
    if (!b) {
      b = { day: today, dayCount: 0, minute: [] };
      this.state[key] = b;
    }
    if (b.day !== today) {
      b.day = today;
      b.dayCount = 0;
      b.minute = [];
      this.stats.resets++;
      this._dirty = true;
    }
    // Drop timestamps older than a minute.
    const cutoff = this.clock() - 60000;
    if (Array.isArray(b.minute) && b.minute.length) {
      const live = b.minute.filter((t) => t > cutoff);
      if (live.length !== b.minute.length) { b.minute = live; this._dirty = true; }
    }
    return b;
  }

  /**
   * May this provider be called right now?
   * @returns {{ok:boolean, reason?:string, retryAfterMs?:number, remaining?:object}}
   */
  check(provider) {
    if (!this.enabled) return { ok: true };
    const lim = this.limitsFor(provider);
    const b = this._bucket(provider);

    if (!isUnlimited(lim.perDay) && b.dayCount >= lim.perDay) {
      this.stats.denied++;
      return {
        ok: false,
        reason: `daily quota exhausted (${b.dayCount}/${lim.perDay} ${lim.unit})`,
        retryAfterMs: msUntilReset(this.clock()),
        remaining: { day: 0, minute: null },
      };
    }
    if (!isUnlimited(lim.perMinute) && b.minute.length >= lim.perMinute) {
      this.stats.denied++;
      const oldest = b.minute[0] || this.clock();
      return {
        ok: false,
        reason: `per-minute limit reached (${b.minute.length}/${lim.perMinute})`,
        retryAfterMs: Math.max(0, oldest + 60000 - this.clock()),
        remaining: { day: isUnlimited(lim.perDay) ? null : lim.perDay - b.dayCount, minute: 0 },
      };
    }
    return {
      ok: true,
      remaining: {
        day: isUnlimited(lim.perDay) ? null : lim.perDay - b.dayCount,
        minute: isUnlimited(lim.perMinute) ? null : lim.perMinute - b.minute.length,
      },
    };
  }

  /**
   * Record a call. Call this AFTER a successful request, not before: a request
   * that never left the machine should not burn quota.
   */
  consume(provider, units = 1) {
    if (!this.enabled) return;
    const b = this._bucket(provider);
    const n = Number.isFinite(units) && units > 0 ? units : 1;
    b.dayCount += n;
    b.minute.push(this.clock());
    this._dirty = true;
    this.stats.allowed++;
  }

  /**
   * Convenience: check, and if allowed, run `fn` and consume on success.
   * Returns { ok:false, reason } when the quota is gone, so the caller can move
   * to the next model without ever making the request.
   */
  async guard(provider, fn) {
    const gate = this.check(provider);
    if (!gate.ok) return { ok: false, reason: gate.reason, retryAfterMs: gate.retryAfterMs };
    try {
      const value = await fn();
      this.consume(provider);
      return { ok: true, value };
    } catch (e) {
      // A failed call still cost a request at the provider in most cases, but
      // counting it would punish a network blip. Only count real responses.
      if (!/timeout|abort|ECONN|ENOTFOUND/i.test(e?.message || '')) this.consume(provider);
      return { ok: false, reason: e?.message || String(e), error: e };
    }
  }

  /** Dashboard view: usage, ceiling, reset time, per provider. */
  snapshot() {
    this._load();
    const out = [];
    const providers = new Set([...Object.keys(FREE_LIMITS), ...Object.keys(this.state)]);
    for (const p of providers) {
      const lim = this.limitsFor(p);
      const b = this._bucket(p);
      out.push({
        provider: p,
        unit: lim.unit,
        usedToday: b.dayCount,
        limitToday: isUnlimited(lim.perDay) ? null : lim.perDay,
        usedThisMinute: b.minute.length,
        limitPerMinute: isUnlimited(lim.perMinute) ? null : lim.perMinute,
        remainingToday: isUnlimited(lim.perDay) ? null : Math.max(0, lim.perDay - b.dayCount),
        pctUsed: isUnlimited(lim.perDay) || lim.perDay === 0
          ? null
          : Math.round((b.dayCount / lim.perDay) * 1000) / 10,
        resetsInMs: msUntilReset(this.clock()),
        note: lim.note,
      });
    }
    return {
      enabled: this.enabled,
      stateFile: this.stateFile,
      providers: out.sort((a, b) => a.provider.localeCompare(b.provider)),
      ...this.stats,
    };
  }

  /** Manual reset, for tests and for an operator who knows better. */
  reset(provider) {
    if (provider) {
      delete this.state[String(provider).toLowerCase()];
    } else {
      this.state = {};
    }
    this._dirty = true;
    this.persist();
  }
}

module.exports = { RateLimiter, FREE_LIMITS, DEFAULTS, utcDay, msUntilReset, isUnlimited };
