'use strict';
/**
 * BlackBird — jev, the central layer.
 *
 * jev holds three roles at once, and each one is a real code path, not a label:
 *
 *   BRAIN      decide(context)     -> { regime, confidence, bias, riskMultiplier, veto }
 *   MEDIATOR   mediate(request)    -> { resolution, riskMultiplier, winner, reasoning }
 *   MANAGER    supervise(snapshot) -> { modules:[{name,action,reason}], overall }
 *
 * The single most important property of this file is that NONE of those three
 * methods can throw or reject. Every failure path — disabled, no key, network
 * down, timeout, garbage JSON, schema violation, provider bug — resolves to a
 * neutral answer that leaves the engine behaving exactly as it did before jev
 * existed.
 *
 * That is the whole safety argument: a broken jev is indistinguishable from an
 * absent jev.
 *
 * Power limits, enforced in code rather than in prose:
 *   - riskMultiplier is clamped to [0, min(1, cfg.maxRiskMultiplier)]
 *   - a veto only blocks NEW entries; it never closes an open position
 *   - quarantine only stops the system trusting a module's output; it never
 *     stops the module's own safety behaviour (risk halts still halt)
 */

const { createProvider } = require('./providers');
const {
  buildContext,
  buildDecideMessages,
  buildMediateMessages,
  buildSuperviseMessages,
  summarise,
} = require('./prompt');
const {
  validateDecide,
  validateMediate,
  validateSupervise,
  neutralDecision,
  neutralMediation,
  neutralSupervision,
} = require('./schema');
const { ModuleRegistry } = require('./registry');
const { JevBus } = require('./bus');
const { Consensus } = require('./consensus');
const { Ledger } = require('./ledger');
const { now } = require('../core/util');

const DEFAULTS = {
  enabled: false,
  // KEYLESS AND REMOTE by default. `pollinations` needs no key and no local
  // process, so it works on a hosted free tier (botkeep.cloud and friends)
  // where 127.0.0.1 is the container itself and nothing is installed there.
  // The old default was `ollama`, which can never answer on such a host.
  provider: 'pollinations',
  model: 'openai',
  baseUrl: '',
  apiKeyEnv: 'JEV_API_KEY',
  // Tried in order when the chosen provider is unusable. `mock` is last so a
  // total outage degrades to a deterministic answer instead of a crash.
  keylessFallback: ['pollinations', 'mock'],
  // Local models (ollama) are skipped unless this is on: on a hosted container
  // they can only ever time out, and a timeout costs a whole cycle.
  allowLocal: false,
  timeoutMs: 20000,
  maxRiskMultiplier: 1,
  allowVeto: true,
  superviseIntervalMs: 10 * 60 * 1000,
  decideIntervalMs: 5 * 60 * 1000,
  allowQuarantine: true,
};

class Jev {
  /**
   * @param {object} opts
   * @param {object} [opts.cfg]       cfg.jev from config.json
   * @param {object} [opts.log]       logger (child)
   * @param {object} [opts.provider]  inject a provider (tests)
   * @param {object} [opts.env]       inject an env object (tests)
   * @param {object} [opts.registry]  inject a registry (tests)
   * @param {object} [opts.bus]       inject a bus (tests)
   */
  constructor({ cfg = {}, log, provider, env, registry, bus, consensus, ledger, worker } = {}) {
    this.cfg = { ...DEFAULTS, ...(cfg || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
    this.env = env || process.env;

    this.registry = registry || new ModuleRegistry({ log: this.log });
    this.bus = bus || new JevBus({ log: this.log });

    // The panel. When it is configured and ready it outranks the single model:
    // more opinions, and one dead provider cannot take the cycle down.
    this.consensus = consensus || new Consensus({
      cfg: this.cfg.consensus || {},
      log: this.log,
      env: this.env,
    });

    // The observation ledger. Off unless asked for; never throws.
    this.ledger = ledger || new Ledger({
      cfg: this.cfg.ledger || {},
      log: this.log,
    });
    this._cycleSeq = 0;

    this.lastDecision = null;
    this.lastMediation = null;
    this.lastSupervision = null;
    this.lastDecideAt = 0;
    this.lastSuperviseAt = 0;
    this.lastError = null;
    this.alerts = [];
    this.inFlight = { decide: null, mediate: null, supervise: null };

    this.stats = {
      decideRuns: 0, decideOk: 0, decideFailed: 0,
      mediateRuns: 0, mediateOk: 0, mediateFailed: 0,
      superviseRuns: 0, superviseOk: 0, superviseFailed: 0,
      vetoes: 0, reductions: 0, blocks: 0, quarantines: 0, timeouts: 0, skipped: 0,
    };

    this._provider = provider || null;
    this._providerError = null;
    // The fallback chain, built once. Each entry is { name, provider }.
    this._chain = [];

    if (this.enabled && !this._provider) {
      try {
        // undefined (not '') when no key is set, so the provider factory can fall
        // back to the catalog's env var instead of trusting an empty string.
        this._provider = createProvider(this.cfg, { apiKey: this.apiKey() || undefined });
        // اگر درگاه لبه روشن باشد، اول از آن می‌پرسیم؛ اگر جواب نداد، همان
        // provider مستقیم کار می‌کند. ترتیب هیچ‌وقت هم‌زمان نیست.
        if (this._provider && worker && worker.llmEnabled && this._provider.complete) {
          // eslint-disable-next-line global-require
          const { WorkerFirstProvider } = require('../worker/provider');
          this._provider = new WorkerFirstProvider({ inner: this._provider, bridge: worker });
        }
      } catch (e) {
        // A misconfigured provider must not stop the engine from booting.
        this._providerError = e.message;
        this.log.warn(`jev provider unavailable: ${e.message}`);
      }
      this._buildChain();
    }
  }

  /**
   * Build the ordered list of providers to try.
   *
   * `keylessFallback` was documented in .env.example and in DEFAULTS for two
   * releases while nothing ever read it: a dead provider meant a dead cycle.
   * This is the code that makes the documented promise true.
   *
   * Rules:
   *   - the configured provider is always first;
   *   - a local-only provider (ollama) is skipped unless `allowLocal` is on,
   *     because on a hosted container it can only time out;
   *   - a provider that needs a key is skipped when the key is absent;
   *   - `mock` is always last, so the chain can never be empty.
   */
  _buildChain() {
    const chain = [];
    const seen = new Set();
    const push = (name) => {
      const key = String(name || '').toLowerCase();
      if (!key || seen.has(key)) return;
      seen.add(key);
      try {
        // eslint-disable-next-line global-require
        const { entry, isKeyless, isLocalOnly } = require('./providers/catalog');
        const cat = entry(key);
        if (!cat) return;
        if (isLocalOnly(key) && !this.cfg.allowLocal) return;
        if (!isKeyless(key)) {
          const envName = cat.apiKeyEnv;
          const has = (envName && this.env[envName]) || this.env.JEV_API_KEY;
          if (!has) return;
        }
        chain.push({ name: key, provider: createProvider({ ...this.cfg, provider: key }, { env: this.env }) });
      } catch (e) {
        this.log.debug(`jev chain: ${key} skipped (${e.message})`);
      }
    };

    push(this.cfg.provider);
    for (const name of this.cfg.keylessFallback || []) push(name);
    push('mock');
    this._chain = chain;
    if (chain.length) this.log.debug(`jev chain: ${chain.map((c) => c.name).join(' -> ')}`);
  }

  /**
   * Ask the chain, in order, until one answers. Returns { text, via }.
   * Throws only when every provider failed, with the last error.
   */
  async _complete(messages, opts = {}) {
    const list = this._chain.length ? this._chain : [{ name: this.cfg.provider, provider: this._provider }];
    let lastErr = null;
    for (const step of list) {
      if (!step || !step.provider) continue;
      try {
        const text = await step.provider.complete({
          messages,
          model: step.name === this.cfg.provider ? this.cfg.model : undefined,
          timeoutMs: opts.timeoutMs || this.cfg.timeoutMs,
        });
        if (step.name !== this.cfg.provider) {
          this.log.warn(`jev: ${this.cfg.provider} failed, answered by ${step.name}`);
        }
        return { text, via: step.name };
      } catch (e) {
        lastErr = e;
        this.log.debug(`jev: ${step.name} failed (${e.message})`);
      }
    }
    throw lastErr || new Error('no provider in the chain could answer');
  }

  get enabled() {
    return Boolean(this.cfg.enabled);
  }

  /**
   * The key lives in the environment only. Never in config.json, never logged.
   *
   * Two names are accepted: the configured one (JEV_API_KEY unless overridden),
   * and the variable the chosen provider's own dashboard tells the operator to
   * set (GROQ_API_KEY, GEMINI_API_KEY, ...). Without the second, following a
   * provider's instructions to the letter left jev "not ready" with no clue why.
   */
  apiKey() {
    const name = this.cfg.apiKeyEnv || 'JEV_API_KEY';
    const v = this.env[name];
    if (typeof v === 'string' && v.trim()) return v.trim();
    try {
      // eslint-disable-next-line global-require
      const { entry } = require('./providers/catalog');
      const cat = entry(this.cfg.provider);
      const alt = cat && cat.apiKeyEnv ? this.env[cat.apiKeyEnv] : null;
      if (typeof alt === 'string' && alt.trim()) return alt.trim();
    } catch { /* catalog missing: JEV_API_KEY alone is still enough */ }
    return '';
  }

  /** True when jev is on and has everything it needs to try. */
  get ready() {
    if (!this.enabled) return false;
    if (this._providerError) return false;
    if (!this._provider) return false;
    // Ask the catalog whether this provider needs a key, instead of keeping a
    // second hard-coded list here. The old regex only knew `mock` and `ollama`,
    // so any other keyless provider would have been reported "not ready" even
    // though it needs no key at all.
    let needsKey = true;
    try {
      // eslint-disable-next-line global-require
      const { isKeyless } = require('./providers/catalog');
      needsKey = !isKeyless(this.cfg.provider);
    } catch {
      needsKey = !/^(mock|ollama)$/i.test(String(this.cfg.provider || ''));
    }
    if (needsKey && !this.apiKey()) return false;
    return true;
  }

  get ceiling() {
    const m = Number(this.cfg.maxRiskMultiplier);
    return Number.isFinite(m) ? Math.min(1, Math.max(0, m)) : 1;
  }

  // =========================================================== ROLE 1: BRAIN
  /**
   * Analyse a market context. NEVER throws, NEVER rejects.
   * @param {object} context  output of prompt.buildContext(), or a raw engine status
   * @returns {Promise<object>} a decision object (see schema.js)
   */
  async decide(context) {
    if (!this.enabled) {
      this.stats.skipped++;
      return neutralDecision('jev_disabled');
    }
    if (!this.ready) {
      this.stats.skipped++;
      const why = this._providerError
        ? `jev_provider_error: ${this._providerError}`
        : `jev_not_ready: missing ${this.cfg.apiKeyEnv || 'JEV_API_KEY'}`;
      this.lastError = why;
      return neutralDecision(why);
    }
    // Coalesce concurrent callers: a burst of bars must not become a burst of
    // API calls. Everyone waiting gets the same answer.
    if (this.inFlight.decide) return this.inFlight.decide;
    this.inFlight.decide = this._runDecide(context).finally(() => { this.inFlight.decide = null; });
    return this.inFlight.decide;
  }

  async _runDecide(context) {
    const started = now();
    this.stats.decideRuns++;
    this.lastDecideAt = started;
    try {
      const ctx = context && context.market ? context : buildContext(context);

      // A ready panel answers first. If it cannot reach quorum it returns null
      // and we fall through to the single model, then to the rules.
      if (this.consensus && this.consensus.ready) {
        const viaPanel = await this.consensus.decide(ctx);
        if (viaPanel) {
          this.stats.decideOk++;
          if (viaPanel.veto) this.stats.vetoes++;
          if (viaPanel.riskMultiplier < 1) this.stats.reductions++;
          this.lastDecision = viaPanel;
          this.lastError = null;
          this.log.info(`jev decide (consensus): ${summarise(viaPanel)}`, {
            latencyMs: viaPanel.latencyMs, reasoning: viaPanel.reasoning,
          });
          this.bus.emit('decide', viaPanel);
          this._observe(ctx, viaPanel);
          return viaPanel;
        }
      }

      const messages = buildDecideMessages(ctx, {
        maxRiskMultiplier: this.ceiling,
        allowVeto: this.cfg.allowVeto,
      });
      const raw = await this._complete(messages, { timeoutMs: this.cfg.timeoutMs });
      const checked = validateDecide(raw.text, {
        maxRiskMultiplier: this.ceiling,
        allowVeto: this.cfg.allowVeto,
      });
      if (!checked.ok) {
        this.stats.decideFailed++;
        this.lastError = `invalid decide output: ${checked.problems.join('; ')}`;
        this.log.warn(`jev decide rejected: ${checked.problems.join('; ')}`);
        return this._degradeDecision('invalid_output', checked.problems.join('; '));
      }
      const decision = {
        ...checked.value,
        degraded: false,
        source: raw.via || this.cfg.provider,
        model: this.cfg.model,
        latencyMs: now() - started,
        at: started,
      };
      this.stats.decideOk++;
      if (decision.veto) this.stats.vetoes++;
      if (decision.riskMultiplier < 1) this.stats.reductions++;
      this.lastDecision = decision;
      this.lastError = null;
      this.log.info(`jev decide: ${summarise(decision)}`, {
        latencyMs: decision.latencyMs, reasoning: decision.reasoning,
      });
      this.bus.emit('decide', decision);
      this._observe(ctx, decision);
      return decision;
    } catch (e) {
      this.stats.decideFailed++;
      const isTimeout = /timeout|abort/i.test(e?.message || '');
      if (isTimeout) this.stats.timeouts++;
      this.lastError = e?.message || String(e);
      this.log.warn(`jev decide failed (${isTimeout ? 'timeout' : 'error'}): ${this.lastError}`);
      return this._degradeDecision(isTimeout ? 'timeout' : 'error', this.lastError);
    }
  }

  /**
   * Write one observation record for this cycle.
   *
   * Everything a future training run would need: the input the model saw, what
   * every party said, and the decision that came out. The outcome is attached
   * later by ledger.label(cycleId, ...) once the horizon has passed.
   *
   * Never throws: a broken ledger must not break a decision.
   */
  _observe(ctx, decision) {
    if (!this.ledger || !this.ledger.enabled) return null;
    try {
      const cycleId = `c${now().toString(36)}-${(++this._cycleSeq).toString(36)}`;
      const panel = decision && decision.consensus ? decision.consensus : null;

      this.ledger.write({
        type: 'cycle',
        cycleId,
        input: ctx,
        // Every model's raw opinion, including the ones that failed.
        models: panel
          ? {
              votes: panel.perModel || [],
              failures: panel.failures || [],
              dispersion: panel.dispersion,
              agreement: panel.agreement,
              medianRiskMultiplier: panel.medianRiskMultiplier,
            }
          : (decision ? [{
              provider: decision.source,
              model: decision.model,
              regime: decision.regime,
              confidence: decision.confidence,
              bias: decision.bias,
              riskMultiplier: decision.riskMultiplier,
              veto: decision.veto,
              latencyMs: decision.latencyMs,
            }] : []),
        // What the modules thought, as far as the bus knows.
        modules: this.registry.snapshot().map((m) => ({
          name: m.name, status: m.status, lastError: m.lastError,
        })),
        decision: decision
          ? {
              regime: decision.regime,
              confidence: decision.confidence,
              bias: decision.bias,
              riskMultiplier: decision.riskMultiplier,
              veto: Boolean(decision.veto),
              reasoning: decision.reasoning,
              source: decision.source,
              degraded: Boolean(decision.degraded),
              latencyMs: decision.latencyMs ?? null,
            }
          : null,
      });
      return cycleId;
    } catch (e) {
      this.log.warn(`jev ledger write failed: ${e.message}`);
      return null;
    }
  }

  _degradeDecision(kind, detail) {
    const d = neutralDecision(`jev_${kind}: ${detail}`);
    d.at = now();
    // Keep the failure visible, but never let a stale opinion keep steering risk.
    this.lastDecision = d;
    this._alert('decide', `${kind}: ${detail}`);
    return d;
  }

  // ======================================================== ROLE 2: MEDIATOR
  /**
   * Arbitrate a conflict between modules. NEVER throws, NEVER rejects.
   *
   * @param {object} request
   * @param {string} request.topic
   * @param {Array}  [request.opinions]  defaults to whatever the bus collected
   * @param {object} [request.context]
   * @returns {Promise<object>} { resolution, riskMultiplier, winner, reasoning }
   */
  async mediate(request = {}) {
    const topic = request.topic || 'unspecified';
    const opinions = Array.isArray(request.opinions) ? request.opinions : this.bus.collect(topic);

    // Deterministic pre-pass. This is the part that must work with jev off:
    // a risk objection outranks a strategy opinion, always.
    const pre = this._mediateByRule(opinions);

    if (!this.enabled || !this.ready) {
      this.stats.skipped++;
      const v = { ...pre, degraded: true, source: 'rules', reasoning: pre.reasoning || 'jev_disabled: rule-based arbitration' };
      this.bus.recordVerdict(topic, v);
      this.lastMediation = v;
      return v;
    }
    if (this.inFlight.mediate) return this.inFlight.mediate;

    this.inFlight.mediate = this._runMediate(topic, opinions, request.context, pre)
      .finally(() => { this.inFlight.mediate = null; });
    return this.inFlight.mediate;
  }

  /**
   * The rule-based arbiter. This is the fallback AND the sanity check: if the
   * model's answer is less conservative than this, the stricter one wins.
   */
  _mediateByRule(opinions = []) {
    if (!opinions.length) {
      return { resolution: 'allow', riskMultiplier: 1, winner: null, reasoning: 'no opinions recorded' };
    }
    const blockers = opinions.filter((o) => o.stance === 'block');
    const reducers = opinions.filter((o) => o.stance === 'reduce');

    if (blockers.length) {
      // A risk module's block is decisive; a strategy module's block is not.
      const riskBlocker = blockers.find((o) => /risk|auditor|witness/i.test(o.module));
      const winner = (riskBlocker || blockers[0]).module;
      return {
        resolution: 'block',
        riskMultiplier: 0,
        winner,
        reasoning: `${winner} objects: ${(riskBlocker || blockers[0]).reason || 'no reason given'}`,
      };
    }
    if (reducers.length) {
      const rm = Math.min(...reducers.map((o) => (Number.isFinite(o.weight) ? o.weight : 1)));
      return {
        resolution: 'reduce',
        riskMultiplier: Math.min(1, Math.max(0, rm)),
        winner: reducers[0].module,
        reasoning: `${reducers[0].module} asks for reduced size`,
      };
    }
    return { resolution: 'allow', riskMultiplier: 1, winner: null, reasoning: 'all modules allow' };
  }

  async _runMediate(topic, opinions, context, pre) {
    const started = now();
    this.stats.mediateRuns++;
    try {
      const messages = buildMediateMessages(
        { topic, opinions, context: context || null },
        { maxRiskMultiplier: this.ceiling }
      );
      const raw = await this._provider.complete({
        messages, model: this.cfg.model, timeoutMs: this.cfg.timeoutMs,
      });
      const checked = validateMediate(raw, { maxRiskMultiplier: this.ceiling });
      if (!checked.ok) {
        this.stats.mediateFailed++;
        this.log.warn(`jev mediate rejected: ${checked.problems.join('; ')}`);
        return this._degradeMediation(topic, pre, 'invalid_output', checked.problems.join('; '));
      }

      // The model may be more permissive than the rules. It may not be.
      const merged = this._stricter(pre, checked.value);
      const verdict = {
        ...merged,
        degraded: false,
        source: this.cfg.provider,
        latencyMs: now() - started,
        at: started,
      };
      this.stats.mediateOk++;
      if (verdict.resolution === 'block') this.stats.blocks++;
      this.lastMediation = verdict;
      this.bus.recordVerdict(topic, verdict);
      this.log.info(`jev mediate ${topic}: ${verdict.resolution} ×${verdict.riskMultiplier}`, {
        winner: verdict.winner, reasoning: verdict.reasoning,
      });
      return verdict;
    } catch (e) {
      this.stats.mediateFailed++;
      const isTimeout = /timeout|abort/i.test(e?.message || '');
      if (isTimeout) this.stats.timeouts++;
      this.log.warn(`jev mediate failed (${isTimeout ? 'timeout' : 'error'}): ${e?.message}`);
      return this._degradeMediation(topic, pre, isTimeout ? 'timeout' : 'error', e?.message || String(e));
    }
  }

  /** Take whichever of two verdicts is more conservative. */
  _stricter(a, b) {
    const rank = { allow: 0, reduce: 1, block: 2 };
    const ra = rank[a.resolution] ?? 0;
    const rb = rank[b.resolution] ?? 0;
    const winner = rb > ra ? b : a;
    const rm = Math.min(
      Number.isFinite(a.riskMultiplier) ? a.riskMultiplier : 1,
      Number.isFinite(b.riskMultiplier) ? b.riskMultiplier : 1,
      this.ceiling
    );
    return {
      resolution: winner.resolution,
      riskMultiplier: winner.resolution === 'block' ? 0 : rm,
      winner: winner.winner || a.winner || b.winner || null,
      reasoning: winner.reasoning || a.reasoning || b.reasoning || '',
    };
  }

  _degradeMediation(topic, pre, kind, detail) {
    const v = {
      ...pre,
      degraded: true,
      source: 'rules',
      reasoning: `${pre.reasoning} (jev ${kind}: ${detail})`,
      at: now(),
    };
    this.lastMediation = v;
    this.bus.recordVerdict(topic, v);
    this._alert('mediate', `${kind}: ${detail}`);
    return v;
  }

  // ========================================================= ROLE 3: MANAGER
  /**
   * Watch the modules. NEVER throws, NEVER rejects.
   * @param {object} [snapshot]  defaults to registry.promptSnapshot()
   * @returns {Promise<object>} { modules:[{name,action,reason}], overall, reasoning }
   */
  async supervise(snapshot) {
    const snap = snapshot || this.registry.promptSnapshot();
    const ruleView = this._superviseByRule(snap);

    if (!this.enabled || !this.ready) {
      this.stats.skipped++;
      const v = { ...ruleView, degraded: true, source: 'rules' };
      this.lastSupervision = v;
      this.lastSuperviseAt = now();
      this._applySupervision(v);
      return v;
    }
    if (this.inFlight.supervise) return this.inFlight.supervise;

    this.inFlight.supervise = this._runSupervise(snap, ruleView)
      .finally(() => { this.inFlight.supervise = null; });
    return this.inFlight.supervise;
  }

  /**
   * Deterministic health pass. Runs with jev off, and is the floor the model
   * cannot go below: a module the rules want quarantined stays quarantined.
   */
  _superviseByRule(snap) {
    const modules = [];
    let worst = 'healthy';
    for (const m of snap.modules || []) {
      let action = 'ok';
      let reason = '';
      if (m.status === 'quarantined') {
        action = 'quarantine';
        reason = 'already quarantined';
      } else if (m.status === 'watch') {
        action = 'watch';
        reason = m.lastError ? `last error: ${m.lastError}` : 'stale or unhealthy';
      } else if (m.lastError && (m.counters?.errorCount || 0) >= 3) {
        action = 'quarantine';
        reason = `repeated errors (${m.counters.errorCount})`;
      }
      if (action === 'quarantine') worst = 'critical';
      else if (action === 'watch' && worst === 'healthy') worst = 'degraded';
      modules.push({ name: m.name, action, reason });
    }
    return { modules, overall: worst, reasoning: 'rule-based health pass' };
  }

  async _runSupervise(snap, ruleView) {
    const started = now();
    this.stats.superviseRuns++;
    this.lastSuperviseAt = started;
    try {
      const messages = buildSuperviseMessages(snap, {
        quarantineAllowed: this.cfg.allowQuarantine !== false,
      });
      const raw = await this._provider.complete({
        messages, model: this.cfg.model, timeoutMs: this.cfg.timeoutMs,
      });
      const checked = validateSupervise(raw, {
        quarantineAllowed: this.cfg.allowQuarantine !== false,
        knownModules: (snap.modules || []).map((m) => m.name),
      });
      if (!checked.ok) {
        this.stats.superviseFailed++;
        this.log.warn(`jev supervise rejected: ${checked.problems.join('; ')}`);
        return this._degradeSupervision(ruleView, 'invalid_output', checked.problems.join('; '));
      }
      const merged = this._mergeSupervision(ruleView, checked.value);
      const v = { ...merged, degraded: false, source: this.cfg.provider, latencyMs: now() - started, at: started };
      this.stats.superviseOk++;
      this.lastSupervision = v;
      this._applySupervision(v);
      this.log.info(`jev supervise: ${v.overall}`, { flagged: v.modules.filter((m) => m.action !== 'ok').length });
      return v;
    } catch (e) {
      this.stats.superviseFailed++;
      const isTimeout = /timeout|abort/i.test(e?.message || '');
      if (isTimeout) this.stats.timeouts++;
      this.log.warn(`jev supervise failed (${isTimeout ? 'timeout' : 'error'}): ${e?.message}`);
      return this._degradeSupervision(ruleView, isTimeout ? 'timeout' : 'error', e?.message || String(e));
    }
  }

  /** Union of both views, taking the stricter action per module. */
  _mergeSupervision(ruleView, modelView) {
    const rank = { ok: 0, watch: 1, quarantine: 2 };
    const byName = new Map();
    for (const m of ruleView.modules) byName.set(m.name, { ...m });
    for (const m of modelView.modules) {
      const cur = byName.get(m.name);
      if (!cur) { byName.set(m.name, { ...m }); continue; }
      if ((rank[m.action] ?? 0) > (rank[cur.action] ?? 0)) {
        byName.set(m.name, { name: m.name, action: m.action, reason: m.reason || cur.reason });
      }
    }
    const modules = [...byName.values()];
    const overall = modules.some((m) => m.action === 'quarantine')
      ? 'critical'
      : (modules.some((m) => m.action === 'watch') ? 'degraded' : 'healthy');
    return { modules, overall, reasoning: modelView.reasoning || ruleView.reasoning };
  }

  _degradeSupervision(ruleView, kind, detail) {
    const v = { ...ruleView, degraded: true, source: 'rules', reasoning: `${ruleView.reasoning} (jev ${kind}: ${detail})`, at: now() };
    this.lastSupervision = v;
    this._applySupervision(v);
    this._alert('supervise', `${kind}: ${detail}`);
    return v;
  }

  /** Turn a supervision verdict into registry state. */
  _applySupervision(v) {
    for (const m of v.modules || []) {
      if (m.action === 'quarantine' && !this.registry.isQuarantined(m.name)) {
        this.registry.quarantine(m.name, m.reason || 'jev quarantine');
        this.stats.quarantines++;
        this._alert('quarantine', `${m.name}: ${m.reason || 'no reason'}`);
      } else if (m.action === 'watch') {
        this._alert('watch', `${m.name}: ${m.reason || 'unhealthy'}`);
      }
    }
  }

  // ================================================================ helpers
  _alert(kind, message) {
    const entry = { kind, message: String(message).slice(0, 300), at: now() };
    this.alerts.push(entry);
    if (this.alerts.length > 50) this.alerts.shift();
    this.bus.emit('alert', entry);
  }

  /**
   * The only sanctioned way for the rest of the system to consume a decision.
   * Returns a risk multiplier in 0..1 and an entry gate. Safe with null.
   */
  static apply(decision, opts = {}) {
    const maxRisk = Number.isFinite(opts.maxRiskMultiplier) ? opts.maxRiskMultiplier : 1;
    if (!decision || decision.degraded) {
      return { riskMultiplier: 1, blockEntries: false, reason: decision?.reasoning || 'no_decision' };
    }
    const rm = Number.isFinite(decision.riskMultiplier) ? decision.riskMultiplier : 1;
    return {
      riskMultiplier: Math.min(1, Math.max(0, Math.min(rm, maxRisk))),
      blockEntries: Boolean(decision.veto),
      reason: decision.reasoning,
    };
  }

  current() {
    return this.lastDecision || neutralDecision('no_analysis_yet');
  }

  /** Should new entries be blocked right now? */
  blocksEntries() {
    const d = this.lastDecision;
    return Boolean(d && !d.degraded && d.veto);
  }

  /** Risk multiplier to apply to new sizing. 1 when anything is off. */
  riskMultiplier() {
    return Jev.apply(this.lastDecision, { maxRiskMultiplier: this.ceiling }).riskMultiplier;
  }

  /** Is a module's output currently trusted? */
  trusts(moduleName) {
    return !this.registry.isQuarantined(moduleName);
  }

  /** One call for the dashboard: everything jev knows about itself. */
  health() {
    const reg = this.registry.health();
    return {
      enabled: this.enabled,
      ready: this.ready,
      provider: this.cfg.provider,
      model: this.cfg.model,
      apiKeyEnv: this.cfg.apiKeyEnv,
      hasKey: Boolean(this.apiKey()),
      allowVeto: Boolean(this.cfg.allowVeto),
      maxRiskMultiplier: this.ceiling,
      lastError: this.lastError,
      lastDecideAt: this.lastDecideAt || null,
      lastSuperviseAt: this.lastSuperviseAt || null,
      modules: reg,
      decision: this.lastDecision,
      mediation: this.lastMediation,
      supervision: this.lastSupervision,
      bus: this.bus.snapshot(5),
      consensus: this.consensus ? this.consensus.snapshot() : null,
      ledger: this.ledger ? this.ledger.snapshot() : null,
      alerts: this.alerts.slice(-10),
      stats: this.stats,
    };
  }

  /** Compact view for /status (the dashboard polls this every 5s). */
  snapshot() {
    const d = this.lastDecision;
    return {
      enabled: this.enabled,
      ready: this.ready,
      provider: this.cfg.provider,
      model: this.cfg.model,
      apiKeyEnv: this.cfg.apiKeyEnv,
      hasKey: Boolean(this.apiKey()),
      allowVeto: Boolean(this.cfg.allowVeto),
      maxRiskMultiplier: this.ceiling,
      lastError: this.lastError,
      lastDecideAt: this.lastDecideAt || null,
      lastSuperviseAt: this.lastSuperviseAt || null,
      decision: d
        ? {
            regime: d.regime, confidence: d.confidence, bias: d.bias,
            riskMultiplier: d.riskMultiplier, reasoning: d.reasoning,
            veto: d.veto, degraded: Boolean(d.degraded), source: d.source,
            latencyMs: d.latencyMs ?? null, at: d.at ?? null,
          }
        : null,
      mediation: this.lastMediation
        ? {
            resolution: this.lastMediation.resolution,
            riskMultiplier: this.lastMediation.riskMultiplier,
            winner: this.lastMediation.winner || null,
            reasoning: this.lastMediation.reasoning,
            degraded: Boolean(this.lastMediation.degraded),
            at: this.lastMediation.at ?? null,
          }
        : null,
      supervision: this.lastSupervision
        ? {
            overall: this.lastSupervision.overall,
            flagged: (this.lastSupervision.modules || []).filter((m) => m.action !== 'ok'),
            degraded: Boolean(this.lastSupervision.degraded),
            at: this.lastSupervision.at ?? null,
          }
        : null,
      modules: this.registry.snapshot(),
      consensus: this.consensus ? this.consensus.snapshot() : null,
      ledger: this.ledger ? this.ledger.snapshot() : null,
      alerts: this.alerts.slice(-5),
      ...this.stats,
    };
  }
}

module.exports = { Jev, DEFAULTS };
