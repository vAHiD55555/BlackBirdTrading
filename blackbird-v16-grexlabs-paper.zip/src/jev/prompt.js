'use strict';
/**
 * BlackBird — jev prompt builders.
 *
 * jev has three jobs and therefore three prompts. They are kept separate on
 * purpose: a single mega-prompt that asks a small local model to decide, judge
 * and audit at once produces mush. Each prompt asks for one JSON object with a
 * fixed shape, and each is built only from numbers the engine already computed.
 *
 * Determinism matters more than cleverness here. Two runs over the same context
 * must produce the same bytes, otherwise "the model changed its mind" can never
 * be audited.
 */

const MAX_SYMBOLS = 12;

function round(v, digits = 2) {
  if (!Number.isFinite(v)) return null;
  const f = 10 ** digits;
  return Math.round(v * f) / f;
}

function shortSymbol(s) {
  return String(s || '').replace(/USDT$/, '');
}

// ------------------------------------------------------------------ context
/**
 * Reduce the engine's live status into the small, stable object the model sees.
 * Anything the model does not need is dropped: it costs tokens and invites the
 * model to reason about fields it cannot verify.
 */
function buildContext(status, extra = {}) {
  const risk = status?.risk || {};
  const rotator = status?.rotator || {};
  const market = Array.isArray(status?.market) ? status.market : [];

  const symbols = market.slice(0, MAX_SYMBOLS).map((m) => ({
    symbol: shortSymbol(m.symbol),
    price: round(m.price, m.price > 100 ? 2 : 6),
    regime: m.regime || 'n/a',
    atrPct: round(m.atrPct, 2),
    volPercentile: round(m.volPercentile, 3),
    rsi: round(m.rsi, 1),
    spreadBps: round(m.spreadBps, 1),
    depthUsd: Number.isFinite(m.depthUsd) ? Math.round(m.depthUsd) : null,
  }));

  const positions = (rotator.positions || []).map((p) => ({
    symbol: shortSymbol(p.symbol),
    side: p.side,
    entry: round(p.entry, p.entry > 100 ? 2 : 6),
    stop: round(p.stop, p.stop > 100 ? 2 : 6),
    pnl: round(p.pnl, 2),
  }));

  return {
    asOf: status?.time || new Date().toISOString(),
    mode: status?.mode || 'paper',
    strategy: status?.strategy || 'rotator',
    equity: round(risk.equity, 2),
    equityMtm: round(risk.equityMtm, 2),
    drawdownPct: round(risk.drawdownPct, 2),
    dailyPnlPct: round(risk.dailyPnlPct, 2),
    halted: Boolean(risk.halted),
    haltReason: risk.haltReason || null,
    openPositions: positions.length,
    volScale: round(rotator.volScale, 2),
    ddScale: round(rotator.ddScale, 2),
    lastRebalanceAt: rotator.lastRebalanceAt || null,
    positions,
    market: symbols,
    ...extra,
  };
}

// ------------------------------------------------------------- 1. the brain
const DECIDE_SYSTEM = [
  'You are a conservative market-regime analyst embedded in an automated crypto futures system.',
  'You do not place orders. You do not size positions. You produce one structured opinion that a',
  'deterministic risk engine may use to REDUCE exposure or stand aside.',
  '',
  'Rules you must follow:',
  '1. Answer with a single JSON object and nothing else. No prose, no markdown fences.',
  '2. riskMultiplier is a fraction of the system\'s normal risk, between 0 and 1.',
  '   - 1.0 means "no opinion, carry on as configured".',
  '   - 0.5 means "halve exposure".',
  '   - 0.0 means "stand down completely".',
  '   You can never increase risk above 1.0. Asking for more is a schema violation.',
  '3. Set veto=true only when the evidence is strong that trading now is harmful',
  '   (e.g. toxic liquidity, contradictory signals across the whole book, an obvious data problem).',
  '   A veto is expensive: it stops new entries, it does not close positions.',
  '4. confidence is your own calibrated certainty in this read, 0..1. Be honest: 0.3 is a fine answer.',
  '5. reasoning must be one or two sentences citing the specific numbers you used.',
  '6. If the data looks stale, contradictory, or insufficient, say so and return a low confidence',
  '   with riskMultiplier 1.0. Do not invent a regime you cannot see.',
  '',
  'Required JSON shape:',
  '{"regime":"trend|muddy|toxic|calm","confidence":0.0,"bias":"long|short|neutral",',
  ' "riskMultiplier":1.0,"reasoning":"...","veto":false}',
].join('\n');

function buildDecideMessages(context, opts = {}) {
  const constraints = {
    maxRiskMultiplier: Number.isFinite(opts.maxRiskMultiplier) ? opts.maxRiskMultiplier : 1,
    vetoAllowed: opts.allowVeto !== false,
  };
  const user = [
    'Market snapshot (all values computed by the engine, not by you):',
    JSON.stringify(context, null, 2),
    '',
    'Operator constraints for this run:',
    JSON.stringify(constraints, null, 2),
    '',
    'Return the JSON object now.',
  ].join('\n');
  return [
    { role: 'system', content: DECIDE_SYSTEM },
    { role: 'user', content: user },
  ];
}

// ---------------------------------------------------------- 2. the mediator
const MEDIATE_SYSTEM = [
  'You are the arbiter between modules of an automated trading system that disagree.',
  'Two or more modules have produced conflicting opinions about the same decision.',
  'You must pick a resolution that is SAFE, not one that is profitable.',
  '',
  'Rules:',
  '1. Answer with a single JSON object and nothing else.',
  '2. resolution must be one of:',
  '   - "allow"    the action may proceed as proposed',
  '   - "reduce"   the action may proceed at reduced size (set riskMultiplier < 1)',
  '   - "block"    the action must not happen',
  '3. When a risk module objects, its objection wins unless it is clearly stale or malformed.',
  '   Risk modules are allowed to be wrong about opportunity; they are not allowed to be overruled',
  '   on safety by a strategy module that only sees upside.',
  '4. riskMultiplier is 0..1 and may only reduce. Never propose more than 1.',
  '5. reasoning must name the modules you weighed and the specific conflict you resolved.',
  '',
  'Required JSON shape:',
  '{"resolution":"allow|reduce|block","riskMultiplier":1.0,"reasoning":"...","winner":"module_name"}',
].join('\n');

/**
 * @param {object} req
 * @param {string} req.topic      what is being decided, e.g. "entry:BTCUSDT"
 * @param {Array}  req.opinions   [{ module, stance: 'allow'|'block'|'reduce', reason, weight }]
 * @param {object} [req.context]  market context
 */
function buildMediateMessages(req = {}, opts = {}) {
  const payload = {
    topic: req.topic || 'unspecified',
    opinions: (req.opinions || []).map((o) => ({
      module: o.module,
      stance: o.stance,
      reason: o.reason || '',
      weight: Number.isFinite(o.weight) ? o.weight : 1,
    })),
    context: req.context || null,
    constraints: {
      maxRiskMultiplier: Number.isFinite(opts.maxRiskMultiplier) ? opts.maxRiskMultiplier : 1,
    },
  };
  return [
    { role: 'system', content: MEDIATE_SYSTEM },
    { role: 'user', content: `Conflict to resolve:\n${JSON.stringify(payload, null, 2)}\n\nReturn the JSON object now.` },
  ];
}

// --------------------------------------------------------- 3. the supervisor
const SUPERVISE_SYSTEM = [
  'You are the health supervisor of an automated trading system. You watch modules, not markets.',
  'You receive each module\'s declared state, its last error, and a few counters.',
  '',
  'Rules:',
  '1. Answer with a single JSON object and nothing else.',
  '2. For each module you may recommend one action:',
  '   - "ok"        nothing to do',
  '   - "watch"     note it, keep running',
  '   - "quarantine" the module looks broken; the system should stop trusting its output',
  '3. Quarantine only on evidence: a repeated error, a stale heartbeat, or counters that cannot be',
  '   true (e.g. more closes than opens). Never quarantine because a module is merely quiet.',
  '4. Do not invent modules. Only report on the names you were given.',
  '5. reasoning must be one sentence per module you flag, and empty for modules you leave alone.',
  '',
  'Required JSON shape:',
  '{"modules":[{"name":"...","action":"ok|watch|quarantine","reason":"..."}],',
  ' "overall":"healthy|degraded|critical","reasoning":"..."}',
].join('\n');

function buildSuperviseMessages(snapshot = {}, opts = {}) {
  const payload = {
    asOf: snapshot.asOf || new Date().toISOString(),
    modules: (snapshot.modules || []).map((m) => ({
      name: m.name,
      version: m.version || null,
      status: m.status || 'unknown',
      lastError: m.lastError || null,
      counters: m.counters || null,
      staleMs: Number.isFinite(m.staleMs) ? m.staleMs : null,
    })),
    constraints: {
      quarantineAllowed: opts.quarantineAllowed !== false,
    },
  };
  return [
    { role: 'system', content: SUPERVISE_SYSTEM },
    { role: 'user', content: `Module snapshot:\n${JSON.stringify(payload, null, 2)}\n\nReturn the JSON object now.` },
  ];
}

/** A short, human-readable one-liner for logs and the dashboard. */
function summarise(decision) {
  if (!decision) return 'no analysis yet';
  const bits = [
    `regime=${decision.regime}`,
    `conf=${Number(decision.confidence || 0).toFixed(2)}`,
    `bias=${decision.bias}`,
    `risk×${Number(decision.riskMultiplier).toFixed(2)}`,
  ];
  if (decision.veto) bits.push('VETO');
  if (decision.degraded) bits.push('(fallback)');
  return bits.join(' ');
}

module.exports = {
  buildContext,
  buildDecideMessages,
  buildMediateMessages,
  buildSuperviseMessages,
  summarise,
  DECIDE_SYSTEM,
  MEDIATE_SYSTEM,
  SUPERVISE_SYSTEM,
  MAX_SYMBOLS,
};
