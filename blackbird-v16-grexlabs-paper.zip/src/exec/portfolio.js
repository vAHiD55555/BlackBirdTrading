'use strict';
/**
 * BlackBird — portfolio (position book + realised P&L).
 * Supports both directions: spot longs and futures shorts.
 *
 * Convention: pos.dir = +1 for long, -1 for short. Every P&L expression is
 * multiplied by dir, so there is exactly one formula to audit.
 */
const { uuid, now } = require('../core/util');

const round2 = (x) => Math.round(x * 100) / 100;

class Position {
  constructor({
    symbol, side, qty, entry, fee, notional, strategy, tp, sl,
    timeStopAt, proposalId, decisionId, context, rationale, riskUnit, openedAt,
  }) {
    this.id = uuid('pos');
    this.symbol = symbol;
    this.side = side === 'short' ? 'short' : 'long';
    this.dir = this.side === 'short' ? -1 : 1;
    this.qty = qty;
    this.entry = entry;
    this.entryFee = fee;
    this.notional = notional;
    this.strategy = strategy;
    this.tp = tp;
    this.sl = sl;
    this.initialSl = sl;
    this.initialTp = tp;
    this.riskUnit = riskUnit || Math.max(1e-12, (entry - sl) * this.dir);
    // The open time must come from the caller's clock when one is supplied.
    // A historical replay closes positions with the bar's own timestamp; if the
    // open were stamped with the wall clock, durationMs came out negative.
    this.openedAt = Number.isFinite(Number(openedAt)) && Number(openedAt) > 0 ? Number(openedAt) : now();
    this.timeStopAt = timeStopAt;
    // never leave `undefined` on a trade: it vanishes through JSON and would
    // make the journal hash unverifiable after a reload
    this.proposalId = proposalId ?? null;
    this.decisionId = decisionId ?? null;
    this.context = context ?? null;
    this.rationale = rationale ?? null;
    this.mfePrice = entry; // best price seen
    this.maePrice = entry; // worst price seen
    this.last = entry;
    this.fundingPaid = 0;
    this.lastFundingAt = 0;
  }

  mark(price) {
    this.last = price;
    if (this.dir > 0) {
      if (price > this.mfePrice) this.mfePrice = price;
      if (price < this.maePrice) this.maePrice = price;
    } else {
      if (price < this.mfePrice) this.mfePrice = price;
      if (price > this.maePrice) this.maePrice = price;
    }
  }

  unrealisedPnl(price = this.last) {
    return (price - this.entry) * this.qty * this.dir;
  }

  /** Favorable excursion in dollars (always >= 0 by construction). */
  get mfe() {
    return Math.max(0, (this.mfePrice - this.entry) * this.qty * this.dir);
  }
  /** Adverse excursion in dollars (always <= 0). */
  get mae() {
    return Math.min(0, (this.maePrice - this.entry) * this.qty * this.dir);
  }
}

class Portfolio {
  constructor(log) {
    this.log = log;
    this.positions = new Map();
    this.closed = [];
    this.maxClosed = 2000;
  }

  open(pos) {
    this.positions.set(pos.symbol, pos);
    return pos;
  }
  get(symbol) {
    return this.positions.get(symbol);
  }
  hasPosition(symbol) {
    return this.positions.has(symbol);
  }
  openPositions() {
    return [...this.positions.values()];
  }
  ids() {
    return [...this.positions.keys()];
  }

  close(symbol, { price, fee, feeKind, reason, ts }) {
    const pos = this.positions.get(symbol);
    if (!pos) return null;
    this.positions.delete(symbol);
    const exitTs = ts || now();
    const proceeds = price * pos.qty;
    const gross = (price - pos.entry) * pos.qty * pos.dir;
    const funding = pos.fundingPaid || 0;
    const fees = (pos.entryFee || 0) + (fee || 0) + Math.abs(funding);
    const pnl = gross - (fee || 0) - funding - (pos.entryFee || 0);
    const trade = {
      id: pos.id,
      symbol: pos.symbol,
      side: pos.side,
      dir: pos.dir,
      strategy: pos.strategy,
      entry: { price: pos.entry, qty: pos.qty, notional: pos.notional, fee: pos.entryFee, ts: pos.openedAt },
      exit: { price, qty: pos.qty, notional: proceeds, fee: fee || 0, feeKind: feeKind || 'taker', ts: exitTs, reason },
      grossPnl: round2(gross),
      funding: round2(funding),
      fees: round2(fees),
      pnl: round2(pnl),
      pnlPct: round2(pos.notional ? (pnl / pos.notional) * 100 : 0),
      pnlBps: round2(pos.notional ? (pnl / pos.notional) * 10000 : 0),
      mfe: round2(pos.mfe),
      mae: round2(pos.mae),
      durationMs: exitTs - pos.openedAt,
      proposalId: pos.proposalId,
      decisionId: pos.decisionId,
      context: pos.context,
      rationale: pos.rationale,
      win: pnl > 0,
    };
    this.closed.push(trade);
    if (this.closed.length > this.maxClosed) this.closed.shift();
    return trade;
  }

  mark(symbol, price) {
    const p = this.positions.get(symbol);
    if (p) p.mark(price);
  }

  exposureBySymbol(symbol) {
    const p = this.positions.get(symbol);
    return p ? p.notional : 0;
  }
  totalExposure() {
    let s = 0;
    for (const p of this.positions.values()) s += p.notional;
    return s;
  }
  /** Net directional exposure: +long, -short. Used by the risk officer. */
  netExposure() {
    let s = 0;
    for (const p of this.positions.values()) s += p.notional * p.dir;
    return s;
  }
  unrealisedTotal() {
    let s = 0;
    for (const p of this.positions.values()) s += p.unrealisedPnl();
    return s;
  }
  exposureBySymbolMap() {
    const out = {};
    for (const p of this.positions.values()) out[p.symbol] = round2(p.notional);
    return out;
  }
}

module.exports = { Portfolio, Position };
