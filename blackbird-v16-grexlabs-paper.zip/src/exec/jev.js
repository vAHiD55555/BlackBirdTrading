'use strict';
/**
 * JEV — Just-in-Time Execution Vector.
 *
 * The measured bottleneck in retail scalping is not the signal, it is the path
 * from "decision" to "order actually at the venue": JSON building, tick-size
 * rounding, safety checks, HTTP setup. JEV removes everything that can be done
 * *before* the signal from the hot path:
 *
 *   boot time : resolve symbol metadata, quantise steps, budget the latency
 *   hot path  : one multiply, one quantise, one submit -- and a hard deadline
 *
 * If the deadline (signal time + cfg.jevExec.maxLatencyMs) is already blown, the
 * entry is aborted instead of being sent at a stale price. Losing a trade is
 * cheaper than paying for a price that no longer exists.
 */
const { now } = require('../core/util');

const PRICE_STEP = {
  BTCUSDT: 0.1,
  ETHUSDT: 0.01,
  SOLUSDT: 0.001,
  XRPUSDT: 0.0001,
  BNBUSDT: 0.01,
  DOGEUSDT: 0.00001,
  ADAUSDT: 0.0001,
  AVAXUSDT: 0.001,
  LINKUSDT: 0.001,
  TONUSDT: 0.001,
};

function guessPriceStep(price) {
  if (price >= 10000) return 0.1;
  if (price >= 1000) return 0.01;
  if (price >= 100) return 0.01;
  if (price >= 10) return 0.001;
  if (price >= 1) return 0.0001;
  if (price >= 0.1) return 0.00001;
  return 0.000001;
}

function guessQtyStep(price) {
  // keep ~$0.10 granularity on the notional
  return Math.max(1e-8, 0.1 / price);
}

class Jev {
  constructor(cfg, log) {
    this.cfg = cfg;
    this.log = log;
    this.templates = new Map();
    this.latencies = [];
    this.maxLatencies = 500;
    this.aborted = 0;
    this.sent = 0;
  }

  /** Warm the cache: called at boot for every configured symbol. */
  prewarm(symbols, prices = {}) {
    for (const sym of symbols) {
      const px = prices[sym] || 1;
      const priceStep = PRICE_STEP[sym] || guessPriceStep(px);
      this.templates.set(sym, {
        symbol: sym,
        priceStep,
        qtyStep: guessQtyStep(px),
        minQty: Math.max(1e-8, 1 / px), // ~1 USDT minimum
        minNotional: 5,
        priceDecimals: Math.max(0, -Math.floor(Math.log10(priceStep))),
        qtyDecimals: 8,
      });
    }
    this.log.info('JEV prewarmed', { symbols: symbols.length });
  }

  template(symbol) {
    let t = this.templates.get(symbol);
    if (!t) {
      t = {
        symbol,
        priceStep: 0.0001,
        qtyStep: 1e-6,
        minQty: 1e-6,
        minNotional: 5,
        priceDecimals: 4,
        qtyDecimals: 8,
      };
      this.templates.set(symbol, t);
    }
    return t;
  }

  quantisePrice(symbol, price) {
    const t = this.template(symbol);
    return Number((Math.round(price / t.priceStep) * t.priceStep).toFixed(t.priceDecimals));
  }

  quantiseQty(symbol, qty) {
    const t = this.template(symbol);
    return Number((Math.floor(qty / t.qtyStep) * t.qtyStep).toFixed(t.qtyDecimals));
  }

  /**
   * Build an execution vector. Deliberately synchronous and allocation-small.
   * @returns {{ok:boolean, order?:object, reason?:string, latencyMs:number}}
   */
  build({ symbol, side, type, qty, price, signalTs, ttlMs = 8000, tag }) {
    const t0 = now();
    const deadline = (signalTs || t0) + this.cfg.jevExec.maxLatencyMs;
    if (this.cfg.jevExec.enabled && t0 > deadline) {
      this.aborted++;
      return {
        ok: false,
        reason: `latency_budget_exceeded(${t0 - (signalTs || t0)}ms>${this.cfg.jevExec.maxLatencyMs}ms)`,
        latencyMs: t0 - t0,
      };
    }
    const tmpl = this.template(symbol);
    const q = this.quantiseQty(symbol, qty);
    if (!(q > 0)) return { ok: false, reason: 'qty_below_step', latencyMs: now() - t0 };
    if (q * (price || 0) < tmpl.minNotional) {
      return { ok: false, reason: `notional_below_min(${q * (price || 0)})`, latencyMs: now() - t0 };
    }
    const order = {
      symbol,
      side,
      type: type || 'limit',
      qty: q,
      price: type === 'market' ? null : this.quantisePrice(symbol, price),
      ttlMs,
      tag: tag || `jev_${symbol}_${t0}`,
      createdAt: t0,
    };
    this.sent++;
    return { ok: true, order, latencyMs: now() - t0 };
  }

  /** Record decision -> submit latency; this feeds the latency auditor. */
  record(latencyMs, meta = {}) {
    this.latencies.push({ ts: now(), ms: latencyMs, ...meta });
    if (this.latencies.length > this.maxLatencies) this.latencies.shift();
  }

  percentile(p) {
    if (!this.latencies.length) return 0;
    const arr = this.latencies.map((l) => l.ms).sort((a, b) => a - b);
    const idx = Math.min(arr.length - 1, Math.floor((p / 100) * arr.length));
    return arr[idx];
  }

  stats() {
    return {
      enabled: this.cfg.jevExec.enabled,
      sent: this.sent,
      aborted: this.aborted,
      p50: this.percentile(50),
      p95: this.percentile(95),
      p99: this.percentile(99),
      n: this.latencies.length,
      budgetMs: this.cfg.jevExec.maxLatencyMs,
    };
  }
}

module.exports = { Jev };
