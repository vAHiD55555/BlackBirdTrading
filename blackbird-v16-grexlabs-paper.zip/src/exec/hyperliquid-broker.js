'use strict';
/**
 * BlackBird — Hyperliquid broker.
 *
 * Implements EXACTLY the interface PaperBroker exposes, so the trader, the
 * portfolio, the risk module, the lawyer and the ledger cannot tell the two
 * apart:
 *
 *   submit({symbol, side, qty, type, price?, ttlMs?, tag?})
 *       -> {status:'filled'|'open'|'rejected', price?, qty?, notional?, fee?, reason?}
 *   onTick(ticker, feed) -> fills[]
 *   expire(nowTs) -> expired[]
 *   cancel(orderId) / cancelAll(symbol)
 *   stats()
 *
 * THREE MODES
 * -----------
 *   paper   (default) — fills are simulated against the REAL Hyperliquid book.
 *                       No key, no network write, no money. This is what the
 *                       tests and the demo run use.
 *   dry-run           — orders are signed and built but never POSTed. Proves
 *                       the signing path works without touching the venue.
 *   live              — orders are POSTed. Requires an API wallet key AND
 *                       BB_I_UNDERSTAND_REAL_MONEY=YES. Refuses otherwise.
 *
 * The live path is deliberately hard to reach: this build has never placed a
 * real order, and the docs say an incorrect signature fails with a message
 * that does not explain why. So `live` is gated, and `dry-run` exists to make
 * the gap visible instead of pretending it is closed.
 *
 * API WALLET
 * ----------
 * Hyperliquid lets a master account approve an "API wallet" (agent wallet) that
 * can sign orders but CANNOT withdraw. That is the only key this adapter will
 * accept: `HL_API_WALLET_KEY`. The master key is never read.
 */

const { now, uuid } = require('../core/util');
const { walkBook } = require('../data/exchanges');
const {
  HyperliquidPublic, HyperliquidHttp, toCoin, toSymbol,
  roundPrice, roundSize, lotSize,
} = require('../data/hyperliquid');
const { signL1Action, addressFromPrivate } = require('./hl-sign');

const DEFAULTS = {
  mode: 'paper',            // paper | dry-run | live
  apiWalletKeyEnv: 'HL_API_WALLET_KEY',
  accountAddressEnv: 'HL_ACCOUNT_ADDRESS',
  vaultAddressEnv: 'HL_VAULT_ADDRESS',
  slippageBps: 30,          // market orders: how far through the book to allow
  tif: 'Gtc',               // Gtc | Ioc | Alo
  reduceOnly: false,
  maxNotionalUsd: 0,        // 0 = no extra cap (risk module still applies)
};

class HyperliquidBroker {
  constructor({ cfg, log, getBook, getFeed, publicApi, clock } = {}) {
    this.cfg = cfg || {};
    this.hl = { ...DEFAULTS, ...(this.cfg.hyperliquid || {}) };
    this.log = log || { info() {}, warn() {}, error() {}, debug() {} };
    this.getBook = getBook || (() => null);
    this.getFeed = getFeed || (() => null);
    this.clock = clock || (() => Date.now());

    this.pub = publicApi || new HyperliquidPublic({ log: this.log });
    this.http = this.pub.http || new HyperliquidHttp();

    this.mode = this.hl.mode;
    this.openOrders = new Map();
    this.fills = [];
    this.rejections = [];
    this._nonce = 0;
    this._assetCache = new Map();

    this.stats_ = {
      submitted: 0, filled: 0, rejected: 0, cancelled: 0, expired: 0,
      signed: 0, posted: 0, lastError: null,
    };

    this._check();
  }

  // ------------------------------------------------------------------ gating
  _check() {
    this.blockers = [];
    this.apiWallet = null;
    this.accountAddress = null;

    if (this.mode === 'paper') {
      this.ready = true;
      return;
    }

    const keyEnv = this.hl.apiWalletKeyEnv;
    const key = process.env[keyEnv];
    if (!key) {
      this.blockers.push(`${keyEnv} is not set (an API wallet key is required)`);
    } else {
      try {
        this.apiWallet = addressFromPrivate(key);
      } catch (e) {
        this.blockers.push(`${keyEnv} is not a valid secp256k1 private key: ${e.message}`);
      }
    }

    const acct = process.env[this.hl.accountAddressEnv];
    if (!acct) {
      // The docs are explicit: querying with the agent wallet's address returns
      // an empty result. The master/sub-account address is required.
      this.blockers.push(`${this.hl.accountAddressEnv} is not set (the master account address, not the API wallet)`);
    } else if (!/^0x[0-9a-fA-F]{40}$/.test(acct)) {
      this.blockers.push(`${this.hl.accountAddressEnv} is not a 0x-prefixed 20-byte address`);
    } else {
      this.accountAddress = acct.toLowerCase();
    }

    if (this.mode === 'live') {
      if (process.env.BB_I_UNDERSTAND_REAL_MONEY !== 'YES') {
        this.blockers.push('live mode requires BB_I_UNDERSTAND_REAL_MONEY=YES');
      }
      if (!(Number(this.hl.maxNotionalUsd) > 0)) {
        this.blockers.push('live mode requires hyperliquid.maxNotionalUsd > 0');
      }
    }

    this.ready = this.blockers.length === 0;
    if (!this.ready) {
      this.log.warn(`hyperliquid broker (${this.mode}) is not ready: ${this.blockers.join(' | ')}`);
    }
  }

  get isPaper() { return this.mode === 'paper'; }

  // ------------------------------------------------------------- quantisation
  async _asset(symbol) {
    const coin = toCoin(symbol);
    if (this._assetCache.has(coin)) return this._assetCache.get(coin);
    const a = await this.pub.asset(coin);
    if (a) this._assetCache.set(coin, a);
    return a;
  }

  /**
   * Quantise a price and size to what the venue accepts.
   * Exposed so tests can assert the rounding without a network call.
   */
  quantise(symbol, price, qty, szDecimals) {
    const px = roundPrice(price, szDecimals);
    const sz = roundSize(qty, szDecimals);
    return { price: px, qty: sz, lot: lotSize(szDecimals) };
  }

  // ------------------------------------------------------------------- submit
  async submit(order) {
    const o = { ...order, orderId: order.orderId || uuid('hl'), submittedAt: this.clock() };
    this.stats_.submitted++;

    try {
      const asset = await this._asset(o.symbol);
      if (!asset) {
        return this._reject(o, 'unknown_asset', `hyperliquid does not list ${toCoin(o.symbol)}`);
      }

      const szDecimals = Number(asset.szDecimals) || 0;
      const qty = roundSize(o.qty, szDecimals);
      if (!Number.isFinite(qty)) {
        return this._reject(o, 'qty_below_lot', `qty ${o.qty} rounds to zero at szDecimals=${szDecimals}`);
      }

      if (o.type === 'market') {
        return await this._market(o, asset, qty);
      }
      return await this._limit(o, asset, qty);
    } catch (e) {
      this.stats_.lastError = e.message;
      this.log.warn(`hyperliquid submit failed: ${e.message}`);
      return this._reject(o, 'venue_error', e.message);
    }
  }

  _reject(o, reason, detail) {
    this.stats_.rejected++;
    const r = { status: 'rejected', orderId: o.orderId, symbol: o.symbol, side: o.side, reason, detail, ts: this.clock() };
    this.rejections.push(r);
    if (this.rejections.length > 200) this.rejections.shift();
    return r;
  }

  /**
   * Market order.
   *
   * In paper mode this walks the real book — the same honest simulation the
   * Binance paper broker does, so P&L is comparable across venues.
   *
   * In dry-run/live it becomes an IOC limit at a price far enough through the
   * book to fill immediately, which is how Hyperliquid expresses a market
   * order (there is no separate market order type on the wire).
   */
  async _market(o, asset, qty) {
    const feed = this.getFeed(o.symbol);
    const book = this.getBook(o.symbol);

    if (this.isPaper) {
      if (!book || (feed && feed.isStale)) return this._reject(o, 'stale_book', 'no fresh book');
      const levels = o.side === 'buy' ? feed?.depth?.asks : feed?.depth?.bids;
      let fillPrice;
      let filled = qty;
      if (levels && levels.length) {
        const walked = walkBook(levels, qty);
        if (!walked.complete) return this._reject(o, 'insufficient_depth', `book holds ${walked.filled} of ${qty}`);
        fillPrice = walked.avgPrice;
        filled = walked.filled;
      } else {
        const slip = 1 + (o.side === 'buy' ? 1 : -1) * (this.cfg.fees?.slippageBpsPer1kNotional || 0.6) * 1e-4;
        fillPrice = (o.side === 'buy' ? book.ask : book.bid) * slip;
      }
      const notional = fillPrice * filled;
      const ref = o.side === 'buy' ? book.ask : book.bid;
      const fill = {
        status: 'filled',
        orderId: o.orderId,
        symbol: o.symbol,
        side: o.side,
        qty: filled,
        price: fillPrice,
        notional,
        fee: (notional * (this.cfg.fees?.takerBps || 5)) / 10000,
        feeKind: 'taker',
        slippageBps: ref ? ((fillPrice - ref) / ref) * 10000 : 0,
        tag: o.tag,
        venue: 'hyperliquid',
        ts: this.clock(),
      };
      this.fills.push(fill);
      this.stats_.filled++;
      return fill;
    }

    // dry-run / live: an aggressive IOC limit
    const ref = o.side === 'buy' ? book?.ask : book?.bid;
    if (!Number.isFinite(ref)) return this._reject(o, 'no_reference_price', 'cannot price a market order without a book');
    const slip = (Number(this.hl.slippageBps) || 30) / 10000;
    const px = roundPrice(o.side === 'buy' ? ref * (1 + slip) : ref * (1 - slip), asset.szDecimals);
    return this._send(o, asset, qty, px, 'Ioc');
  }

  /** Limit order: rests in paper mode, is POSTed in dry-run/live. */
  async _limit(o, asset, qty) {
    const px = roundPrice(o.price, asset.szDecimals);
    if (!Number.isFinite(px)) return this._reject(o, 'invalid_price', `price ${o.price} is not representable`);

    if (this.isPaper) {
      this.openOrders.set(o.orderId, { ...o, qty, price: px, remaining: qty, status: 'open' });
      return { status: 'open', orderId: o.orderId, price: px, qty, ts: this.clock() };
    }
    return this._send(o, asset, qty, px, this.hl.tif || 'Gtc');
  }

  /**
   * Build, sign and (unless dry-run) POST an order action.
   *
   * Field order matters for msgpack, so the action object is built in the
   * documented order and never sorted.
   */
  async _send(o, asset, qty, px, tif) {
    if (!this.ready) {
      return this._reject(o, 'not_ready', this.blockers.join(' | '));
    }

    const nonce = this._nextNonce();
    const isBuy = o.side === 'buy';

    const orderWire = {
      a: asset.index,                       // asset id
      b: isBuy,                             // is buy
      p: String(px),                        // price as a string, trailing zeros trimmed
      s: String(qty),                       // size as a string
      r: Boolean(this.hl.reduceOnly),       // reduce only
      t: { limit: { tif } },                // order type
    };
    if (o.cloid) orderWire.c = o.cloid;

    const action = {
      type: 'order',
      orders: [orderWire],
      grouping: 'na',
    };

    let signature;
    try {
      signature = signL1Action(action, nonce, process.env[this.hl.apiWalletKeyEnv], process.env[this.hl.vaultAddressEnv] || null);
      this.stats_.signed++;
    } catch (e) {
      return this._reject(o, 'signing_failed', e.message);
    }

    const payload = { action, nonce, signature, vaultAddress: process.env[this.hl.vaultAddressEnv] || null };

    if (this.mode === 'dry-run') {
      // Prove the path without touching the venue.
      this.log.info('hyperliquid dry-run: order built and signed, not sent', {
        symbol: o.symbol, side: o.side, qty, price: px, tif,
      });
      return {
        status: 'open',
        orderId: o.orderId,
        symbol: o.symbol,
        side: o.side,
        qty,
        price: px,
        dryRun: true,
        signed: true,
        signer: this.apiWallet,
        ts: this.clock(),
      };
    }

    // live
    try {
      const res = await this.http.exchange(payload, 1);
      this.stats_.posted++;
      const statuses = res?.response?.data?.statuses || [];
      const st = statuses[0] || {};

      if (st.error) return this._reject(o, 'venue_rejected', st.error);

      if (st.resting) {
        this.openOrders.set(o.orderId, { ...o, qty, price: px, remaining: qty, status: 'open', oid: st.resting.oid });
        return { status: 'open', orderId: o.orderId, oid: st.resting.oid, price: px, qty, ts: this.clock() };
      }
      if (st.filled) {
        const notional = px * qty;
        const fill = {
          status: 'filled', orderId: o.orderId, oid: st.filled.oid, symbol: o.symbol, side: o.side,
          qty, price: px, notional,
          fee: (notional * (this.cfg.fees?.takerBps || 5)) / 10000,
          feeKind: tif === 'Alo' ? 'maker' : 'taker',
          slippageBps: 0, tag: o.tag, venue: 'hyperliquid', ts: this.clock(),
        };
        this.fills.push(fill);
        this.stats_.filled++;
        return fill;
      }
      return this._reject(o, 'unknown_status', JSON.stringify(st).slice(0, 200));
    } catch (e) {
      this.stats_.lastError = e.message;
      return this._reject(o, 'venue_error', e.message);
    }
  }

  /** Monotonic nonce. Hyperliquid rejects a nonce that is not increasing. */
  _nextNonce() {
    const t = this.clock();
    this._nonce = Math.max(this._nonce + 1, t);
    return this._nonce;
  }

  // -------------------------------------------------------------------- ticks
  /** Fill resting limits when the market trades through them. */
  onTick(ticker, feed) {
    const out = [];
    for (const o of [...this.openOrders.values()]) {
      if (o.symbol !== ticker.symbol) continue;
      const px = o.price;
      const hit = o.side === 'buy' ? ticker.bid <= px : ticker.ask >= px;
      if (!hit) continue;

      const crossing = o.side === 'buy' ? ticker.ask <= px : ticker.bid >= px;
      const fillPrice = crossing ? (o.side === 'buy' ? ticker.ask : ticker.bid) : px;
      const notional = fillPrice * o.remaining;
      const fill = {
        status: 'filled',
        orderId: o.orderId,
        symbol: o.symbol,
        side: o.side,
        qty: o.remaining,
        price: fillPrice,
        notional,
        fee: (notional * (crossing ? (this.cfg.fees?.takerBps || 5) : (this.cfg.fees?.makerBps || 2))) / 10000,
        feeKind: crossing ? 'taker' : 'maker',
        slippageBps: 0,
        tag: o.tag,
        venue: 'hyperliquid',
        ts: this.clock(),
      };
      this.openOrders.delete(o.orderId);
      this.fills.push(fill);
      this.stats_.filled++;
      out.push(fill);
    }
    return out;
  }

  expire(nowTs = this.clock()) {
    const expired = [];
    for (const o of [...this.openOrders.values()]) {
      if (!o.ttlMs) continue;
      if (nowTs - o.submittedAt >= o.ttlMs) {
        this.openOrders.delete(o.orderId);
        this.stats_.expired++;
        expired.push({ orderId: o.orderId, symbol: o.symbol, side: o.side, reason: 'expired' });
      }
    }
    return expired;
  }

  cancel(orderId) {
    const o = this.openOrders.get(orderId);
    if (!o) return false;
    this.openOrders.delete(orderId);
    this.stats_.cancelled++;
    return true;
  }

  cancelAll(symbol) {
    for (const [id, o] of [...this.openOrders]) {
      if (!symbol || o.symbol === symbol) {
        this.openOrders.delete(id);
        this.stats_.cancelled++;
      }
    }
  }

  // ------------------------------------------------------------------ account
  /**
   * Read the account's perp state (balance + open positions).
   *
   * Requires the MASTER account address, not the API wallet — the docs call
   * this out as the most common mistake.
   */
  async account() {
    if (!this.accountAddress) {
      return { ok: false, reason: 'no_account_address', blockers: this.blockers };
    }
    try {
      const d = await this.http.info({ type: 'clearinghouseState', user: this.accountAddress }, 2);
      const ms = d?.marginSummary || {};
      const positions = (d?.assetPositions || []).map((p) => {
        const pos = p.position || {};
        return {
          symbol: toSymbol(pos.coin),
          coin: pos.coin,
          side: Number(pos.szi) >= 0 ? 'long' : 'short',
          qty: Math.abs(Number(pos.szi) || 0),
          entry: Number(pos.entryPx) || null,
          notional: Math.abs(Number(pos.positionValue) || 0),
          unrealised: Number(pos.unrealizedPnl) || 0,
          leverage: Number(pos.leverage?.value) || null,
        };
      });
      return {
        ok: true,
        equity: Number(ms.accountValue) || 0,
        marginUsed: Number(ms.totalMarginUsed) || 0,
        withdrawable: Number(d?.withdrawable) || 0,
        positions,
        raw: undefined,
      };
    } catch (e) {
      return { ok: false, reason: 'venue_error', error: e.message };
    }
  }

  /** Open orders from the venue (live only). */
  async openOrdersRemote() {
    if (!this.accountAddress) return { ok: false, reason: 'no_account_address' };
    try {
      const d = await this.http.info({ type: 'openOrders', user: this.accountAddress }, 20);
      return { ok: true, orders: Array.isArray(d) ? d : [] };
    } catch (e) {
      return { ok: false, reason: 'venue_error', error: e.message };
    }
  }

  stats() {
    return {
      mode: this.mode,
      venue: 'hyperliquid',
      ready: this.ready,
      blockers: this.blockers,
      signer: this.apiWallet,
      account: this.accountAddress,
      openOrders: this.openOrders.size,
      fills: this.fills.length,
      ...this.stats_,
    };
  }
}

module.exports = { HyperliquidBroker, DEFAULTS };
