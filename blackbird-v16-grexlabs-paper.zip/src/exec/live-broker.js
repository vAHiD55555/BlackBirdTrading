'use strict';
/**
 * BlackBird — live broker (scaffold, deliberately NOT enabled).
 *
 * Everything the rest of the system needs from a broker already goes through
 * the small interface used by PaperBroker:
 *
 *     submit({ symbol, side, qty, type: 'market'|'limit', price?, ttlMs?, tag? })
 *         -> { status: 'filled'|'open'|'rejected', price?, qty?, notional?, fee?, reason? }
 *     onTick(ticker, feed) -> fills[]        (limit orders that got hit)
 *     expire(nowTs) -> expired[]
 *     cancel(orderId) / cancelAll(symbol)
 *
 * So going live is *not* a rewrite: it is one adapter that implements the same
 * methods on a real exchange. This file is that adapter's skeleton, and it
 * refuses to trade until every box below is ticked in config.json.
 *
 * WHY IT IS DISABLED
 * ------------------
 * A paper fill is simulated; a live fill moves real money, pays real funding,
 * can be partial, can be rejected, can arrive late. Before this class is
 * switched on we need, at minimum:
 *
 *   1. exchange credentials with TRADE permission only (never withdraw)
 *   2. a clock-skew and API-error path that cannot wedge the engine
 *   3. order state reconciliation after a restart (positions vs exchange)
 *   4. a small-capital canary run measured against the paper book
 *   5. funding, commission tiers and minimum-notional checks per venue
 */
const { now } = require('../core/util');

class LiveBroker {
  constructor({ cfg, log }) {
    this.cfg = cfg;
    this.log = log;
    this.mode = 'live';
    this.ready = false;
    this.blockers = [];
    this._check();
  }

  _check() {
    const c = this.cfg;
    if (!c.keys || !c.keys.apiKey || !c.keys.apiSecret) this.blockers.push('missing API key/secret');
    if (!c.live || !c.live.iUnderstandRealMoney) this.blockers.push('config.live.iUnderstandRealMoney is not true');
    if (!c.live || !c.live.maxNotionalUsd) this.blockers.push('config.live.maxNotionalUsd is not set');
    this.ready = this.blockers.length === 0;
  }

  _refuse() {
    const msg = `live broker is not implemented in this build; blockers: ${this.blockers.join(' | ')}`;
    this.log.error(msg);
    throw new Error(msg);
  }

  submit() { return this._refuse(); }
  onTick() { return this._refuse(); }
  expire() { return []; }
  cancel() { return this._refuse(); }
  cancelAll() { return this._refuse(); }

  stats() {
    return { mode: 'live', ready: this.ready, blockers: this.blockers, ts: now() };
  }
}

module.exports = { LiveBroker };
