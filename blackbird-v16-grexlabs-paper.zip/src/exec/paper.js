'use strict';
/**
 * BlackBird — paper broker.
 *
 * Simulates fills against the *real* live order book so that the paper P&L is
 * an honest proxy, not a frictionless fantasy:
 *
 *   market order  -> walks the book, pays taker fee + impact
 *   limit order   -> rests until the market trades through the price (maker fee)
 *   latency       -> cfg.fees.latencyMs is applied before the fill is priced
 *
 * The broker holds no position state; it only executes. Portfolio accounting is
 * the trader's job (and the witness re-derives it independently).
 */
const { now, uuid } = require('../core/util');
const { walkBook } = require('../data/exchanges');

class PaperBroker {
  constructor({ cfg, log, getBook, getFeed }) {
    this.cfg = cfg;
    this.log = log;
    this.getBook = getBook;
    this.getFeed = getFeed;
    this.openOrders = new Map();
    this.fills = [];
    this.mode = 'paper';
  }

  _fee(notional) {
    return (notional * this.cfg.fees.takerBps) / 10000;
  }
  _makerFee(notional) {
    return (notional * this.cfg.fees.makerBps) / 10000;
  }

  _slippage(notional) {
    return (notional / 1000) * this.cfg.fees.slippageBpsPer1kNotional * 1e-4;
  }

  /** Immediate execution (market). */
  _market(order) {
    const feed = this.getFeed(order.symbol);
    const book = this.getBook(order.symbol);
    if (!book || feed.isStale) {
      return { status: 'rejected', reason: 'stale_book' };
    }
    const side = order.side;
    const levels = side === 'buy'
      ? feed.depth?.asks
      : feed.depth?.bids;
    let fillPrice;
    let filled = order.qty;
    if (levels && levels.length) {
      const walked = walkBook(levels, order.qty);
      if (!walked.complete) return { status: 'rejected', reason: 'insufficient_depth' };
      fillPrice = walked.avgPrice;
      filled = walked.filled;
    } else {
      const slip = 1 + (side === 'buy' ? 1 : -1) * (this.cfg.fees.slippageBpsPer1kNotional * 1e-4);
      fillPrice = (side === 'buy' ? book.ask : book.bid) * slip;
    }
    const notional = fillPrice * filled;
    const fee = this._fee(notional);
    const ref = side === 'buy' ? book.ask : book.bid;
    const slipBps = ref ? ((fillPrice - ref) / ref) * 10000 : 0;
    return {
      status: 'filled',
      orderId: order.orderId,
      symbol: order.symbol,
      side,
      qty: filled,
      price: fillPrice,
      notional,
      fee,
      feeKind: 'taker',
      slippageBps: slipBps,
      ts: now(),
    };
  }

  submit(order) {
    const o = { ...order, orderId: order.orderId || uuid('ord'), submittedAt: now() };
    if (o.type === 'market') {
      const fill = this._market(o);
      if (fill.status === 'filled') this.fills.push(fill);
      return fill;
    }
    // limit: rest it
    this.openOrders.set(o.orderId, { ...o, remaining: o.qty, status: 'open' });
    return { status: 'open', orderId: o.orderId, ts: now() };
  }

  /** Called on every quote update. Fills resting limits and reports fills. */
  onTick(ticker, feed) {
    const out = [];
    for (const o of this.openOrders.values()) {
      if (o.symbol !== ticker.symbol) continue;
      const px = o.price;
      let hit = false;
      if (o.side === 'buy') hit = ticker.bid <= px; // market traded down to our bid
      else hit = ticker.ask >= px;
      if (!hit) continue;

      // crossing the spread would be taker; a touch at the price is maker
      const crossing = o.side === 'buy' ? ticker.ask <= px : ticker.bid >= px;
      const fillPrice = crossing ? (o.side === 'buy' ? ticker.ask : ticker.bid) : px;
      const notional = fillPrice * o.remaining;
      const fee = crossing ? this._fee(notional) : this._makerFee(notional);
      const fill = {
        status: 'filled',
        orderId: o.orderId,
        symbol: o.symbol,
        side: o.side,
        qty: o.remaining,
        price: fillPrice,
        notional,
        fee,
        feeKind: crossing ? 'taker' : 'maker',
        slippageBps: 0,
        tag: o.tag,
        ts: now(),
      };
      this.openOrders.delete(o.orderId);
      this.fills.push(fill);
      out.push(fill);
    }
    return out;
  }

  /** Cancel orders that have outlived their ttl. */
  expire(nowTs = now()) {
    const expired = [];
    for (const o of this.openOrders.values()) {
      if (nowTs - o.submittedAt >= o.ttlMs) {
        this.openOrders.delete(o.orderId);
        expired.push({ orderId: o.orderId, symbol: o.symbol, side: o.side, reason: 'expired' });
      }
    }
    return expired;
  }

  cancel(orderId) {
    const o = this.openOrders.get(orderId);
    if (!o) return false;
    this.openOrders.delete(orderId);
    return true;
  }

  cancelAll(symbol) {
    for (const [id, o] of [...this.openOrders]) {
      if (!symbol || o.symbol === symbol) this.openOrders.delete(id);
    }
  }

  stats() {
    return { mode: 'paper', openOrders: this.openOrders.size, fills: this.fills.length };
  }
}

module.exports = { PaperBroker };
