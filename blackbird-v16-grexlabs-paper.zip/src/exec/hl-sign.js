'use strict';
/**
 * BlackBird — Hyperliquid signing primitives. Zero npm dependencies.
 *
 * Hyperliquid signs actions with EIP-712 over a "phantom agent" struct, and the
 * action itself is msgpack-encoded. Node ships secp256k1 signing but NOT
 * keccak256 (it has sha3-256, which is a different padding) and NOT msgpack, so
 * both are implemented here.
 *
 * ⚠️ STATUS: the primitives are unit-tested against published vectors
 * (keccak256 of the empty string, address derivation from a known private key,
 * EIP-712 domain separator). The full order-signing path has NOT been verified
 * against the live venue, because that requires a funded account and a real
 * order — which this build deliberately never does. Treat `signL1Action` as
 * "implemented to spec, unverified end-to-end".
 *
 * Sources:
 *   https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/signing
 *   https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/nonces-and-api-wallets
 */

const crypto = require('node:crypto');

// ===========================================================================
// keccak-256 (original Keccak padding 0x01, NOT SHA3's 0x06)
// ===========================================================================

const MASK64 = (1n << 64n) - 1n;

const RC = [
  0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n,
  0x000000000000808bn, 0x0000000080000001n, 0x8000000080008081n, 0x8000000000008009n,
  0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
  0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n,
  0x8000000000008002n, 0x8000000000000080n, 0x000000000000800an, 0x800000008000000an,
  0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n,
];

// rho rotation offsets, indexed [x][y]
const ROT = [
  [0, 36, 3, 41, 18],
  [1, 44, 10, 45, 2],
  [62, 6, 43, 15, 61],
  [28, 55, 25, 21, 56],
  [27, 20, 39, 8, 14],
];

function rotl(x, n) {
  const s = BigInt(n % 64);
  if (s === 0n) return x & MASK64;
  return ((x << s) | (x >> (64n - s))) & MASK64;
}

function keccakF(A) {
  const C = new Array(5);
  const D = new Array(5);
  const B = new Array(25);

  for (let round = 0; round < 24; round++) {
    // theta
    for (let x = 0; x < 5; x++) {
      C[x] = A[x] ^ A[x + 5] ^ A[x + 10] ^ A[x + 15] ^ A[x + 20];
    }
    for (let x = 0; x < 5; x++) {
      D[x] = C[(x + 4) % 5] ^ rotl(C[(x + 1) % 5], 1);
    }
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) A[x + 5 * y] = (A[x + 5 * y] ^ D[x]) & MASK64;
    }

    // rho + pi
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) {
        B[y + 5 * ((2 * x + 3 * y) % 5)] = rotl(A[x + 5 * y], ROT[x][y]);
      }
    }

    // chi
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) {
        const i = x + 5 * y;
        A[i] = (B[i] ^ ((~B[((x + 1) % 5) + 5 * y] & MASK64) & B[((x + 2) % 5) + 5 * y])) & MASK64;
      }
    }

    // iota
    A[0] = (A[0] ^ RC[round]) & MASK64;
  }
  return A;
}

/**
 * keccak256 of a Buffer/Uint8Array.
 * @param {Buffer|Uint8Array|string} input
 * @returns {Buffer} 32 bytes
 */
function keccak256(input) {
  const data = Buffer.isBuffer(input) ? input : Buffer.from(input);
  const rate = 136; // 1088 bits for keccak-256

  // pad10*1 with the original Keccak domain byte 0x01
  const padLen = rate - (data.length % rate);
  const padded = Buffer.alloc(data.length + padLen);
  data.copy(padded);
  padded[data.length] ^= 0x01;
  padded[padded.length - 1] ^= 0x80;

  const A = new Array(25).fill(0n);

  for (let off = 0; off < padded.length; off += rate) {
    for (let i = 0; i < rate / 8; i++) {
      // little-endian lane
      A[i] ^= padded.readBigUInt64LE(off + i * 8);
    }
    keccakF(A);
  }

  const out = Buffer.alloc(32);
  for (let i = 0; i < 4; i++) out.writeBigUInt64LE(A[i] & MASK64, i * 8);
  return out;
}

// ===========================================================================
// msgpack (deterministic; preserves object key insertion order)
// ===========================================================================

function mpUint(n) {
  const v = BigInt(n);
  if (v < 0x80n) return Buffer.from([Number(v)]);
  if (v <= 0xffn) return Buffer.from([0xcc, Number(v)]);
  if (v <= 0xffffn) { const b = Buffer.alloc(3); b[0] = 0xcd; b.writeUInt16BE(Number(v), 1); return b; }
  if (v <= 0xffffffffn) { const b = Buffer.alloc(5); b[0] = 0xce; b.writeUInt32BE(Number(v), 1); return b; }
  const b = Buffer.alloc(9); b[0] = 0xcf; b.writeBigUInt64BE(v, 1); return b;
}

function mpInt(n) {
  const v = BigInt(n);
  if (v >= 0n) return mpUint(v);
  if (v >= -32n) return Buffer.from([Number(0xe0n + (v + 32n))]);
  if (v >= -128n) return Buffer.from([0xd0, Number(v & 0xffn)]);
  if (v >= -32768n) { const b = Buffer.alloc(3); b[0] = 0xd1; b.writeInt16BE(Number(v), 1); return b; }
  if (v >= -2147483648n) { const b = Buffer.alloc(5); b[0] = 0xd2; b.writeInt32BE(Number(v), 1); return b; }
  const b = Buffer.alloc(9); b[0] = 0xd3; b.writeBigInt64BE(v, 1); return b;
}

function mpStr(s) {
  const body = Buffer.from(s, 'utf8');
  const n = body.length;
  let head;
  if (n < 32) head = Buffer.from([0xa0 | n]);
  else if (n <= 0xff) head = Buffer.from([0xd9, n]);
  else if (n <= 0xffff) { head = Buffer.alloc(3); head[0] = 0xda; head.writeUInt16BE(n, 1); }
  else { head = Buffer.alloc(5); head[0] = 0xdb; head.writeUInt32BE(n, 1); }
  return Buffer.concat([head, body]);
}

function mpBin(buf) {
  const n = buf.length;
  let head;
  if (n <= 0xff) head = Buffer.from([0xc4, n]);
  else if (n <= 0xffff) { head = Buffer.alloc(3); head[0] = 0xc5; head.writeUInt16BE(n, 1); }
  else { head = Buffer.alloc(5); head[0] = 0xc6; head.writeUInt32BE(n, 1); }
  return Buffer.concat([head, buf]);
}

function mpArr(items) {
  const n = items.length;
  let head;
  if (n < 16) head = Buffer.from([0x90 | n]);
  else if (n <= 0xffff) { head = Buffer.alloc(3); head[0] = 0xdc; head.writeUInt16BE(n, 1); }
  else { head = Buffer.alloc(5); head[0] = 0xdd; head.writeUInt32BE(n, 1); }
  return Buffer.concat([head, ...items]);
}

function mpMap(entries) {
  const n = entries.length;
  let head;
  if (n < 16) head = Buffer.from([0x80 | n]);
  else if (n <= 0xffff) { head = Buffer.alloc(3); head[0] = 0xde; head.writeUInt16BE(n, 1); }
  else { head = Buffer.alloc(5); head[0] = 0xdf; head.writeUInt32BE(n, 1); }
  return Buffer.concat([head, ...entries.flat()]);
}

/**
 * Encode a JS value as msgpack.
 *
 * Object key order is preserved exactly as written — Hyperliquid's docs warn
 * that field order matters, so callers must build objects in the documented
 * order and never rely on a sort.
 */
function msgpack(value) {
  if (value === null || value === undefined) return Buffer.from([0xc0]);
  if (typeof value === 'boolean') return Buffer.from([value ? 0xc3 : 0xc2]);
  if (typeof value === 'bigint') return mpInt(value);
  if (typeof value === 'number') {
    if (Number.isInteger(value) && Number.isSafeInteger(value)) return mpInt(value);
    const b = Buffer.alloc(9); b[0] = 0xcb; b.writeDoubleBE(value, 1); return b;
  }
  if (typeof value === 'string') return mpStr(value);
  if (Buffer.isBuffer(value)) return mpBin(value);
  if (Array.isArray(value)) return mpArr(value.map(msgpack));
  if (typeof value === 'object') {
    const entries = Object.entries(value).map(([k, v]) => [mpStr(k), msgpack(v)]);
    return mpMap(entries);
  }
  throw new Error(`msgpack: cannot encode ${typeof value}`);
}

// ===========================================================================
// secp256k1 (BigInt) — only what signing needs
// ===========================================================================

const P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2Fn;
const N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141n;
const GX = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798n;
const GY = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8n;

const mod = (a, m = P) => ((a % m) + m) % m;

function inv(a, m = P) {
  let [old_r, r] = [mod(a, m), m];
  let [old_s, s] = [1n, 0n];
  while (r !== 0n) {
    const q = old_r / r;
    [old_r, r] = [r, old_r - q * r];
    [old_s, s] = [s, old_s - q * s];
  }
  if (old_r !== 1n) throw new Error('secp256k1: not invertible');
  return mod(old_s, m);
}

// Jacobian-free affine arithmetic: slow but this runs a handful of times.
function pointAdd(a, b) {
  if (!a) return b;
  if (!b) return a;
  if (a.x === b.x) {
    if (mod(a.y + b.y) === 0n) return null; // point at infinity
    return pointDouble(a);
  }
  const l = mod((b.y - a.y) * inv(b.x - a.x));
  const x = mod(l * l - a.x - b.x);
  const y = mod(l * (a.x - x) - a.y);
  return { x, y };
}

function pointDouble(a) {
  if (!a) return null;
  if (a.y === 0n) return null;
  const l = mod((3n * a.x * a.x) * inv(2n * a.y));
  const x = mod(l * l - 2n * a.x);
  const y = mod(l * (a.x - x) - a.y);
  return { x, y };
}

function pointMul(k, pt) {
  let result = null;
  let addend = pt;
  let n = mod(k, N);
  while (n > 0n) {
    if (n & 1n) result = pointAdd(result, addend);
    addend = pointDouble(addend);
    n >>= 1n;
  }
  return result;
}

const G = { x: GX, y: GY };

function bufToBig(buf) { return BigInt(`0x${buf.toString('hex') || '0'}`); }
function bigToBuf32(n) {
  const h = n.toString(16).padStart(64, '0');
  return Buffer.from(h, 'hex');
}

/** Uncompressed public key (64 bytes, no 0x04 prefix) from a private key. */
function publicKeyFromPrivate(privHex) {
  const d = bufToBig(Buffer.from(privHex.replace(/^0x/, ''), 'hex'));
  if (d <= 0n || d >= N) throw new Error('secp256k1: private key out of range');
  const pt = pointMul(d, G);
  return Buffer.concat([bigToBuf32(pt.x), bigToBuf32(pt.y)]);
}

/** Ethereum address (0x + 40 hex, lowercase) from a private key. */
function addressFromPrivate(privHex) {
  const pub = publicKeyFromPrivate(privHex);
  const h = keccak256(pub);
  return `0x${h.subarray(12).toString('hex')}`;
}

/**
 * Sign a 32-byte digest, returning {r, s, v} with v in {27, 28}.
 *
 * Node gives us r||s but not the recovery id, so it is derived: with
 * R = s^-1 (z*G + r*P), the parity of R.y and whether R.x overflowed n give it.
 */
function signDigest(digest, privHex) {
  const key = crypto.createPrivateKey({
    key: {
      kty: 'EC',
      crv: 'secp256k1',
      d: Buffer.from(privHex.replace(/^0x/, ''), 'hex').toString('base64url'),
      x: publicKeyFromPrivate(privHex).subarray(0, 32).toString('base64url'),
      y: publicKeyFromPrivate(privHex).subarray(32, 64).toString('base64url'),
    },
    format: 'jwk',
  });
  const sig = crypto.sign(null, digest, { key, dsaEncoding: 'ieee-p1363' });
  const r = bufToBig(sig.subarray(0, 32));
  const s = bufToBig(sig.subarray(32, 64));

  // R = s^-1 (z*G + r*P)
  const z = bufToBig(digest);
  const Ppt = { x: bufToBig(publicKeyFromPrivate(privHex).subarray(0, 32)), y: bufToBig(publicKeyFromPrivate(privHex).subarray(32, 64)) };
  const sInv = inv(s, N);
  const R = pointMul(sInv, pointAdd(pointMul(z, G), pointMul(r, Ppt)));
  if (!R) throw new Error('secp256k1: recovery failed');

  let recid = Number(R.y & 1n);
  if (R.x >= N) recid |= 2;
  return { r: bigToBuf32(r), s: bigToBuf32(s), v: 27 + recid };
}

// ===========================================================================
// EIP-712
// ===========================================================================

const DOMAIN_TYPEHASH = keccak256(
  Buffer.from('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)')
);
const AGENT_TYPEHASH = keccak256(Buffer.from('Agent(string source,bytes32 connectionId)'));

const HL_CHAIN_ID = 1337;
const HL_DOMAIN_NAME = 'Exchange';
const HL_DOMAIN_VERSION = '1';

/** EIP-712 domain separator for Hyperliquid's Exchange domain. */
function domainSeparator() {
  return keccak256(Buffer.concat([
    DOMAIN_TYPEHASH,
    keccak256(Buffer.from(HL_DOMAIN_NAME)),
    keccak256(Buffer.from(HL_DOMAIN_VERSION)),
    bigToBuf32(BigInt(HL_CHAIN_ID)),
    Buffer.alloc(32), // verifyingContract = address(0)
  ]));
}

/**
 * Hash an L1 action for signing.
 *
 * Per the docs: msgpack(action), then append 0x00 (no vault) or 0x01 + the
 * 20-byte vault address, then the 8-byte big-endian nonce. keccak256 of that
 * is the "connectionId" of the phantom agent.
 */
function l1ActionHash(action, nonce, vaultAddress = null) {
  const parts = [msgpack(action)];
  if (vaultAddress) {
    parts.push(Buffer.from([0x01]));
    parts.push(Buffer.from(vaultAddress.replace(/^0x/, ''), 'hex'));
  } else {
    parts.push(Buffer.from([0x00]));
  }
  const nb = Buffer.alloc(8);
  nb.writeBigUInt64BE(BigInt(nonce));
  parts.push(nb);
  return keccak256(Buffer.concat(parts));
}

/** EIP-712 digest for the phantom agent wrapping a connectionId. */
function agentDigest(connectionId) {
  const structHash = keccak256(Buffer.concat([
    AGENT_TYPEHASH,
    keccak256(Buffer.from('a')), // source = "a" (L1 action)
    connectionId,
  ]));
  return keccak256(Buffer.concat([Buffer.from([0x19, 0x01]), domainSeparator(), structHash]));
}

/**
 * Sign an L1 action. Returns the wire-ready signature object.
 *
 * @param {object} action
 * @param {number} nonce  ms timestamp
 * @param {string} privHex  API wallet private key (0x-prefixed or not)
 * @param {string|null} [vaultAddress]
 * @returns {{r:string,s:string,v:number}}
 */
function signL1Action(action, nonce, privHex, vaultAddress = null) {
  const cid = l1ActionHash(action, nonce, vaultAddress);
  const digest = agentDigest(cid);
  const { r, s, v } = signDigest(digest, privHex);
  return { r: `0x${r.toString('hex')}`, s: `0x${s.toString('hex')}`, v };
}

module.exports = {
  keccak256,
  msgpack,
  signL1Action,
  l1ActionHash,
  agentDigest,
  domainSeparator,
  addressFromPrivate,
  publicKeyFromPrivate,
  signDigest,
  HL_CHAIN_ID,
};
