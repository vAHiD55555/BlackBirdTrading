# استقرار BlackBird Trader روی سرور لینوکسی

این سند از صفر شروع می‌کند: یک سرور تازه، بدون هیچ چیز نصب‌شده، تا داشبوردی که از بیرون باز می‌شود.

---

## ۱. چرا داشبورد بالا نمی‌آمد — سه علت واقعی

هر سه با اجرای واقعی روی همین کد پیدا شدند، نه با حدس. هر سه در نسخه‌ی v4 رفع شده‌اند و هر سه تست دارند.

### علت اول (کشنده): متغیر `HOST`

بسیاری از پلتفرم‌ها — Heroku، Render، Railway، Fly و اکثر میزبان‌های Docker — متغیر `HOST` را روی **هاست عمومی اپ** ست می‌کنند، مثلاً `myapp.example.com`.

کد قدیمی این را مستقیم به `server.listen()` می‌داد. Node سعی می‌کرد آن را به‌عنوان یک اینترفیس محلی resolve کند و با `ENOTFOUND` شکست می‌خورد. و آن خطا **بلعیده می‌شد**:

```js
server.on('error', (e) => engine.log.warn(`status server error: ${e.message}`));
```

نتیجه: پروسه زنده می‌ماند، پورت هیچ‌وقت bind نمی‌شود، health check پلتفرم شکست می‌خورد، پلتفرم ری‌استارت می‌کند — و همین حلقه تا ابد تکرار می‌شود. در لاگ فقط یک `WARN` بود که کسی نمی‌دید.

**اثبات با اجرا:**

```
$ HOST=myapp.example.com node src/index.js
WARN [engine] status server error: getaddrinfo ENOTFOUND myapp.example.com
$ curl http://127.0.0.1:<PORT>/
  / -> CONNECTION REFUSED
```

**رفع:** فقط آدرس‌های واقعاً قابل bind پذیرفته می‌شوند (`0.0.0.0`، `127.0.0.1`، `::`، `localhost`). هر چیز دیگری نادیده گرفته و با صدای بلند لاگ می‌شود. برای تغییر عمدی، `BB_HOST` اضافه شد.

```
$ HOST=myapp.example.com node src/index.js
WARN [engine] ignoring HOST="myapp.example.com" — it is not a bindable address...
INFO [engine] status panel on http://0.0.0.0:<PORT> (attempt 1)
$ curl http://127.0.0.1:<PORT>/  ->  HTTP 200
```

### علت دوم: `EADDRINUSE` هم بلعیده می‌شد

اگر ری‌استارت با سوکت قبلی که هنوز در `TIME_WAIT` بود برخورد می‌کرد، همان اتفاق می‌افتاد: پروسه زنده، پورت مرده.

**رفع:** پنج تلاش با فاصله‌ی افزایشی، و اگر باز هم نشد **خروج با کد غیرصفر** تا supervisor آن را تمیز ری‌استارت کند — نه اینکه بی‌صدا آویزان بماند.

### علت سوم: اسکریپت مسدودکننده‌ی `telegram.org`

داشبورد این را در `<body>` داشت:

```html
<script src="https://telegram.org/js/telegram-web-app.js"></script>
```

این یک اسکریپت **مسدودکننده** است. روی شبکه‌ای که `telegram.org` در دسترس نیست (ایران از جمله)، درخواست آویزان می‌ماند، پارسر HTML منتظر می‌ماند، و **کل صفحه سفید می‌ماند** — در حالی که `/status` کاملاً سالم جواب می‌دهد. یعنی «داشبورد بالا نمی‌آید» در حالی که سرور کاملاً کار می‌کند.

**رفع:** SDK به‌صورت lazy و `async` تزریق می‌شود، و شکستش هیچ اثری روی نمای فقط‌خواندنی ندارد.

### دو ایراد دیگر که در همین مسیر پیدا شد

**`reports/` ساخته نمی‌شد.** کد فقط زیرپوشه‌ی تاریخ‌دار را `mkdir` می‌کرد، نه پوشه‌ی والد. روی یک checkout تازه (یا ایمیجی که `.dockerignore` پوشه‌ی `reports` را حذف کرده) این با `ENOENT` شکست می‌خورد و `/report/latest` تا ابد ۴۰۴ می‌داد.

**`reports` در مسیر فقط‌خواندنی.** در کانتینر درخت اپ اغلب مال root است و پروسه با کاربر `node` اجرا می‌شود. نوشتن گزارش کنار سورس `EACCES` می‌داد. حالا گزارش‌ها زیر `DATA_DIR` می‌روند — تنها مسیری که اپراتور تضمین می‌کند قابل نوشتن است.

### و یک دروغ که برداشته شد

داشبورد همیشه `SYSTEM HEALTHY` می‌نوشت، حتی وقتی هر هشت فید با `HTTP 451` مرده بودند و موتور روی صفر کندل کار می‌کرد. حالا سه حالت واقعی دارد:

| حالت | شرط |
|---|---|
| `BOOTING` | موتور هنوز بالا نیامده |
| `NO DATA · n/8 FEED DOWN` | فیدها مرده‌اند |
| `RISK HALT` | ریسک متوقف کرده |
| `SYSTEM HEALTHY` | داده هست و ریسک عادی است |

---

## ۲. نصب روی سرور تازه (Debian / Ubuntu)

### گام ۱ — اتصال و به‌روزرسانی

```bash
ssh root@<server-ip>
apt-get update && apt-get upgrade -y
apt-get install -y curl git ufw
```

### گام ۲ — آوردن کد

```bash
mkdir -p /opt && cd /opt
# از مخزن خودتان:
git clone <your-repo-url> blackbird-src
# یا از فایل ZIP:
# unzip blackbird-trader.zip -d blackbird-src
cd blackbird-src
```

### گام ۳ — نصب با یک دستور

```bash
sudo ./deploy/install.sh
```

این اسکریپت به‌ترتیب:

1. Node را چک می‌کند و اگر نبود، Node 20 نصب می‌کند
2. کاربر سیستمی `blackbird` و مسیر `/var/lib/blackbird` را می‌سازد
3. اپ را در `/opt/blackbird` می‌نشاند (بدون `data/`، بدون `.env`)
4. `/etc/blackbird/blackbird.env` را از نمونه می‌نویسد — **بدون هیچ رمزی**
5. سرویس systemd را نصب و استارت می‌کند
6. با `curl` تأیید می‌کند که واقعاً جواب می‌دهد

خروجی موفق:

```
1/6  Node.js
  ✓ node v20.x.x
2/6  system user and directories
  ✓ created user blackbird
3/6  application files
  ✓ installed to /opt/blackbird
4/6  environment file
  ✓ wrote /etc/blackbird/blackbird.env
5/6  systemd unit
  ✓ service installed and started
6/6  verification
  ✓ /healthz answers on port <PORT>

done
  dashboard:  http://203.0.113.10:<PORT>/
```

### گام ۴ — باز کردن پورت

```bash
ufw allow 22/tcp      # اول SSH، وگرنه قفل می‌شوید
ufw allow <PORT>/tcp
ufw --force enable
```

اگر سرور روی ابر است (AWS، Hetzner، Arvan، …)، **Security Group** یا فایروال پنل را هم باز کنید. این رایج‌ترین دلیل «سرویس بالاست ولی از بیرون باز نمی‌شود» است.

### گام ۵ — تأیید از بیرون

از کامپیوتر خودتان:

```bash
curl http://<server-ip>:<PORT>/healthz
# {"ok":true,"up":12}

curl http://<server-ip>:<PORT>/readyz
# {"ok":true,"dataOk":true,"feedsDegraded":0,...}
```

بعد در مرورگر: `http://<server-ip>:<PORT>/`

---

## ۳. سه راه دیگر

### Docker Compose (ساده‌ترین)

```bash
docker compose up -d --build
docker compose logs -f
curl http://localhost:<PORT>/healthz
```

داده در volume به‌نام `bb-data` می‌ماند. `docker compose down` آن را نگه می‌دارد، `down -v` پاکش می‌کند.

### Docker خالی

```bash
docker build -t blackbird .
docker run -d --name blackbird \
  -p <PORT>:<PORT> \
  -v blackbird-data:/app/data \
  --restart unless-stopped \
  blackbird
```

### اجرای دستی (برای تست)

```bash
cd /opt/blackbird
PORT=<PORT> DATA_DIR=/tmp/bb-data node src/index.js
```

---

## ۴. متغیرهای محیطی

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `PORT` | `<PORT>` | پورت پنل. پلتفرم‌ها این را تزریق می‌کنند و بر `BB_PORT` اولویت دارد |
| `BB_PORT` | `<PORT>` | جایگزین محلی وقتی `PORT` ست نشده |
| `BB_HOST` | `0.0.0.0` | آدرس bind. **فقط** برای تغییر عمدی؛ `HOST` پلتفرم نادیده گرفته می‌شود |
| `DATA_DIR` | `./data` | تنها مسیر نوشتنی: state، journal، لاگ، K، گزارش‌ها |
| `REPORT_DIR` | `$DATA_DIR/reports` | فقط اگر مسیر دیگری می‌خواهید |
| `MODE` | `paper` | `live` در این نسخه پیاده نشده و صریحاً رد می‌شود |
| `EXCHANGE` | `binance` | `binance` \| `mexc` \| `bitget` \| `bybit` \| `hyperliquid` |
| `SYMBOLS` | ۸ نماد | کتاب مومنتوم به حداقل ۶ نماد نیاز دارد |
| `ADMIN_TOKEN` | خالی | خالی = پنل فقط‌خواندنی. ساخت: `openssl rand -hex 24` |
| `LOG_LEVEL` | `info` | `debug` \| `info` \| `warn` \| `error` |

---

## ۵. اگر بالا نیامد — به کجا نگاه کنید

به همین ترتیب:

```bash
# ۱. آیا سرویس زنده است؟
systemctl status blackbird --no-pager -l

# ۲. چه گفت؟
journalctl -u blackbird -n 100 --no-pager

# ۳. آیا پورت گوش می‌دهد؟
ss -lntp | grep <PORT>

# ۴. از خود سرور جواب می‌دهد؟
curl -v http://127.0.0.1:<PORT>/healthz

# ۵. از بیرون؟
curl -v http://<server-ip>:<PORT>/healthz
```

### جدول عیب‌یابی

| نشانه | علت | راه‌حل |
|---|---|---|
| `CONNECTION REFUSED` از خود سرور | پورت bind نشده | `journalctl` را ببینید؛ دنبال `ignoring HOST` یا `EADDRINUSE` بگردید |
| از خود سرور ۲۰۰، از بیرون نه | فایروال | `ufw allow <PORT>/tcp` + Security Group ابری |
| `EACCES` روی پورت | پورت زیر ۱۰۲۴ | `PORT=<PORT>` بگذارید |
| `EADDRINUSE` | نمونه‌ی قبلی زنده است | `systemctl stop blackbird`، `pkill -f src/index.js` |
| صفحه سفید، ولی `/status` سالم | اسکریپت خارجی مسدود | در v4 رفع شده؛ مطمئن شوید نسخه‌ی درست را deploy کرده‌اید |
| `NO DATA · 8/8 FEED DOWN` | صرافی از این IP جواب نمی‌دهد | `EXCHANGE=hyperliquid` یا `bybit` را امتحان کنید |
| `/readyz` می‌گوید `booting` | بوت‌استرپ کند است | ۳۰–۶۰ ثانیه صبر کنید؛ ۸ نماد × ۹۰۰ کندل طول می‌کشد |
| گزارش‌ها خالی | `DATA_DIR` قابل نوشتن نیست | `chown -R blackbird:blackbird /var/lib/blackbird` |

### درباره‌ی `HTTP 451`

اگر صرافی از موقعیت سرور شما جواب ندهد، این را می‌بینید:

```
WARN [market] bootstrap failed (1/3): HTTP 451 https://api.binance.com/...
```

این **خطای کد نیست**. بایننس از برخی کشورها (از جمله ایران) سرویس نمی‌دهد. موتور به‌درستی degrade می‌کند و `/healthz` را زنده نگه می‌دارد، ولی داده ندارد. راه‌حل: صرافی دیگری انتخاب کنید.

```bash
# در /etc/blackbird/blackbird.env
EXCHANGE=hyperliquid
```

---

## ۶. تفاوت `/healthz` و `/readyz`

این تفکیک عمدی است و مهم:

| مسیر | سؤال | کد |
|---|---|---|
| `/healthz` | «پروسه زنده و گوش‌دهنده است؟» | همیشه ۲۰۰ تا وقتی پروسه بالاست |
| `/readyz` | «موتور داده‌ی بازار دارد؟» | ۲۰۰ اگر دارد، ۵۰۳ با دلیل اگر ندارد |

**چرا مهم است:** اگر health check پلتفرم را به `/readyz` وصل کنید و صرافی مسدود باشد، پلتفرم فکر می‌کند سرویس مرده و بی‌وقفه ری‌استارت می‌کند — یک قطعی داده را به یک حلقه‌ی ری‌استارت تبدیل می‌کنید. برای probe پلتفرم از `/healthz` استفاده کنید؛ `/readyz` برای انسان و مانیتورینگ است.

---

## ۷. پایداری داده

`DATA_DIR` شامل این‌هاست:

```
state.json        وضعیت لحظه‌ای (سرمایه، پوزیشن‌ها)
journal.jsonl     تاریخچه‌ی زنجیره‌هش‌شده — دست‌کاری‌ناپذیر
trials.jsonl      رجیستری K — شمارنده‌ی آزمون‌ها
equity.jsonl      منحنی سرمایه — ورودی شارپ و DSR
logs/             لاگ‌ها
reports/          گزارش‌های ساعتی
```

**اگر این مسیر از دست برود، K صفر می‌شود و DSR بی‌معنا.** در Docker حتماً volume وصل کنید؛ روی سرور خالی، از `/var/lib/blackbird` بکاپ بگیرید:

```bash
tar czf /root/blackbird-$(date +%F).tar.gz -C /var/lib blackbird
```

---

## ۸. به‌روزرسانی

```bash
cd /opt/blackbird-src && git pull
sudo ./deploy/install.sh          # idempotent — داده را دست نمی‌زند
systemctl status blackbird
```

`install.sh` فایل env موجود را **بازنویسی نمی‌کند**، پس تنظیمات شما می‌مانند.

---

## ۹. آنچه تأیید نشد

صادقانه، این‌ها را نتوانستم روی یک سرور واقعی بیرونی تأیید کنم:

- **دسترسی از بیرون روی یک IP عمومی واقعی** — همه‌ی تست‌ها روی `127.0.0.1` و پورت‌های ephemeral در همین sandbox بودند. رفتار bind و probe تأیید شد، ولی عبور از فایروال ابری و NAT تأیید نشد.
- **`docker build`** — Docker در این محیط نصب نیست. Dockerfile و compose از نظر ساختار تست شده‌اند (پورت، volume، healthcheck، کاربر غیر root) ولی ایمیج واقعاً build نشده.
- **`systemd`** — یونیت از نظر محتوا تست شده (کاربر غیر root، `Restart=always`، `EnvironmentFile`، سخت‌سازی) ولی روی یک systemd واقعی اجرا نشده.
- **`install.sh`** — سینتکس با `bash -n` تأیید شد؛ اجرای کاملش نیاز به root و apt دارد که در این sandbox در دسترس نبود.
- **دسترسی به صرافی‌ها از ایران** — هیچ منبعی تأیید نکرد. `HTTP 451` بایننس مشاهده شد، ولی اینکه کدام صرافی از ایران کار می‌کند تأیید نشد.

هر کدام از این‌ها را روی سرور خودتان با دستورهای بخش ۵ می‌توانید در یک دقیقه بسنجید.
