# Merge decisions (fixed vs strategist-v2)

Evidence: SESSION-HANDOFF.md identical; v2 is later (15:16 vs 06:43, 2026-11-12) and adds strategist, host/port resolution, telegram, supervisor probe. But v2 lacks the safety fixes in `fixed` (REVIEW.md), so v2 is the base and these were ported from `fixed`:
- risk.js, store.js: persisted peak equity, day anchor + state migration.
- rotator.js: risk gate on entries, fee on partial closes, settle via risk, true gross cap, injected clock, three sleeves (+ sleeves/*, tests). v2's externalScale (strategist can only reduce) re-applied on top.
- exchanges.js funding endpoints; engine.js mark-to-exit, hourly-feed warning, async onBar handling; config.js .env inline-comment stripping, TP/SL + rotator validation.
Kept from v2: strategist, lawyer/charter additions, telegram rewrite, supervisor probe, halt-log de-dup, SERVER_PORT, port-free Dockerfile/compose.
