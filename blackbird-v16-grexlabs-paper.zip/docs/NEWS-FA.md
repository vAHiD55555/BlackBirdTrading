# هوش بازار (Market Intel) — v10

## مسئله

موتور می‌داند قیمت چه کرد. نمی‌داند در جهان چه خبر است که قیمت هنوز آن را حساب نکرده.

## تکنیک: توقف رویداد + تمایل احساسی

دو کار، هیچ‌کدام پیش‌بینی جهت نیست:

### ۱. توقف رویداد (event blackout)

اگر یک رویداد با اثر بالا (FOMC، CPI، تصمیم نرخ بهره، حقوق و دستمزد) داخل پنجرهٔ `INTEL_BLACKOUT_BEFORE_MS` تا `INTEL_BLACKOUT_AFTER_MS` باشد، **ورود جدید ممنوع** می‌شود.

این پیش‌بینی نیست. این پذیرش این واقعیت است که در پنجرهٔ خبر، اسپرد باز می‌شود، نقدینگی می‌رود و استاپ‌ها شکار می‌شوند. کنار ایستادن در آن پنجره یک تصمیم آماری است، نه یک حدس.

### ۲. تمایل احساسی (sentiment tilt)

هر تیتر با یک واژه‌نامهٔ صریح امتیاز می‌گیرد:

| دسته | نمونه واژه | اثر بر tone |
|---|---|---|
| hawkish | rate hike, tightening, inflation surge | منفی |
| dovish | rate cut, easing, inflation cools | مثبت |
| risk_off | war, sanctions, default, bank failure | منفی |
| risk_on | ceasefire, agreement, recovery | مثبت |
| weather | hurricane, drought, flood, freeze | منفی (وزن نیم) |
| high_impact | FOMC, CPI, GDP, payrolls | اثر بالا |

اگر `|tone|` از `INTEL_EXTREME_THRESHOLD` بگذرد و اطمینان کافی باشد، ریسک **کاهش** می‌یابد.

## قاعدهٔ سخت: فقط کاهش، هرگز افزایش

```js
riskMultiplier() // در بازهٔ [1 - maxRiskImpact, 1]
```

- لحن risk-on → دقیقاً `1`، نه بیشتر
- لحن risk-off شدید → کاهش تا سقف
- توقف رویداد → کف (`1 - maxRiskImpact`)

`INTEL_MAX_RISK_IMPACT` را هر چقدر هم بزرگ بگذارید، ضریب از ۱ بالاتر نمی‌رود. این در تست `intel: riskMultiplier() can only reduce risk, never raise it` قفل شده است.

## چرا واژه‌نامه و نه مدل بزرگ

یک لیست را می‌توان بازرسی کرد. می‌توان دید چرا «rate hike» منفی حساب شد. یک مدل بزرگ نمی‌تواند این را بدهد، و برای این کار هم لازم نیست: دانستن اینکه «rate hike» hawkish است نیازی به ۷۰ میلیارد پارامتر ندارد.

## منابع — همه رایگان و بدون کلید

هر منبع یک `GET` ساده است که JSON برمی‌گرداند. `path` مسیر نقطه‌ای به آرایه است.

### GDELT (پیشنهاد اول — بدون کلید، بدون ثبت‌نام)

```
INTEL_MACRO_URL=https://api.gdeltproject.org/api/v2/doc/doc?query=inflation%20OR%20%22rate%20decision%22&mode=artlist&format=json&maxrecords=40
INTEL_MACRO_PATH=articles
```

### نمونه‌های دیگر

| منبع | نوع | کلید |
|---|---|---|
| GDELT DOC 2.0 | macro / geo | ندارد |
| Open-Meteo | weather | ندارد |
| RSS-to-JSON (rss2json) | هر فید RSS | ندارد (سقف روزانه) |
| NewsAPI | macro | کلید رایگان |

## هشدار صادقانه

**اتصال زنده به هیچ منبع خبری در این نسخه تست نشده است.** لایهٔ فید پیکربندی‌محور و مستند است، و با `fetchImpl` تزریقی تست شده، اما هیچ فراخوانی واقعی به GDELT یا منبع دیگری در ساخت این نسخه انجام نشد.

قبل از اتکا، یک بار با URL واقعی اجرا کنید و `/api/public/summary` را ببینید: کارت «هوش بازار» باید `ok` یا `watch` بدهد، نه `unknown`.

## تنظیمات پنل

| متغیر | پیش‌فرض | معنا |
|---|---|---|
| `INTEL_ENABLED` | `false` | روشن/خاموش |
| `INTEL_REFRESH_MS` | `900000` | فاصلهٔ بازخوانی (۱۵ دقیقه) |
| `INTEL_TIMEOUT_MS` | `8000` | مهلت هر فید |
| `INTEL_BLACKOUT_BEFORE_MS` | `1800000` | ۳۰ دقیقه قبل از رویداد |
| `INTEL_BLACKOUT_AFTER_MS` | `900000` | ۱۵ دقیقه بعد |
| `INTEL_EXTREME_THRESHOLD` | `0.6` | آستانهٔ «شدید» |
| `INTEL_MAX_RISK_IMPACT` | `0.25` | سقف کاهش ریسک |
| `INTEL_MACRO_URL` / `_PATH` / `_WEIGHT` | خالی | فید اقتصادی |
| `INTEL_GEO_URL` / `_PATH` / `_WEIGHT` | خالی | فید سیاسی |
| `INTEL_WEATHER_URL` / `_PATH` / `_WEIGHT` | خالی | فید هواشناسی |

## نکتهٔ مهم دربارهٔ `enabled`

`INTEL_ENABLED=true` با هیچ URL تنظیم‌شده، **کار نمی‌کند** و `enabled: false` گزارش می‌دهد. این عمدی است: ماژولی که «روشن» است ولی داده ندارد، روی داشبورد یک دروغ است.

## خاموش کردن

`INTEL_ENABLED=false` — هیچ فراخوانی شبکه‌ای انجام نمی‌شود و هیچ بلاکی اعمال نمی‌گردد.
