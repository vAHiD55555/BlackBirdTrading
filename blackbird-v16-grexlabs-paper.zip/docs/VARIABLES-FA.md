# کاتالوگ متغیرهای محیطی — BlackBird

این فایل **خودکار** از `.env.example` ساخته می‌شود. اگر متغیری اضافه یا حذف شد، دوباره بسازید:

```bash
node scripts/gen-vars-doc.js
```

**173** متغیر در **5** گروه. از این تعداد **22** اجباری است.

> همهٔ این متغیرها از **پنل botkeep** خوانده می‌شوند. هیچ‌کدام نیاز به ویرایش فایل روی سرور ندارند.
> متغیری که خالی بماند، پیش‌فرض امن خودش را می‌گیرد — مگر در ستون «اجباری» با ✅ علامت خورده باشد.

## فهرست گروه‌ها

| گروه | تعداد | اجباری |
|---|---|---|
| BlackBird Trader v3 «Orbital» — نمونه‌ی تنظیمات | 79 | 20 |
| متغیرهای پنل (variables) — نسخهٔ ۴ | 53 | 2 |
| v10 — کارآموز (the apprentice) | 5 | 0 |
| v10 — هوش بازار (market intel) | 30 | 0 |
| v10 — نظیر تاریخی (historical analog) | 6 | 0 |

## BlackBird Trader v3 «Orbital» — نمونه‌ی تنظیمات

| متغیر | مقدار پیشنهادی | توضیح | اجباری |
|---|---|---|---|
| `MODE` | `paper` | paper = معاملات آزمایشی روی داده‌ی واقعی بازار (پیش‌فرض و امن) | — |
| `BB_STRATEGY` | `rotator` | rotator = مومنتوم مقطعی، ری‌بالانس هفتگی (نسخه ۳ — پیش‌فرض) discretionary = پولبک روند نسخه ۲ (مسیر قدیمی، برای مقایسه) | — |
| `CONFIDENCE_FLOOR` | `0.45` | حداقل اعتماد لازم برای تأیید معامله. اگر لاگ می‌گوید "confidence 0.37 < floor 0.55" یعنی هیئت هر پیشنهاد را رد کرده؛ این عدد را کمی پایین بیاورید (۰.۳۰ تا ۰.۴۵). | — |
| `BOARD_MIN_APPROVE` | `2` | چند رأی از سه افسر لازم است (۲ = پیش‌فرض) | — |
| `BOARD_REQUIRE_ZERO_VETOES` | `true` | اگر ۱ باشد، یک وتوی واحد معامله را می‌بندد | — |
| `MAX_SPREAD_BPS` | `9` | اسپرد بیش از این (بی‌پی) رد می‌شود | — |
| `MIN_DEPTH_USD` | `25000` | عمق کمتر از این (دلار) رد می‌شود | — |
| `EXCHANGE` | `binance` | صرافی داده‌ی بازار: binance \| mexc \| bitget \| bybit | — |
| `WITNESS_EXCHANGE` | `bybit` | صرافی مستقل «شاهد» (برای تطبیق قیمت و کشف دستکاری) | — |
| `WITNESS_ENABLED` | `true` | روشن/خاموش کردن شاهد (تایید مستقل قیمت و PnL) | — |
| `WITNESS_REQUIRE_CROSS_SOURCE` | `true` | شاهد باید از منبع دوم بخواند (نه همان صرافی اصلی) | — |
| `WITNESS_MAX_DIVERGENCE_BPS` | `35` | حداکثر اختلاف قیمت با شاهد (بی‌پی) — بیشتر از این = هشدار دستکاری | — |
| `WITNESS_MAX_PNL_DIVERGENCE_USD` | `0.25` | حداکثر اختلاف PnL با شاهد (دلار) | — |
| `WITNESS_UPDATE_MS` | `5000` | فاصلهٔ به‌روزرسانی قیمت شاهد (میلی‌ثانیه). کتاب §۳: ۵ ثانیه | — |
| `SYMBOLS` | `BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,…` | هشت رمزارز (کتاب مومنتوم به حداقل ۶ نماد نیاز دارد تا رتبه‌بندی معنا داشته باشد) | — |
| `BB_INTERVAL` | `1h` | تایم‌فریم: در حالت rotator همیشه ۱ ساعته می‌شود (پنجره‌ی مومنتوم بر حسب ساعت است) | — |
| `START_EQUITY` | `5000` | — | — |
| `MAX_OPEN_POSITIONS` | `8` | — | — |
| `MAX_DAILY_LOSS_PCT` | `0.04` | سقف ضرر روزانه (کسر سرمایه). قانون‌نامه بند ۷: ۴٪. | — |
| `MAX_DAILY_TRADES` | `30` | سقف تعداد معامله در روز. قانون‌نامه بند ۷: ۳۰. | — |
| `KILL_SWITCH_DD_PCT` | `0.12` | خاموشی کامل در افت از اوج. قانون‌نامه بند ۷: ۱۲٪. ⚠️ این عدد قبلاً ۰٫۳۰ نوشته شده بود در حالی که کد ۰٫۱۲ بود — یعنی پنل می‌گفت ۳۰٪ ولی ربات در ۱۲٪ می‌ایستاد. حالا هر دو یکی است. | — |
| `DRAWDOWN_COOLDOWN_MS` | `86400000` | بازگشت فقط با گذشت زمان انجام نمی‌شود؛ سه شرط باید هم‌زمان برقرار باشند. ۱) دورهٔ خنک‌شدن (میلی‌ثانیه) — پیش‌فرض ۲۴ ساعت | — |
| `RESUME_DRAWDOWN_PCT` | `0.06` | ۲) افت باید به این حد برگشته باشد (یا دفتر خالی باشد) — پیش‌فرض ۶٪ | — |
| `RESUME_SCALE` | `0.5` | ۳) اولین ورودها بعد از بازگشت با این ضریب کوچک‌تر می‌شوند — پیش‌فرض نصف | — |
| `PER_POSITION_PCT` | `11` | درصد سرمایه به‌ازای هر انتخاب | — |
| `MAX_GROSS_PCT` | `150` | سقف ناخالص (نسبت به سرمایه) | — |
| `VOL_TARGET_PCT` | `45` | تارگت نوسان سالانه | — |
| `MAKER_FEE_BPS` | `2` | این اعداد کارمزد واقعی فیوچرز بایننس است. اگر صرافی دیگری دارید، عوض کنید. | — |
| `TAKER_FEE_BPS` | `5` | — | — |
| `REPORT_INTERVAL_MS` | `3600000` | هر ساعت | — |
| `REPORT_ON_BOOT` | `true` | — | — |
| `BB_PORT` | `61257` | هرگز پورت ۳۰۸۰ یا ۳۰۸۳ را اشغال نکنید (پنل خود اپ روی آن‌هاست) | — |
| `SERVER_TOKEN` | — | برای فعال‌شدن endpoint های کنترلی لازم است | ✅ |
| `EMAIL_ENABLED` | `false` | PORT را پلتفرم (Docker/Heroku/Render/Railway) تزریق می‌کند و بر BB_PORT اولویت دارد. روی Pterodactyl (Botkeep، KataBump) متغیر SERVER_PORT است و کد آن را هم می‌خواند. اگر هیچ‌کدام ست نشوند، ۶۱۲۵۷ استفاده می‌شود. PORT=61… | — |
| `SMTP_HOST` | — | — | ✅ |
| `SMTP_PORT` | `465` | — | — |
| `SMTP_USER` | — | — | ✅ |
| `SMTP_PASS` | — | — | ✅ |
| `EMAIL_FROM` | — | — | ✅ |
| `EMAIL_TO` | — | — | ✅ |
| `TELEGRAM_ENABLED` | `false` | ربات را در کانال/گروه ادمین کنید؛ توکن را هرگز در Git یا گزارش ذخیره نکنید. | — |
| `TELEGRAM_BOT_TOKEN` | — | — | ✅ |
| `TELEGRAM_CHAT_ID` | — | TELEGRAM_CHAT_ID نامی است که تقریباً همه‌ی راهنماها می‌گویند و به‌عنوان معادل TELEGRAM_REPORT_CHAT_ID پذیرفته می‌شود. عدد، @username یا لینک t.me. | ✅ |
| `TELEGRAM_REPORT_CHAT_ID` | — | — | ✅ |
| `TELEGRAM_ALERT_CHAT_ID` | — | — | ✅ |
| `TELEGRAM_CONTROL_USER_IDS` | — | شناسه عددی کاربران مجاز، با کاما جدا شود | ✅ |
| `TELEGRAM_TIMEOUT_MS` | `10000` | — | — |
| `SUPERVISOR_ENABLED` | `false` | پیش‌فرض خاموش است: روی هاست رایگان نه Ollama هست نه کلید، و موتور بدون آن کامل کار می‌کند. اگر SUPERVISOR_URL را ست کنید خودش روشن می‌شود. اگر آدرس در دسترس نباشد، یک بار تست می‌کند و خاموش می‌ماند — نه خطای تکراری در ل… | — |
| `SUPERVISOR_URL` | — | — | ✅ |
| `SUPERVISOR_API_KEY` | — | — | ✅ |
| `SUPERVISOR_MODEL` | `qwen2.5:7b` | — | — |
| `SUPERVISOR_INTERVAL_MS` | `21600000` | — | — |
| `JEV_ENABLED` | `false` | پیش‌فرض خاموش است. برای روشن کردن: JEV_ENABLED=true | — |
| `JEV_PROVIDER` | `pollinations` | پیش‌فرض بدون کلید و راه‌دور است: روی سرور اجاره‌ای (botkeep.cloud) آدرس 127.0.0.1 خودِ کانتینر است و هیچ مدلی آنجا نصب نیست، پس مدل محلی کار نمی‌کند. pollinations نه کلید می‌خواهد نه نصب. سهمیهٔ ناشناس کم است (یک پاسخ د… | — |
| `JEV_MODEL` | `openai` | — | — |
| `JEV_KEYLESS_FALLBACK` | `pollinations,mock` | اگر درگاه انتخابی جواب نداد، به ترتیب این‌ها امتحان می‌شوند. mock آخرین است. | — |
| `JEV_ALLOW_LOCAL` | `false` | مدل محلی (ollama) فقط وقتی روشن می‌شود که این true باشد. روی سرور اجاره‌ای روشن نکنید: فقط timeout می‌خورد و یک چرخه را می‌سوزاند. | — |
| `JEV_TIMEOUT_MS` | `20000` | — | — |
| `JEV_MAX_RISK_MULTIPLIER` | `1` | — | — |
| `JEV_ALLOW_VETO` | `true` | — | — |
| `CLOUDFLARE_API_TOKEN` | — | هیچ‌کدام کارت اعتباری لازم ندارند. فقط کلیدی که واقعاً داری را پر کن؛ بقیه را خالی بگذار — probe.js می‌گوید کدام‌ها آماده‌اند. هر کدام از این‌ها را بگذاری قبول است: کلید اختصاصی همان سرویس (مثل GROQ_API_KEY) یا JEV_API_… | ✅ |
| `CLOUDFLARE_ACCOUNT_ID` | — | — | ✅ |
| `GROQ_API_KEY` | — | Groq — https://console.groq.com/keys | ✅ |
| `GEMINI_API_KEY` | — | Google Gemini — https://aistudio.google.com/apikey | ✅ |
| `CEREBRAS_API_KEY` | — | Cerebras — https://cloud.cerebras.ai | ✅ |
| `MISTRAL_API_KEY` | — | Mistral — https://console.mistral.ai/api-keys | ✅ |
| `OPENROUTER_API_KEY` | — | OpenRouter (آخرین پشتیبان، فقط مدل‌های :free) — https://openrouter.ai/keys | ✅ |
| `JEV_CONSENSUS_ENABLED` | `false` | Ollama محلی کلید نمی‌خواهد. آدرسش را اگر جای دیگری است عوض کن: JEV_BASE_URL=http://127.0.0.1:11434/v1 | — |
| `JEV_CONSENSUS_QUORUM` | `2` | — | — |
| `JEV_CONSENSUS_TIMEOUT_MS` | `20000` | — | — |
| `JEV_LEDGER_ENABLED` | `true` | — | — |
| `JEV_LEDGER_MAX_BYTES_PER_DAY` | `52428800` | — | — |
| `JEV_LEDGER_KEEP_DAYS` | `30` | — | — |
| `TRIALS_ENABLED` | `true` | API_KEY= API_SECRET= BB_I_UNDERSTAND_REAL_MONEY=YES EXCHANGE=hyperliquid HL_MODE=paper # paper \| dry-run \| live HL_API_WALLET_KEY= # کلید خصوصی API wallet — هرگز کلید اصلی HL_ACCOUNT_ADDRESS= # آدرس حساب اصلی (نه آدرس A… | — |
| `STRATEGIST_ENABLED` | `true` | LAWYER_DSR_THRESHOLD=0.95 در این نسخه روشن است (طبق درخواست). برای خاموش کردن، false بگذارید. با روشن بودن، هر ۳ دقیقه و ۳۰ ثانیه یک چرخه اجرا می‌شود. | — |
| `STRATEGIST_CRISIS_AUTHORITY` | `false` | STRATEGIST_INTERVAL_MS=210000 # ۳ دقیقه و ۳۰ ثانیه STRATEGIST_RESPONSE_WINDOW_MS=60000 # ۶۰ ثانیه مهلت کمیته STRATEGIST_LIVE_REPORT=true # ثبت هر چرخه در data/strategist/live.jsonl پیش‌فرض: غیرمسلح. فقط وقتی روشن است، ا… | — |
| `STRATEGIST_PUBLISH` | `off` | STRATEGIST_MAX_ACTIONS_PER_HOUR=6 STRATEGIST_MAX_RISK_DELTA_PCT=25 STRATEGIST_OVERLAY_TTL_MS=1800000 # ۳۰ دقیقه؛ بعد از آن خودکار برداشته می‌شود STRATEGIST_KILL_SWITCH=0 # ۱ = خاموشی فوری، بدون ری‌استارت پیش‌فرض: off. ه… | — |
| `HEAL_ENABLED` | `true` | STRATEGIST_PUBLISH_INTERVAL_MS=300000 GITHUB_TOKEN= GITHUB_REPO=owner/private-reports GITHUB_BRANCH=main GITHUB_PATH=blackbird/strategist MIRROR_TOKEN= MIRROR_REPO=owner/second-mirror MIRROR_BRANCH=main MIRROR_PATH=blac… | — |
| `HEAL_FALLBACKS` | `bitget,bybit,binance,hyperliquid` | صرافی‌های جانشین به ترتیب اولویت. صرافی شاهد هرگز انتخاب نمی‌شود. | — |

## متغیرهای پنل (variables) — نسخهٔ ۴

| متغیر | مقدار پیشنهادی | توضیح | اجباری |
|---|---|---|---|
| `RISK_PER_TRADE_PCT` | `0.5` | درصد سرمایه در هر معامله (۰.۵ = نیم درصد) | — |
| `MAX_SYMBOL_EXPOSURE_PCT` | `10` | سقف مواجهه با یک نماد (درصد سرمایه) | — |
| `MAX_NET_EXPOSURE_PCT` | `30` | سقف مواجههٔ خالص کل کتاب (درصد سرمایه) | — |
| `MAX_CONSECUTIVE_LOSSES` | `3` | بعد از این تعداد ضرر پشت‌سرهم، ورودهای جدید متوقف می‌شود | — |
| `COOLDOWN_AFTER_LOSS_MS` | `900000` | مدت خنک‌شدن بعد از ضرر (میلی‌ثانیه) | — |
| `MIN_NOTIONAL_USD` | `25` | کوچک‌ترین حجم مجاز برای باز کردن پوزیشن (دلار) | — |
| `USE_RISK_SIZING` | `true` | اندازه‌گیری بر اساس ریسک (true) یا درصد ثابت سرمایه (false) | — |
| `MAX_POSITIONS` | `8` | — | — |
| `CORE_PCT` | `40` | — | — |
| `CORE_TOP` | `3` | — | — |
| `DISASTER_STOP_ATR` | `6` | Disaster stop, in ATR units. Constitution §6.4 says 6 ATR; this file used to say 3.5, which stopped positions out at half the charter's distance. | — |
| `TRAIL_ENABLED` | `true` | نردبان trailing طبق بند ۱۲ قانون‌نامه. R = DISASTER_STOP_ATR × ATR. تا ۱R: استاپ ساختاری ثابت می‌ماند در ۱R: استاپ به نقطهٔ ورود می‌رود (breakeven) در ۲R: حداقل ۱R سود قفل می‌شود بعد از آن: استاپ ۱٫۵ ATR پشت بهترین قیمت… | — |
| `TRAIL_BE_AT_R` | `1` | — | — |
| `TRAIL_LOCK_AT_R` | `2` | — | — |
| `TRAIL_LOCK_R` | `1` | — | — |
| `TRAIL_ATR` | `1.5` | — | — |
| `TRAIL_START_ATR` | `2` | منسوخ: نردبان دیگر این دو را نمی‌خواند؛ فقط برای سازگاری نگه داشته شده‌اند. | — |
| `TRAIL_DISTANCE_ATR` | `2` | — | — |
| `GATE_SYMBOL` | `BTCUSDT` | — | — |
| `VOL_FLOOR` | `20` | — | — |
| `VOL_CAP` | `180` | — | — |
| `MIN_RR` | `1.5` | — | — |
| `MIN_TP_BPS` | `30` | — | — |
| `MAX_TP_BPS` | `400` | — | — |
| `MIN_SL_BPS` | `40` | — | — |
| `MAX_SL_BPS` | `250` | — | — |
| `ALLOW_SHORT` | `false` | — | — |
| `USE_BREADTH_GATE` | `true` | — | — |
| `BREADTH_MIN` | `0.4` | — | — |
| `SLIPPAGE_BPS_PER_1K` | `0.6` | — | — |
| `STALE_QUOTE_MS` | `5000` | — | — |
| `SCAN_INTERVAL_MS` | `15000` | — | — |
| `PROPOSAL_TTL_MS` | `45000` | — | — |
| `MAX_PROPOSALS_PER_CYCLE` | `2` | — | — |
| `SLEEVE_DONCHIAN` | `true` | — | — |
| `SLEEVE_MEANREV` | `true` | — | — |
| `SLEEVE_CARRY` | `true` | — | — |
| `WATCH_ENABLED` | `true` | روشن/خاموش کردن کل دیده‌بان | — |
| `WATCH_INTERVAL_MS` | `7200000` | فاصلهٔ هر چرخهٔ کشف (میلی‌ثانیه). پیش‌فرض ۲ ساعت = ۱۲ بار در روز. قبلاً ۶ ساعت بود و چرخش‌ها را دیر می‌دید. | — |
| `WATCH_SCAN_LIMIT` | `40` | چند نماد از فهرست پرحجم صرافی واقعاً بررسی شود. قبلاً به maxCandidates*4 قفل بود (۲۰) و همیشه همان بزرگان را می‌دید. ۴۰ = یک فراخوانی ارزان. | — |
| `WATCH_UNIVERSE` | — | فهرست نمادهایی که دیده‌بان بررسی می‌کند (با کاما). خالی = فهرست پرحجم‌ترین نمادهای خود صرافی، که پاسخ صادقانه‌ی «الان چه چیزی نقدشونده است» است. | ✅ |
| `WATCH_MAX_CANDIDATES` | `5` | حداکثر تعداد ایدهٔ جدید در هر چرخه | — |
| `WATCH_MIN_QUOTE_VOLUME_USD` | `5000000` | کف گردش ۲۴ ساعته (دلار) — کتاب‌های نازک رد می‌شوند | — |
| `WATCH_MIN_EDGE_BPS` | `25` | حداقل برتری مورد انتظار نسبت به دارایی فعلی (بی‌پی) تا ارزش جابه‌جایی داشته باشد | — |
| `WATCH_STAGNANT_DAYS` | `14` | دارایی «راکد» یعنی در این تعداد روز کمتر از آستانهٔ بعدی بازده داشته | — |
| `WATCH_STAGNANT_RETURN_PCT` | `1.0` | — | — |
| `WATCH_MIN_MOMENTUM_PCT` | `0` | بدون این دروازه، دیده‌بان چاقوهای در حال سقوط را پیشنهاد می‌داد. حداقل مومنتوم (درصد، میانگین ۷/۳۰/۹۰ روزه). صفر = فقط غیرمنفی. | — |
| `WATCH_MIN_TREND_QUALITY` | `0.35` | حداقل کیفیت روند (۰ تا ۱). ۰٫۳۵ = بالای میانگین ۵۰ و شیب مثبت. | — |
| `WATCH_LOOKBACK_BARS` | `72` | تعداد کندل برای سنجش روند (۷۲ = ۳ روز کندل ساعتی) | — |
| `WATCH_AUTO_APPLY` | `false` | false = فقط پیشنهاد بده و منتظر تصمیم بمان (پیش‌فرض و امن) | — |
| `WATCH_REQUIRE_COUNCIL` | `true` | شورای ایجنت‌ها باید جابه‌جایی را تأیید کند | — |
| `WATCH_MAX_SWAPS_PER_CYCLE` | `1` | حداکثر جابه‌جایی در هر چرخه — هرگز جایگزینی دسته‌جمعی | — |
| `JEV_BASE_URL` | — | پیش‌فرض ollama است: بدون کلید، بدون ثبت‌نام، بدون کارت اعتباری. گزینه‌های بدون کلید: ollama \| mock گزینه‌های با کلید رایگان: cloudflare \| groq \| gemini \| cerebras \| mistral \| openrouter ⚠️ این دو کلید بالاتر (بخش «jev»)… | ✅ |

## v10 — کارآموز (the apprentice)

| متغیر | مقدار پیشنهادی | توضیح | اجباری |
|---|---|---|---|
| `APPRENTICE_ENABLED` | `true` | کارآموز دائماً از هر فاعل می‌پرسد «چرا؟» و پاسخ بدون دلیل را رد می‌کند. لاگ آن یک دیتاست آموزشی قابل حمل است، نه یک فایل دیباگ. | — |
| `APPRENTICE_MAX_BYTES_PER_DAY` | `20971520` | سقف بایت روزانه. وقتی پر شود رکوردها دور ریخته می‌شوند، نه دیسک. | — |
| `APPRENTICE_MAX_OPEN_QUESTIONS` | `200` | حداکثر پرسش باز همزمان. قدیمی‌ترین به‌عنوان نقض بسته می‌شود. | — |
| `APPRENTICE_REQUIRE_REASON` | `true` | اگر true باشد، پاسخ کوتاه‌تر از حد زیر رد و به‌عنوان نقض ثبت می‌شود. | — |
| `APPRENTICE_MIN_REASON_CHARS` | `8` | — | — |

## v10 — هوش بازار (market intel)

| متغیر | مقدار پیشنهادی | توضیح | اجباری |
|---|---|---|---|
| `INTEL_ENABLED` | `true` | تکنیک: «توقف رویداد + تمایل احساسی». فقط ریسک را کم می‌کند، هرگز زیاد نمی‌کند. با هیچ URL تنظیم‌شده، enabled=false گزارش می‌شود — نه یک دروغ روی داشبورد. | — |
| `INTEL_REFRESH_MS` | `900000` | — | — |
| `INTEL_TIMEOUT_MS` | `8000` | — | — |
| `INTEL_BLACKOUT_BEFORE_MS` | `1800000` | پنجرهٔ توقف: چند دقیقه قبل و بعد از یک رویداد با اثر بالا، ورود جدید ممنوع. | — |
| `INTEL_BLACKOUT_AFTER_MS` | `900000` | — | — |
| `INTEL_EXTREME_THRESHOLD` | `0.6` | \|tone\| بالاتر از این = «شدید» و ریسک کاهش می‌یابد. | — |
| `INTEL_MAX_RISK_IMPACT` | `0.25` | سقف کاهش ریسک. مقدار بزرگ‌تر هرگز ریسک را بالا نمی‌برد (کلمپ‌شده). | — |
| `INTEL_MACRO_URL` | `https://api.gdeltproject.org/api/v2/doc/doc?query=inflati…` | macro = اقتصادی/سیاست پولی، geo = سیاسی/جغرافیایی، weather = هواشناسی شدید format = json یا rss. path = مسیر نقطه‌ای به آرایه در پاسخ JSON (برای rss لازم نیست). fallbackUrl = منبع پشتیبان. اگر منبع اصلی خطا داد (مثلاً G… | — |
| `INTEL_MACRO_PATH` | `articles` | — | — |
| `INTEL_MACRO_WEIGHT` | `1.0` | — | — |
| `INTEL_MACRO_FORMAT` | `json` | — | — |
| `INTEL_MACRO_FALLBACK_URL` | `https://feeds.bbci.co.uk/news/business/rss.xml` | — | — |
| `INTEL_GEO_URL` | `https://api.gdeltproject.org/api/v2/doc/doc?query=war%20O…` | — | — |
| `INTEL_GEO_PATH` | `articles` | — | — |
| `INTEL_GEO_WEIGHT` | `0.8` | — | — |
| `INTEL_GEO_FORMAT` | `json` | — | — |
| `INTEL_GEO_FALLBACK_URL` | `https://feeds.bbci.co.uk/news/world/rss.xml` | — | — |
| `INTEL_WEATHER_URL` | `https://api.gdeltproject.org/api/v2/doc/doc?query=hurrica…` | — | — |
| `INTEL_WEATHER_PATH` | `articles` | — | — |
| `INTEL_WEATHER_WEIGHT` | `0.5` | — | — |
| `INTEL_WEATHER_FORMAT` | `json` | — | — |
| `INTEL_WEATHER_FALLBACK_URL` | `https://www.aljazeera.com/xml/rss/all.xml` | — | — |
| `INTEL_CRYPTO_URL` | `https://www.coindesk.com/arc/outboundfeeds/rss/` | crypto = خبر کریپتو (CoinDesk / Cointelegraph / Decrypt). RSS، بدون کلید. wire = خبر بازار از سرویس سیمی (رویترز). RSS، بدون کلید. ⚠️ دربارهٔ رویترز: دامنهٔ feeds.reuters.com از ۲۰۲۱ مرده است و www.reuters.com/markets/r… | — |
| `INTEL_CRYPTO_WEIGHT` | `0.9` | وزن خانواده در محاسبهٔ لحن. crypto کمی کمتر از macro است چون تیتر کریپتو معمولاً همان رویداد را با تأخیر بازتاب می‌دهد. | — |
| `INTEL_CRYPTO_FORMAT` | `rss` | — | — |
| `INTEL_CRYPTO_FALLBACK_URL` | `https://cointelegraph.com/rss` | اگر CoinDesk خطا داد (ریدایرکت، ۴۰۳، فید خالی)، Cointelegraph خوانده می‌شود. | — |
| `INTEL_WIRE_URL` | `https://news.google.com/rss/search?q=site:reuters.com+mar…` | آینهٔ RSS گوگل‌نیوز برای خبر بازار رویترز. بدون کلید، بدون ثبت‌نام. | — |
| `INTEL_WIRE_WEIGHT` | `0.9` | وزن خانوادهٔ سرویس سیمی. برابر با crypto تا خبر بازار و خبر کریپتو هم‌وزن باشند. | — |
| `INTEL_WIRE_FORMAT` | `rss` | — | — |
| `INTEL_WIRE_FALLBACK_URL` | `https://feeds.bbci.co.uk/news/business/rss.xml` | اگر آینهٔ گوگل‌نیوز خطا داد، BBC Business خوانده می‌شود. | — |

## v10 — نظیر تاریخی (historical analog)

| متغیر | مقدار پیشنهادی | توضیح | اجباری |
|---|---|---|---|
| `ANALOG_ENABLED` | `true` | شکل فعلی بازار را با شکل‌های گذشته مقایسه می‌کند و می‌گوید بعدشان چه شد. تطابق ضعیف «بدون تطابق» گزارش می‌شود، نه یک قیاس ساختگی. | — |
| `ANALOG_K` | `12` | — | — |
| `ANALOG_MIN_SAMPLES` | `20` | — | — |
| `ANALOG_MAX_DISTANCE` | `0.55` | — | — |
| `ANALOG_MIN_WIN_RATE` | `0.35` | اگر نرخ برد نظیرهای نزدیک از این کمتر بود، ورود جدید مسدود می‌شود. | — |
| `ANALOG_MAX_HISTORY` | `500` | — | — |

---

## یادداشت‌های عملیاتی

1. **`MODE=paper` را تا پایان تست تغییر ندهید.** تنها با `MODE=live` سفارش واقعی ارسال می‌شود.
2. **`SERVER_TOKEN` را حتماً ست کنید.** بدون آن پنل روی سرور عمومی باز است.
3. **`KILL_SWITCH_DD_PCT` را بالاتر از `0.12` نبرید.** قانون‌نامه بند ۷ سقف ۱۲٪ می‌گذارد.
4. **`JEV_PROVIDER` را فقط یک بار تعریف کنید.** تعریف تکراری در `.env` یعنی یکی بی‌صدا نادیده گرفته می‌شود.
5. **`INTEL_*_FALLBACK_URL` را خالی نگذارید.** GDELT از IP دیتاسنتر کد ۴۲۹ می‌دهد.
6. **کلیدها را در Git نگذارید.** `.env` در `.gitignore` است و در زیپ تحویلی هم نیست.
