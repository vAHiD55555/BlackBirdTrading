# کارآموز (The Apprentice) — v10

## چرا وجود دارد

هر تصمیم در این پروژه یک «چرا» دارد. اگر آن چرا ثبت نشود، سیستم فقط یک جعبهٔ سیاه است که نمی‌توان از آن یاد گرفت و نمی‌توان اشتباهش را پیدا کرد.

کارآموز یک فاعل دائمی است که کنار همهٔ فاعل‌های دیگر می‌نشیند و یک سؤال می‌پرسد: **چرا این کار را کردی؟**

## قرارداد (نه پیشنهاد)

1. **هر فاعلی که عمل می‌کند باید بتواند پاسخ دهد.** `ask()` یک پرسش باز می‌کند و `answer()` آن را می‌بندد.
2. **پاسخ بدون دلیل رد می‌شود.** دلیلی کوتاه‌تر از `APPRENTICE_MIN_REASON_CHARS` (پیش‌فرض ۸ کاراکتر) پذیرفته نمی‌شود و به‌عنوان **نقض** ثبت می‌گردد.
3. **سکوت هم نقض است.** پرسشی که بی‌پاسخ بماند دور ریخته نمی‌شود؛ به‌عنوان نقض بسته می‌شود. تصمیمی که کسی نمی‌تواند توضیح دهد، تصمیمی است که کسی نمی‌تواند بهترش کند.
4. **همه‌چیز روی دیسک می‌نشیند.** `data/apprentice-log.jsonl`، فقط-افزودنی، یک رکورد در هر خط.
5. **دیتاست قابل حمل است.** `exportDataset()` سه‌گانه‌های `{instruction, input, output}` می‌سازد — قالبی که هر پایپ‌لاین آموزش می‌فهمد، نه فقط این کارآموز.

## چرا خطرناک نیست

| ریسک | مهار |
|---|---|
| معامله را بلاک کند | `ask()` همگام است و فقط یک شناسه برمی‌گرداند؛ موتور منتظر نمی‌ماند |
| موتور را کرش کند | هیچ متدی throw نمی‌کند |
| رمز را لو بدهد | `redact()` کلیدها، توکن تلگرام و هدر Bearer را قبل از نوشتن پاک می‌کند |
| دیسک را پر کند | سقف بایت روزانه + حلقهٔ محدود پرسش‌های باز |
| حجم حافظه را ببرد | حلقهٔ حافظه با سقف `maxRecordsInMemory` |

## API

```js
const { Apprentice } = require('./agents/apprentice');

const a = new Apprentice({ cfg: cfg.apprentice, log, dir: dataDir, bus });

// مسیر ۱: پرسش و پاسخ
const id = a.ask('scout', 'why propose BTCUSDT?', { symbol: 'BTCUSDT' });
a.answer(id, 'momentum crossed the 20-EMA with breadth above 50%');

// مسیر ۲: مشاهدهٔ یک تصمیم که دلیلش را همراه دارد
a.observe('board', 'reject SOLUSDT', 'depth was $12k, below the $25k floor');

// دیتاست
a.writeDataset();            // data/apprentice-dataset.jsonl
a.exportDataset({ actor: 'scout', limit: 100 });
```

## اتصال به باس

کارآموز به این رویدادها خودکار مشترک می‌شود و دلیل موجود در payload را برمی‌دارد — دلیلی نمی‌سازد:

| رویداد | فاعل | دلیل از کجا |
|---|---|---|
| `entry:submitted` | trader | `proposal.rationale` |
| `trade:closed` | trader | `rationale` یا `exit.reason` |
| `report:ready` | reporter | `report.lessons` |
| `audit:alert` | auditor | `message` |

## استفادهٔ بعدی

فایل `apprentice-dataset.jsonl` را می‌توان روی **هر** مدلی به کار برد:

- fine-tune یک مدل کوچک محلی
- few-shot در پرامپت یک مدل بزرگ‌تر
- آموزش یک سیستم موازی معامله‌گر

قالب عمداً ساده است تا وابسته به هیچ ارائه‌دهنده‌ای نباشد.

## تنظیمات پنل

| متغیر | پیش‌فرض | معنا |
|---|---|---|
| `APPRENTICE_ENABLED` | `true` | روشن/خاموش |
| `APPRENTICE_MAX_BYTES_PER_DAY` | `20971520` | سقف بایت روزانه |
| `APPRENTICE_MAX_OPEN_QUESTIONS` | `200` | حداکثر پرسش باز |
| `APPRENTICE_REQUIRE_REASON` | `true` | الزام دلیل |
| `APPRENTICE_MIN_REASON_CHARS` | `8` | حداقل طول دلیل |

## خاموش کردن

`APPRENTICE_ENABLED=false` — هیچ فایلی نوشته نمی‌شود و هیچ رویدادی ثبت نمی‌گردد. بقیهٔ سیستم دست‌نخورده کار می‌کند.
