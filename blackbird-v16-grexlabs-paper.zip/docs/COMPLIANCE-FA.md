# BlackBird Trader — جدول انطباق قانون‌نامه با کد (v7)

منبع قانون: `docs/sources/constitution.md` (بندهای ۱ تا ۲۷) و `docs/sources/inventory.md`.
هر ردیف: بند قانون → مقدار/رفتار قانون → مقدار/رفتار کد → وضعیت.

وضعیت‌ها: **منطبق** / **اصلاح شد** / **انحراف آگاهانه** / **خارج از دامنه**.

---

## ۱. حدود عددی (بند ۷)

| بند | قانون | کد (v7) | وضعیت |
|---|---|---|---|
| ۷ | سرمایهٔ شروع ۵٬۰۰۰ USDT | `risk.startEquity = 5000` | منطبق |
| ۷ | سقف هر پوزیشن تاکتیکی ۲۰٪ Equity | `maxPositionPct = 0.2` | منطبق |
| ۷ | حداکثر پوزیشن هم‌زمان Risk Manager = ۸ | `maxOpenPositions = 8` | منطبق |
| ۷ | سقف مواجههٔ هر نماد ۲۵٪ Equity | `maxSymbolExposurePct = 0.25` | منطبق |
| ۷ | حداکثر زیان روزانه ۴٪ | `maxDailyLossPct = 0.04` | منطبق (در v6 از ۳٪ اصلاح شد) |
| ۷ | حداکثر معاملات روزانه ۳۰ | `maxDailyTrades = 30` | منطبق (در v6 از ۶۰ اصلاح شد) |
| ۷ | حداکثر باخت متوالی ۴ | `maxConsecutiveLosses = 4` | منطبق |
| ۷ | Cooldown پس از باخت‌های متوالی ۶۰۰ ثانیه | `cooldownAfterLossMs = 600000` | منطبق |
| ۷ | Kill Switch Drawdown ۱۲٪ | `killSwitchDrawdownPct = 0.12` | منطبق |
| ۷ | حداقل Notional ۱۵ دلار | `minNotionalUsd = 15` | منطبق |
| ۷ | سقف Net Exposure ۷۰٪ Equity | `maxNetExposurePct = 0.7` | منطبق |
| ۷ | هدف سود ناخالص نرم هر معامله ۱ دلار | `targetProfitUsdPerTrade = 1.0` | منطبق |
| ۷ | Risk per trade ۰٫۵٪ Equity | `riskPerTradePct = 0.005` | منطبق |
| ۷ | Rotator Gross cap ۷۰٪ | `strategy.rotator.maxGrossPct = 70` | منطبق |
| ۷ | Rotator per-position ۹٪ | `strategy.rotator.perPositionPct = 9` | منطبق |
| ۷ | Rotator max positions ۶ | `strategy.rotator.maxPositions = 6` | منطبق |

## ۲. قوانین سخت Risk Manager (بند ۸)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۸.۱ | Risk Manager وتوی قطعی است | `risk.check()` → `{ok:false}` و Board آن را veto می‌کند | منطبق |
| ۸.۲ | در Halt ورود جدید ممنوع | `if (this.halted) return veto(...)` | منطبق |
| ۸.۳ | سقف معاملات روزانه | `maxDailyTrades` در `check()` | منطبق |
| ۸.۴ | زیان روزانه از ۴٪ عبور نکند | `maxDailyLossPct` + halt روزانه | منطبق |
| ۸.۵ | Drawdown به ۱۲٪ نرسد | `killSwitchDrawdownPct` | منطبق |
| ۸.۶ | Cooldown جهانی | `cooldowns` در state | منطبق |
| ۸.۷ | تعداد پوزیشن باز از سقف عبور نکند | `maxOpenPositions` | منطبق |
| ۸.۸ | هر نماد فقط یک پوزیشن | `portfolio.hasPosition()` | منطبق |
| ۸.۹ | Exposure هر نماد ≤ ۲۵٪ | `maxSymbolExposurePct` | منطبق |
| ۸.۱۰ | Net Exposure ≤ ۷۰٪ | `maxNetExposurePct` | منطبق |
| ۸.۱۱ | Gross تاکتیکی = maxOpenPositions × maxPositionPct × equity | در `check()` محاسبه می‌شود | منطبق |
| ۸.۱۲ | Equity زیر کف شروع نرود | `equityFloor` پس از Kill Switch | منطبق |
| ۸.۱۳ | هر رد شدن علت و چک‌های Pass/Fail ثبت کند | `veto()` → `checks[]` + `vetoes[]` | منطبق |

## ۳. Broker و هزینه‌ها (بند ۱۴)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۱۴ | حالت پیش‌فرض Paper | `mode: "paper"` در config.json | منطبق |
| ۱۴ | هزینه‌ها در Edge و PnL لحاظ شوند | `fees` در `risk.size()` و `portfolio.close()` | منطبق |
| ۱۴ | Maker 2bps / Taker 5bps / Slippage 0.6bps per $1000 | `fees = {2, 5, 0.6}` | منطبق (در v6 از ۷٫۵/۱۰ اصلاح شد) |
| ۱۴ | Latency پایه ۱۲۰ms | `fees.latencyMs = 120` | منطبق |
| ۱۴ | Limit بدون Fill معامله حساب نشود | `pendingEntries` تا `filled` | منطبق |
| ۱۴ | سفارش منقضی از Pending پاک و در Journal ثبت شود | `trader.onClock()` → `order_expired` | منطبق |
| ۱۴ | Live در این نسخه تأیید نشده | `live-broker.js` → `_refuse()` | منطبق |

## ۴. Board سه‌نفره (بند ۱۵)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۱۵.۱ | Risk Officer: Risk Check + Confidence floor 0.55 + حداقل Notional | `_riskOfficer()` | **اصلاح شد** — floor از ۰٫۴۵/۰٫۳ به ۰٫۵۵ |
| ۱۵.۲ | Execution Officer: Book، تازگی Quote، Spread، Depth، JEV p99، Edge خالص | `_executionOfficer()` | منطبق |
| ۱۵.۳ | Integrity Officer: مقایسه با Witness، پیوستگی داده، Candle Gap | `_integrityOfficer()` | منطبق |
| ۱۵ | حداقل ۲ رأی موافق از ۳ | `minApprove = 2` | منطبق |
| ۱۵ | `requireZeroVetoes = true` | `requireZeroVetoes = true` | منطبق |
| ۱۵ | Abstain با Reject یکی نیست | `vote: 'abstain'` جدا شمرده می‌شود | منطبق |
| ۱۵ | Witness غیرفعال → Integrity Abstain | `if (!cfg.witness.enabled) return abstain` | منطبق |

## ۵. JEV و اجرا (بند ۱۳)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۱۳ | Deadline سخت؛ سفارش کهنه ارسال نشود | `jev.build()` با `maxLatencyMs` | منطبق |
| ۱۳ | Quantise قیمت به tick size | `PRICE_STEP` + `guessPriceStep()` | منطبق |
| ۱۳ | Latency اندازه‌گیری و ثبت شود | `jev.record()` | منطبق |

## ۶. Witness و اثبات صحت (بند ۱۶)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۱۶ | قیمت مستقل از منبع دوم | `witness.price()` از صرافی دوم | منطبق |
| ۱۶ | واگرایی بیش از حد → رد | `maxPriceDivergenceBps` | منطبق |
| ۱۶ | بازهٔ به‌روزرسانی قابل تنظیم | `WITNESS_UPDATE_MS` (در v6 از hard-code اصلاح شد) | منطبق |

## ۷. Trials، Backtest و اعتبار آماری (بند ۲۰)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۲۰ | هر بک‌تست در Trial Registry ثبت شود | `TrialRegistry.record()` در CLI | منطبق |
| ۲۰ | DSR برای اصلاح Selection Bias | `src/jev/trials.js` | منطبق |
| ۲۰ | بک‌تست آفلاین، بدون شبکه و کلید | `src/backtest/run.js` | منطبق |
| ۲۰ | بک‌تست باید همان کد زنده را اجرا کند | `runBacktest` از `Rotator` واقعی استفاده می‌کند | منطبق |
| ۲۰ | **بک‌تست باید استاپ را اجرا کند** | `rotator.onTick()` در حلقهٔ بازپخش | **اصلاح شد** — قبلاً صدا زده نمی‌شد |
| ۲۰ | **مدت نگهداری معامله باید معتبر باشد** | `Position.openedAt` از ساعت بازپخش | **اصلاح شد** — قبلاً منفی می‌شد |

## ۸. امنیت و حدود دسترسی (بند ۱۰)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۱۰.۳ | هیچ توکن/کلیدی در بسته نباشد | `make-zip` فایل `.env` را حذف می‌کند | **اصلاح شد** — در v5 توکن تلگرام داخل زیپ بود |
| ۱۰ | دادهٔ اجرای قبلی در بسته نباشد | `make-zip` پوشهٔ `data` را رد می‌کند | **اصلاح شد** — در v5 ژورنال داخل زیپ بود |

## ۹. استقلال از هوش مصنوعی (بند ۳)

| بند | قانون | کد | وضعیت |
|---|---|---|---|
| ۳ | موتور بدون مدل هم کار کند | `jev` اختیاری؛ موتور با قواعد قطعی | منطبق |
| ۳ | مدل پیش‌فرض بدون کلید | `JEV_PROVIDER=ollama` | منطبق (در v5 از مدل پولی اصلاح شد) |
| ۳ | انتخاب مدل از پنل | `JEV_PROVIDER` / `JEV_MODEL` / `JEV_BASE_URL` | منطبق |

## ۱۰. دیده‌بان (خارج از قانون‌نامهٔ اصلی)

| مورد | رفتار | وضعیت |
|---|---|---|
| کشف فرصت جدید | endpoint عمومی صرافی، بدون کلید | منطبق با اصل «سرویس رایگان» |
| جایگزینی نه اضافه‌کردن | `notional = min(swap.notional, incumbent.notional)` | منطبق |
| تصویب شورا | `requireCouncil = true` | منطبق |
| اعمال واقعی | `applySwap()` + `runCycle()` | **اصلاح شد** — قبلاً مسیر اعمال وجود نداشت |
| پیش‌فرض محافظه‌کار | `autoApply = false` | منطبق |
| حداکثر یک جابه‌جایی در چرخه | `maxSwapsPerCycle = 1` | منطبق |
| خطای شورا = رد | `review()` → `approved:false` | منطبق |

---

## خلاصهٔ انحراف‌های باقی‌مانده (آگاهانه)

1. **`confidenceFloor` در `config.json` قابل بازنویسی است.** پیش‌فرض ۰٫۵۵ است، اما اپراتور می‌تواند از پنل پایین بیاورد. این عمدی است: قانون سقف می‌گذارد، نه کف اجباری.
2. **دیده‌بان در قانون‌نامهٔ اصلی نیست.** به‌عنوان افزودهٔ v5/v6/v7 اضافه شده و هیچ سقف ریسکی را بالا نمی‌برد.
3. **Live تأیید نشده.** طبق بند ۱۴، `live-broker` عمداً همه‌چیز را رد می‌کند.
