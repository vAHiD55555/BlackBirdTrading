/**
 * BlackBird — کارگر میانی (Cloudflare Worker)
 *
 * دو مسیر دارد و هیچ‌کدام در مسیر تصمیم معامله نیست:
 *
 *   GET  /healthz        — پاسخ سریع برای پایش
 *   GET  /v1/snapshot    — آخرین قیمت چند نماد، با کش لبه‌ای
 *   POST /v1/llm         — درگاه واحد مدل، با کش پاسخ
 *
 * قواعد:
 *   • هر خطا به JSON برمی‌گردد، نه به صفحه‌ی خطا.
 *   • اگر کش در دسترس نبود، کار بدون کش ادامه می‌یابد.
 *   • توکن محرمانه فقط از متغیر محیطی خوانده می‌شود.
 */

const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });

/** نمادهای درخواستی را از رشته‌ی کوئری بیرون می‌کشد. */
function parseSymbols(raw) {
  return String(raw || '')
    .split(',')
    .map((s) => s.trim().toUpperCase())
    .filter((s) => /^[A-Z0-9]{2,20}$/.test(s))
    .slice(0, 20);
}

/** امضای محتوا، برای کلید کش. */
async function digest(text) {
  const bytes = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 40);
}

async function cacheGet(env, key) {
  try {
    return env.CACHE ? await env.CACHE.get(key, 'text') : null;
  } catch {
    return null;
  }
}

async function cachePut(env, key, value, ttl) {
  try {
    if (env.CACHE) await env.CACHE.put(key, value, { expirationTtl: ttl });
  } catch {
    /* کش اختیاری است؛ نبودش کار را نمی‌شکند */
  }
}

/** یک نماد را از صرافی می‌خواند و به شکل یکسان برمی‌گرداند. */
async function fetchQuote(symbol, timeoutMs) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(new Error('upstream timeout')), timeoutMs);
  try {
    const url = `https://api.mexc.com/api/v3/ticker/bookTicker?symbol=${encodeURIComponent(symbol)}`;
    const res = await fetch(url, { signal: ctl.signal, headers: { accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${symbol}`);
    const t = await res.json();
    const bid = Number(t.bidPrice);
    const ask = Number(t.askPrice);
    if (!(bid > 0) || !(ask > 0)) throw new Error(`empty book for ${symbol}`);
    return { bid, ask, last: (bid + ask) / 2, ts: Date.now() };
  } finally {
    clearTimeout(timer);
  }
}

async function handleSnapshot(req, env, url) {
  const symbols = parseSymbols(url.searchParams.get('symbols'));
  if (!symbols.length) return json(400, { ok: false, error: 'symbols is required' });

  const ttl = Math.max(5, Math.min(120, Number(env.SNAPSHOT_TTL_SEC) || 15));
  const timeoutMs = Math.max(1000, Number(env.UPSTREAM_TIMEOUT_MS) || 4000);
  const out = {};
  let cachedCount = 0;

  await Promise.all(
    symbols.map(async (sym) => {
      const key = `snap:${sym}`;
      const hit = await cacheGet(env, key);
      if (hit) {
        try {
          out[sym] = { ...JSON.parse(hit), cached: true };
          cachedCount++;
          return;
        } catch {
          /* کش خراب: دوباره بگیر */
        }
      }
      try {
        const q = await fetchQuote(sym, timeoutMs);
        out[sym] = { ...q, cached: false };
        await cachePut(env, key, JSON.stringify(q), ttl);
      } catch (e) {
        out[sym] = { error: String(e.message || e) };
      }
    }),
  );

  const okCount = Object.values(out).filter((v) => !v.error).length;
  return json(okCount ? 200 : 502, {
    ok: okCount > 0,
    ts: Date.now(),
    cached: cachedCount === symbols.length,
    symbols: out,
  });
}

async function handleLlm(req, env) {
  let body;
  try {
    body = await req.json();
  } catch {
    return json(400, { ok: false, error: 'invalid JSON body' });
  }
  const messages = Array.isArray(body?.messages) ? body.messages : null;
  if (!messages || !messages.length) return json(400, { ok: false, error: 'messages is required' });

  const model = String(body.model || env.LLM_MODEL || 'openai/gpt-oss-20b');
  const baseUrl = String(env.LLM_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/+$/, '');
  const apiKey = String(env.LLM_API_KEY || '');
  if (!apiKey) return json(503, { ok: false, error: 'LLM_API_KEY is not set on the worker' });

  const useCache = body.cache !== false;
  const key = `llm:${await digest(JSON.stringify({ model, messages }))}`;
  if (useCache) {
    const hit = await cacheGet(env, key);
    if (hit) {
      try {
        const parsed = JSON.parse(hit);
        return json(200, { ok: true, text: parsed.text, model, cached: true });
      } catch {
        /* کش خراب: دوباره بگیر */
      }
    }
  }

  const ctl = new AbortController();
  const timeoutMs = Math.max(2000, Number(env.LLM_TIMEOUT_MS) || 20000);
  const timer = setTimeout(() => ctl.abort(new Error('llm timeout')), timeoutMs);
  try {
    const res = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model,
        messages,
        temperature: body.temperature ?? 0,
        max_tokens: body.max_tokens ?? 400,
      }),
      signal: ctl.signal,
    });
    const text = await res.text();
    if (!res.ok) return json(502, { ok: false, error: `upstream HTTP ${res.status}`, detail: text.slice(0, 300) });
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      return json(502, { ok: false, error: 'upstream returned non-JSON' });
    }
    const answer = parsed?.choices?.[0]?.message?.content;
    if (typeof answer !== 'string' || !answer.trim()) return json(502, { ok: false, error: 'empty completion' });
    if (useCache) await cachePut(env, key, JSON.stringify({ text: answer }), 6 * 60 * 60);
    return json(200, { ok: true, text: answer, model, cached: false });
  } catch (e) {
    return json(502, { ok: false, error: String(e.message || e) });
  } finally {
    clearTimeout(timer);
  }
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);

    if (url.pathname === '/healthz') return json(200, { ok: true, ts: Date.now() });

    // توکن مشترک: اگر روی کارگر تنظیم شده باشد، همه‌ی مسیرها بسته‌اند.
    const expected = String(env.BB_PROXY_TOKEN || '');
    if (expected && req.headers.get('x-bb-token') !== expected) {
      return json(401, { ok: false, error: 'unauthorized' });
    }

    if (url.pathname === '/v1/snapshot' && req.method === 'GET') {
      return handleSnapshot(req, env, url);
    }
    if (url.pathname === '/v1/llm' && req.method === 'POST') {
      return handleLlm(req, env);
    }
    return json(404, { ok: false, error: 'not found' });
  },
};
