#!/usr/bin/env node
'use strict';
/**
 * «این کتاب از لحظه‌ی X تا الان چقدر سود/زیان داشت؟»
 *
 *   node scripts/pnl-since.js --at=2026-11-03T01:03:00Z
 *
 * کتاب هدف را در لحظه‌ی داده‌شده می‌سازد، با قیمت همان کندل وارد می‌شود،
 * حد ضرر ۶×ATR می‌گذارد و بعد با کندل‌های بعدی جلو می‌آید: اگر قیمت به حد
 * ضرر خورد (قبل از هر چیز) پوزیشن بسته می‌شود، وگرنه تا آخرین قیمت mark می‌شود.
 */
const { loadConfig } = require('../src/config');
const { createExchange } = require('../src/data/exchanges');
const { Rotator, atrSeries, ema } = require('../src/strategy/rotator');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const AT = Date.parse(arg('at', new Date(Date.now() - 3600000).toISOString()));
const EQUITY = Number(arg('equity', 5000));

(async () => {
  const cfg = loadConfig();
  const ex = createExchange(cfg.exchange);
  const bars = {};
  for (const sym of cfg.symbols) {
    const rows = await ex.klines(sym, 420, '1h');
    bars[sym] = rows.map((r) => ({ t: r.t, o: r.o, h: r.h, l: r.l, c: r.c, v: r.v }));
  }
  const cut = (list) => list.filter((b) => b.t + 3600000 <= AT);
  const at = Object.fromEntries(Object.keys(bars).map((s) => [s, cut(bars[s])]));

  const hub = { get: (s) => ({ bars: { toArray: () => at[s] }, book: () => null }) };
  const rot = new Rotator({
    cfg, log: { info() {}, warn() {}, error() {}, debug() {} },
    store: { append() {} },
    risk: { state: { equity: EQUITY }, peakEquity: EQUITY, halted: false },
    portfolio: { positions: new Map(), ids: () => [], openPositions: () => [], hasPosition: () => false, get: () => null, unrealisedTotal: () => 0 },
    broker: { submit: () => ({ status: 'rejected' }) },
    hub, bus: { emit() {} },
  });

  const book = rot.targetBook(at);
  if (!book.size) { console.log('کتاب در این لحظه خالی بود.'); return; }

  const scale = Math.min(1, rot.rc.maxGrossPct / [...book.values()].reduce((a, t) => a + t.pct, 0));

  console.log(`\nلحظه‌ی ورود: ${new Date(AT).toISOString().replace('T', ' ').slice(0, 16)} UTC · سرمایه ${EQUITY}$\n`);
  console.log('نماد'.padEnd(9) + 'جهت'.padEnd(7) + 'ورود'.padStart(11) + 'حدضرر'.padStart(11) + 'الان'.padStart(11) + 'P&L$'.padStart(9) + '  وضعیت');
  console.log('-'.repeat(72));

  let total = 0, open = 0;
  for (const [sym, t] of book) {
    const entry = at[sym][at[sym].length - 1].c;
    const a = atrSeries(at[sym], 14);
    const atrv = a[a.length - 1];
    const stop = t.dir > 0 ? entry - 6 * atrv : entry + 6 * atrv;
    const notional = EQUITY * (t.pct / 100) * scale;
    const qty = notional / entry;

    let closed = null;
    const full = bars[sym].filter((b) => b.t > AT);
    for (const b of full) {
      if (t.dir > 0 && b.l <= stop) { closed = { price: stop, t: b.t }; break; }
      if (t.dir < 0 && b.h >= stop) { closed = { price: stop, t: b.t }; break; }
    }
    const last = bars[sym][bars[sym].length - 1].c;
    const px = closed ? closed.price : last;
    const pnl = (px - entry) * qty * t.dir - notional * 0.0005 * 2;
    total += pnl;
    if (!closed) open++;
    console.log(
      sym.padEnd(9) + (t.dir > 0 ? 'خرید' : 'فروش').padEnd(7) +
      entry.toFixed(4).padStart(11) + stop.toFixed(4).padStart(11) + px.toFixed(4).padStart(11) +
      pnl.toFixed(2).padStart(9) + '  ' + (closed ? 'حد ضرر @ ' + new Date(closed.t).toISOString().slice(11, 16) + 'Z' : 'باز')
    );
  }
  console.log('-'.repeat(72));
  console.log(`جمع P&L: ${total >= 0 ? '+' : ''}${total.toFixed(2)}$  (${((total / EQUITY) * 100).toFixed(2)}%) · پوزیشن باز: ${open}/${book.size}\n`);
})().catch((e) => { console.error('failed:', e.message); process.exit(1); });
