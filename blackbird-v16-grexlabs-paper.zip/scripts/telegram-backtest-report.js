#!/usr/bin/env node
'use strict';
/**
 * Send the 6-month backtest comparison to the configured Telegram channel.
 *
 *   node scripts/telegram-backtest-report.js
 *
 * Reads the two JSON files the backtest CLI wrote (baseline and fixed) and
 * posts one message with the numbers, the exit-reason split and a short
 * excerpt of the reviewed trades. Uses the project's own notifier, so it
 * exercises exactly the path the hourly report uses.
 *
 * Exit codes: 0 sent, 1 not sent (reason printed).
 */
const fs = require('node:fs');
const path = require('node:path');
const { loadConfig } = require(path.join(__dirname, '..', 'src', 'config'));
const { sendConfiguredTelegram } = require(path.join(__dirname, '..', 'src', 'notify', 'telegram'));

const read = (p) => {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
};

const fmt = (n, d = 2) => (n === null || n === undefined || !Number.isFinite(Number(n)) ? '—' : Number(n).toFixed(d));

function exitSplit(trades) {
  const m = new Map();
  for (const t of trades || []) {
    const r = t.exit?.reason || 'unknown';
    m.set(r, (m.get(r) || 0) + 1);
  }
  return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join('  ');
}

(async () => {
  const cfg = loadConfig();
  const base = read(path.join(__dirname, '..', 'data', 'backtest', 'base6m.json'));
  const fixed = read(path.join(__dirname, '..', 'data', 'backtest', 'fixed6m.json'));
  const trades = read(path.join(__dirname, '..', 'data', 'backtest', 'trades_fixed6m.json'));

  if (!base || !fixed) {
    console.error('missing data/backtest/base6m.json or fixed6m.json — run the backtest first');
    process.exit(1);
  }

  const b = base.summary;
  const f = fixed.summary;
  const list = (trades && trades.trades) || [];

  const lines = [
    '🐦 BlackBird — بک‌تست ۶ ماهه (۱ ساعته، ۴ نماد، MEXC)',
    '',
    'قبل از اصلاح:',
    `  بازده ${fmt(b.returnPct)}%  |  افت ${fmt(b.maxDrawdownPct)}%  |  ${b.trades} معامله`,
    `  برد ${fmt(b.hitRate)}%  |  PF ${fmt(b.profitFactor)}  |  شارپ ${fmt(b.sharpePerPeriod, 4)}`,
    '',
    'بعد از اصلاح (نردبان trailing طبق بند ۱۲):',
    `  بازده ${fmt(f.returnPct)}%  |  افت ${fmt(f.maxDrawdownPct)}%  |  ${f.trades} معامله`,
    `  برد ${fmt(f.hitRate)}%  |  PF ${fmt(f.profitFactor)}  |  شارپ ${fmt(f.sharpePerPeriod, 4)}`,
    '',
    `دلیل خروج‌ها (بعد از اصلاح): ${exitSplit(list)}`,
    '',
    'نمونهٔ معاملات:',
  ];

  for (const t of list.slice(0, 8)) {
    lines.push(
      `  ${t.symbol} ${t.side}  ${fmt(t.entry?.price, 4)} → ${fmt(t.exit?.price, 4)}  ` +
      `${t.exit?.reason || '—'}  ${fmt(t.pnlPct)}%`
    );
  }

  lines.push('', '⚠️ همه در حالت paper — هیچ سفارش واقعی ارسال نشد.');

  const text = lines.join('\n');
  const r = await sendConfiguredTelegram(cfg, 'report', text);

  if (r && r.ok) {
    console.log(`✓ sent  chunks=${r.chunks ?? 1}  chat=${r.chatId}`);
    process.exit(0);
  }
  console.error(`✗ not sent: ${r?.reason || r?.description || 'unknown'}`);
  process.exit(1);
})();
