#!/usr/bin/env node
'use strict';
/**
 * BlackBird — historical backtest on real 1m candles.
 *
 * This is the honest answer to "will it make $1 per trade?": it replays the
 * *same* scout and board code that runs live, against real Binance candles,
 * with taker entry + maker TP + taker SL fees and slippage.
 *
 *   node scripts/backtest.js --days=7 --symbols=BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT
 *   node scripts/backtest.js --days=3 --relaxed     # lower volatility gate
 */
const fs = require('node:fs');
const path = require('node:path');
const { loadConfig } = require('../src/config');
const { createExchange } = require('../src/data/exchanges');
const { Ring, mean, quantile } = require('../src/core/util');
const { computeSnapshot } = require('../src/data/indicators');
const { classify } = require('../src/data/regime');
const { Scout } = require('../src/agents/scout');
const { Board } = require('../src/agents/board');
const { RiskManager } = require('../src/risk/risk');
const { Portfolio } = require('../src/exec/portfolio');
const { Jev } = require('../src/exec/jev');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const flag = (n) => process.argv.includes(`--${n}`);

// ---------------------------------------------------------------------------
// in-memory store (a backtest must not pollute the live journal)
// ---------------------------------------------------------------------------
const memStore = () => {
  const log = [];
  return {
    state: {
      equity: 0,
      dayStartEquity: 0,
      counters: { day: '', tradesToday: 0, wins: 0, losses: 0, trades: 0, grossProfit: 0, grossLoss: 0, lossesStreak: 0 },
      cooldowns: {},
      learned: {},
    },
    append: (type, data) => log.push({ type, data }),
    readJournal: () => [],
    verifyChain: () => ({ ok: true, count: 0 }),
    saveState: () => {},
    entries: log,
  };
};

class FakeFeed {
  constructor(symbol, cfg) {
    this.symbol = symbol;
    this.cfg = cfg;
    this.bars = new Ring(500);
    this.ticker = null;
    this.depth = null;
    this.lastQuoteTs = Date.now();
    this.gapCount = 0;
    this.quoteSource = 'backtest';
    this._snap = null;
  }
  ingest(b) {
    this.bars.push(b);
    this._snap = null;
  }
  setBar(b) {
    const spreadBps = 1.2;
    const bid = b.c * (1 - spreadBps / 20000);
    const ask = b.c * (1 + spreadBps / 20000);
    this.ticker = { symbol: this.symbol, bid, ask, last: b.c, ts: Date.now() };
    const depthUsd = Math.min(3e6, b.v * b.c * 30);
    this.depth = {
      bids: [[bid, depthUsd / bid / 2]],
      asks: [[ask, depthUsd / ask / 2]],
      ts: Date.now(),
    };
    this.lastQuoteTs = Date.now();
  }
  get isStale() {
    return false;
  }
  book() {
    const t = this.ticker;
    if (!t) return null;
    const mid = (t.bid + t.ask) / 2;
    return {
      bid: t.bid,
      ask: t.ask,
      mid,
      spreadBps: ((t.ask - t.bid) / mid) * 10000,
      bidNotional: this.depth ? this.depth.bids[0][0] * this.depth.bids[0][1] : 0,
      askNotional: this.depth ? this.depth.asks[0][0] * this.depth.asks[0][1] : 0,
      depthUsd: this.depth ? this.depth.bids[0][0] * this.depth.bids[0][1] + this.depth.asks[0][0] * this.depth.asks[0][1] : 0,
      quoteAgeMs: 0,
      depthTs: Date.now(),
    };
  }
  snapshot() {
    if (this._snap) return this._snap;
    const minBars = this.cfg.strategy.bbPeriod + this.cfg.strategy.atrPeriod + 10;
    if (this.bars.length < minBars) return null;
    const book = this.book();
    this._snap = computeSnapshot(this.bars.toArray(), this.cfg.strategy, {
      symbol: this.symbol,
      bid: book?.bid,
      ask: book?.ask,
      mid: book?.mid,
      spreadBps: book?.spreadBps ?? null,
      depthUsd: book?.depthUsd ?? null,
      quoteAgeMs: 0,
      stale: false,
    });
    return this._snap;
  }
}

class FakeHub {
  constructor(feeds) {
    this.feeds = feeds;
  }
  get(s) {
    return this.feeds.get(s);
  }
  all() {
    return [...this.feeds.values()];
  }
}

async function fetchHistory(exchange, symbol, days, tf) {
  const cacheDir = path.join(__dirname, '..', 'data', 'cache');
  fs.mkdirSync(cacheDir, { recursive: true });
  const cacheFile = path.join(cacheDir, `kl-${symbol}-${days}-${tf}-o${arg('offset', 0)}.json`);
  try {
    const st = fs.statSync(cacheFile);
    if (Date.now() - st.mtimeMs < 30 * 60 * 1000) {
      return JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    }
  } catch { /* no cache */ }
  const bars = await fetchHistoryRemote(exchange, symbol, days, tf);
  try { fs.writeFileSync(cacheFile, JSON.stringify(bars)); } catch { /* ignore */ }
  return bars;
}

async function fetchHistoryRemote(exchange, symbol, days, tf) {
  const TF_MIN = { '1m': 1, '3m': 3, '5m': 5, '15m': 15, '30m': 30, '1h': 60 };
  const need = Math.floor((days * 1440) / (TF_MIN[tf] || 5));
  const out = [];
  let endTime = Date.now() - (Number(arg('offset', 0)) * 86400000);
  while (out.length < need) {
    const limit = Math.min(1000, need - out.length);
    const url = `${exchange.baseUrl || ''}`;
    const rows = await exchange.klinesBefore(symbol, endTime, limit, tf);
    if (!rows.length) break;
    out.unshift(...rows);
    endTime = rows[0].t - 1;
    if (rows.length < limit) break;
  }
  // de-duplicate & sort
  const seen = new Set();
  return out.filter((b) => (seen.has(b.t) ? false : (seen.add(b.t), true))).sort((a, b) => a.t - b.t);
}

async function main() {
  const days = Number(arg('days', 7));
  const makerFee = arg('makerfee', '');
  const takerFee = arg('takerfee', '');
  const tf = arg('tf', '');
  const offsetDays = Number(arg('offset', 0)); // shift the window back in time
  const symbolArg = arg('symbols', '');
  const cfg = loadConfig();
  if (symbolArg) cfg.symbols = symbolArg.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
  const tsMin = Number(arg('timestop', 0));
  if (tsMin > 0) cfg.strategy.timeStopMs = tsMin * 60000;
  const entryMode = arg('entry', cfg.strategy.entryType);
  cfg.strategy.entryType = entryMode;
  const minVol = arg('minvol', '');
  if (minVol !== '') cfg.strategy.minVolPercentile = Number(minVol);
  const minEdge = arg('minedge', '');
  if (minEdge !== '') cfg.scout.minExpectedEdgeBps = Number(minEdge);
  if (makerFee !== '') cfg.fees.makerBps = Number(makerFee);
  if (takerFee !== '') cfg.fees.takerBps = Number(takerFee);
  if (flag('relaxed')) {
    cfg.strategy.minVolPercentile = 0.4;
    cfg.strategy.minTpBps = 18;
    cfg.board.confidenceFloor = 0.45;
  }
  if (tf) cfg.data.timeframe = tf;
  const TF_MS = { '1m': 60000, '3m': 180000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000 };
  cfg.data.intervalMs = TF_MS[cfg.data.timeframe] || 300000;
  cfg.mode = 'paper';

  console.log(`\n🐦 BlackBird backtest — ${days}d, ${cfg.symbols.join(', ')} @ ${cfg.exchange}`);
  console.log(`   fees: taker ${cfg.fees.takerBps}bps / maker ${cfg.fees.makerBps}bps, equity ${cfg.risk.startEquity}`);
  console.log(`   entry=${cfg.strategy.entryType} timeStop=${cfg.strategy.timeStopMs / 60000}min minVolP=${cfg.strategy.minVolPercentile} minEdge=${cfg.scout.minExpectedEdgeBps}\n`);

  const ex = createExchange(cfg.exchange);
  // adapters expose klines(symbol,limit); we need a time cursor for history
  ex.klinesBefore = async (symbol, endTime, limit, tfArg) => {
    const interval = tfArg || cfg.data.timeframe;
    const id = ex.id;
    if (id === 'binance') {
      const d = await ex.http.getJson(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}&endTime=${endTime}`);
      return d.map((r) => ({ t: +r[0], o: +r[1], h: +r[2], l: +r[3], c: +r[4], v: +r[5] }));
    }
    if (id === 'bybit') {
      const TF = { '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30', '1h': '60' };
      const d = await ex.http.getJson(`https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}&interval=${TF[interval] || '5'}&limit=${Math.min(limit, 1000)}&end=${endTime}`);
      return (d.result?.list || []).map((r) => ({ t: +r[0], o: +r[1], h: +r[2], l: +r[3], c: +r[4], v: +r[5] })).sort((a, b) => a.t - b.t);
    }
    throw new Error(`history cursor not implemented for ${id}`);
  };

  const data = {};
  for (const sym of cfg.symbols) {
    process.stdout.write(`   fetching ${sym}… `);
    data[sym] = await fetchHistory(ex, sym, days, cfg.data.timeframe);
    console.log(`${data[sym].length} bars`);
  }
  const n = Math.min(...Object.values(data).map((d) => d.length));
  if (!n) throw new Error('no history fetched');

  const feeds = new Map(cfg.symbols.map((s) => [s, new FakeFeed(s, cfg)]));
  const hub = new FakeHub(feeds);
  const store = memStore();
  store.state.equity = cfg.risk.startEquity;
  store.state.dayStartEquity = cfg.risk.startEquity;

  const risk = new RiskManager({ cfg, store, log: quietLog() });
  const portfolio = new Portfolio(quietLog());
  const jev = new Jev(cfg, quietLog());
  jev.prewarm(cfg.symbols, Object.fromEntries(cfg.symbols.map((s) => [s, data[s][n - 1].c])));
  const learner = { bias: () => 0 };
  const scout = new Scout({ cfg, log: quietLog(), store, hub, risk, learner });
  const board = new Board({ cfg, log: quietLog(), store, risk, witness: null, hub, jev });

  const trades = [];
  const equityCurve = [];
  const warmup = cfg.strategy.bbPeriod + cfg.strategy.atrPeriod + 10;
  for (const sym of cfg.symbols) {
    const feed = feeds.get(sym);
    for (let k = 0; k < warmup; k++) if (data[sym][k]) feed.ingest(data[sym][k]);
  }
  let peak = cfg.risk.startEquity;

  for (let i = warmup; i < n; i++) {
    const bar = data[cfg.symbols[0]][i];
    if (!bar) continue;

    // 1) mark & exit open positions using this bar's OHLC
    for (const [sym, feed] of feeds) {
      const b = data[sym][i];
      if (!b) continue;
      feed.ingest(b);
      feed.setBar(b);
      const pos = portfolio.get(sym);
      if (!pos) continue;

      // trailing stop, evaluated on the close of the previous bar
      try {
        const sn = feed.snapshot();
        if (sn) updateStop(pos, { price: b.c, atr: sn.atr, beAtR: cfg.strategy.beAtR ?? 1, lockAtR: cfg.strategy.lockAtR ?? 2, trailAtr: cfg.strategy.trailAtr ?? 1.5 });
      } catch { /* ignore */ }

      // funding accrues at 00/08/16 UTC
      if (cfg.market === 'futures' && cfg.futures && cfg.futures.fundingBps) {
        const H = 8 * 3600 * 1000;
        const since = pos.lastFundingAt || pos.openedAt;
        const boundary = Math.floor(since / H) * H + H;
        if (boundary <= b.t) {
          pos.fundingPaid += (pos.notional * cfg.futures.fundingBps / 10000) * (pos.dir > 0 ? 1 : -1);
          pos.lastFundingAt = boundary;
        }
      }

      // conservative ordering inside the bar: stop loss first
      let exit = null;
      if (pos.dir > 0) {
        if (b.l <= pos.sl) exit = { price: Math.min(pos.sl, b.o), reason: 'stop_loss', feeKind: 'taker' };
        else if (b.h >= pos.tp) exit = { price: Math.max(pos.tp, b.o), reason: 'take_profit', feeKind: 'maker' };
      } else {
        if (b.h >= pos.sl) exit = { price: Math.max(pos.sl, b.o), reason: 'stop_loss', feeKind: 'taker' };
        else if (b.l <= pos.tp) exit = { price: Math.min(pos.tp, b.o), reason: 'take_profit', feeKind: 'maker' };
      }
      if (!exit && b.t - pos.openedAt >= cfg.strategy.timeStopMs) {
        exit = { price: b.c, reason: 'time_stop', feeKind: 'taker' };
      }
      if (!exit) continue;
      const feeBps = exit.feeKind === 'maker' ? cfg.fees.makerBps : cfg.fees.takerBps;
      const fee = (exit.price * pos.qty * feeBps) / 10000;
      const trade = portfolio.close(sym, { price: exit.price, fee, feeKind: exit.feeKind, reason: exit.reason, ts: b.t + 59999 });
      if (trade) {
        trades.push(trade);
        risk.settle({ pnl: trade.pnl, fee: (trade.entry.fee || 0) + fee, win: trade.win, symbol: sym, tradeId: trade.id });
        peak = Math.max(peak, risk.state.equity);
      }
    }

    // 2) new entries (only if flat on that symbol)
    for (const sym of cfg.symbols) {
      const feed = feeds.get(sym);
      const b = data[sym][i];
      if (!b || portfolio.hasPosition(sym)) continue;
      if (portfolio.openPositions().length >= cfg.risk.maxOpenPositions) break;
      if (risk.halted) break;

      const proposal = scout.evaluate(sym);
      if (!proposal) continue;
      const decision = board.review(proposal, portfolio, 0);
      if (!decision.approved) continue;

      const next = data[sym][i + 1];
      if (!next) continue;
      // Entry model
      //   taker: market at the next open (pays the spread)
      //   maker: resting limit at the proposal price (the bid we saw);
      //          fills only if the market actually traded down to it
      let entry = 0;
      let feeBps = cfg.fees.takerBps;
      const isShort = proposal.side === 'sell';
      const wantsMaker = (proposal.entryType || cfg.strategy.entryType) === 'maker';
      if (wantsMaker) {
        const limit = proposal.price;
        const horizon = Math.max(1, Math.floor(cfg.strategy.makerTimeoutMs / 60000));
        let filled = false;
        for (let k = i + 1; k <= Math.min(i + horizon, n - 1); k++) {
          const bk = data[sym][k];
          if (!bk) break;
          if (isShort ? bk.h >= limit : bk.l <= limit) { filled = true; break; }
        }
        if (!filled) continue;
        entry = limit;
        feeBps = cfg.fees.makerBps;
      } else {
        entry = next.o * (1 + (isShort ? -1 : 1) * (cfg.fees.takerBps * 1e-4) * 0.5);
      }
      const qty = decision.qty;
      const notional = entry * qty;
      const fee = (notional * feeBps) / 10000;
      const { Position } = require('../src/exec/portfolio');
      portfolio.open(
        new Position({
          symbol: sym,
          side: 'long',
          qty,
          entry,
          fee,
          notional,
          strategy: proposal.strategy,
          tp: entry * (1 + proposal.tpBps / 10000),
          sl: entry * (1 - proposal.slBps / 10000),
          timeStopAt: next.t + cfg.strategy.timeStopMs,
          proposalId: proposal.id,
          decisionId: decision.id,
          context: { ...proposal.features, regime: proposal.regime },
          rationale: proposal.rationale,
        })
      );
      portfolio.get(sym).openedAt = next.t;
    }
    if (i % 30 === 0) equityCurve.push({ t: bar.t, equity: Math.round(risk.state.equity * 100) / 100 });
  }

  // ------------------------------------------------------------------ report
  const equity = risk.state.equity;
  const wins = trades.filter((t) => t.win);
  const pnl = trades.reduce((s, t) => s + t.pnl, 0);
  const fees = trades.reduce((s, t) => s + t.entry.fee + t.exit.fee, 0);
  const rets = trades.map((t) => t.pnlBps);
  const wr = trades.length ? wins.length / trades.length : 0;
  const exp = trades.length ? pnl / trades.length : 0;
  const gp = wins.reduce((s, t) => s + t.pnl, 0);
  const gl = Math.abs(trades.filter((t) => !t.win).reduce((s, t) => s + t.pnl, 0));
  const pf = gl > 0 ? gp / gl : gp > 0 ? Infinity : 0;

  // max drawdown from the equity curve
  let dd = 0;
  let hi = -Infinity;
  for (const p of equityCurve) {
    hi = Math.max(hi, p.equity);
    dd = Math.max(dd, ((hi - p.equity) / hi) * 100);
  }

  const byReason = {};
  for (const t of trades) byReason[t.exit.reason] = (byReason[t.exit.reason] || 0) + 1;
  const bySymbol = {};
  for (const t of trades) {
    bySymbol[t.symbol] = bySymbol[t.symbol] || { n: 0, pnl: 0, wins: 0 };
    bySymbol[t.symbol].n++;
    bySymbol[t.symbol].pnl += t.pnl;
    if (t.win) bySymbol[t.symbol].wins++;
  }
  const byStrategy = {};
  for (const t of trades) {
    byStrategy[t.strategy] = byStrategy[t.strategy] || { n: 0, pnl: 0, wins: 0 };
    byStrategy[t.strategy].n++;
    byStrategy[t.strategy].pnl += t.pnl;
    if (t.win) byStrategy[t.strategy].wins++;
  }

  const result = {
    generatedAt: new Date().toISOString(),
    days,
    symbols: cfg.symbols,
    exchange: cfg.exchange,
    relaxed: flag('relaxed'),
    bars: n,
    equityStart: cfg.risk.startEquity,
    equityEnd: Math.round(equity * 100) / 100,
    returnPct: Math.round(((equity / cfg.risk.startEquity - 1) * 100) * 100) / 100,
    trades: trades.length,
    perDay: Math.round((trades.length / days) * 10) / 10,
    wins: wins.length,
    losses: trades.length - wins.length,
    winRate: Math.round(wr * 1000) / 10,
    pnl: Math.round(pnl * 100) / 100,
    fees: Math.round(fees * 100) / 100,
    feesPctOfGross: gp + gl > 0 ? Math.round((fees / (gp + gl)) * 1000) / 10 : 0,
    expectancy: Math.round(exp * 100) / 100,
    avgBps: rets.length ? Math.round(mean(rets) * 10) / 10 : 0,
    medianBps: rets.length ? Math.round(quantile(rets, 0.5) * 10) / 10 : 0,
    profitFactor: Math.round(pf * 100) / 100,
    maxDrawdownPct: Math.round(dd * 100) / 100,
    exits: byReason,
    bySymbol: mapRound(bySymbol),
    byStrategy: mapRound(byStrategy),
    scoutSkips: scout.stats.skipped,
    board: board.stats,
    equityCurve,
  };

  const bh = {};
  for (const sym of cfg.symbols) {
    const d = data[sym];
    if (!d || d.length < warmup + 1) continue;
    bh[sym] = Math.round(((d[n - 1].c / d[warmup].c - 1) * 100) * 100) / 100;
  }
  result.buyHold = bh;
  result.buyHoldAvg = Math.round((Object.values(bh).reduce((a, v) => a + v, 0) / Math.max(1, Object.keys(bh).length)) * 100) / 100;

  // --- trade anatomy: R-multiples tell you whether the exits are the problem
  const R = trades.map((t) => {
    const risk = t.entry.price - (t.context && t.context.__sl || 0);
    return null;
  });
  const anatomy = trades.map((t) => ({
    sym: t.symbol, strat: t.strategy, reason: t.exit.reason,
    pnlBps: t.pnlBps, dur: Math.round(t.durationMs / 60000) + 'm',
    mfeBps: Math.round(((t.mfe / t.entry.notional) * 10000) * 10) / 10,
    maeBps: Math.round(((t.mae / t.entry.notional) * 10000) * 10) / 10,
  }));
  result.anatomy = anatomy;

  console.log('\n────────── نتیجه ──────────');
  console.log(`معاملات: ${result.trades}  (${result.perDay}/روز)`);
  console.log(`برد/باخت: ${result.wins}/${result.losses}  نرخ برد ${result.winRate}%`);
  console.log(`سود خالص: ${result.pnl}$  (${result.returnPct}%)  کارمزد: ${result.fees}$`);
  console.log(`انتظار ریاضی: ${result.expectancy}$/معامله  میانگین ${result.avgBps}bps`);
  console.log(`Profit Factor: ${result.profitFactor}  حداکثر افت: ${result.maxDrawdownPct}%`);
  console.log(`خروج‌ها: ${JSON.stringify(result.exits)}`);
  console.log(`به تفکیک نماد: ${JSON.stringify(result.bySymbol)}`);
  console.log(`دلایل رد کاشف: ${JSON.stringify(result.scoutSkips)}`);
  console.log('───────────────────────────\n');

  const dir = path.join(cfg.reporter.dir);
  fs.mkdirSync(dir, { recursive: true });
  const out = path.join(dir, `backtest-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
  fs.writeFileSync(out, JSON.stringify(result, null, 2));
  if (anatomy.length) {
    console.log('\nآناتومی معاملات (bps نسبت به حجم):');
    for (const a of anatomy.slice(-12)) {
      console.log('  ' + a.sym.padEnd(8) + a.strat.padEnd(15) + a.reason.padEnd(13) + ('pnl ' + a.pnlBps + 'bps').padEnd(14) + ('MFE ' + a.mfeBps).padEnd(12) + ('MAE ' + a.maeBps).padEnd(12) + a.dur);
    }
  }
  console.log(`📄 ${out}`);
}

const mapRound = (m) =>
  Object.fromEntries(
    Object.entries(m).map(([k, v]) => [k, { n: v.n, pnl: Math.round(v.pnl * 100) / 100, winRate: v.n ? Math.round((v.wins / v.n) * 1000) / 10 : 0 }])
  );

function quietLog() {
  const noop = () => {};
  return { info: noop, warn: noop, error: noop, debug: noop, child: () => quietLog() };
}

main().catch((e) => {
  console.error('backtest failed:', e.message);
  process.exit(1);
});
