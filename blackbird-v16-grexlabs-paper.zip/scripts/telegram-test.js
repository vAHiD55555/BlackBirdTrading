#!/usr/bin/env node
'use strict';
/**
 * Send one Telegram message right now, without waiting for the hourly report.
 *
 *   node scripts/telegram-test.js
 *
 * Reads the same environment the engine does, so if this works the reports will
 * work too. Prints the real Telegram error code and description on failure —
 * never just "skipped".
 *
 * Exit codes: 0 sent, 1 not sent (with the reason printed).
 */
const path = require('node:path');
const { loadConfig } = require(path.join(__dirname, '..', 'src', 'config'));
const { sendTestMessage, normalizeChatId } = require(path.join(__dirname, '..', 'src', 'notify', 'telegram'));

(async () => {
  const cfg = loadConfig();
  const t = cfg.notifications.telegram;

  console.log('BlackBird — Telegram test');
  console.log('  enabled   :', t.enabled);
  console.log('  token     :', t.botToken ? `set (${t.botToken.length} chars, ends …${t.botToken.slice(-4)})` : 'MISSING');
  console.log('  chat id   :', t.reportChatId ? `${normalizeChatId(t.reportChatId)} (report)` : 'MISSING');
  console.log('  alert id  :', t.alertChatId ? `${normalizeChatId(t.alertChatId)} (alert)` : '(falls back to report)');
  console.log('');

  if (!t.enabled) {
    console.log('✗ Telegram is disabled. Set TELEGRAM_ENABLED=true.');
    process.exit(1);
  }

  const r = await sendTestMessage(cfg);

  if (r.ok) {
    console.log(`✓ Sent. message_id=${r.messageId ?? '—'} chat=${r.chatId}`);
    process.exit(0);
  }

  if (r.skipped) {
    console.log(`✗ Not sent: ${r.reason}`);
    console.log('  Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in the panel environment.');
  } else if (r.network) {
    console.log(`✗ Network error: ${r.reason}`);
    console.log('  api.telegram.org is not reachable from this host (blocked, DNS, or timeout).');
  } else {
    console.log(`✗ Telegram rejected it: ${r.errorCode || ''} ${r.description || ''}`);
    if (r.hint) console.log(`  ${r.hint}`);
  }
  process.exit(1);
})();
