#!/usr/bin/env bash
# توقف ربات روی گوشی
cd "$(dirname "$0")/.."
if [ -f data/engine.pid ]; then
  PID=$(cat data/engine.pid)
  kill "$PID" 2>/dev/null || true
  rm -f data/engine.pid
  echo "stopped pid $PID"
else
  echo "no pid file"
fi
