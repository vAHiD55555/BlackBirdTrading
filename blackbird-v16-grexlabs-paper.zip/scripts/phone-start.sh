#!/usr/bin/env bash
# اجرای ربات روی گوشی، جدا از ترمینال (تا وقتی اپ DSH زنده است)
#   bash scripts/phone-start.sh
set -e
cd "$(dirname "$0")/.."
PIDFILE=data/engine.pid
mkdir -p data
if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then
  echo "already running (pid $(cat $PIDFILE))"
  exit 0
fi
PORT="${BB_PORT:-${PORT:-$(node -e "const s=require('net').createServer().listen(0,()=>{console.log(s.address().port);s.close()})")}}"
setsid nohup env BB_PORT="$PORT" node src/index.js >> data/engine.log 2>&1 < /dev/null &
echo $! > "$PIDFILE"
sleep 2
echo "started pid $(cat $PIDFILE) · panel http://127.0.0.1:$PORT · log data/engine.log"
