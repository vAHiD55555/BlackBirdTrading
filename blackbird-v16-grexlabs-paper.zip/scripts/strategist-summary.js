#!/usr/bin/env node
'use strict';
/**
 * BlackBird — summarise a strategist run.
 *
 *   node scripts/strategist-summary.js <console.log> [<live.jsonl>]
 *
 * Reads a captured console log and the strategist's live journal and prints a
 * plain-language summary: how many cycles ran, what severities were seen, what
 * requests were raised, whether the crisis authority ever fired, and every
 * warning or error. It reads files only — no network, no engine, no keys.
 *
 * This exists because "the strategist ran for ten minutes" is not evidence.
 * The counts below are.
 */
const fs = require('node:fs');
const path = require('node:path');

const consolePath = process.argv[2];
const journalPath = process.argv[3] || null;

if (!consolePath) {
  console.error('usage: node scripts/strategist-summary.js <console.log> [<live.jsonl>]');
  process.exit(2);
}

const text = fs.readFileSync(consolePath, 'utf8');
const lines = text.split('\n');

// ---- console log -----------------------------------------------------------
const stamp = (l) => {
  const m = l.match(/^(\d{2}:\d{2}:\d{2})/);
  return m ? m[1] : null;
};
const first = lines.map(stamp).find(Boolean);
const last = [...lines].reverse().map(stamp).find(Boolean);

const byLevel = { INFO: 0, WARN: 0, ERROR: 0 };
const strategistLines = [];
const warnings = [];
const errors = [];

for (const l of lines) {
  const m = l.match(/^\d{2}:\d{2}:\d{2}\s+(INFO|WARN|ERROR)\s+\[([^\]]+)\]\s*(.*)$/);
  if (!m) continue;
  const [, level, src, msg] = m;
  byLevel[level] = (byLevel[level] || 0) + 1;
  if (src === 'strategist') strategistLines.push({ level, msg });
  if (level === 'WARN') warnings.push({ src, msg });
  if (level === 'ERROR') errors.push({ src, msg });
}

// ---- strategist journal ----------------------------------------------------
let records = [];
if (journalPath && fs.existsSync(journalPath)) {
  for (const line of fs.readFileSync(journalPath, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try { records.push(JSON.parse(line)); } catch { /* torn line */ }
  }
}

const cycles = records.filter((r) => r.type === 'cycle');
const severityCount = { green: 0, amber: 0, red: 0, unknown: 0 };
for (const c of cycles) severityCount[c.severity] = (severityCount[c.severity] || 0) + 1;

const requests = records.filter((r) => r.type === 'request');
const answers = records.filter((r) => r.type === 'answer');
const selfExec = records.filter((r) => r.type === 'self_execution');
const refused = records.filter((r) => r.type === 'self_execution_refused');
const windowExpired = records.filter((r) => r.type === 'window_expired');
const overlayExpired = records.filter((r) => r.type === 'overlay_expired');

// The console is the second witness. A request that reached the log but not
// the journal (or the reverse) is a discrepancy worth seeing, so both are
// counted and printed side by side rather than trusting one source.
const consoleRequests = strategistLines.filter((l) => /strategist request \(/.test(l.msg)).length;
const consoleSelfExec = strategistLines.filter((l) => /SELF-EXECUTED/.test(l.msg)).length;
const consoleRefused = strategistLines.filter((l) => /crisis authority refused/.test(l.msg)).length;
const consoleCommitteeFail = strategistLines.filter((l) => /failed to reach the committee/.test(l.msg)).length;

const contradictions = cycles.flatMap((c) => (c.contradiction || []).map((x) => x.detail));
const opportunities = cycles.flatMap((c) => (c.opportunity || []).map((x) => x.detail));

const uniq = (a) => [...new Set(a)];

const out = [];
out.push('══════════════════════════════════════════════════════════════');
out.push('  BlackBird — خلاصه‌ی اجرای استراتژیست');
out.push('══════════════════════════════════════════════════════════════');
out.push('');
out.push(`  بازه‌ی لاگ        : ${first || '?'} → ${last || '?'} (UTC)`);
out.push(`  خطوط لاگ         : ${lines.length}`);
out.push(`  INFO/WARN/ERROR  : ${byLevel.INFO}/${byLevel.WARN}/${byLevel.ERROR}`);
out.push('');
out.push('  ── چرخه‌های استراتژیست ──────────────────────────────────');
out.push(`  چرخه‌های ثبت‌شده   : ${cycles.length}`);
out.push(`  سبز / زرد / قرمز : ${severityCount.green} / ${severityCount.amber} / ${severityCount.red}`);
out.push(`  درخواست صادرشده  : ${requests.length} (ژورنال) / ${consoleRequests} (کنسول)`);
out.push(`  پاسخ کمیته       : ${answers.length}`);
out.push(`  شکست دسترسی به کمیته: ${consoleCommitteeFail}`);
out.push(`  انقضای پنجره     : ${windowExpired.length}`);
out.push(`  اقدام خودکار     : ${selfExec.length} (ژورنال) / ${consoleSelfExec} (کنسول)`);
out.push(`  رد‌شده توسط مجوز : ${refused.length} (ژورنال) / ${consoleRefused} (کنسول)`);
out.push(`  overlay منقضی    : ${overlayExpired.length}`);
out.push('');
out.push('  ── تناقض‌های روش با بازار ───────────────────────────────');
if (contradictions.length) for (const c of uniq(contradictions)) out.push(`  • ${c}`);
else out.push('  (هیچ)');
out.push('');
out.push('  ── فرصت‌های شناسایی‌شده ─────────────────────────────────');
if (opportunities.length) for (const o of uniq(opportunities)) out.push(`  • ${o}`);
else out.push('  (هیچ)');
out.push('');
out.push('  ── خطوط استراتژیست در کنسول ─────────────────────────────');
if (strategistLines.length) for (const s of strategistLines) out.push(`  [${s.level}] ${s.msg}`);
else out.push('  (هیچ)');
out.push('');
out.push('  ── هشدارها ──────────────────────────────────────────────');
if (warnings.length) for (const w of uniq(warnings.map((w) => `[${w.src}] ${w.msg}`))) out.push(`  • ${w}`);
else out.push('  (هیچ)');
out.push('');
out.push('  ── خطاها ────────────────────────────────────────────────');
if (errors.length) for (const e of uniq(errors.map((e) => `[${e.src}] ${e.msg}`))) out.push(`  • ${e}`);
else out.push('  (هیچ)');
out.push('');
out.push('══════════════════════════════════════════════════════════════');

console.log(out.join('\n'));
