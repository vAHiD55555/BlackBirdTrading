#!/usr/bin/env node
'use strict';
/**
 * BlackBird — fetch historical candles from a free public endpoint.
 *
 * Default source is MEXC's public klines API: no key, no signup, no rate-limit
 * account. Binance is blocked from some regions, so it is not the default.
 *
 *   node scripts/fetch-candles.js --symbols BTCUSDT,ETHUSDT --months 6
 *
 * Output: data/candles/<SYMBOL>_1h.csv  (time,open,high,low,close,volume)
 * The format is exactly what src/backtest/csv.js reads.
 */
const fs = require('node:fs');
const path = require('node:path');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};

const BASE = arg('base', 'https://api.mexc.com/api/v3/klines');
const symbols = String(arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT')).split(',').map((s) => s.trim()).filter(Boolean);
const months = Number(arg('months', 6));
const interval = arg('interval', '60m');
const outDir = path.resolve(arg('out', 'data/candles'));

const HOUR = 3600000;
const now = Date.now();
const startMs = now - months * 30 * 24 * HOUR;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchChunk(symbol, fromMs, toMs) {
  const url = `${BASE}?symbol=${symbol}&interval=${interval}&startTime=${fromMs}&endTime=${toMs}&limit=1000`;
  const res = await fetch(url, { headers: { accept: 'application/json' } });
  if (!res.ok) throw new Error(`${symbol}: HTTP ${res.status}`);
  const rows = await res.json();
  if (!Array.isArray(rows)) throw new Error(`${symbol}: unexpected payload ${JSON.stringify(rows).slice(0, 120)}`);
  return rows;
}

async function fetchAll(symbol) {
  const out = [];
  let cursor = startMs;
  let guard = 0;
  while (cursor < now && guard++ < 40) {
    const rows = await fetchChunk(symbol, cursor, now);
    if (!rows.length) break;
    for (const r of rows) {
      out.push({ t: Number(r[0]), o: Number(r[1]), h: Number(r[2]), l: Number(r[3]), c: Number(r[4]), v: Number(r[5]) });
    }
    const last = Number(rows[rows.length - 1][0]);
    if (!(last > cursor)) break;
    cursor = last + HOUR;
    // MEXC caps a page at 500 rows even when limit=1000 is asked for, so the
    // loop must continue until a page comes back empty or stops advancing.
    if (rows.length < 2) break;
    await sleep(120);
  }
  // Deduplicate by timestamp and sort ascending.
  const seen = new Map();
  for (const b of out) seen.set(b.t, b);
  return [...seen.values()].sort((a, b) => a.t - b.t);
}

async function main() {
  fs.mkdirSync(outDir, { recursive: true });
  console.log('');
  console.log(`  source=${BASE}`);
  console.log(`  months=${months}  interval=${interval}  symbols=${symbols.length}`);
  console.log('');

  for (const symbol of symbols) {
    try {
      const bars = await fetchAll(symbol);
      if (bars.length < 100) {
        console.log(`  ${symbol.padEnd(10)} SKIP  only ${bars.length} bars`);
        continue;
      }
      const file = path.join(outDir, `${symbol}_1h.csv`);
      const lines = ['time,open,high,low,close,volume'];
      for (const b of bars) lines.push(`${b.t},${b.o},${b.h},${b.l},${b.c},${b.v}`);
      fs.writeFileSync(file, lines.join('\n') + '\n', 'utf8');
      const days = ((bars[bars.length - 1].t - bars[0].t) / 86400000).toFixed(1);
      console.log(`  ${symbol.padEnd(10)} OK    ${String(bars.length).padStart(5)} bars  ${days} days  -> ${path.relative(process.cwd(), file)}`);
    } catch (e) {
      console.log(`  ${symbol.padEnd(10)} FAIL  ${e.message}`);
    }
    await sleep(200);
  }
  console.log('');
}

main().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
