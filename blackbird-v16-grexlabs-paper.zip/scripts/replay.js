#!/usr/bin/env node
'use strict';
/**
 * Replay the REAL live code path over historical candles.
 *
 *   node scripts/replay.js [--weeks=52] [--symbols=BTCUSDT,ETHUSDT,...]
 *
 * Unlike research/sim.js (a fast isolated simulator), this drives the actual
 * Rotator + Portfolio + RiskManager + Store classes with a virtual clock, so it
 * exercises the same code the server runs: weekly buckets, disaster stops,
 * journal writes, persistence and equity accounting.
 *
 * It is the parity check between "what we measured" and "what we ship".
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { loadConfig } = require('../src/config');
const { Rotator } = require('../src/strategy/rotator');
const { Portfolio } = require('../src/exec/portfolio');
const { RiskManager } = require('../src/risk/risk');
const { Store } = require('../src/core/store');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const DIR = path.join(__dirname, '..', 'data', 'research');
const SYMS = arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT').split(',');
const WEEKS = Number(arg('weeks', 52));
const START = Number(arg('equity', 5000));

const raw = {};
for (const s of SYMS) raw[s] = JSON.parse(fs.readFileSync(path.join(DIR, `${s}-1h.json`), 'utf8'));
const n = Math.min(...SYMS.map((s) => raw[s].length));
const from = Math.max(260, n - WEEKS * 168);

const noop = () => {};
const quiet = () => ({ info: noop, warn: noop, error: noop, debug: noop });
const cfg = loadConfig();
cfg.strategy.mode = 'rotator';
cfg.data.timeframe = '1h';
cfg.symbols = SYMS;
cfg.risk.startEquity = START;
const rebArg = process.argv.find(a=>a.startsWith('--reb='));
if (rebArg) cfg.strategy.rotator.rebalanceHours = Number(rebArg.split('=')[1]);
const coreArg = process.argv.find(a=>a.startsWith('--core='));
if (coreArg) cfg.strategy.rotator.corePct = Number(coreArg.split('=')[1]);
const coreTopArg = process.argv.find(a=>a.startsWith('--coretop='));
if (coreTopArg) cfg.strategy.rotator.coreTop = Number(coreTopArg.split('=')[1]);
if (process.argv.includes('--nokill')) { cfg.risk.killSwitchDrawdownPct = 10; cfg.risk.maxDailyLossPct = 10; }

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-replay-'));
cfg.runtime = Object.assign({}, cfg.runtime, {
  stateFile: path.join(dir, 'state.json'),
  journalFile: path.join(dir, 'journal.jsonl'),
  logDir: dir,
});

let clock = raw[SYMS[0]][from][0];
const store = new Store(cfg, quiet());
store.loadState();
store.state.equity = START;
store.state.dayStartEquity = START;
const risk = new RiskManager({ cfg, store, log: quiet() });
const portfolio = new Portfolio(quiet());

const live = Object.fromEntries(SYMS.map((s) => [s, []]));
const hub = {
  get(sym) {
    const last = live[sym][live[sym].length - 1];
    return {
      bars: { toArray: () => live[sym] },
      book: () => (last ? { bid: last.c * 0.9999, ask: last.c * 1.0001, quoteAgeMs: 0, spreadBps: 2, depthUsd: 1e6 } : null),
    };
  },
};

const fills = [];
const broker = {
  submit(order) {
    const last = live[order.symbol][live[order.symbol].length - 1];
    if (!last) return { status: 'rejected', reason: 'no book' };
    const px = order.side === 'buy' ? last.c * 1.00015 : last.c * 0.99985;
    const notional = px * order.qty;
    const fee = (notional * cfg.fees.takerBps) / 10000;
    fills.push({ order });
    return { status: 'filled', symbol: order.symbol, side: order.side, qty: order.qty, price: px, notional, fee, feeKind: 'taker', ts: clock };
  },
};

const rot = new Rotator({
  cfg, log: quiet(), store, risk, portfolio, broker, hub, bus: { emit() {} },
  now: () => clock,
});

const stamps = [];
const origReb = rot.rebalance.bind(rot);
rot.rebalance = function () { const r = origReb(); stamps.push([new Date(clock).toISOString().slice(0,10), r && r.targets, r && r.opened]); return r; };
let hoursInMarket = 0, hoursTotal = 0;
const weekly = [];
let lastWeek = null;
for (let i = from; i < n; i++) {
  clock = raw[SYMS[0]][i][0];
  for (const s of SYMS) { const b = raw[s][i]; live[s].push({ t: b[0], o: b[1], h: b[2], l: b[3], c: b[4], v: b[5] }); }
  const day = new Date(clock).toISOString().slice(0, 10);
  if (day !== store.state.counters.day) {
    store.state.counters.day = day;
    store.state.dayStartEquity = risk.state.equity;
    store.state.counters.tradesToday = 0;
  }
  rot.onBar();
  risk.maybeAutoResume(clock);
  // mark to market
  for (const p of portfolio.openPositions()) {
    const c = live[p.symbol][live[p.symbol].length - 1].c;
    p.mark(c);
  }
  hoursTotal++;
  if (portfolio.openPositions().length > 0) hoursInMarket++;
  const wk = Math.floor(clock / (7 * 86400000));
  if (lastWeek === null) lastWeek = wk;
  if (wk !== lastWeek) {
    const mtm = risk.state.equity + portfolio.unrealisedTotal();
    weekly.push({ t: clock, equity: mtm });
    lastWeek = wk;
  }
}

// close everything at the last close so the final equity is realised
for (const p of [...portfolio.openPositions()]) rot._close(p.symbol, 'end');

const finalMTM = weekly.length ? weekly[weekly.length - 1].equity : START;
const closes = portfolio.closed.length;
const wins = portfolio.closed.filter((t) => t.pnl > 0).length;
const pnl = risk.state.equity - START;
const fees = portfolio.closed.reduce((a, t) => a + t.fees, 0);

const curve = weekly.map((w) => w.equity).concat([risk.state.equity]);
let peak = curve[0], dd = 0;
for (const e of curve) { peak = Math.max(peak, e); dd = Math.max(dd, 1 - e / peak); }
const posWeeks = weekly.filter((w, i) => i > 0 && w.equity > weekly[i - 1].equity).length;

console.log(`\n🔁 بازپخش کد زنده — ${SYMS.length} نماد · ${Math.round((n - from) / 168)} هفته\n`);
console.log(`  سرمایه‌ی شروع: ${START}$`);
console.log(`  سرمایه‌ی پایان: ${risk.state.equity.toFixed(2)}$  (${((risk.state.equity / START - 1) * 100).toFixed(2)}%)`);
console.log(`  معاملات بسته‌شده: ${closes}  (برد ${wins} / ${((wins / Math.max(1, closes)) * 100).toFixed(0)}٪)`);
console.log(`  کارمزد: ${fees.toFixed(2)}$`);
console.log(`  حداکثر افت (بر اساس هفته): ${(dd * 100).toFixed(1)}%`);
console.log(`  هفته‌های مثبت: ${posWeeks}/${Math.max(1, weekly.length - 1)}`);
console.log(`  ورودی‌های سفارش: ${fills.length}`);
console.log(`  ری‌بالانس‌ها: ${rot.stats.rebalances} · باز‌شده: ${rot.stats.opens} · بسته‌شده: ${rot.stats.closes} · استاپ: ${rot.stats.stops}`);
console.log(`  ژورنال: ${store.verifyChain().count} رکورد، سالم: ${store.verifyChain().ok ? 'بله ✅' : 'خیر ❌'}`);
console.log('  زمان در بازار: ' + ((hoursInMarket / Math.max(1, hoursTotal)) * 100).toFixed(1) + '% از ساعت‌ها حداقل یک پوزیشن باز داشته');
console.log('  stamps', stamps.length, stamps[0] ? stamps[0][0] + ' → ' + stamps[stamps.length-1][0] : 'none');
console.log('');
