#!/usr/bin/env node
'use strict';
/**
 * «آیا الان باید معامله می‌کرد؟» — وضعیت زنده‌ی استراتژی روی داده‌ی واقعی.
 *
 *   node scripts/check-now.js                 # همین حالا
 *   node scripts/check-now.js --at=2026-11-03T09:30:00Z   # یک لحظه‌ی مشخص در گذشته
 *
 * همان کد استراتژی‌ای که ربات اجرا می‌کند (src/strategy/rotator.js) روی
 * کندل‌های تازه‌ی بایننس اجرا می‌شود تا ببینیم کتاب هدف چه بوده است.
 */
const { loadConfig } = require('../src/config');
const { createExchange } = require('../src/data/exchanges');
const { Rotator } = require('../src/strategy/rotator');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};
const AT = arg('at', '');

(async () => {
  const cfg = loadConfig();
  const ex = createExchange(cfg.exchange);
  const bars = {};
  for (const sym of cfg.symbols) {
    const rows = await ex.klines(sym, 420, '1h');
    bars[sym] = rows.map((r) => ({ t: r.t, o: r.o, h: r.h, l: r.l, c: r.c, v: r.v }));
  }

  if (AT) {
    const cut = Date.parse(AT);
    for (const s of Object.keys(bars)) bars[s] = bars[s].filter((b) => b.t + 3600000 <= cut);
  }

  const lastT = Math.max(...Object.values(bars).map((b) => b[b.length - 1].t));
  const hub = { get: (s) => ({ bars: { toArray: () => bars[s] }, book: () => null }) };

  const rot = new Rotator({
    cfg,
    log: { info() {}, warn() {}, error() {}, debug() {} },
    store: { append() {} },
    risk: { state: { equity: 5000 }, peakEquity: 5000, halted: false },
    portfolio: { positions: new Map(), ids: () => [], openPositions: () => [], hasPosition: () => false, get: () => null, unrealisedTotal: () => 0 },
    broker: { submit: () => ({ status: 'rejected', reason: 'check-only' }) },
    hub,
    bus: { emit() {} },
  });

  console.log(`\n⏱  لحظه‌ی بررسی: ${new Date(lastT).toISOString().replace('T', ' ').slice(0, 16)} UTC`);
  console.log(`   صرافی: ${cfg.exchange} · نمادها: ${cfg.symbols.length}\n`);

  // رژیم کلی بازار: BTC نسبت به EMA200
  const btc = bars['BTCUSDT'];
  const closes = btc.map((b) => b.c);
  const e200 = require('../src/strategy/rotator').ema(closes, 200);
  const btcLast = closes[closes.length - 1];
  const e = e200[e200.length - 1];
  console.log(`📊 BTC: ${btcLast.toFixed(0)}  |  EMA200(1h): ${e.toFixed(0)}  |  ${btcLast > e ? 'بالای EMA200 ✅ (خرید مجاز)' : 'زیر EMA200 ⛔ (خرید قفل، فقط فروش)'}`);

  const btcRet = (d) => ((btcLast / closes[closes.length - 1 - d] - 1) * 100).toFixed(1);
  console.log(`   بازده BTC: ۱روز ${btcRet(24)}٪ · ۳روز ${btcRet(72)}٪ · ۷روز ${btcRet(168)}٪\n`);

  // بازده هر نماد برای دیدن پراکندگی
  console.log('بازده نمادها (برای رتبه‌بندی مومنتوم):');
  console.log('  ' + 'نماد'.padEnd(10) + '۷۲h'.padStart(9) + '۱۶۸h'.padStart(9));
  const rows = [];
  for (const sym of cfg.symbols) {
    const c = bars[sym].map((b) => b.c);
    const r72 = (c[c.length - 1] / c[c.length - 1 - 72] - 1) * 100;
    const r168 = (c[c.length - 1] / c[c.length - 1 - 168] - 1) * 100;
    rows.push({ sym, r72, r168 });
    console.log(`  ${sym.padEnd(10)}${r72.toFixed(1).padStart(9)}${r168.toFixed(1).padStart(9)}`);
  }

  console.log('\n🎯 انتخاب هر واریانت:');
  for (const [i, v] of rot.variants.entries()) {
    const picks = rot.variantPicks(v, bars);
    const txt = picks.map((p) => `${p.sym}${p.dir > 0 ? '↑خرید' : '↓فروش'}`).join('  ') || '— هیچ';
    console.log(`  واریانت ${i + 1} (look ${v.lookHours}h${v.skipHours ? `، پرش ${v.skipHours}h` : ''}، top ${v.top}${v.gate ? '، فیلتر BTC' : ''}): ${txt}`);
  }

  const book = rot.targetBook(bars);
  console.log('\n📚 کتاب هدف نهایی (قبل از اعمال مقیاس ریسک):');
  if (!book.size) {
    console.log('  — خالی. هیچ شرطی برقرار نیست.');
  } else {
    let gross = 0;
    for (const [sym, t] of book) {
      gross += t.pct;
      console.log(`  ${sym.padEnd(10)} ${t.dir > 0 ? 'خرید ' : 'فروش '} ${t.pct.toFixed(0)}٪ از سرمایه`);
    }
    console.log(`  ─── ناخالص کل: ${gross.toFixed(0)}٪ (سقف ${rot.rc.maxGrossPct}٪)`);
  }
  console.log('');
})().catch((e) => { console.error('check failed:', e.message); process.exit(1); });
