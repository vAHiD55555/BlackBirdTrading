#!/usr/bin/env node
'use strict';
/**
 * BlackBird — inspect the individual trades of an offline backtest.
 *
 * The CLI prints the summary only. This script replays the same fixtures and
 * prints every closed trade, so a human can judge the actual behaviour:
 * entry, exit, reason, fees, PnL, and how long the position was held.
 *
 *   node scripts/inspect-trades.js --dir tests/fixtures --limit 10
 *
 * Read-only: it writes nothing except the equity curve the engine already
 * writes, and it never touches the network.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { loadConfig } = require('../src/config');
const { readCsvFile } = require('../src/backtest/csv');
const { runBacktest } = require('../src/backtest/engine');

const arg = (n, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.split('=')[1] : d;
};

const dir = path.resolve(arg('dir', 'tests/fixtures'));
const limit = Number(arg('limit', 10));

const cfg = loadConfig({ server: { enabled: false } });
const barsBySymbol = {};
for (const f of fs.readdirSync(dir).sort()) {
  if (!/\.csv$/i.test(f)) continue;
  const symbol = f.replace(/\.csv$/i, '').split(/[_.]/)[0].toUpperCase();
  const { bars, report } = readCsvFile(path.join(dir, f), { symbol });
  if (report.ok) barsBySymbol[symbol] = bars;
}

// Keep the equity curve out of the live data dir: this is an inspection run.
const equityFile = path.join(os.tmpdir(), `bb-inspect-${Date.now()}.jsonl`);

const result = runBacktest({ cfg, barsBySymbol, equityFile });
if (!result.ok) {
  console.error(`backtest failed: ${result.error}`);
  process.exit(1);
}

const trades = result.trades || [];
console.log('');
console.log(`  trades closed: ${trades.length}   (showing first ${Math.min(limit, trades.length)})`);
console.log('  ' + '-'.repeat(96));
console.log(
  '  #  symbol     side   entry        exit         reason        pnl$     pnl%    fees$   held'
);
console.log('  ' + '-'.repeat(96));

const held = (t) => {
  const ms = (t.exit?.ts || 0) - (t.entry?.ts || 0);
  if (!(ms > 0)) return '—';
  const h = ms / 3600000;
  return h >= 1 ? `${h.toFixed(1)}h` : `${Math.round(ms / 60000)}m`;
};
const pad = (v, n) => String(v).padEnd(n).slice(0, n);

trades.slice(0, limit).forEach((t, i) => {
  console.log(
    `  ${String(i + 1).padStart(2)} ${pad(t.symbol, 10)} ${pad(t.side, 6)} ` +
      `${pad(Number(t.entry?.price).toFixed(4), 12)} ${pad(Number(t.exit?.price).toFixed(4), 12)} ` +
      `${pad(t.exit?.reason || '—', 13)} ${pad(Number(t.pnl).toFixed(2), 8)} ` +
      `${pad(Number(t.pnlPct).toFixed(2), 7)} ${pad(Number(t.fees).toFixed(2), 7)} ${held(t)}`
  );
});

console.log('  ' + '-'.repeat(96));
const s = result.summary;
console.log(
  `  equity ${s.startEquity} -> ${s.finalEquity}   return ${s.returnPct}%   ` +
    `dd ${s.maxDrawdownPct}%   win ${s.hitRate}%   PF ${s.profitFactor}   fees ${s.feesPaid}`
);
console.log('');

// A machine-readable copy for the review document.
const out = path.resolve(arg('json', 'data/backtest/trades.json'));
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify({ summary: s, trades }, null, 2), 'utf8');
console.log(`  JSON: ${out}`);
console.log('');
