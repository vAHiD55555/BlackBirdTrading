#!/usr/bin/env node
'use strict';
/**
 * ساخت دو بسته‌ی مستقل و کامل:
 *
 *   node scripts/make-bots.js
 *
 *   dist/Abot.zip  — استراتژی پولبک نسخه ۲ (۴ ارز، ۱۵ دقیقه)
 *   dist/Bbot.zip  — استراتژی Orbital نسخه ۳ (۸ ارز، ۱ ساعت)
 *
 * هر دو از یک کدبال می‌آیند و فقط config.json شان فرق دارد؛ بنابراین هر
 * اصلاحی در موتور، به‌طور خودکار در هر دو هست.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { buildZip } = require('./make-zip');

const ROOT = path.resolve(__dirname, '..');
const SKIP = new Set(['data', 'reports', 'dist', 'node_modules', 'configs', '.git']);

function stage(configPath, name) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `bb-${name}-`));
  fs.cpSync(ROOT, dir, {
    recursive: true,
    filter: (src) => {
      const rel = path.relative(ROOT, src);
      if (!rel) return true;
      const top = rel.split(path.sep)[0];
      return !SKIP.has(top) && !rel.startsWith('.git');
    },
  });
  fs.copyFileSync(path.resolve(ROOT, configPath), path.join(dir, 'config.json'));
  return dir;
}

function stamp(name, cfg) {
  const label = name === 'Abot' ? 'پولبک • نسخه ۲' : 'Orbital • نسخه ۳';
  fs.writeFileSync(
    path.join(path.dirname(cfg), 'BOT.txt'),
    `${name} — ${label}\nexecutable: src/index.js\nport: ${JSON.parse(fs.readFileSync(cfg, 'utf8')).server.port}\n`
  );
}

const bots = [
  { name: 'Abot', cfg: path.join(ROOT, 'configs', 'abot.json') },
  { name: 'Bbot', cfg: path.join(ROOT, 'configs', 'bbot.json') },
];

const summary = [];
for (const bot of bots) {
  const dir = stage(bot.cfg, bot.name);
  // BOT.txt tells whoever opens the zip which bot it is (and which entry file)
  fs.writeFileSync(
    path.join(dir, 'BOT.txt'),
    `${bot.name}\nاستراتژی: ${bot.name === 'Abot' ? 'پولبک روند (نسخه ۲) — ۴ ارز، ۱۵ دقیقه' : 'Orbital (نسخه ۳) — ۸ ارز، ۱ ساعت'}\nفایل اجرایی: src/index.js\n`
  );
  const out = path.join(ROOT, 'dist', `${bot.name}.zip`);
  const r = buildZip(dir, out);
  summary.push({ bot: bot.name, out: r.out, files: r.files, size: r.size });
  console.log(`✔ ${bot.name}: ${r.files} files, ${(r.size / 1024).toFixed(1)} KB → ${r.out}`);
}

module.exports = { summary };
