#!/usr/bin/env node
'use strict';
/**
 * BlackBird — does market intel help? A controlled A/B over the same candles.
 *
 *   node scripts/intel-ab.js [--dir data/candles] [--from 2025-11-22] [--to 2026-11-22]
 *
 * WHAT IT DOES
 * ------------
 * Runs the SAME production Rotator, Portfolio and risk accounting over the SAME
 * bars twice:
 *
 *   A  baseline   intel not wired at all
 *   B  intel      the FOMC blackout gate wired in (src/intel/historical.js)
 *
 * The only difference between the two runs is the intel hook, so any difference
 * in the numbers is attributable to it. That is the whole point of an A/B: one
 * variable.
 *
 * WHAT IT MEASURES
 * ----------------
 * Only the EVENT BLACKOUT half of the intel technique. The sentiment half needs
 * the headlines of each historical day, which are not available offline, and
 * inventing them would fabricate the input being measured. The report says so.
 *
 * NO NETWORK. The only input is CSV on disk.
 */

const fs = require('node:fs');
const path = require('node:path');
const { loadConfig } = require('../src/config');
const { readCsvFile } = require('../src/backtest/csv');
const { runBacktest } = require('../src/backtest/engine');
const { HistoricalIntel } = require('../src/intel/historical');

function arg(name, dflt) {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.split('=')[1] : dflt;
}

function toMs(v) {
  if (!v) return undefined;
  if (/^\d+$/.test(String(v))) {
    const n = Number(v);
    return n >= 1e11 ? n : n * 1000;
  }
  const ms = Date.parse(String(v).includes('T') ? v : `${v}T00:00:00Z`);
  return Number.isFinite(ms) ? ms : undefined;
}

const fmt = (n, d = 2) => (n === null || n === undefined || !Number.isFinite(Number(n)) ? '—' : Number(n).toFixed(d));

function main() {
  const dir = path.resolve(arg('dir', path.join(__dirname, '..', 'data', 'candles')));
  const from = toMs(arg('from', ''));
  const to = toMs(arg('to', ''));

  if (!fs.existsSync(dir)) {
    console.error(`candles directory not found: ${dir}`);
    process.exit(2);
  }

  const files = fs.readdirSync(dir).filter((f) => /\.csv$/i.test(f)).sort();
  if (!files.length) {
    console.error(`no CSV files in ${dir}`);
    process.exit(2);
  }

  const barsBySymbol = {};
  const spans = [];
  for (const f of files) {
    const symbol = f.replace(/\.csv$/i, '').split(/[_.]/)[0].toUpperCase();
    const { bars, report } = readCsvFile(path.join(dir, f), { symbol, from, to });
    if (!report.ok || !bars.length) {
      console.error(`  ${f}: unusable (${report.problems.map((p) => p.code).join(', ') || 'empty'})`);
      continue;
    }
    barsBySymbol[symbol] = bars;
    spans.push({ symbol, first: bars[0].t, last: bars[bars.length - 1].t, n: bars.length });
  }

  const symbols = Object.keys(barsBySymbol);
  if (!symbols.length) {
    console.error('no usable series — aborting');
    process.exit(1);
  }

  const first = Math.max(...spans.map((s) => s.first));
  const last = Math.min(...spans.map((s) => s.last));
  const days = Math.round((last - first) / 86400000);

  console.log('');
  console.log('  BlackBird — market intel A/B');
  console.log('  ' + '─'.repeat(72));
  console.log(`  symbols=${symbols.join(',')}`);
  console.log(`  window=${new Date(first).toISOString().slice(0, 10)} .. ${new Date(last).toISOString().slice(0, 10)}  (${days} days)`);
  console.log(`  bars=${Math.min(...spans.map((s) => s.n))} per symbol   network=OFF`);
  console.log('');

  const cfg = loadConfig();
  const dataDir = cfg.runtime?.dataDir || path.join(cfg.root || process.cwd(), 'data');

  // ---- A: baseline (no intel at all) -------------------------------------
  const t0 = Date.now();
  const base = runBacktest({
    cfg,
    barsBySymbol,
    equityFile: path.join(dataDir, 'equity-ab-baseline.jsonl'),
  });
  const baseMs = Date.now() - t0;
  if (!base.ok) {
    console.error(`  baseline failed: ${base.error}`);
    process.exit(1);
  }

  // ---- B: intel (FOMC blackout gate, configured 45-minute window) --------
  const intel = new HistoricalIntel();
  const eventsInWindow = intel.countIn(first, last);
  const t1 = Date.now();
  const withIntel = runBacktest({
    cfg,
    barsBySymbol,
    equityFile: path.join(dataDir, 'equity-ab-intel.jsonl'),
    intelAt: (ts) => intel.at(ts),
  });
  const intelMs = Date.now() - t1;
  if (!withIntel.ok) {
    console.error(`  intel run failed: ${withIntel.error}`);
    process.exit(1);
  }

  // ---- C: intel with a FULL-DAY event window -----------------------------
  // The configured window is 30 min before / 15 min after the statement. That
  // is the right window for a bot that can act on a tick, but this strategy
  // rebalances once a week: the odds of a rebalance landing inside a 45-minute
  // window are ~0.4%, so the gate fires zero times in a year and the A/B is
  // uninformative. A full-day window is what an operator would actually use
  // for a weekly book, so it is measured separately rather than assumed.
  const dayIntel = new HistoricalIntel({ blackoutBeforeMs: 12 * 3600 * 1000, blackoutAfterMs: 12 * 3600 * 1000 });
  const t2 = Date.now();
  const withDayIntel = runBacktest({
    cfg,
    barsBySymbol,
    equityFile: path.join(dataDir, 'equity-ab-intel-day.jsonl'),
    intelAt: (ts) => dayIntel.at(ts),
  });
  const dayMs = Date.now() - t2;
  if (!withDayIntel.ok) {
    console.error(`  intel-day run failed: ${withDayIntel.error}`);
    process.exit(1);
  }

  const a = base.summary;
  const b = withIntel.summary;
  const c = withDayIntel.summary;

  const row = (label, x, y, z, d = 2) => {
    const delta = Number.isFinite(Number(x)) && Number.isFinite(Number(z)) ? Number(z) - Number(x) : null;
    const sign = delta === null ? '' : delta > 0 ? '+' : '';
    console.log(
      `  ${label.padEnd(20)} ${fmt(x, d).padStart(11)} ${fmt(y, d).padStart(11)} ${fmt(z, d).padStart(11)} ${(delta === null ? '—' : sign + fmt(delta, d)).padStart(11)}`
    );
  };

  console.log('  ' + '─'.repeat(72));
  console.log(`  ${'metric'.padEnd(20)} ${'baseline'.padStart(11)} ${'45-min'.padStart(11)} ${'full-day'.padStart(11)} ${'Δ day'.padStart(11)}`);
  console.log('  ' + '─'.repeat(72));
  row('return %', a.returnPct, b.returnPct, c.returnPct);
  row('max drawdown %', a.maxDrawdownPct, b.maxDrawdownPct, c.maxDrawdownPct);
  row('trades', a.trades, b.trades, c.trades, 0);
  row('wins', a.wins, b.wins, c.wins, 0);
  row('losses', a.losses, b.losses, c.losses, 0);
  row('hit rate %', a.hitRate, b.hitRate, c.hitRate);
  row('profit factor', a.profitFactor, b.profitFactor, c.profitFactor);
  row('fees paid', a.feesPaid, b.feesPaid, c.feesPaid);
  row('final equity', a.finalEquity, b.finalEquity, c.finalEquity);
  row('sharpe / period', a.sharpePerPeriod, b.sharpePerPeriod, c.sharpePerPeriod, 4);
  console.log('  ' + '─'.repeat(72));
  console.log(`  FOMC events inside the window: ${eventsInWindow}`);
  const st = (s) => (s.intel ? `calls ${s.intel.calls}, blackouts ${s.intel.blackouts}, reductions ${s.intel.reductions}` : 'not wired');
  console.log(`  45-min gate:  ${st(b)}`);
  console.log(`  full-day gate: ${st(c)}`);
  console.log(`  runtime: baseline ${baseMs} ms, 45-min ${intelMs} ms, full-day ${dayMs} ms`);
  console.log('');

  // Machine-readable output for the report.
  const out = {
    generatedAt: new Date().toISOString(),
    window: { from: new Date(first).toISOString(), to: new Date(last).toISOString(), days },
    symbols,
    bars: Math.min(...spans.map((s) => s.n)),
    eventsInWindow,
    baseline: a,
    intel45: b,
    intelDay: c,
    intelStats45: withIntel.summary.intel,
    intelStatsDay: withDayIntel.summary.intel,
    note:
      'Only the EVENT BLACKOUT half of the intel technique is measured. The sentiment half ' +
      'needs the headlines of each historical day, which are not available offline; inventing ' +
      'them would fabricate the input being measured. The 45-minute window is the configured ' +
      'live window; it fires zero times at a weekly rebalance cadence, which is itself the ' +
      'finding. The full-day window is the variant an operator would use for a weekly book.',
  };
  const outPath = path.resolve(arg('json', path.join(dataDir, 'intel-ab.json')));
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8');
  console.log(`  JSON: ${outPath}`);
  console.log('');
}

if (require.main === module) main();

module.exports = { toMs };
