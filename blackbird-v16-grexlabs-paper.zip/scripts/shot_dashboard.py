#!/usr/bin/env python3
"""Screenshot the live BlackBird dashboard with a real Chromium (Playwright).

    python3 scripts/shot_dashboard.py --url http://127.0.0.1:61500 --out shots

Produces:
    shots/dashboard-full.png     full page after the entrance overlay is dismissed
    shots/card-intel.png         the "هوش بازار" card, cropped
    shots/card-apprentice.png    the "کارآموز" card, cropped

The entrance overlay is a gesture gate, not authentication: the page ships a
quiet "ورود بدون حرکت" button for exactly this case, so we click it instead of
faking a pointer gesture.
"""
import argparse
import os
import sys

from playwright.sync_api import sync_playwright


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:61500")
    ap.add_argument("--out", default="shots")
    args = ap.parse_args()

    out = os.path.abspath(args.out)
    os.makedirs(out, exist_ok=True)

    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage"])
        # reduced_motion="reduce" turns every CSS animation/transition off, so an
        # element screenshot can never catch a card mid-fade (that produced an
        # all-black PNG for the last card in v12's first attempt).
        page = browser.new_page(
            viewport={"width": 1440, "height": 1000},
            device_scale_factor=2,
            reduced_motion="reduce",
        )
        page.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
        page.on("console", lambda m: errors.append(f"console: {m.text}") if m.type == "error" else None)

        page.goto(args.url, wait_until="networkidle", timeout=30000)

        enter = page.locator("#welcome-enter")
        if enter.count():
            try:
                enter.click(timeout=5000)
            except Exception:
                pass

        try:
            page.wait_for_function(
                "() => { const w = document.getElementById('welcome');"
                " return !w || w.hidden || getComputedStyle(w).display === 'none'; }",
                timeout=10000,
            )
        except Exception:
            pass

        page.wait_for_timeout(2500)

        titles = page.eval_on_selector_all(
            "article.card h2", "els => els.map(e => e.textContent.trim())"
        )
        print("cards rendered:", titles)

        page.screenshot(path=os.path.join(out, "dashboard-full.png"), full_page=True)
        print("wrote dashboard-full.png")

        for title, filename in (("هوش بازار", "card-intel.png"), ("کارآموز", "card-apprentice.png")):
            card = page.locator("article.card", has=page.locator("h2", has_text=title)).first
            if card.count():
                card.scroll_into_view_if_needed()
                page.wait_for_timeout(400)
                card.screenshot(path=os.path.join(out, filename))
                print(f"wrote {filename}")
            else:
                print(f"MISSING card: {title}")

        browser.close()

    if errors:
        print("--- page errors ---")
        for e in errors[:10]:
            print(e)
    else:
        print("no page errors")
    return 0


if __name__ == "__main__":
    sys.exit(main())
