#!/usr/bin/env node
'use strict';

// Phase-zero gate: fail early on unsafe or incomplete free-host deployments.
// This does not contact an exchange and never enables live trading.
const fs = require('node:fs');
const path = require('node:path');
const { loadConfig, validateConfig } = require('../src/config');

const root = path.resolve(__dirname, '..');
const cfg = loadConfig();
const result = validateConfig(cfg);
const problems = [...result.problems];
const warnings = [...result.warnings];

if (Number(process.versions.node.split('.')[0]) < 18) {
  problems.push(`Node 18+ is required (found ${process.version})`);
}
if (cfg.mode !== 'paper') {
  problems.push('phase zero is paper-only; set MODE=paper');
}
if (cfg.strategy.mode !== 'hybrid') {
  warnings.push(`strategy=${cfg.strategy.mode}; phase-zero baseline is hybrid`);
}
if (cfg.server.port < 0 || cfg.server.port > 65535) {
  problems.push(`server port is invalid: ${cfg.server.port}`);
}

for (const dir of [path.dirname(cfg.runtime.stateFile), cfg.reporter.dir, cfg.runtime.logDir]) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
  } catch (e) {
    problems.push(`directory is not writable: ${dir} (${e.message})`);
  }
}

const hasSecretsInEnv = ['API_KEY', 'API_SECRET'].some((key) => process.env[key]);
if (hasSecretsInEnv && cfg.mode === 'paper') {
  warnings.push('API credentials are present in the environment but are unused in paper mode');
}

console.log(`BlackBird phase-zero preflight | node=${process.version} mode=${cfg.mode} strategy=${cfg.strategy.mode} port=${cfg.server.port || 'auto (assigned at start)'}`);
for (const warning of warnings) console.log(`WARN  ${warning}`);
for (const problem of problems) console.log(`ERROR ${problem}`);

if (problems.length) {
  console.error(`Preflight failed: ${problems.length} blocking issue(s)`);
  process.exitCode = 2;
} else {
  console.log('Preflight passed: paper-only deployment is ready for validation.');
}
