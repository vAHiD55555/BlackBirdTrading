#!/usr/bin/env node
'use strict';
/**
 * BlackBird v3 — "Orbital" historical report.
 *
 * Replays the exact strategy that the live rotator trades (three momentum
 * variants + volatility targeting + drawdown throttle) over cached 1h candles
 * and writes a Persian markdown report plus a JSON blob.
 *
 *   node research/fetch.js --days=730 --tf=1h      # once, to fill the cache
 *   node scripts/report-v3.js                      # then this
 *
 * Costs are the real Binance USDⓈ-M futures schedule: 5bps taker, 2bps maker,
 * 1.5bps slippage per side. Funding is charged from real historical funding.
 */
const fs = require('node:fs');
const path = require('node:path');
const S = require('../research/sim');
const Z = require('../research/strategies');

const DIR = path.join(__dirname, '..', 'data', 'research');
const OUT = path.join(__dirname, '..', 'reports');
const TF = '1h';
const BPD = 24;
const START = 5000;
const COSTS = { maker: 2, taker: 5, slip: 1.5 };

const rc = {
  perPositionPct: 11,
  maxGrossPct: 150,
  volTargetPct: 45,
  volFloor: 0.3,
  volCap: 1.6,
  ddSteps: [0.08, 0.6, 0.15, 0.35, 0.22, 0.2],
};

function variants() {
  return [
    Z.xsMomentum({ look: 72, every: 168, top: 2, neutral: true, stopAtr: 6, gate: 'none', volWeight: false, notionalPct: 33, leverage: 2, tfPerDay: 24 }),
    Z.xsMomentum({ look: 168, every: 168, top: 2, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: 33, leverage: 2, tfPerDay: 24 }),
    Z.xsMomentum({ look: 168, skip: 24, every: 168, top: 3, neutral: true, stopAtr: 6, gate: 'btc', volWeight: false, notionalPct: 33, leverage: 2, tfPerDay: 24 }),
  ];
}

function load(sym) {
  return JSON.parse(fs.readFileSync(path.join(DIR, `${sym}-${TF}.json`), 'utf8'));
}

function runUniverse(symbols, label) {
  const raw = Object.fromEntries(symbols.map((s) => [s, load(s)]));
  const n = Math.min(...symbols.map((s) => raw[s].length));
  const data = Object.fromEntries(symbols.map((s) => [s, S.prep(raw[s].slice(0, n))]));
  const fund = {};
  for (const s of symbols) {
    try { fund[s] = JSON.parse(fs.readFileSync(path.join(DIR, `funding-${s}.json`), 'utf8')); } catch { /* none */ }
  }
  const runs = variants().map((strat) => S.run({ data, strat, start: START, costs: COSTS, funding: fund }));
  const L = Math.min(...runs.map((r) => r.equityCurve.length - 1));
  const rets = [];
  for (let i = 0; i < L; i++) {
    let x = 0;
    for (const r of runs) x += (r.equityCurve[i + 1] / r.equityCurve[i] - 1) / runs.length;
    rets.push(x);
  }
  return { label, symbols, raw, data, n, runs, rets, t0: raw[symbols[0]][0][0], t1: raw[symbols[0]][n - 1][0] };
}

/** Same overlays the live rotator applies at each rebalance. */
function overlaySeries(rets) {
  const out = [];
  let eq = START, peak = START;
  const hist = [];
  for (let i = 0; i < rets.length; i++) {
    let scale = 1;
    if (hist.length >= 20) {
      const w = hist.slice(-20);
      const m = w.reduce((a, b) => a + b, 0) / w.length;
      const v = Math.sqrt(w.reduce((a, b) => a + (b - m) ** 2, 0) / w.length) * Math.sqrt(365);
      scale *= Math.max(rc.volFloor, Math.min(rc.volCap, (rc.volTargetPct / 100) / Math.max(v, 1e-6)));
    }
    const dd = 1 - eq / peak;
    let f = 1;
    for (let k = 0; k < rc.ddSteps.length; k += 2) if (dd >= rc.ddSteps[k]) f = rc.ddSteps[k + 1];
    scale *= f;
    const r = rets[i] * scale;
    eq *= 1 + r;
    peak = Math.max(peak, eq);
    hist.push(r);
    out.push(r);
  }
  return out;
}

function curve(rets) {
  const c = [START];
  for (const r of rets) c.push(c[c.length - 1] * (1 + r));
  return c;
}

const TUNED = 'BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BNBUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT'.split(',');
const UNSEEN = 'DOTUSDT,BCHUSDT,ATOMUSDT,XLMUSDT,ETCUSDT,LINKUSDT,LTCUSDT,TRXUSDT'.split(',');

const results = [];
for (const [label, syms] of [['داده‌ی تنظیم (۸ ارز اصلی)', TUNED], ['داده‌ی آزمون (۸ ارز دست‌نخورده)', UNSEEN]]) {
  const u = runUniverse(syms, label);
  const blended = overlaySeries(u.rets);
  const m = S.metrics(curve(blended), START);

  // per-window consistency (4 months)
  const per = Math.max(20, Math.floor(blended.length / 6));
  const wins = [];
  for (let i = 0; i + per <= blended.length; i += per) {
    let eq = START;
    for (let k = i; k < i + per; k++) eq *= 1 + blended[k];
    wins.push((eq / START - 1) * 100);
  }
  // buy & hold reference
  const bh = syms.map((s) => ((u.data[s].c[u.n - 1] / u.data[s].c[0] - 1) * 100));
  const trades = u.runs.reduce((a, r) => a + r.trades, 0);
  results.push({ label, syms, m, wins, bh, trades, days: blended.length, t0: u.t0, t1: u.t1 });
}

const pct = (x) => `${x >= 0 ? '+' : ''}${x.toFixed(1)}%`;
const lines = [];
lines.push('# BlackBird v3 — «Orbital»  گزارش بک‌تست');
lines.push('');
lines.push(`تولید: ${new Date().toISOString().slice(0, 19).replace('T', ' ')} UTC · سرمایه‌ی شروع ${START}$ · هزینه‌ها: تیکر ۵bps، اسلیپیج ۱.۵bps، فاندینگ واقعی`);
lines.push('');
for (const r of results) {
  lines.push(`## ${r.label}`);
  lines.push('');
  lines.push(`- دوره: ${new Date(r.t0).toISOString().slice(0, 10)} تا ${new Date(r.t1).toISOString().slice(0, 10)} (${r.days} روز)`);
  lines.push(`- بازده کل: **${pct(r.m.totalReturnPct)}** · CAGR ${pct(r.m.cagrPct)}`);
  lines.push(`- حداکثر افت سرمایه: **${r.m.maxDrawdownPct.toFixed(1)}%** · کالمار ${r.m.calmar}`);
  lines.push(`- شارپ ${r.m.sharpe} · سورتینو ${r.m.sortino}`);
  lines.push(`- پنجره‌های مثبت: ${r.wins.filter((w) => w > 0).length}/${r.wins.length} (${r.wins.map((w) => pct(w)).join(' · ')})`);
  lines.push(`- خرید و نگهداری همان سبد: ${r.bh.map((x) => `${x.toFixed(0)}%`).join(' · ')}`);
  lines.push('');
  lines.push('| پنجره (۴ ماهه) | بازده |');
  lines.push('|---|---|');
  r.wins.forEach((w, i) => lines.push(`| ${i + 1} | ${pct(w)} |`));
  lines.push('');
}

const md = lines.join('\n');
fs.mkdirSync(OUT, { recursive: true });
const mdPath = path.join(OUT, 'v3-backtest.md');
fs.writeFileSync(mdPath, md);
fs.writeFileSync(path.join(OUT, 'v3-backtest.json'), JSON.stringify(results.map((r) => ({
  label: r.label, symbols: r.syms, days: r.days, from: new Date(r.t0).toISOString().slice(0,10), to: new Date(r.t1).toISOString().slice(0,10),
  totalReturnPct: r.m.totalReturnPct, cagrPct: r.m.cagrPct, maxDrawdownPct: r.m.maxDrawdownPct,
  sharpe: r.m.sharpe, sortino: r.m.sortino, calmar: r.m.calmar,
  windowsPct: r.wins.map((x) => +x.toFixed(1)), buyHoldPct: r.bh.map((x) => +x.toFixed(1)),
  trades: r.trades,
})), null, 1));

for (const r of results) {
  console.log(`\n${r.label}`);
  console.log(`  total ${pct(r.m.totalReturnPct)}  CAGR ${pct(r.m.cagrPct)}  maxDD ${r.m.maxDrawdownPct.toFixed(1)}%  sharpe ${r.m.sharpe}  calmar ${r.m.calmar}`);
  console.log(`  windows: ${r.wins.map((w) => pct(w)).join(' ')}  (${r.wins.filter((w) => w > 0).length}/${r.wins.length})`);
}
console.log(`\n📄 ${mdPath}`);
