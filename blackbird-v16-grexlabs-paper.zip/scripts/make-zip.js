#!/usr/bin/env node
'use strict';
/**
 * Build a real .zip without any external tool (no `zip` on Android).
 *
 *   node scripts/make-zip.js [outfile]
 *   node scripts/make-zip.js --root=<dir> --out=<file>
 *
 * Exported as buildZip(root, out) so scripts/make-bots.js can package the same
 * code with different config.json files without duplicating the zip logic.
 */
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const SKIP_DIRS = new Set(['node_modules', '.git', 'data', 'reports', 'dist', 'coverage', 'configs', 'shots']);
const SKIP_FILES = new Set(['.env', '.DS_Store']);

// ---- crc32 ---------------------------------------------------------------
let TABLE = null;
function crcTable() {
  if (TABLE) return TABLE;
  TABLE = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    TABLE[n] = c >>> 0;
  }
  return TABLE;
}
function crc32(buf) {
  const t = crcTable();
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = t[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function walk(dir, base, files) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const rel = path.relative(base, full).split(path.sep).join('/');
    const st = fs.statSync(full);
    if (st.isDirectory()) {
      // Skip runtime data dirs at ANY depth (run10b/data, data, ...), but never
      // src/data: that is source code, not a run's journal. The old rule only
      // skipped `data` at the project root, so a previous run's journal and
      // equity curve shipped inside the delivered zip.
      const isSourceData = name === 'data' && path.basename(dir) === 'src';
      if (SKIP_DIRS.has(name) && !isSourceData) continue;
      walk(full, base, files);
    } else if (st.isFile()) {
      if (SKIP_FILES.has(name)) continue;
      files.push({ rel, full, mtime: st.mtime, size: st.size });
    }
  }
}

function dosDateTime(d) {
  const year = d.getFullYear() < 1980 ? 1980 : d.getFullYear();
  const date = ((year - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  return { date, time };
}

function buildZip(root, out) {
  const files = [];
  walk(root, root, files);
  files.sort((a, b) => a.rel.localeCompare(b.rel));

  const chunks = [];
  const central = [];
  let offset = 0;

  for (const f of files) {
    const data = fs.readFileSync(f.full);
    const crc = crc32(data);
    let method = 8;
    let payload = zlib.deflateRawSync(data, { level: 9 });
    if (payload.length >= data.length) {
      method = 0;
      payload = data;
    }
    const nameBuf = Buffer.from(f.rel, 'utf8');
    const { date, time } = dosDateTime(f.mtime);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6); // UTF-8
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(payload.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);

    chunks.push(local, nameBuf, payload);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(0x0800, 8);
    cd.writeUInt16LE(method, 10);
    cd.writeUInt16LE(time, 12);
    cd.writeUInt16LE(date, 14);
    cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(payload.length, 20);
    cd.writeUInt32LE(data.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt16LE(0, 30);
    cd.writeUInt16LE(0, 32);
    cd.writeUInt16LE(0, 34);
    cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(0, 38);
    cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf);

    offset += local.length + nameBuf.length + payload.length;
  }

  const cdBuf = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, Buffer.concat([...chunks, cdBuf, eocd]));
  const size = fs.statSync(out).size;
  return { files: files.length, size, out };
}

module.exports = { buildZip };

if (require.main === module) {
  const arg = (n, d) => {
    const hit = process.argv.find((a) => a.startsWith(`--${n}=`));
    return hit ? hit.split('=')[1] : d;
  };
  const ROOT = path.resolve(__dirname, '..');
  const root = path.resolve(arg('root', ROOT));
  const out = path.resolve(arg('out', path.join(ROOT, 'dist', 'blackbird-trader.zip')));
  const r = buildZip(root, out);
  console.log(`✔ ${r.out}`);
  console.log(`  ${r.files} files, ${(r.size / 1024).toFixed(1)} KB`);
}
