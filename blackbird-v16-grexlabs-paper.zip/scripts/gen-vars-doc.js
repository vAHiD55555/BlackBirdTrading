'use strict';
/**
 * Generates docs/VARIABLES-FA.md from .env.example.
 *
 * Why generated and not hand-written: a hand-written catalog drifts from the
 * file the moment someone adds a variable, and a catalog that lists a variable
 * the code does not read is worse than no catalog. This reads the real file,
 * so the list is always exactly what the panel accepts.
 *
 * Usage: node scripts/gen-vars-doc.js
 */
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const ENV = path.join(ROOT, '.env.example');
const OUT = path.join(ROOT, 'docs', 'VARIABLES-FA.md');

// A variable is "required" when the shipped example leaves it empty, or when it
// is a credential with no keyless path. Everything else has a working default
// and can be left blank on the panel.
const SECRET = /(TOKEN|_KEY|PASS|SECRET|API_KEY)$/;
const truncate = (s, n) => (s.length <= n ? s : s.slice(0, n - 1).trimEnd() + '…');
const KEYLESS_OK = new Set([
  'JEV_API_KEY', 'ADVISOR_API_KEY', 'SUPERVISOR_API_KEY',
  'CLOUDFLARE_API_TOKEN', 'GROQ_API_KEY', 'GEMINI_API_KEY',
  'CEREBRAS_API_KEY', 'MISTRAL_API_KEY', 'OPENROUTER_API_KEY',
  'TELEGRAM_BOT_TOKEN', 'SMTP_PASS', 'SMTP_USER',
]);

const lines = fs.readFileSync(ENV, 'utf8').split('\n');

const sections = [];
let section = { title: 'عمومی', note: [], rows: [] };
let pending = []; // comment lines waiting to describe the next key

// A banner is three consecutive lines:  # ====…  /  # <title>  /  # ====…
// Detected by lookahead rather than a toggle, because a toggle desynchronises
// the moment one banner is malformed and then every later section is wrong.
// Both `=` and `═` (U+2550) are used in the file, so both count as a rule.
const isRule = (s) => /^#\s*[=═]{10,}\s*$/.test(s);
// A line that is mostly a rule character is decoration, never a description.
const isDecorative = (s) => /[=═]{6,}/.test(s);

for (let i = 0; i < lines.length; i++) {
  const line = lines[i].trimEnd();

  // A banner is a rule line, then one or more comment lines, then a rule line.
  // The block length varies (the file header is five lines, the section
  // banners are three), so scan forward for the closing rule instead of
  // assuming a fixed offset.
  if (isRule(line)) {
    let close = -1;
    for (let j = i + 1; j < Math.min(i + 10, lines.length); j++) {
      if (isRule(lines[j].trimEnd())) {
        close = j;
        break;
      }
      if (!lines[j].startsWith('#')) break;
    }
    if (close !== -1) {
      // A banner title is a heading, not a paragraph. The file header carries
      // three lines of prose; take the first one only, or the group table gets
      // a 300-character row.
      const heading = truncate(
        lines
          .slice(i + 1, close)
          .map((c) => c.replace(/^#\s*/, '').trim())
          .filter(Boolean)[0] || '',
        70
      );
      if (heading) {
        if (section.rows.length || section.note.length) sections.push(section);
        section = { title: heading, note: [], rows: [] };
      }
      pending = [];
      i = close;
      continue;
    }
    continue;
  }

  const kv = line.match(/^([A-Z][A-Z0-9_]*)=(.*)$/);
  if (kv) {
    const [, name, rawValue] = kv;
    // An inline "# …" after the value is a comment, not part of the value.
    // Splitting on it matters: `MAX_SPREAD_BPS=9   # spread above this` would
    // otherwise be documented as the value "9   # spread above this".
    const hashAt = rawValue.search(/\s#/);
    const value = (hashAt === -1 ? rawValue : rawValue.slice(0, hashAt)).trim();
    const inlineNote = hashAt === -1 ? '' : rawValue.slice(hashAt + 1).replace(/^#\s*/, '').trim();

    const desc = pending
      .map((c) => c.replace(/^#\s?/, '').trim())
      .filter((c) => c && !isDecorative(c) && !/^-{3,}/.test(c))
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();

    const empty = value === '';
    const required = empty || (SECRET.test(name) && !KEYLESS_OK.has(name));
    section.rows.push({
      name,
      value,
      // A long block of prose above a key is context, not a one-line answer.
      // Cap it so the table stays readable; the full text is in .env.example.
      desc: truncate([desc, inlineNote].filter(Boolean).join(' — '), 220),
      required,
    });
    pending = [];
    continue;
  }

  if (line.startsWith('#')) {
    pending.push(line);
    continue;
  }
  if (line.trim() === '') {
    if (pending.length && lines[i + 1] && !lines[i + 1].startsWith('#')) pending = [];
    continue;
  }
  pending = [];
}
if (section.rows.length) sections.push(section);

// ------------------------------------------------------------------ render
const esc = (s) => String(s).replace(/\|/g, '\\|');
const total = sections.reduce((n, s) => n + s.rows.length, 0);
const requiredCount = sections.reduce((n, s) => n + s.rows.filter((r) => r.required).length, 0);

const out = [];
out.push('# کاتالوگ متغیرهای محیطی — BlackBird');
out.push('');
out.push('این فایل **خودکار** از `.env.example` ساخته می‌شود. اگر متغیری اضافه یا حذف شد، دوباره بسازید:');
out.push('');
out.push('```bash');
out.push('node scripts/gen-vars-doc.js');
out.push('```');
out.push('');
out.push(`**${total}** متغیر در **${sections.length}** گروه. از این تعداد **${requiredCount}** اجباری است.`);
out.push('');
out.push('> همهٔ این متغیرها از **پنل botkeep** خوانده می‌شوند. هیچ‌کدام نیاز به ویرایش فایل روی سرور ندارند.');
out.push('> متغیری که خالی بماند، پیش‌فرض امن خودش را می‌گیرد — مگر در ستون «اجباری» با ✅ علامت خورده باشد.');
out.push('');
out.push('## فهرست گروه‌ها');
out.push('');
out.push('| گروه | تعداد | اجباری |');
out.push('|---|---|---|');
for (const s of sections) {
  out.push(`| ${esc(s.title)} | ${s.rows.length} | ${s.rows.filter((r) => r.required).length} |`);
}
out.push('');

for (const s of sections) {
  out.push(`## ${s.title}`);
  out.push('');
  out.push('| متغیر | مقدار پیشنهادی | توضیح | اجباری |');
  out.push('|---|---|---|---|');
  for (const r of s.rows) {
    const val = r.value === '' ? '—' : `\`${r.value.length > 60 ? r.value.slice(0, 57) + '…' : r.value}\``;
    out.push(`| \`${r.name}\` | ${esc(val)} | ${esc(r.desc || '—')} | ${r.required ? '✅' : '—'} |`);
  }
  out.push('');
}

out.push('---');
out.push('');
out.push('## یادداشت‌های عملیاتی');
out.push('');
out.push('1. **`MODE=paper` را تا پایان تست تغییر ندهید.** تنها با `MODE=live` سفارش واقعی ارسال می‌شود.');
out.push('2. **`SERVER_TOKEN` را حتماً ست کنید.** بدون آن پنل روی سرور عمومی باز است.');
out.push('3. **`KILL_SWITCH_DD_PCT` را بالاتر از `0.12` نبرید.** قانون‌نامه بند ۷ سقف ۱۲٪ می‌گذارد.');
out.push('4. **`JEV_PROVIDER` را فقط یک بار تعریف کنید.** تعریف تکراری در `.env` یعنی یکی بی‌صدا نادیده گرفته می‌شود.');
out.push('5. **`INTEL_*_FALLBACK_URL` را خالی نگذارید.** GDELT از IP دیتاسنتر کد ۴۲۹ می‌دهد.');
out.push('6. **کلیدها را در Git نگذارید.** `.env` در `.gitignore` است و در زیپ تحویلی هم نیست.');
out.push('');

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, out.join('\n'), 'utf8');
console.log(`wrote ${path.relative(ROOT, OUT)} — ${total} variables in ${sections.length} groups (${requiredCount} required)`);
