# GrexLabs paper AI test

Use only for a 3-7 day PAPER evaluation. GrexLabs is an external keyless gateway; do not send secrets, account data, or credentials.

Environment:
MODE=paper
EXCHANGE=binance
WITNESS_EXCHANGE=bybit
JEV_ENABLED=true
JEV_PROVIDER=grex
JEV_MODEL=auto:free
JEV_BASE_URL=https://www.grexlabs.in/api/v1
JEV_KEYLESS_FALLBACK=grex,pollinations,mock
JEV_ALLOW_LOCAL=false
JEV_TIMEOUT_MS=20000
JEV_ALLOW_VETO=true
STRATEGIST_ENABLED=true
STRATEGIST_CRISIS_AUTHORITY=false
JEV_CONSENSUS_ENABLED=false
JEV_LEDGER_ENABLED=true

The model may advise, mediate, and supervise. Hard risk, paper execution, veto, exposure limits and crisis safety remain in deterministic code.

After restart, check logs for provider=grex and ready=true. If unavailable, fallback/mock must fail closed; do not switch to live mode.
