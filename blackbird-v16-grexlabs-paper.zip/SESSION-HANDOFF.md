# BlackBird Hybrid — Session Handoff

## وضعیت فعلی

- پایه‌ی توسعه: Bbot / Orbital v3
- علت انتخاب: استراتژی مومنتوم مقطعی، تنوع بین نمادها، ری‌بالانس کم‌تعداد و گزارش بک‌تست خارج از نمونه.
- Abot و Bbot از نظر کد اجرایی تقریباً یکسان بودند؛ تفاوت اصلی در `config.json` بود.
- هر دو نسخه تست شدند: 66 passed, 0 failed.
- هر دو نسخه در حالت `paper` هستند و اجرای واقعی سفارش هنوز فعال نیست.
- بررسی شبکه‌ی doctor در محیط فعلی برای Binance و Bybit timeout داد؛ این موضوع باید در محیط BotKeep دوباره بررسی شود.

## تصمیم معماری

نسخه‌ی هدف: `Hybrid Orbital-Pullback`

- Orbital به‌عنوان هسته‌ی تخصیص سبد و مومنتوم.
- Pullback به‌عنوان فیلتر ورود تاکتیکی.
- استراتژی سوم برای حالت دفاعی/کنترل ریسک، پس از بک‌تست و اعتبارسنجی.
- شورای نظارت برای رأی‌گیری، quorum و veto.
- JEV برای کاهش تأخیر تصمیم تا اجرای سفارش.
- Risk Manager مشترک برای جلوگیری از جمع‌شدن اکسپوژر.

## الزامات ثبت‌شده

- امنیت سایبری و fail-closed.
- خاموشی اضطراری در سطح برنامه (`OFFLINE_LOCK`) و در صورت امکان قطع شبکه در سطح زیرساخت.
- هشدارهای ایمیلی برای گزارش کامل و WhatsApp رسمی برای هشدارهای بحرانی.
- داشبورد آنلاین، حرفه‌ای و فقط‌خواندنی.
- گزارش ساعتی معامله‌گر شامل مشاهده‌ی بازار، علت تصمیم، سطح اطمینان و مقایسه‌ی پیش‌بینی با واقعیت.
- ذخیره‌ی audit trail و پشتیبان ثانویه‌ی redact‌شده؛ عدم ذخیره‌ی secret در GitHub.
- آماده‌سازی برای BotKeep با یک process، start command مشخص، secrets محیطی و persistence.

## داشبورد تأییدشده و پیاده‌سازی‌شده

سبک انتخابی: `Glass Liquidity Pro`

فایل پیاده‌سازی:

- `src/web/dashboard.html`

قابلیت‌های فعلی:

- ظاهر شیشه‌ای تیره با رنگ‌های cyan/green.
- کارت equity، P&L، drawdown و JEV.
- نمودار زنده‌ی equity در مرورگر.
- وضعیت شورای استراتژی.
- جدول بازار و نقدشوندگی.
- پوزیشن‌های باز.
- گزارش آخرین وضعیت معامله‌گر.
- وضعیت کنترل‌های ریسک، witness و offline lock.
- timeline امنیتی/حسابرسی.
- بدون کنترل معاملاتی در رابط کاربری؛ داشبورد view-only طراحی شده است.

پروژه‌ی کاری مستقل:

- `/root/blackbird-hybrid`

نمونه‌های بصری اولیه:

- `/root/dashboard-concepts/glass-liquidity-pro.svg`
- `/root/dashboard-concepts/liquid-aurora.svg`
- `/root/dashboard-concepts/secure-glass-terminal.svg`

## مرحله‌ی بعد

1. دریافت و بررسی لاگ‌های ABot و Bbot.
2. اصلاح خطاهای واقعی در startup، شبکه، WebSocket/REST، JEV، broker، risk و portfolio.
3. تکمیل endpointهای read-only با headerهای امنیتی و احراز هویت مشاهده.
4. اضافه‌کردن observer ساعتی و journal ساختاریافته‌ی باور/تصمیم/نتیجه.
5. تکمیل notification router برای Email و WhatsApp رسمی.
6. انتقال سه استراتژی و شورای نظارت به معماری hybrid.
7. افزودن تست‌های امنیتی، تست قطع شبکه و تست بازیابی state.
8. آماده‌سازی lockfile، health check و deployment configuration برای BotKeep.
9. اجرای paper و walk-forward قبل از هرگونه live.

## نکات مهم

- هیچ API key، secret، password یا token در لاگ، ZIP، repository یا این فایل ذخیره نشود.
- live mode تا زمان تکمیل paper validation و مسیر kill switch فعال نشود.
- مدل زبانی/ناظر فقط پیشنهاد و توضیح بدهد و اختیار مستقیم ارسال سفارش نداشته باشد.

## یافته‌ی مقایسه‌ی اجرای پلتفرم‌ها — 2026-11-06

سه آرشیو بررسی شد:

- آرشیو A: `discretionary`، چهار نماد، paper روی Binance، بازه‌ی 6 ساعته؛ دو پوزیشن باز، `equity=5002.55` و `equityMtm=5004.00`.
- آرشیو B: `discretionary`، چهار نماد، paper روی Binance، اما بازه‌ی زمانی متفاوت؛ بدون پوزیشن باز، `equity=equityMtm=5003.07`.
- آرشیو C: `rotator`، هشت نماد، تایم‌فریم ساعتی؛ چهار short از state قبلی بازیابی شده، `equity=4913.43`، سود باز `110.24` و `equityMtm=5023.67`.

نتیجه:

- اختلاف مشاهده‌شده فعلاً به‌تنهایی قابل انتساب به BotKeep یا پلتفرم دوم نیست؛ strategy، تعداد نماد، تایم‌فریم، بازه‌ی زمانی و state یکسان نیستند.
- در همه‌ی گزارش‌ها witness امتیاز 100/100 و journal chain معتبر است؛ نشانه‌ای از خرابی داده یا دستکاری گزارش دیده نشد.
- JEV در اجرای discretionary فعال بوده (`p50` حدود 4–5ms)، ولی در اجرای rotator سفارش جدیدی صادر نشده و `n=0` طبیعی است.
- در اجرای rotator، مقایسه باید با `equityMtm` انجام شود، نه فقط `equity`. در غیر این صورت سود باز به‌صورت افت نقدی نمایش داده می‌شود.
- در نسخه‌ی بعدی باید `cash equity`، `unrealized P&L` و `mark-to-market equity` جدا و شفاف در گزارش و داشبورد نمایش داده شوند.

برای اثبات اختلاف پلتفرم، هنوز لازم است از هر اجرا این موارد جمع شود: config مؤثر پس از env، commit/version، زمان شروع process، timezone، state snapshot، tail ژورنال و خطاهای شبکه/WebSocket.

## نقطه‌ی توقف فعلی

برای مرحله‌ی بعد کاربر باید ساختار بات جدید را ارسال کند. موارد موردنیاز:

- tree کامل پروژه
- `package.json` و lockfile
- config نمونه بدون secret
- engine/config/strategy/rotator
- risk، broker، portfolio و market data
- status server و dashboard
- start/deploy مربوط به BotKeep
- نسخه Node.js و environmentهای غیرحساس
- state و journal نمونه‌ی redact‌شده
- لاگ‌های startup، reconnect، شبکه و shutdown

هر API key، secret، password، token یا اطلاعات خصوصی حساب نباید ارسال شود.

## بررسی ZIP اجرای Abot — 2026-11-06

ZIP جدید `Abot-FINAL.zip` با source tree قبلی Abot مقایسه شد:

- فایل‌های `src/`, `scripts/`, `research/` و `tests/` از نظر checksum یکسان‌اند.
- تفاوت فقط این است که ZIP جدید `data/` و `reports/` runtime را ندارد؛ این برای deploy تمیز مناسب است.
- `config.json` صراحتاً Abot است: `discretionary`، چهار نماد، `15m`، paper، Binance→Bybit.

سرنخ مهم:

- `.env.example` و راهنمای deploy تنظیمات Bbot/Orbital را پیشنهاد می‌کنند: `BB_STRATEGY=rotator`، هشت نماد و `1h`.
- طبق `src/config.js`، environment variables بعد از `config.json` اعمال می‌شوند و اولویت دارند.
- بنابراین ممکن است یک ZIP واحد روی یک پلتفرم به‌صورت Abot و روی پلتفرم دیگر به‌صورت Bbot اجرا شده باشد. این دقیقاً با گزارش C (`strategy=rotator`، هشت نماد، پوزیشن‌های short) سازگار است و محتمل‌ترین علت اختلاف نتایج است.
- در زمان تغییر strategy باید data directory/state جدا استفاده شود؛ state یک strategy نباید به strategy دیگر منتقل شود.

اختلاف پورت:

- `config.json` در Abot پورت `8788` دارد.
- `.env.example` و `deploy/botkeep.md` پورت `8787` را می‌نویسند.
- این mismatch احتمالاً روی معامله اثر ندارد، اما می‌تواند باعث شود داشبورد روی پلتفرم قابل‌دسترسی نباشد یا به workload دیگری وصل شود.

اقدام بعدی لازم:

- از startup log هر پلتفرم، مقدار نهایی `strategy`, `symbols`, `timeframe`, `port`, `dataDir` و hash تنظیمات را استخراج کنیم.
- برای Abot صراحتاً `BB_STRATEGY=discretionary`, چهار symbol و `BB_INTERVAL=15m` تنظیم شود.
- برای Botkeep پورت اختصاصی پلتفرم با adapter درست خوانده شود، نه دو مقدار دستی 8787/8788.

## نتیجه‌ی مقایسه‌ی سود — 2026-11-06

در بازه‌های موجود، اجرای C با `rotator` بهترین نتیجه‌ی mark-to-market را داشت:

- A / discretionary: از 5000 به 5004، بازده حدود 0.08٪، کمینه‌ی MTM برابر 4998.60.
- B / discretionary: از 5000 به 5003.07، بازده حدود 0.061٪.
- C / rotator: از 5000 به 5023.67، بازده حدود 0.473٪، کمینه‌ی MTM برابر 4993.99 و افت حدود 1.11٪.

تفسیر:

- مزیت C با گرفتن short در حرکت نزولی و تنوع هشت‌نمادی سازگار است.
- این نمونه کوتاه برای تغییر پارامترها یا تضمین برتری کافی نیست، چون state، strategy، نمادها و زمان یکسان نیستند.
- قابلیت rotator/short در پایه‌ی Bbot از قبل وجود دارد؛ بنابراین رفتار سودده جدیدی بدون بررسی بیشتر به‌صورت کور اضافه نشد.

تغییر مفید و کم‌ریسک اعمال‌شده:

- `Engine.status()` اکنون `unrealised`، `equityMtm` و fingerprint تنظیمات مؤثر را برمی‌گرداند تا مقایسه‌ی پلتفرم‌ها و وضعیت واقعی سرمایه اشتباه نشود.
- fingerprint فقط از تنظیمات غیرمحرمانه ساخته می‌شود و secretها را در خود ندارد.
- `node --check` و هر 66 تست پروژه موفق هستند.

## بررسی و ادغام ایده‌های Vibe-Trading — 2026-11-06

از Vibe-Trading ایده‌های زیر برای پروژه انتخاب شد:

- Risk X-Ray برای تفکیک long/short، gross/net، concentration و MTM.
- جداسازی research/evidence از اجرای زنده؛ مدل یا کد تولیدی نباید اختیار مستقیم سفارش داشته باشد.
- اجرای فقط‌خواندنی داشبورد و hardening مسیرهای HTTP.

پیاده‌سازی‌شده:

- `src/risk/xray.js` با گزارش exposure و `equityMtm`.
- `Engine.status()` اکنون `riskXray` و fingerprint تنظیمات را برمی‌گرداند.
- `src/web/status.js` اکنون کاملاً read-only است؛ endpointهای action حذف شدند و headerهای امنیتی اضافه شدند.
- تست Risk X-Ray اضافه شد.
- تست‌ها: 67 passed, 0 failed.

عمداً وارد نشد:

- واردکردن مستقیم 478 alpha یا وابستگی Python/LLM؛ برای هسته‌ی کم‌ریسک فعلی پیچیدگی و overfitting اضافه می‌کند.
- اعتماد دادن به کد تولیدشده توسط مدل برای اجرای سفارش؛ research باید sandbox و paper-only باشد.
