# v13 — هوش بازار با GDELT واقعی

## خلاصه

کارت «هوش بازار» از حالت خاموش به حالت فعال رفت و **۹۲ خبر واقعی** خواند.
اما GDELT از این سرور جواب نداد — و این را صادقانه گزارش می‌کند.

---

## ۱. نتیجهٔ تست GDELT (واقعی، اجراشده)

سه درخواست خام با `curl`، هر کدام با ۶ ثانیه فاصله:

| تلاش | کد HTTP |
|---|---|
| ۱ | **429** |
| ۲ | **200** |
| ۳ | **429** |

**نتیجه:** GDELT از IP مشترک دیتاسنتر **متناوب** جواب می‌دهد. سقفش «یک درخواست در هر ۵ ثانیه به ازای هر IP» است، و چون IP مشترک است، درخواست‌های دیگران سهم ما را می‌خورند.

پیام خطای خود GDELT:
```
Please limit requests to one every 5 seconds or contact kalev.leetaru5@gmail.com
for larger queries.
```

### چرا این یک باگ بود، نه فقط یک محدودیت

نسخهٔ v12 فقط **JSON** می‌خواند و **fallback** نداشت. یعنی:
- GDELT ۴۲۹ می‌داد
- هیچ منبع دیگری نبود
- کارت خالی می‌ماند
- ولی `enabled: true` گزارش می‌شد

یعنی داشبورد می‌گفت «فعال است» در حالی که هیچ داده‌ای نداشت. این بدترین حالت است: خرابی که خودش را سالم نشان می‌دهد.

---

## ۲. سه اصلاحی که انجام شد

### الف) پارسر RSS بومی (بدون وابستگی)

`parseRss()` و `decodeEntities()` به `src/intel/news.js` اضافه شد.
- RSS 2.0 و Atom هر دو
- CDATA باز می‌شود
- entityها (`&#39;`، `&amp;`، `&quot;`) رمزگشایی می‌شوند
- تگ‌های HTML حذف می‌شوند تا مارک‌آپ به امتیازدهی نرسد
- ورودی خراب → `[]`، هرگز throw نمی‌کند

### ب) زنجیرهٔ جایگزین (fallback)

هر فید حالا دو آدرس دارد: `url` (اصلی) و `fallbackUrl` (پشتیبان).

```
macro   → GDELT (json) → BBC Business RSS
geo     → GDELT (json) → BBC World RSS
weather → GDELT (json) → Al Jazeera RSS
```

وضعیت هر فید جداگانه ثبت می‌شود:

```json
{ "ok": true, "source": "fallback", "error": null, "items": 58 }
```

`source` می‌گوید داده از کجا آمده. کارت داشبورد همین را نشان می‌دهد — نه یک ادعای مبهم.

### ج) تلاش مجدد برای ۴۲۹

چون ۴۲۹ گذرا است، یک retry با ۶ ثانیه تأخیر اضافه شد.
- فقط برای ۴۲۹ (خطای ۵۰۰ هرگز retry نمی‌شود)
- پیش‌فرض: `INTEL_RETRY_429=1`
- قابل خاموش‌کردن از پنل

---

## ۳. نتیجهٔ اجرای واقعی ربات

ربات با `node src/index.js` روی پورت ۶۱۶۰۰ بوت شد، ۸ نماد، حالت paper.

کارت «هوش بازار» روی داشبورد:

> **هوش بازار** — سالم
> ۹۲ خبر خوانده شد؛ جوّ بازار عادی است. — منابع: ۳/۳ (۳ از پشتیبان)

**ترجمهٔ صادقانه:** هر سه فید جواب دادند، اما **هر سه از منبع پشتیبان** — یعنی GDELT در آن لحظه ۴۲۹ می‌داد.

| فید | منبع | تعداد خبر |
|---|---|---|
| macro | fallback (BBC Business) | ۵۸ |
| geo | fallback (BBC World) | ۲۷ |
| weather | fallback (Al Jazeera) | ۲۵ |

مجموع: ۹۲ خبر. لحن: `-0.331` (کمی محتاطانه). ضریب ریسک: `1` (بدون کاهش، چون شدت کافی نبود).

---

## ۴. متغیرهای پنل (جدول کامل هوش بازار)

| متغیر | مقدار پیشنهادی | توضیح | اجباری؟ |
|---|---|---|---|
| `INTEL_ENABLED` | `true` | کلید اصلی هوش بازار | خیر |
| `INTEL_REFRESH_MS` | `900000` | هر ۱۵ دقیقه تازه‌سازی | خیر |
| `INTEL_TIMEOUT_MS` | `8000` | مهلت هر درخواست | خیر |
| `INTEL_RETRY_429` | `1` | تعداد تلاش مجدد برای ۴۲۹ | خیر |
| `INTEL_RETRY_DELAY_MS` | `6000` | فاصلهٔ تلاش مجدد | خیر |
| `INTEL_BLACKOUT_BEFORE_MS` | `1800000` | ۳۰ دقیقه قبل از رویداد: ورود ممنوع | خیر |
| `INTEL_BLACKOUT_AFTER_MS` | `900000` | ۱۵ دقیقه بعد از رویداد | خیر |
| `INTEL_EXTREME_THRESHOLD` | `0.6` | آستانهٔ «لحن شدید» | خیر |
| `INTEL_MAX_RISK_IMPACT` | `0.25` | سقف کاهش ریسک (هرگز بیشتر نمی‌شود) | خیر |
| `INTEL_MACRO_URL` | GDELT (نگاه کنید پایین) | فید اقتصادی | خیر |
| `INTEL_MACRO_PATH` | `articles` | مسیر آرایه در JSON | خیر |
| `INTEL_MACRO_FORMAT` | `json` | `json` یا `rss` | خیر |
| `INTEL_MACRO_FALLBACK_URL` | `https://feeds.bbci.co.uk/news/business/rss.xml` | پشتیبان | **توصیه‌شده** |
| `INTEL_GEO_URL` | GDELT | فید سیاسی | خیر |
| `INTEL_GEO_PATH` | `articles` | | خیر |
| `INTEL_GEO_FORMAT` | `json` | | خیر |
| `INTEL_GEO_FALLBACK_URL` | `https://feeds.bbci.co.uk/news/world/rss.xml` | پشتیبان | **توصیه‌شده** |
| `INTEL_WEATHER_URL` | GDELT | فید هواشناسی | خیر |
| `INTEL_WEATHER_PATH` | `articles` | | خیر |
| `INTEL_WEATHER_FORMAT` | `json` | | خیر |
| `INTEL_WEATHER_FALLBACK_URL` | `https://www.aljazeera.com/xml/rss/all.xml` | پشتیبان | **توصیه‌شده** |

### آدرس‌های GDELT (کپی-پیست)

```
INTEL_MACRO_URL=https://api.gdeltproject.org/api/v2/doc/doc?query=inflation%20OR%20%22rate%20decision%22%20OR%20CPI&mode=artlist&format=json&maxrecords=40&sort=datedesc
INTEL_GEO_URL=https://api.gdeltproject.org/api/v2/doc/doc?query=war%20OR%20sanctions%20OR%20conflict%20OR%20election&mode=artlist&format=json&maxrecords=40&sort=datedesc
INTEL_WEATHER_URL=https://api.gdeltproject.org/api/v2/doc/doc?query=hurricane%20OR%20flood%20OR%20drought%20OR%20heatwave&mode=artlist&format=json&maxrecords=40&sort=datedesc
```

---

## ۵. تست‌ها

`node tests/run.js` → **۶۴۵ پاس، ۰ شکست** (خط پایهٔ v12: ۶۳۰)

مجموعهٔ جدید `tests/intel-rss.test.js` — ۱۵ تست:

| تست | چه چیزی را قفل می‌کند |
|---|---|
| parseRss × ۴ | RSS 2.0، Atom، CDATA، ورودی خراب |
| decodeEntities | حذف تگ HTML |
| fallback × ۴ | ۴۲۹ → پشتیبان، موفقیت اصلی، هر دو خراب، timeout |
| safety × ۳ | ضریب ریسک ≤ ۱، snapshot، enabled=false |
| retry × ۳ | ۴۲۹ یک بار retry، خاموش‌کردن، ۵۰۰ بدون retry |

زیپ استخراج شد و دوباره تست زده شد → **۶۴۵ پاس**.

---

## ۶. چه چیزی واقعاً اجرا شد

- `curl` سه‌باره به GDELT → ۴۲۹، ۲۰۰، ۴۲۹
- `curl` به BBC/Al Jazeera → همه ۲۰۰
- `node tests/intel-rss.test.js` → ۱۵ پاس
- `node tests/run.js` → ۶۴۵ پاس
- `node scripts/preflight.js` → پاس
- بوت واقعی `node src/index.js` → ۸ نماد، پنل روی ۶۱۶۰۰
- `curl /api/public/summary` → کارت هوش بازار با ۹۲ خبر
- **Chromium واقعی** → ۹ کارت، صفر خطای صفحه
- بررسی چشمی اسکرین‌شات‌ها → RTL درست، بدون متن بریده
- `make-zip.js` → ۲۴۱ فایل، بدون `.env`، بدون `data/`
- استخراج زیپ + تست مجدد → ۶۴۵ پاس

## ۷. چه چیزی فقط خوانده شد

- منطق عمیق `risk.js` / `board.js` / `court.js`
- رفتار دیده‌بان در بازار زنده
- اتصال طولانی‌مدت به صرافی
- رندر موبایل (فقط ۱۴۴۰ پیکسل تست شد)
- انیمیشن‌ها در حرکت (با `reduced_motion` خاموش شدند)

---

## ۸. rollback

### کامل
زیپ v12 دست‌نخورده:
`documents/blackbird-v12/blackbird-trader-v12-branding-2026-11-22.zip`

هیچ مهاجرت داده‌ای لازم نیست. `data/` ساختارش تغییر نکرد.

### جزئی
| هدف | کار |
|---|---|
| خاموش‌کردن هوش بازار | `INTEL_ENABLED=false` |
| برگشت به رفتار v12 (بدون fallback) | `INTEL_*_FALLBACK_URL=` را خالی کنید |
| خاموش‌کردن retry | `INTEL_RETRY_429=0` |
| برگشت به GDELT-only | `INTEL_*_FORMAT=json` و fallback خالی |

⚠️ اگر fallback را خالی کنید و GDELT ۴۲۹ بدهد، کارت خالی می‌ماند — همان باگ v12.

---

## ۹. هشدار

⚠️ همه در حالت **paper** بود. هیچ سفارش واقعی ارسال نشد.
⚠️ هوش بازار فقط ریسک را **کم** می‌کند، هرگز زیاد نمی‌کند. این در تست قفل شده.
⚠️ GDELT از IP دیتاسنتر قابل اتکا نیست. fallback را خالی نگذارید.
