# اجرا روی Botkeep.cloud

## تنظیمات Workload

| مورد | مقدار |
|---|---|
| Runtime | Node.js 18 یا بالاتر |
| Start command | `npm start` (یا `node src/index.js`) |
| پورت | همان که پنل می‌دهد؛ کد `SERVER_PORT` و `PORT` را می‌خواند |
| منبع | آپلود همین فایل ZIP |

## متغیرهای محیطی (پیشنهادی)

```
MODE=paper
EXCHANGE=mexc
WITNESS_EXCHANGE=bitget
DATA_DIR=/app/data
ADMIN_TOKEN=<یک رشته‌ی تصادفی>
```

- اگر پنل `SERVER_PORT` بدهد، همان استفاده می‌شود؛ نیازی به ست‌کردن پورت نیست.
- روی Botkeep دیسک با هر Redeploy پاک می‌شود. برای ماندگاری State، ژورنال و گزارش‌ها `DATA_DIR` را روی یک Volume پایدار بگذارید (طبق هشدار §25.11 قانون‌نامه).
- بدون `ADMIN_TOKEN` پنل `/ops` فقط‌خواندنی و قفل است.

## بررسی سلامت

```
/healthz   پروسه زنده است
/readyz    داده‌ی بازار تازه است (۵۰۳ اگر نباشد)
```
