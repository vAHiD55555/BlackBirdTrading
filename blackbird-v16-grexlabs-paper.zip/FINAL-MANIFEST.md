# BlackBird Trader v16 — tested paper package

Validation: Node.js 22, npm test = 707 passed / 0 failed.
Preflight: passed, paper-only.

Safe first deployment:
- MODE=paper
- EXCHANGE=binance
- WITNESS_EXCHANGE=bybit
- JEV_ENABLED=false
- STRATEGIST_ENABLED=false
- STRATEGIST_CRISIS_AUTHORITY=false

The platform-provided PORT is honored. The config port is only a local development fallback.
No API keys, .env, node_modules, runtime state, reports, or private data are included.
