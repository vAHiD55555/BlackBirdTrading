# BlackBird v15 — گزارش تست امنیتی فید خبری و بک‌تست هوش بازار

تاریخ: ۲۰۲۶-۱۱-۲۲ · حالت: **paper** · هیچ سفارش واقعی ارسال نشد.

---

## ۱) تست فید خبری مخرب — باگ پیدا شد و رفع شد

### باگ

`decodeEntities()` در `src/intel/news.js` تگ‌ها را با `/<[^>]+>/g` حذف می‌کرد. این الگو به یک `>` **بسته** نیاز دارد. پس تگ **باز** از آن رد می‌شد:

```
<title>Fed &lt;img src=x onerror=alert(1) hikes</title>
  →  "Fed <img src=x onerror=alert(1) hikes"
```

سه سوراخ دیگر با همان ریشه:

| ورودی | نتیجهٔ قبل از اصلاح |
|---|---|
| `javascript:alert(1) FOMC` | دست‌نخورده رد می‌شد |
| `a\u0000b\u001b[31m CPI` | کاراکتر کنترلی و ANSI باقی می‌ماند |
| تیتر ۲۰۰٬۰۰۰ کاراکتری | بدون سقف پذیرفته می‌شد |
| سند ۵٬۰۰۰ آیتمی | بدون سقف پذیرفته می‌شد |
| مسیر JSON (`extractItems`) | هیچ sanitize نداشت |

**چرا مهم است:** تیتر خنثی نیست. در گزارش تلگرام، گزارش مارک‌داون روی دیسک، ژورنال و payload داشبورد نوشته می‌شود. هر کدام که بعداً آن را HTML رندر کند، فید خبری را به وکتور تزریق تبدیل می‌کند. ANSI escape هم چیزی را که اپراتور در ترمینال می‌بیند بازنویسی می‌کند.

### اثبات شکست قبل از اصلاح

```
$ node tests/intel-sanitize.test.js
  ✗ hostile: an UNCLOSED <img onerror> headline is dropped
  ✗ hostile: a <script> payload is dropped
  ✗ hostile: a CDATA-wrapped <img onerror> is dropped
  ✗ hostile: a double-encoded &lt;script&gt; is dropped
  ✗ hostile: a javascript: scheme is dropped
  ✗ hostile: a bare event handler is dropped
  ✗ noise: control characters and ANSI escapes are removed, headline kept
  ✗ hostile: an oversized title is capped
  ✗ hostile: a 5000-item document is capped
  ✗ hostile: the JSON feed path is sanitised as well
  ✗ hostile: a poisoned feed never puts markup in the aggregate view
  ✗ hostile: sanitising does not damage a normal headline
  intel-sanitize: 2 passed, 12 failed
```

### اصلاح

`src/intel/news.js`:

1. **`decodeRaw()`** — entityها را باز می‌کند و CDATA را باز می‌کند، اما تگ‌ها را **در جای خود نگه می‌دارد**. این شکلِ ورودی sanitizer است. اگر اول تگ را حذف کنیم، `<script>alert(1)</script>` به `alert(1)` بی‌خطرنما تبدیل می‌شود و حمله از دید همهٔ بررسی‌های بعدی پنهان می‌ماند.
2. **`sanitizeTitle()`** — دو رفتار متفاوت، عمداً:
   - کاراکتر کنترلی و ANSI = **نویز** → پاک می‌شود، تیتر می‌ماند.
   - تگ، `javascript:`، `onerror=` = **حمله** → کل تیتر **حذف** می‌شود. تیتر خبری واقعی هیچ‌وقت `<img` ندارد؛ ترمیم کردن فقط رشتهٔ مخرب را در خط لوله نگه می‌دارد.
3. **سقف‌ها** — `MAX_TITLE_CHARS = 400`، `MAX_ITEMS = 500`.
4. **هر دو مسیر** — `parseRss` و `extractItems` هر دو از همان sanitizer رد می‌شوند.

### اثبات پاس بعد از اصلاح

```
$ node tests/intel-sanitize.test.js
  ✓ hostile: an UNCLOSED <img onerror> headline is dropped
  ✓ hostile: a <script> payload is dropped
  ✓ hostile: a CDATA-wrapped <img onerror> is dropped
  ✓ hostile: a double-encoded &lt;script&gt; is dropped
  ✓ hostile: a javascript: scheme is dropped
  ✓ hostile: a bare event handler is dropped
  ✓ hostile: a title that is ONLY markup is dropped
  ✓ noise: control characters and ANSI escapes are removed, headline kept
  ✓ hostile: an oversized title is capped
  ✓ hostile: a 5000-item document is capped
  ✓ hostile: the JSON feed path is sanitised as well
  ✓ hostile: a poisoned feed never puts markup in the aggregate view
  ✓ hostile: sanitising does not damage a normal headline
  ✓ hostile: decodeEntities still decodes the harmless entities
  intel-sanitize: 14 passed, 0 failed
```

---

## ۲) هوش بازار در بک‌تست — اعداد واقعی

### چرا فقط نیمهٔ «توقف رویداد» سنجیده شد

تکنیک هوش بازار دو نیمه دارد:

1. **توقف رویداد** — وقتی رویداد برنامه‌ریزی‌شدهٔ پراثر نزدیک است، کنار بایست. تقویم FOMC سال‌ها قبل منتشر می‌شود، پس **آفلاین قابل دانستن** است.
2. **تمایل احساسی** — وقتی لحن جمعی شدید است، خلاف جمعیت بایست. این نیمه به تیترهای واقعی هر روز نیاز دارد. آفلاین نداریم، و ساختن یک سری لحن ساختگی یعنی **جعلی کردن همان ورودی‌ای که داریم می‌سنجیم**.

پس `src/intel/historical.js` فقط تقویم را می‌دهد و `riskMultiplier()` همیشه **دقیقاً ۱** است. نتیجه، بیانیه‌ای دربارهٔ دروازهٔ تقویم است، نه دربارهٔ دروازهٔ احساس.

### تنظیمات اجرا

| مورد | مقدار |
|---|---|
| نمادها | BTCUSDT, ETHUSDT, SOLUSDT, XRPUSDT |
| بازه | ۲۰۲۵-۱۱-۲۷ تا ۲۰۲۶-۱۱-۲۲ (**۳۶۰ روز**) |
| کندل | ۸٬۶۴۰ در هر نماد (۱ ساعته) |
| شبکه | **خاموش** |
| رویداد FOMC در بازه | ۸ |

### نتیجه

| سنجه | خط پایه | پنجرهٔ ۴۵ دقیقه | پنجرهٔ یک‌روزه | Δ یک‌روزه |
|---|---|---|---|---|
| بازده | **−۲٫۰۱٪** | −۲٫۰۱٪ | **+۰٫۳۲٪** | **+۲٫۳۳** |
| حداکثر افت | ۱۱٫۱۳٪ | ۱۱٫۱۳٪ | **۱۱٫۰۵٪** | −۰٫۰۸ |
| تعداد معاملات | ۱۱۰ | ۱۱۰ | **۱۰۱** | −۹ |
| برد | ۳۹ | ۳۹ | ۳۸ | −۱ |
| باخت | ۷۱ | ۷۱ | **۶۳** | **−۸** |
| نرخ برد | ۳۵٫۴۵٪ | ۳۵٫۴۵٪ | **۳۷٫۶۲٪** | +۲٫۱۷ |
| ضریب سود | ۰٫۹۱ | ۰٫۹۱ | **۰٫۹۷** | +۰٫۰۶ |
| کارمزد | ۵۰٫۶۱ | ۵۰٫۶۱ | ۴۸٫۷۳ | −۱٫۸۸ |
| موجودی نهایی | ۴٬۸۹۹٫۲۸ | ۴٬۸۹۹٫۲۸ | **۵٬۰۱۵٫۸۰** | +۱۱۶٫۵۲ |
| شارپ (هر دوره) | −۰٫۰۰۲۰ | −۰٫۰۰۲۰ | **+۰٫۰۰۰۹** | +۰٫۰۰۲۹ |

### یافتهٔ اصلی — و مهم‌ترین بخش این گزارش

**پنجرهٔ ۴۵ دقیقه‌ای صفر بار فعال شد.**

```
45-min gate:  calls 48, blackouts 0, reductions 0
full-day gate: calls 48, blackouts 16, reductions 0
```

هوک ۴۸ بار صدا زده شد (یک بار در هر ریبالانس هفتگی) و **هیچ‌کدام** داخل پنجرهٔ ۳۰ دقیقه قبل / ۱۵ دقیقه بعد نیفتاد. احتمال برخورد یک ریبالانس هفتگی با پنجرهٔ ۴۵ دقیقه‌ای حدود **۰٫۴٪** است.

یعنی تنظیمات پیش‌فرض `INTEL_BLACKOUT_BEFORE_MS` برای این استراتژی **عملاً بی‌اثر** است. این یک باگ نیست — تنظیم برای رباتی است که می‌تواند روی تیک عمل کند، نه برای کتابی که هفتگی می‌چرخد. اما اگر کسی فکر کند هوش بازار روشن است و از او محافظت می‌کند، اشتباه می‌کند.

با پنجرهٔ یک‌روزه، دروازه ۱۶ بار فعال شد و اثر واقعی ظاهر شد: **۹ معاملهٔ کمتر، ۸ باخت کمتر، بازده از −۲٫۰۱٪ به +۰٫۳۲٪**.

### هشدارهای صداقتی

- **بازده +۰٫۳۲٪ هنوز زیر تورم و زیر هزینهٔ فرصت است.** این «سوددهی» نیست؛ فقط «کمتر زیان‌ده» است.
- **۸ رویداد در ۳۶۰ روز = نمونهٔ کوچک.** ۹ معاملهٔ کمتر روی ۱۱۰ معامله می‌تواند شانس باشد. برای اطمینان به چند سال داده نیاز است.
- **ضریب سود ۰٫۹۷ هنوز زیر ۱ است** — یعنی مجموع باخت‌ها از مجموع بردها بیشتر است.
- **هوش بازار در این اجرا فقط ورود جدید را بست.** هیچ پوزیشن بازی را نبست — این عمدی است: یک تیتر دلیل فروش یک پوزیشن با قیمت بد نیست.

---

## ۳) تست‌ها

```
$ node tests/run.js
  698 passed, 0 failed
```

| مجموعه | پاس | خط پایه |
|---|---|---|
| کل | **۶۹۸** | ۶۶۹ |
| `intel-sanitize` (جدید) | ۱۴ | — |
| `intel-backtest` (جدید) | ۱۵ | — |

`intel-backtest` شامل این قیدهاست:

- هوک `intelAt` واقعاً صدا زده می‌شود و آمارش گزارش می‌شود
- هوکی که همیشه مسدود می‌کند → **صفر معامله**
- هوکی که همیشه ۱ برمی‌گرداند → **هیچ تغییری** در تعداد معامله و بازده
- هوکی که **۵** برمی‌گرداند → **هیچ افزایشی** در معامله یا بازده (rotator به ۰..۱ clamp می‌کند)
- هوکی که throw می‌کند → اجرا کرش نمی‌کند
- `riskMultiplier` همیشه دقیقاً ۱ است، حتی در لحظهٔ blackout

---

## ۴) چه چیزی را واقعاً اجرا کردم

| کار | دستور | نتیجه |
|---|---|---|
| تست امنیتی قبل از اصلاح | `node tests/intel-sanitize.test.js` | **۱۲ شکست، ۲ پاس** |
| تست امنیتی بعد از اصلاح | همان | **۱۴ پاس، ۰ شکست** |
| تست اتصال بک‌تست | `node tests/intel-backtest.test.js` | **۱۵ پاس، ۰ شکست** |
| کل مجموعه | `node tests/run.js` | **۶۹۸ پاس، ۰ شکست** |
| بک‌تست A/B | `node scripts/intel-ab.js` | ۳ اجرا، اعداد بالا |

هر سه اجرای بک‌تست روی همان ۸٬۶۴۰ کندل و همان کد تولیدی انجام شد. تنها تفاوت، هوک هوش بازار بود.

## ۵) چه چیزی را فقط خواندم

- منطق `risk.js` / `board.js` / `court.js` — باگی پیدا نشد
- رفتار دیده‌بان در بازار زنده
- اتصال زنده به صرافی و منابع خبری
- رندر داشبورد در مرورگر (این نسخه ظاهر را تغییر نداد)
- **تقویم FOMC را از حافظه نوشتم، نه از یک منبع آنلاین.** تاریخ‌ها باید سالی یک بار بازبینی شوند.

## ۶) rollback

**کامل — بازگشت به v14:**

```
cp -r work/v15 work/v14-rollback   # v15 همان کپی دست‌نخوردهٔ v14 است
```

`work/v15` یک کپی بکر از v14 است و **هیچ تغییری در آن داده نشد**. برای بازگشت کامل، آن را جای v14 بگذارید.

**جزئی — فقط فایل‌های این نسخه:**

| فایل | تغییر | بازگشت |
|---|---|---|
| `src/intel/news.js` | sanitizer + سقف‌ها | `decodeEntities` را به نسخهٔ قبل برگردانید |
| `src/intel/historical.js` | **فایل جدید** | حذف فایل |
| `src/backtest/engine.js` | پارامتر `intelAt` | حذف بلوک `if (typeof intelAt === 'function')` |
| `scripts/intel-ab.js` | **فایل جدید** | حذف فایل |
| `tests/intel-sanitize.test.js` | **فایل جدید** | حذف فایل |
| `tests/intel-backtest.test.js` | **فایل جدید** | حذف فایل |
| `tests/run.js` | دو `runChildSuite` | حذف دو بلوک `group('v15 ...')` |

**هیچ مهاجرت داده‌ای لازم نیست.** هیچ فایل داده‌ای تغییر نکرد. `data/intel-ab.json` و `data/equity-ab-*.jsonl` فقط خروجی‌اند و در زیپ نیستند.

⚠️ اگر `intelAt` را حذف کنید، `summary.intel` به `null` برمی‌گردد و `intel-backtest` می‌شکند — این عمدی است.
