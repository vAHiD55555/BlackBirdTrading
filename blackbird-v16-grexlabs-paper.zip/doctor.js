#!/usr/bin/env node
'use strict';
/**
 * BlackBird — doctor.
 * Run this BEFORE starting the bot (or after it crashes) to see exactly what
 * is broken. `node doctor.js` in the host console.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const ROOT = __dirname;
let fails = 0;
let warns = 0;

function line(status, name, detail) {
  const icon = status === 'ok' ? '✅' : status === 'warn' ? '⚠️ ' : '❌';
  console.log(`${icon} ${name}${detail ? ' — ' + detail : ''}`);
  if (status === 'fail') fails++;
  if (status === 'warn') warns++;
}

(async () => {
  console.log('');
  console.log('==============================================');
  console.log('  🐦 BlackBird Trader — بررسی سلامت محیط');
  console.log('==============================================');
  console.log('');

  // 1) node version
  const major = Number(process.versions.node.split('.')[0]);
  if (major >= 18) line('ok', 'Node.js', `v${process.versions.node}`);
  else if (major >= 14) line('warn', 'Node.js', `v${process.versions.node} قدیمی است (پیشنهاد: 20 یا 22) — با fallback کار می‌کند`);
  else { line('fail', 'Node.js', `v${process.versions.node} خیلی قدیمی است — حداقل 14 لازم است`); }

  // 2) fetch
  const { hasNativeFetch } = require(path.join(ROOT, 'src/data/fetch-compat'));
  line('ok', 'HTTP client', hasNativeFetch ? 'fetch داخلی Node' : 'fallback داخلی (node:https)');

  // 3) files
  const need = ['package.json', 'config.json', 'src/index.js', 'src/engine.js', 'src/data/exchanges.js'];
  const missing = need.filter((f) => !fs.existsSync(path.join(ROOT, f)));
  if (missing.length) line('fail', 'فایل‌های پروژه', 'گم‌شده: ' + missing.join(', ') + '  ← ZIP را در ریشه‌ی درست extract کنید');
  else line('ok', 'فایل‌های پروژه', 'کامل');

  // 4) writable dirs
  try {
    for (const d of ['data', 'data/logs', 'reports']) fs.mkdirSync(path.join(ROOT, d), { recursive: true });
    fs.writeFileSync(path.join(ROOT, 'data', '.doctor'), 'ok');
    fs.unlinkSync(path.join(ROOT, 'data', '.doctor'));
    line('ok', 'نوشتن روی دیسک', ROOT);
  } catch (e) {
    line('fail', 'نوشتن روی دیسک', e.message);
  }

  // 5) config
  let cfg = null;
  try {
    cfg = require(path.join(ROOT, 'src/config')).loadConfig();
    const v = require(path.join(ROOT, 'src/config')).validateConfig(cfg);
    if (!v.ok) line('fail', 'config.json', v.problems.join(' | '));
    else line('ok', 'config.json', `${cfg.mode} | استراتژی ${cfg.strategy.mode} | ${cfg.symbols.length} نماد | ${cfg.data.timeframe} | ${cfg.exchange}→${cfg.witnessExchange}`);
    for (const w of v.warnings) line('warn', 'config', w);
  } catch (e) {
    line('fail', 'config.json', e.message);
  }

  // 6) network
  if (cfg) {
    const { createExchange } = require(path.join(ROOT, 'src/data/exchanges'));
    for (const [label, name] of [['صرافی اصلی', cfg.exchange], ['شاهد', cfg.witnessExchange]]) {
      if (!name) continue;
      try {
        const ex = createExchange(name);
        const t = await Promise.race([
          ex.serverTime(),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout 10s')), 10000)),
        ]);
        line('ok', `شبکه — ${label} (${name})`, `زمان سرور ${new Date(t).toISOString().slice(11, 19)}Z`);
      } catch (e) {
        line('fail', `شبکه — ${label} (${name})`, e.message + '  ← احتمالاً این صرافی از IP سرور بسته است');
      }
    }
    // 7) market data
    try {
      const ex = createExchange(cfg.exchange);
      const bars = await ex.klines(cfg.symbols[0], 5, cfg.data.timeframe);
      if (bars.length >= 3) line('ok', 'داده‌ی بازار', `${cfg.symbols[0]} ${bars.length} کندل، آخرین قیمت ${bars[bars.length - 1].c}`);
      else line('warn', 'داده‌ی بازار', `فقط ${bars.length} کندل برگشت`);
    } catch (e) {
      line('fail', 'داده‌ی بازار', e.message);
    }
  }

  console.log('');
  console.log('----------------------------------------------');
  if (fails === 0) {
    console.log(`✅ همه‌چیز آماده است${warns ? ` (${warns} هشدار)` : ''} — می‌توانید Start بزنید.`);
    if (cfg) console.log(`   اجرا: node src/index.js`);
  } else {
    console.log(`❌ ${fails} مشکل پیدا شد — پیام‌های بالا را برای من بفرستید.`);
  }
  console.log('----------------------------------------------');
  console.log('');
  process.exit(fails ? 1 : 0);
})().catch((e) => {
  console.log('');
  console.log('❌ doctor خودش خطا داد:', e.message);
  console.log(e.stack?.split('\n').slice(0, 4).join('\n'));
  process.exit(2);
});
