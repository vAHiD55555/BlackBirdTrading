# کنسرسیوم — چند مدل، یک رأی

## چرا

یک مدل تنها دو مشکل دارد: نقطه‌ی شکست واحد است، و نقطه‌ی نظر واحد. اگر آن مدل خطا بدهد، چرخه می‌میرد؛ اگر رفتار عجیبی داشته باشد، کسی نیست که با آن مخالفت کند.

کنسرسیوم همان سؤال را همزمان از چند مدل می‌پرسد و آرا را در یک حکم جمع می‌کند.

---

## قواعد، به ترتیب اهمیت

### ۱. مدل خراب هرگز چرخه را نمی‌کشد
هر فراخوانی در `Promise.allSettled` با تایم‌اوت مستقل خودش پیچیده شده. یک ارائه‌دهنده‌ی مرده به‌عنوان «ناموفق» ثبت می‌شود و بقیه ادامه می‌دهند.

### ۲. سکوت رضایت نیست
اگر هیچ رأی معتبری برنگردد، نتیجه `null` است و موتور به رفتار قاعده‌محور برمی‌گردد. کنسرسیوم هرگز حدس نمی‌زند.

### ۳. نتیجه هرگز آسان‌گیرتر از سختگیرترین رأی نیست
`riskMultiplier` **کمینه**‌ی آرا است، نه میانگین. مدلی که می‌خواهد کنار بکشد هرگز با رأی اکثریت به معرض‌گذاری تبدیل نمی‌شود.

میانه هم محاسبه و گزارش می‌شود — به‌عنوان `medianRiskMultiplier` — چون بهترین خلاصه‌ی «نظر پنل» است. اما **هرگز** عددی نیست که به موتور ریسک می‌رسد.

### ۴. اختلاف آرا اطلاعات است
پراکندگی زیاد (`σ > disagreementThreshold`) اطمینان را نصف می‌کند و ریسک را بیشتر سخت می‌کند. هیئت منصفه‌ی دوقطبی دلیل احتیاط است، نه دلیل میانگین‌گیری.

---

## فرمول‌ها

| فیلد | فرمول |
|---|---|
| `riskMultiplier` | `min(آرای معتبر)` سپس `min(سقف)` |
| `regime` / `bias` | اکثریت وزنی (`weight` از config) |
| `veto` | اکثریت وزنی آرا |
| `confidence` | میانگین وزنی؛ اگر پراکنده باشد × ۰.۵ |
| `dispersion` | انحراف معیار جمعیت آرا |
| `uncertain` | `dispersion > disagreementThreshold` |

---

## پیکربندی

```json
"jev": {
  "consensus": {
    "enabled": true,
    "models": [
      { "provider": "cloudflare", "model": "@cf/meta/llama-3.3-70b-instruct-fp8-fast", "weight": 1 },
      { "provider": "groq", "model": "llama-3.3-70b-versatile", "weight": 1 },
      { "provider": "gemini", "model": "gemini-2.0-flash", "weight": 1 }
    ],
    "quorum": 2,
    "timeoutMs": 20000,
    "disagreementThreshold": 0.35
  }
}
```

| فیلد | معنا |
|---|---|
| `enabled` | پیش‌فرض `false` — تا روشن نکنی هیچ چیز عوض نمی‌شود |
| `models` | پنل. `weight` فقط در اکثریت اثر دارد، نه در ریسک |
| `quorum` | حداقل رأی معتبر. کمتر از این = بازگشت به قواعد |
| `timeoutMs` | بودجه‌ی هر مدل، مستقل |
| `disagreementThreshold` | آستانه‌ی σ برای «پنل دوقطبی» |

---

## چطور کلید بگیرم؟

همه رایگان و بدون کارت. جزئیات کامل در `src/jev/providers/CATALOG.md`.

| ارائه‌دهنده | متغیر | لینک |
|---|---|---|
| Cloudflare Workers AI | `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` | https://dash.cloudflare.com/profile/api-tokens |
| Groq | `GROQ_API_KEY` | https://console.groq.com/keys |
| Gemini | `GEMINI_API_KEY` | https://aistudio.google.com/apikey |
| Cerebras | `CEREBRAS_API_KEY` | https://cloud.cerebras.ai |
| Mistral | `MISTRAL_API_KEY` | https://console.mistral.ai/api-keys |
| OpenRouter | `OPENROUTER_API_KEY` | https://openrouter.ai/keys |
| Ollama | — (بدون کلید) | https://ollama.com/download |

---

## چطور probe کنم؟

```bash
node src/jev/probe.js                 # همه
node src/jev/probe.js cloudflare groq # فقط این‌ها
node src/jev/probe.js --consensus     # فقط پنل config.json
node src/jev/probe.js --json          # خروجی ماشینی
```

برای هر ارائه‌دهنده: کلید هست یا نه (فقط طول، هرگز مقدار)، پاسخ داد یا نه، تأخیر، و متن دقیق خطا.

**وقتی پنل می‌گوید «quorum not met»، اول probe بزن.** تقریباً همیشه یک مدل کلید ندارد یا سهمیه‌اش تمام شده.

---

## سهمیه

`src/jev/rateLimiter.js` قبل از هر فراخوانی `check()` می‌کند. اگر سهمیه تمام باشد، **درخواستی زده نمی‌شود** و به مدل بعدی می‌رود. شمارنده‌ها در `data/rate-limits.json` ذخیره می‌شوند تا با ری‌استارت صفر نشوند.

---

## چطور مدل اضافه/حذف کنم؟

**حذف:** خط را از `jev.consensus.models` پاک کن.

**اضافه:** یک آبجکت اضافه کن:
```json
{ "provider": "cerebras", "model": "llama-3.3-70b", "weight": 1 }
```

**ارائه‌دهنده‌ی جدید:** ورودی در `CATALOG` داخل `src/jev/providers/catalog.js` با `kind` یکی از `openai` / `gemini` / `cloudflare` / `mock`.

---

## محدودیت‌ها

- **هزینه‌ی تأخیر:** پنل به‌اندازه‌ی کندترین مدل طول می‌کشد. با `timeoutMs` مهارش کن.
- **همبستگی:** مدل‌های مختلف روی داده‌ی مشابه آموزش دیده‌اند؛ اتفاق نظرشان تضمین تنوع نیست.
- **سهمیه‌ی مشترک:** چند مدل از یک ارائه‌دهنده، سهمیه‌ی یکسان می‌خورند.
- **کمینه‌گیری محافظه‌کارانه است:** ممکن است ریسک را بیش از حد کم کند و بازده را پایین بیاورد. این معامله‌ی آگاهانه است.
- **این ابزار پژوهشی است** و سودی تضمین نمی‌کند.
