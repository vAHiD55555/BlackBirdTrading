'use strict';
/**
 * Regression tests for the risk system found broken by the 12-month replay.
 *
 * THREE BUGS, ALL FOUND BY RUNNING A REAL 12-MONTH BACKTEST
 * ---------------------------------------------------------
 * 1. `BacktestRisk` was a stub: equity, peak, settle, and nothing else. It had
 *    no `check()` and no real `halted`, so the rotator's own gate
 *    (`if (typeof this.risk.check === 'function')`) silently did nothing. The
 *    replay therefore measured a bot with NO risk limits at all and reported a
 *    15.64% drawdown against a 12% kill switch.
 *
 * 2. The kill switch only looked at REALISED equity. A book 16% underwater on
 *    open positions read as 0% drawdown, so the switch never fired until the
 *    loss was already past the limit. Fixed with mark-to-market.
 *
 * 3. A drawdown halt had no way back. `halt()` defaulted to kind 'hard', and
 *    `evaluateResume()` only looks at kind 'drawdown'. The replay locked itself
 *    out on 2026-05-16 and sat idle for five months — a dead bot, not a safe
 *    one. Charter §8 requires a defined resume path.
 *
 * Each test below fails on the old code and passes on the fixed code.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { BacktestRisk } = require('../src/backtest/engine');

const RISK = {
  killSwitchDrawdownPct: 0.12,
  maxDailyLossPct: 0.04,
  maxDailyTrades: 30,
  maxConsecutiveLosses: 4,
  cooldownAfterLossMs: 600000,
  drawdownCooldownMs: 24 * 3600 * 1000,
  resumeDrawdownPct: 0.06,
  resumeScale: 0.5,
  minNotionalUsd: 15,
  maxNetExposurePct: 0.7,
};

const mk = (equity = 5000, clock = () => 1_700_000_000_000) =>
  new BacktestRisk(equity, { risk: RISK }, clock);

(async () => {
  console.log('\n▸ risk system — the three bugs the 12-month replay exposed');

  await t('BUG 1: the replay risk object actually has an entry gate', () => {
    const r = mk();
    // The old stub had no check() at all, so the rotator's gate was a no-op.
    assert.strictEqual(typeof r.check, 'function', 'BacktestRisk must expose check()');
    const gate = r.check({ notional: 100 });
    assert.strictEqual(gate.ok, true, 'a normal entry must be allowed');
  });

  await t('BUG 1: the entry gate refuses a halted book', () => {
    const r = mk();
    r.halt('test');
    const gate = r.check({ notional: 100 });
    assert.strictEqual(gate.ok, false, 'a halted book must refuse new entries');
    assert.match(gate.reason, /halted/);
  });

  await t('BUG 1: the daily trade cap is enforced in replay', () => {
    const r = mk();
    for (let i = 0; i < RISK.maxDailyTrades; i++) r.settle({ pnl: 0, win: true });
    const gate = r.check({ notional: 100 });
    assert.strictEqual(gate.ok, false, 'the daily trade cap must stop entries');
    assert.strictEqual(gate.reason, 'max_daily_trades');
  });

  await t('BUG 1: the daily loss cap halts and lifts at the next UTC day', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.settle({ pnl: -250, win: false }); // -5% on the day, cap is 4%
    assert.strictEqual(r.halted, true, 'a 5% daily loss must halt');
    assert.strictEqual(r.haltKind, 'daily', 'a daily halt must be soft, not hard');
    // Same day: still halted.
    assert.strictEqual(r.check({ notional: 100 }).ok, false);
    // Next UTC day: the daily book rolls and the pause lifts.
    now += 24 * 3600 * 1000;
    r.rollDay(now);
    assert.strictEqual(r.halted, false, 'a daily pause must lift at the next day');
  });

  await t('BUG 2: drawdown is measured on marked equity, not realised equity', () => {
    const r = mk(5000);
    // Nothing has closed, so realised equity is still 5000 and the old code
    // would report 0% drawdown. The book is actually 16% underwater.
    const tripped = r.markToMarket(4200);
    assert.strictEqual(tripped, true, 'a 16% marked drawdown must trip a 12% switch');
    assert.strictEqual(r.halted, true);
  });

  await t('BUG 2: a healthy marked equity does not trip the switch', () => {
    const r = mk(5000);
    assert.strictEqual(r.markToMarket(4900), false, 'a 2% drawdown must not trip a 12% switch');
    assert.strictEqual(r.halted, false);
  });

  await t('BUG 2: the peak follows marked equity, so a run-up is not lost', () => {
    const r = mk(5000);
    r.markToMarket(6000); // open profit raises the high-water mark
    assert.strictEqual(r.peakEquity, 6000, 'the peak must follow marked equity');
    // 6000 -> 5300 is 11.7%, under the 12% limit.
    assert.strictEqual(r.markToMarket(5300), false);
    // 6000 -> 5200 is 13.3%, over the limit.
    assert.strictEqual(r.markToMarket(5200), true);
  });

  await t('BUG 3: a drawdown halt is resumable, not permanent', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.markToMarket(4200);
    assert.strictEqual(r.halted, true);
    // The old code left haltKind as 'hard', which evaluateResume() ignores.
    assert.strictEqual(r.haltKind, 'drawdown', 'a drawdown halt must be kind drawdown');
  });

  await t('BUG 3: resume needs the cooling period, not just a flat book', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.markToMarket(4200);
    // Flat book, but the cooling period has not passed.
    assert.strictEqual(r.evaluateResume({ equityMtm: 4200, openPositions: 0, dataOk: true }), false,
      'resume must not happen before the cooling period');
    now += 25 * 3600 * 1000;
    assert.strictEqual(r.evaluateResume({ equityMtm: 4200, openPositions: 0, dataOk: true }), true,
      'a flat book after the cooling period must resume');
    assert.strictEqual(r.halted, false);
  });

  await t('BUG 3: an underwater book does not get new risk', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.markToMarket(4200);
    now += 25 * 3600 * 1000;
    // Still 16% down and still holding positions: no resume.
    assert.strictEqual(r.evaluateResume({ equityMtm: 4200, openPositions: 2, dataOk: true }), false,
      'a still-underwater book must not resume');
    // Recovered to 5% drawdown: resume is allowed even with positions open.
    assert.strictEqual(r.evaluateResume({ equityMtm: 4750, openPositions: 2, dataOk: true }), true,
      'a recovered book may resume');
  });

  await t('BUG 3: unhealthy data blocks the resume', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.markToMarket(4200);
    now += 25 * 3600 * 1000;
    assert.strictEqual(r.evaluateResume({ equityMtm: 4200, openPositions: 0, dataOk: false }), false,
      'resuming on stale data is how a bot re-enters a market it cannot see');
  });

  await t('BUG 3: the resume comes back at reduced size', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.markToMarket(4200);
    now += 25 * 3600 * 1000;
    r.evaluateResume({ equityMtm: 4200, openPositions: 0, dataOk: true });
    assert.strictEqual(r.resumeScale, 0.5, 'the first entries after a resume must be half size');
  });

  await t('a hard halt (integrity, manual) still never auto-resumes', () => {
    let now = 1_700_000_000_000;
    const r = mk(5000, () => now);
    r.halt('integrity failure', { kind: 'hard' });
    now += 365 * 24 * 3600 * 1000;
    assert.strictEqual(r.evaluateResume({ equityMtm: 5000, openPositions: 0, dataOk: true }), false,
      'a hard halt must require a human, not a timer');
    assert.strictEqual(r.halted, true);
  });

  done('risk-resume');
})();
