#!/usr/bin/env node
'use strict';
/**
 * Public dashboard, route security, port, freshness, gesture, accessibility.
 * Real HTTP on an ephemeral port, a stub engine, no network, no exchange.
 */
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { t, done } = require('./harness');

const ROOT = path.join(__dirname, '..');
const SECRETS = ['sk-live-abcdef1234567890', 'adm1n-t0ken-xyz', '123456:ABCdefGhIJKlmNoPQRsTUVwxyz0123456'];
process.env.ADMIN_TOKEN = 'adm1n-t0ken-xyz';
process.env.SOME_API_KEY = 'sk-live-abcdef1234567890';
delete process.env.PORT; delete process.env.BB_PORT; delete process.env.SERVER_PORT;

const noop = () => {};
const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };

function goodStatus(over = {}) {
  return {
    ok: true, mode: 'paper',
    risk: { equity: 100, equityMtm: 101.5, drawdownPct: 1, dailyPnlPct: 0.4, tradesTotal: 20, tradesToday: 2, wins: 12, losses: 8, lossesStreak: 0, halted: false, haltReason: 'court:secret-detail', lastVeto: { reason: 'x' } },
    health: { booting: false, feedsTotal: 2, feedsDegraded: 0, degradedSymbols: [], dataOk: true, exchange: 'binance', uptimeSec: 600 },
    limits: { killSwitchDrawdownPct: 0.15, maxDailyLossPct: 0.05 },
    market: [{ symbol: 'BTCUSDT', price: 60000, regime: 'trend', spreadBps: 1.1, quoteAgeMs: 800 }],
    rotator: { positions: [{ symbol: 'BTCUSDT', side: 'long', pnl: 1.2 }] },
    // everything below is what the OLD public /status leaked
    jev: { provider: 'gemini', model: 'gemini-2.0-flash', apiKeyEnv: 'GEMINI_API_KEY', hasKey: true },
    supervisor: { url: 'http://internal:11434', lastResult: { reason: SECRETS[0] } },
    strategist: { note: SECRETS[2] },
    ...over,
  };
}

function makeEngine(statusFn) {
  return {
    cfg: { profile: { label: 'AngryBird' }, mode: 'paper', server: { port: 0, host: '127.0.0.1' }, reporter: { dir: '/nonexistent' }, notifications: {} },
    log, court: { publicView: () => ({ phase: 'normal', yellowCards: 0, closing: false }) },
    status: statusFn, health: () => ({ booting: false, dataOk: true, feedsTotal: 1, feedsDegraded: 0, degradedSymbols: [], exchange: 'binance', uptimeSec: 5 }),
    roles: { roles: [], mapError: null, resolve: () => null },
  };
}

function req(port, method, p, headers = {}, body) {
  return new Promise((resolve, reject) => {
    // A body MUST come with a Content-Length (or a transfer-encoding). Writing
    // bytes after the headers without either makes the server parse them as the
    // start of the next request and answer 400 -- which is what made this suite
    // report a "socket hang up" instead of the real status code.
    const h = { ...headers };
    if (body !== undefined && body !== null && !('content-length' in h) && !('transfer-encoding' in h)) {
      h['content-length'] = Buffer.byteLength(String(body));
    }
    const r = http.request({ host: '127.0.0.1', port, method, path: p, headers: h }, (res) => {
      let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d }));
    });
    r.on('error', reject); if (body !== undefined && body !== null) r.write(body); r.end();
  });
}

async function withServer(engine, fn) {
  const { startServer } = require('../src/web/status');
  const server = startServer(engine);
  await new Promise((r) => server.on('listening', r));
  try { await fn(server.address().port); } finally { server.close(); }
}

(async () => {
  console.log('\n\u25b8 public dashboard \u2014 data safety');
  await t('summary and every detail section contain no secret, provider or model identity', async () => {
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      const bodies = [(await req(port, 'GET', '/api/public/summary')).body];
      for (const s of ['risk', 'performance', 'health', 'market', 'positions']) bodies.push((await req(port, 'GET', `/api/public/detail/${s}`)).body);
      for (const b of bodies) {
        for (const sec of SECRETS) assert.ok(!b.includes(sec), 'secret leaked');
        assert.ok(!/gemini|provider|apiKeyEnv|GEMINI|internal:11434|secret-detail/i.test(b), 'identity/internal detail leaked');
      }
    });
  });
  await t('tripwire replaces a payload that would carry a secret (even if the allow-list failed)', () => {
    const { PublicView } = require('../src/web/public');
    const v = new PublicView({ engine: makeEngine(() => goodStatus()), log, env: { X_TOKEN: 'value-that-leaks' } });
    const out = v._guard({ message: 'hello value-that-leaks' }, 'summary');
    assert.strictEqual(out.overall.level, 'unknown');
    assert.ok(!JSON.stringify(out).includes('value-that-leaks'));
  });
  await t('legacy /status and report routes require authentication', async () => {
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      for (const p of ['/status', '/ops/status', '/report/latest', '/report/latest.md', '/ops/probe', '/ops/evidence', '/control/state']) {
        assert.strictEqual((await req(port, 'GET', p)).status, 401, p);
      }
      const ok = await req(port, 'GET', '/ops/status', { authorization: 'Bearer adm1n-t0ken-xyz' });
      assert.strictEqual(ok.status, 200);
      assert.strictEqual((await req(port, 'GET', '/ops/status', { authorization: 'Bearer wrong' })).status, 401);
    });
  });
  await t('repeated bad credentials are rate limited (429)', async () => {
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      let last = 0;
      for (let i = 0; i < 14; i++) last = (await req(port, 'GET', '/ops/status', { authorization: 'Bearer nope' })).status;
      assert.strictEqual(last, 429);
      // and even the right token is refused while blocked: fail closed, no oracle
      assert.strictEqual((await req(port, 'GET', '/ops/status', { authorization: 'Bearer adm1n-t0ken-xyz' })).status, 429);
    });
  });
  await t('public routes are strictly read-only: POST/PUT/PATCH/DELETE are 405', async () => {
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      for (const m of ['POST', 'PUT', 'PATCH', 'DELETE']) for (const p of ['/', '/api/public/summary', '/control/propose-nothing', '/api/public/detail/risk']) {
        const r = await req(port, m, p, {}, '{}');
        assert.ok([405, 401].includes(r.status), `${m} ${p} -> ${r.status}`);
        if (!p.startsWith('/control')) assert.strictEqual(r.status, 405);
      }
    });
  });
  await t('a rejected method with a body still answers, and the connection stays usable', async () => {
    // Regression: the read-only guard used to answer 405 without reading the
    // request body, which made Node destroy the socket. The caller then saw
    // "socket hang up" instead of 405, and the very next request on that
    // keep-alive connection never reached the server at all.
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      const agent = new http.Agent({ keepAlive: true, maxSockets: 1 });
      const call = (method, p, body) =>
        new Promise((resolve, reject) => {
          const payload = body === undefined ? null : String(body);
          const headers = payload === null ? {} : { 'content-length': Buffer.byteLength(payload) };
          const r = http.request({ host: '127.0.0.1', port, method, path: p, headers, agent }, (res) => {
            let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, body: d }));
          });
          r.on('error', reject); if (payload !== null) r.write(payload); r.end();
        });
      try {
        // the rejection itself must arrive as a status code, not a dropped socket
        const rejected = await call('DELETE', '/api/public/summary', '{}');
        assert.strictEqual(rejected.status, 405, 'DELETE with a body must answer 405');
        // ...and the SAME connection must still work afterwards
        const after = await call('GET', '/api/public/summary');
        assert.strictEqual(after.status, 200, 'the connection must survive a rejected method');
        assert.ok(after.body.includes('"schema"'), 'and still serve the summary');
        // a malformed client (body with no length) gets an explicit 400, not silence
        const raw = await new Promise((resolve, reject) => {
          const sock = require('node:net').connect(port, '127.0.0.1', () => {
            sock.write('DELETE / HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n{}');
          });
          let d = ''; sock.on('data', (c) => (d += c)); sock.on('end', () => resolve(d)); sock.on('error', reject);
          setTimeout(() => { sock.destroy(); resolve(d); }, 1500);
        });
        assert.match(raw, /^HTTP\/1\.1 400/, 'a body without a length must be answered 400');
      } finally { agent.destroy(); }
    });
  });
  await t('security headers: strict CSP without inline script or third-party hosts', async () => {
    await withServer(makeEngine(() => goodStatus()), async (port) => {
      const r = await req(port, 'GET', '/');
      const csp = r.headers['content-security-policy'];
      assert.match(csp, /script-src 'self'(;|$)/);
      assert.ok(!/script-src[^;]*unsafe-inline/.test(csp) && !/telegram\.org|https?:\/\//.test(csp));
      assert.match(csp, /frame-ancestors 'none'/);
      assert.strictEqual(r.headers['x-content-type-options'], 'nosniff');
      assert.ok(!r.headers['access-control-allow-origin'], 'no CORS');
    });
  });

  console.log('\n\u25b8 public dashboard \u2014 view-only and accessible');
  const web = (f) => fs.readFileSync(path.join(ROOT, 'src/web', f), 'utf8');
  await t('public page and scripts have no form, input, admin token, POST or unsafe DOM sinks', () => {
    for (const f of ['dashboard.html', 'assets/dashboard.js', 'assets/welcome.js', 'assets/gesture.js']) {
      const s = web(f);
      assert.ok(!/<form|<input|<select|<textarea|adminToken|x-admin-token|\/control\//i.test(s), `${f}: control surface`);
      assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(|new Function/.test(s), `${f}: unsafe sink`);
      assert.ok(!/method:\s*['"](POST|PUT|PATCH|DELETE)/i.test(s), `${f}: non-GET request`);
    }
    assert.ok(!/telegram-web-app/.test(web('dashboard.html')));
  });
  await t('risk is not conveyed by colour alone: every level has an icon and a word', () => {
    const { LEVEL_WORD, LEVEL_ICON } = require('../src/web/public');
    const icons = new Set(Object.values(LEVEL_ICON));
    assert.strictEqual(icons.size, 4);
    for (const k of ['ok', 'watch', 'alert', 'unknown']) assert.ok(LEVEL_WORD[k] && LEVEL_ICON[k]);
  });
  await t('responsive and reduced-motion handling are present', () => {
    assert.match(web('dashboard.html'), /name="viewport" content="width=device-width/);
    assert.match(web('assets/base.css'), /prefers-reduced-motion:\s*reduce/);
    const w = web('assets/welcome.js');
    assert.match(w, /prefers-reduced-motion/); assert.match(w, /devicePixelRatio/); assert.match(w, /document\.hidden/); assert.match(w, /'resize'/);
  });
  await t('an accessible non-gesture entrance exists and the preview is the default', () => {
    const h = web('dashboard.html');
    assert.match(h, /id="welcome-enter"/);
    assert.match(h, /id="welcome"/);
    assert.match(web('assets/base.css'), /body:not\(\.entered\) #app\{display:none\}/);
  });
  await t('cards are ordered by severity (worst first) and each carries one message', () => {
    const { project } = require('../src/web/public');
    const s = project(goodStatus({ health: { booting: false, feedsTotal: 2, feedsDegraded: 2, degradedSymbols: ['A', 'B'], dataOk: false, exchange: 'x', uptimeSec: 1 } }), { profile: {}, court: null });
    const rank = { alert: 3, watch: 2, unknown: 1, ok: 0 };
    for (let i = 1; i < s.cards.length; i++) assert.ok(rank[s.cards[i - 1].level] >= rank[s.cards[i].level]);
    for (const c of s.cards) assert.strictEqual(typeof c.message, 'string');
  });

  console.log('\n\u25b8 freshness \u2014 stale, absent or broken data is never "healthy"');
  await t('booting => unknown, not ok', () => {
    const { project } = require('../src/web/public');
    assert.strictEqual(project({ booting: true }, { profile: {}, court: null }).overall.level, 'unknown');
    assert.strictEqual(project(null, { profile: {}, court: null }).overall.level, 'unknown');
  });
  await t('no market data => alert; old quotes => stale + watch; missing figures => unknown', () => {
    const { project } = require('../src/web/public');
    assert.strictEqual(project(goodStatus({ health: { dataOk: false, feedsTotal: 1, feedsDegraded: 1 } }), { profile: {}, court: null }).overall.level, 'alert');
    const stale = project(goodStatus({ market: [{ symbol: 'A', quoteAgeMs: 5 * 60 * 1000 }] }), { profile: {}, court: null });
    assert.strictEqual(stale.freshness.state, 'stale'); assert.notStrictEqual(stale.overall.level, 'ok');
    const noFig = project(goodStatus({ risk: { halted: false } }), { profile: {}, court: null });
    assert.notStrictEqual(noFig.overall.level, 'ok');
  });
  await t('a failing status path serves unknown/stale, never a fresh-looking ok', () => {
    const { PublicView } = require('../src/web/public');
    let boom = false;
    const v = new PublicView({ engine: makeEngine(() => { if (boom) throw new Error('x'); return goodStatus(); }), log, env: {} });
    assert.strictEqual(v.summary().overall.level, 'ok');
    boom = true; v._cache.clear();
    const s = v.summary();
    assert.strictEqual(s.freshness.state, 'stale'); assert.strictEqual(s.overall.level, 'unknown');
    const fresh = new PublicView({ engine: makeEngine(() => { throw new Error('x'); }), log, env: {} });
    assert.strictEqual(fresh.summary().overall.level, 'unknown');
  });
  await t('a halted book and a closing season surface as alert', () => {
    const { project } = require('../src/web/public');
    assert.strictEqual(project(goodStatus({ risk: { ...goodStatus().risk, halted: true } }), { profile: {}, court: null }).overall.level, 'alert');
    assert.strictEqual(project(goodStatus(), { profile: {}, court: { closing: true, yellowCards: 2 } }).overall.level, 'alert');
  });
  await t('the page ages out client-side too (generatedAt is checked against the clock)', () => {
    const js = web('assets/dashboard.js');
    assert.match(js, /STALE_AFTER_MS/); assert.match(js, /generatedAt/);
  });

  console.log('\n\u25b8 port \u2014 never hard-coded');
  await t('no source, container or deploy file hard-codes 8787 or 8788', () => {
    const files = [];
    const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (['node_modules', '.git', 'run10b'].includes(e.name)) continue; const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else files.push(p); } };
    walk(path.join(ROOT, 'src')); walk(path.join(ROOT, 'deploy'));
    for (const f of ['Dockerfile', 'docker-compose.yml', 'Procfile', 'config.json', 'config.json.example', '.env.example', 'scripts/preflight.js', 'doctor.js']) files.push(path.join(ROOT, f));
    const bad = files.filter((f) => /\b878[78]\b/.test(fs.readFileSync(f, 'utf8'))).map((f) => path.relative(ROOT, f));
    assert.deepStrictEqual(bad, []);
  });
  await t('PORT from the platform wins; with nothing set the OS assigns a port', async () => {
    const net = require('node:net');
    const free = await new Promise((r) => { const s = net.createServer().listen(0, () => { const p = s.address().port; s.close(() => r(p)); }); });
    process.env.PORT = String(free);
    await withServer(makeEngine(() => goodStatus()), async (port) => assert.strictEqual(port, free));
    delete process.env.PORT;
    await withServer(makeEngine(() => goodStatus()), async (port) => { assert.ok(port > 0 && port !== 8787 && port !== 8788); });
  });

  console.log('\n\u25b8 entrance gesture');
  const G = require('../src/web/assets/gesture.js');
  const W = 400, H = 800;
  const A = (t0 = 0, dur = 300) => ({ w: W, h: H, points: [{ x: 20, y: 300, t: t0 }, { x: 200, y: 310, t: t0 + dur / 2 }, { x: 350, y: 300, t: t0 + dur }] });
  const B = (t0 = 0, dur = 500) => ({ w: W, h: H, points: [{ x: 380, y: 50, t: t0 }, { x: 200, y: 420, t: t0 + dur / 2 }, { x: 30, y: 750, t: t0 + dur }] });
  const mk = () => { const o = { n: 0 }; o.gate = G.createGate({ onUnlock: () => o.n++ }); return o; };
  await t('A then B within the time limit unlocks', () => { const o = mk(); o.gate.feed(A(0)); assert.strictEqual(o.n, 0); o.gate.feed(B(1000)); assert.strictEqual(o.n, 1); });
  await t('B then A (wrong order) never unlocks', () => { const o = mk(); o.gate.feed(B(0)); o.gate.feed(A(1000)); assert.strictEqual(o.n, 0); assert.strictEqual(o.gate.state, 'a_done'); o.gate.reset(); o.gate.feed(B(0)); o.gate.feed(B(900)); assert.strictEqual(o.n, 0); });
  await t('A alone, B alone, or A + a wrong stroke does not unlock and resets', () => {
    let o = mk(); o.gate.feed(A(0)); assert.strictEqual(o.n, 0);
    o = mk(); o.gate.feed(B(0)); assert.strictEqual(o.n, 0);
    o = mk(); o.gate.feed(A(0)); o.gate.feed({ w: W, h: H, points: [{ x: 300, y: 600, t: 900 }, { x: 100, y: 650, t: 1200 }] }); assert.strictEqual(o.gate.state, 'idle'); o.gate.feed(B(1500)); assert.strictEqual(o.n, 0);
  });
  await t('waiting too long between A and B resets; overlapping strokes are rejected', () => {
    let o = mk(); o.gate.feed(A(0)); o.gate.feed(B(9000)); assert.strictEqual(o.n, 0); assert.strictEqual(o.gate.state, 'idle');
    o = mk(); o.gate.feed(A(0, 300)); o.gate.feed(B(100)); assert.strictEqual(o.n, 0);
  });
  await t('accidental taps are ignored (they neither advance nor reset)', () => {
    const o = mk(); o.gate.feed(A(0));
    o.gate.feed({ w: W, h: H, points: [{ x: 100, y: 100, t: 600 }, { x: 102, y: 101, t: 640 }] });
    assert.strictEqual(o.gate.state, 'a_done'); o.gate.feed(B(1200)); assert.strictEqual(o.n, 1);
  });
  await t('a scribble, a too-short swipe, a too-fast stroke and a wobbly diagonal are rejected', () => {
    assert.strictEqual(G.classify({ w: W, h: H, points: [{ x: 20, y: 300, t: 0 }, { x: 300, y: 300, t: 100 }, { x: 150, y: 300, t: 200 }, { x: 330, y: 300, t: 300 }] }), 'invalid');
    assert.strictEqual(G.classify({ w: W, h: H, points: [{ x: 20, y: 300, t: 0 }, { x: 120, y: 300, t: 200 }] }), 'invalid');
    assert.strictEqual(G.classify({ w: W, h: H, points: [{ x: 20, y: 300, t: 0 }, { x: 350, y: 300, t: 10 }] }), 'invalid');
    assert.strictEqual(G.classify({ w: W, h: H, points: [{ x: 380, y: 50, t: 0 }, { x: 380, y: 700, t: 300 }, { x: 30, y: 750, t: 600 }] }), 'invalid');
  });
  await t('thresholds are normalised: the same gesture works on a phone and a wide desktop', () => {
    const scale = (s, w, h) => ({ w, h, points: s.points.map((p) => ({ x: (p.x / W) * w, y: (p.y / H) * h, t: p.t })) });
    for (const [w, h] of [[360, 640], [1440, 900]]) { assert.strictEqual(G.classify(scale(A(), w, h)), 'A'); assert.strictEqual(G.classify(scale(B(), w, h)), 'B'); }
  });
  await t('garbage input does not throw', () => {
    for (const s of [null, {}, { points: [], w: 1, h: 1 }, { points: [{ x: NaN, y: 0, t: 0 }, { x: 1, y: 1, t: 1 }], w: 1, h: 1 }]) assert.strictEqual(G.classify(s), 'invalid');
  });
  await t('the gesture is documented and coded as NOT authentication; no secret sits behind it', () => {
    assert.match(web('assets/gesture.js'), /NOT AUTHENTICATION/);
    assert.ok(!/authoriz|token|password/i.test(web('assets/welcome.js')));
  });

  done('public');
})();
