'use strict';
/**
 * کارگر میانی — قرارداد «کمکی بودن».
 *
 * چیزی که این تست‌ها می‌سنجند، دقیقاً همان شرطی است که در تصمیم ساختش گذاشتیم:
 * موتور باید بدون کارگر کامل کار کند، و هر شکست کارگر باید بی‌صدا به مسیر
 * قبلی برگردد — نه توقف، نه خطای پرتاب‌شده.
 */
const path = require('node:path');
const assert = require('node:assert');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { WorkerBridge } = require(path.join(SRC, 'worker/bridge'));
const { WorkerFirstProvider } = require(path.join(SRC, 'worker/provider'));

const quiet = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/** fetch ساختگی: پاسخ از پیش تعیین‌شده، شمارنده‌ی تماس. */
function fakeFetch(handler) {
  const calls = [];
  const fn = async (url, init) => {
    calls.push({ url, init });
    const out = await handler(url, init);
    if (out instanceof Error) throw out;
    return {
      ok: out.status === undefined ? true : out.status < 400,
      status: out.status || 200,
      json: async () => out.body,
    };
  };
  fn.calls = calls;
  return fn;
}

const cfgWith = (worker) => ({ worker });

(async () => {
  await t('کارگر با نشانی خالی خاموش است و هیچ تماسی نمی‌زند', async () => {
    const f = fakeFetch(() => ({ body: { ok: true } }));
    const b = new WorkerBridge({ cfg: cfgWith({ baseUrl: '' }), env: {}, fetchImpl: f, log: quiet() });
    assert.equal(b.enabled, false);
    assert.equal(b.available, false);
    assert.equal(await b.complete({ messages: [{ role: 'user', content: 'x' }] }), null);
    assert.equal(await b.snapshot(['BTCUSDT']), null);
    assert.equal(f.calls.length, 0);
  });

  await t('ست‌کردن نشانی، کارگر را خودکار روشن می‌کند', async () => {
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }),
      env: {}, fetchImpl: fakeFetch(() => ({ body: { ok: true } })), log: quiet(),
    });
    assert.equal(b.enabled, true);
    assert.equal(b.llmEnabled, true);
    assert.equal(b.dataEnabled, true);
  });

  await t('خاموش‌کردن صریح، بر وجود نشانی مقدم است', async () => {
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example', enabled: false }),
      env: {}, fetchImpl: fakeFetch(() => ({ body: { ok: true } })), log: quiet(),
    });
    assert.equal(b.enabled, false);
  });

  await t('پاسخ مدل از درگاه لبه برمی‌گردد', async () => {
    const f = fakeFetch(() => ({ body: { ok: true, text: '  موافق  ', cached: true } }));
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {}, fetchImpl: f, log: quiet(),
    });
    const text = await b.complete({ messages: [{ role: 'user', content: 'سلام' }] });
    assert.equal(text.trim(), 'موافق');
    assert.equal(f.calls.length, 1);
    assert.equal(f.calls[0].url, 'https://edge.example/v1/llm');
    assert.equal(b.stats.modelHits, 1);
  });

  await t('خطای کارگر بی‌صدا است و دوره‌ی افتادن جلوی تماس بعدی را می‌گیرد', async () => {
    const f = fakeFetch(() => ({ status: 502, body: { ok: false, error: 'upstream down' } }));
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {}, fetchImpl: f, log: quiet(),
    });
    assert.equal(await b.complete({ messages: [{ role: 'user', content: 'x' }] }), null);
    assert.equal(b.available, false);
    assert.match(b.stats.lastError, /502/);
    // تماس دوم در دوره‌ی افتادن: نباید دوباره شبکه را بزند.
    assert.equal(await b.complete({ messages: [{ role: 'user', content: 'x' }] }), null);
    assert.equal(f.calls.length, 1);
  });

  await t('وقفه در شبکه هم همان مسیر افتادن را می‌رود', async () => {
    const f = fakeFetch(() => new Error('worker timeout'));
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {}, fetchImpl: f, log: quiet(),
    });
    assert.equal(await b.snapshot(['BTCUSDT']), null);
    assert.equal(b.available, false);
    assert.equal(b.stats.failed, 1);
  });

  await t('نمادهای ناقص در پاسخ لبه دور ریخته می‌شوند', async () => {
    const f = fakeFetch(() => ({
      body: {
        ok: true,
        symbols: {
          BTCUSDT: { bid: 100, ask: 100.2, last: 100.1, ts: 111 },
          ETHUSDT: { error: 'timeout' },
          SOLUSDT: { bid: 0, ask: 0 },
        },
      },
    }));
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {}, fetchImpl: f, log: quiet(),
    });
    const snap = await b.snapshot(['BTCUSDT', 'ETHUSDT', 'SOLUSDT']);
    assert.deepEqual(Object.keys(snap), ['BTCUSDT']);
    assert.equal(snap.BTCUSDT.ask, 100.2);
  });

  await t('provider ترکیبی: اول لبه، و در شکست مستقیم', async () => {
    let innerCalls = 0;
    const inner = {
      name: 'fake',
      model: 'm',
      async complete() { innerCalls++; return 'from-inner'; },
    };

    const edgeUp = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {},
      fetchImpl: fakeFetch(() => ({ body: { ok: true, text: 'from-edge' } })), log: quiet(),
    });
    const p1 = new WorkerFirstProvider({ inner, bridge: edgeUp });
    assert.equal(await p1.complete({ messages: [{ role: 'user', content: 'x' }] }), 'from-edge');
    assert.equal(p1.lastVia, 'edge');
    assert.equal(innerCalls, 0);

    const edgeDown = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {},
      fetchImpl: fakeFetch(() => new Error('boom')), log: quiet(),
    });
    const p2 = new WorkerFirstProvider({ inner, bridge: edgeDown });
    assert.equal(await p2.complete({ messages: [{ role: 'user', content: 'x' }] }), 'from-inner');
    assert.equal(p2.lastVia, 'direct');
    assert.equal(innerCalls, 1);
  });

  await t('بدون کارگر، provider ترکیبی دقیقاً همان provider اصلی است', async () => {
    let innerCalls = 0;
    const inner = { name: 'fake', async complete() { innerCalls++; return 'direct'; } };
    const bridgeOff = new WorkerBridge({ cfg: cfgWith({}), env: {}, fetchImpl: null, log: quiet() });
    const p = new WorkerFirstProvider({ inner, bridge: bridgeOff });
    assert.equal(await p.complete({ messages: [] }), 'direct');
    assert.equal(innerCalls, 1);
  });

  await t('توکن از متغیر محیطی خوانده می‌شود و در هدر می‌رود', async () => {
    const f = fakeFetch(() => ({ body: { ok: true, text: 'ok' } }));
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }),
      env: { BB_WORKER_TOKEN: 'secret-token' }, fetchImpl: f, log: quiet(),
    });
    await b.complete({ messages: [{ role: 'user', content: 'x' }] });
    assert.equal(f.calls[0].init.headers['x-bb-token'], 'secret-token');
  });

  await t('وضعیت برای گزارش‌ها قابل خواندن است', async () => {
    const b = new WorkerBridge({
      cfg: cfgWith({ baseUrl: 'https://edge.example' }), env: {}, fetchImpl: fakeFetch(() => ({ body: { ok: true, text: 'x' } })), log: quiet(),
    });
    await b.complete({ messages: [{ role: 'user', content: 'x' }] });
    const s = b.status();
    assert.equal(s.enabled, true);
    assert.equal(s.modelCalls, 1);
    assert.equal(s.available, true);
    assert.equal(typeof s.lastOkAt, 'number');
  });

  done('worker');
})();
