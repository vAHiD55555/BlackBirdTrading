#!/usr/bin/env node
'use strict';
/**
 * BlackBird — observation ledger test suite.
 *
 * Zero dependencies, no network, real temp directories.
 *
 * What is asserted:
 *   - a record round-trips through JSONL
 *   - redaction removes every shape a key actually takes
 *   - redaction is recursive and does not mutate its input
 *   - outcome and quality labels join back to their cycle
 *   - the daily byte cap stops writes instead of filling the disk
 *   - old files are compressed and eventually pruned
 *   - a broken directory disables the ledger without throwing
 *
 * Run: node tests/ledger.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const zlib = require('node:zlib');

const SRC = path.join(__dirname, '..', 'src');
const { Ledger, redact, containsSecret, REDACTED } = require(path.join(SRC, 'jev/ledger'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'bb-ledger-'));
}

function makeLedger(opts = {}) {
  const dir = opts.dir || tmpDir();
  const l = new Ledger({
    cfg: { enabled: true, ...(opts.cfg || {}) },
    log: quietLog(),
    dir,
    clock: opts.clock,
  });
  return { ledger: l, dir };
}

// ================================================================ redaction
group('ledger — redaction', () => {
  test('OpenAI-style key is removed', () => {
    const out = redact({ note: 'key is sk-abcdefghijklmnopqrstuvwxyz123456' });
    assert.ok(!out.note.includes('sk-abc'), out.note);
    assert.ok(out.note.includes(REDACTED));
  });

  test('GitHub token is removed', () => {
    const out = redact('token ghp_abcdefghijklmnopqrstuvwxyz0123456789');
    assert.ok(!out.includes('ghp_'), out);
  });

  test('Google API key is removed', () => {
    const out = redact('AIzaSyA1234567890abcdefghijklmnopqrstuv');
    assert.ok(!out.includes('AIza'), out);
  });

  test('Groq and Cerebras keys are removed', () => {
    assert.ok(!redact('gsk_abcdefghijklmnopqrstuvwxyz1234').includes('gsk_'));
    assert.ok(!redact('csk-abcdefghijklmnopqrstuvwxyz1234').includes('csk-'));
  });

  test('a Bearer header is removed', () => {
    const out = redact('Authorization: Bearer abcdefghijklmnopqrstuvwxyz');
    assert.ok(!out.includes('abcdefghijklmnopqrstuvwxyz'), out);
  });

  test('a JWT is removed', () => {
    const jwt = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U';
    assert.ok(!redact(jwt).includes('eyJhbGciOiJIUzI1NiJ9'));
  });

  test('a secret-named field is redacted whatever its value', () => {
    const out = redact({ apiKey: 'plainlookingvalue', token: 'x', password: 'hunter2', model: 'gpt-4o' });
    assert.strictEqual(out.apiKey, REDACTED);
    assert.strictEqual(out.token, REDACTED);
    assert.strictEqual(out.password, REDACTED);
    assert.strictEqual(out.model, 'gpt-4o', 'non-secret fields survive');
  });

  test('redaction is recursive through arrays and nested objects', () => {
    const out = redact({
      models: [{ provider: 'groq', apiKey: 'gsk_abcdefghijklmnopqrstuvwxyz1234' }],
      deep: { deeper: { secret: 'value' } },
    });
    assert.strictEqual(out.models[0].apiKey, REDACTED);
    assert.strictEqual(out.deep.deeper.secret, REDACTED);
    assert.strictEqual(out.models[0].provider, 'groq');
  });

  test('redaction does not mutate its input', () => {
    const input = { apiKey: 'sk-abcdefghijklmnopqrstuvwxyz123456', nested: { token: 'abc' } };
    const copy = JSON.parse(JSON.stringify(input));
    redact(input);
    assert.deepStrictEqual(input, copy, 'input must be untouched');
  });

  test('containsSecret detects a leak and clears clean text', () => {
    assert.strictEqual(containsSecret('sk-abcdefghijklmnopqrstuvwxyz123456'), true);
    assert.strictEqual(containsSecret('the market is calm'), false);
  });

  test('a long string is truncated, not dropped', () => {
    const out = redact('x'.repeat(5000));
    assert.ok(out.length < 5000);
    assert.ok(out.includes('[+'));
  });
});

// ================================================================== writing
group('ledger — writing and reading', () => {
  test('a record round-trips through JSONL', () => {
    const { ledger, dir } = makeLedger();
    const ok = ledger.write({ type: 'cycle', cycleId: 'c1', decision: { regime: 'muddy' } });
    assert.strictEqual(ok, true);

    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.jsonl'));
    assert.strictEqual(files.length, 1);

    const back = ledger.read();
    assert.strictEqual(back.length, 1);
    assert.strictEqual(back[0].cycleId, 'c1');
    assert.strictEqual(back[0].decision.regime, 'muddy');
    assert.strictEqual(back[0].schemaVersion, 1);
  });

  test('a key in the payload never reaches disk', () => {
    const { ledger, dir } = makeLedger();
    ledger.write({
      type: 'cycle',
      cycleId: 'c2',
      input: { note: 'using sk-abcdefghijklmnopqrstuvwxyz123456' },
      models: [{ provider: 'groq', apiKey: 'gsk_abcdefghijklmnopqrstuvwxyz1234' }],
    });
    const file = fs.readdirSync(dir).find((f) => f.endsWith('.jsonl'));
    const raw = fs.readFileSync(path.join(dir, file), 'utf8');
    assert.ok(!raw.includes('sk-abc'), 'OpenAI key leaked to disk');
    assert.ok(!raw.includes('gsk_'), 'Groq key leaked to disk');
    assert.ok(raw.includes(REDACTED));
  });

  test('records are appended, not overwritten', () => {
    const { ledger } = makeLedger();
    ledger.write({ type: 'cycle', cycleId: 'a' });
    ledger.write({ type: 'cycle', cycleId: 'b' });
    ledger.write({ type: 'cycle', cycleId: 'c' });
    const back = ledger.read();
    assert.strictEqual(back.length, 3);
    assert.deepStrictEqual(back.map((r) => r.cycleId), ['a', 'b', 'c']);
  });

  test('read filters by type', () => {
    const { ledger } = makeLedger();
    ledger.write({ type: 'cycle', cycleId: 'a' });
    ledger.write({ type: 'outcome', cycleId: 'a', outcome: { win: true } });
    assert.strictEqual(ledger.read({ type: 'cycle' }).length, 1);
    assert.strictEqual(ledger.read({ type: 'outcome' }).length, 1);
  });

  test('a disabled ledger writes nothing', () => {
    const { ledger, dir } = makeLedger({ cfg: { enabled: false } });
    assert.strictEqual(ledger.write({ type: 'cycle', cycleId: 'x' }), false);
    assert.strictEqual(fs.existsSync(dir) ? fs.readdirSync(dir).length : 0, 0);
  });
});

// ================================================================== labelling
group('ledger — outcome and quality labels', () => {
  test('an outcome label joins back to its cycle', () => {
    const { ledger } = makeLedger();
    ledger.write({ type: 'cycle', cycleId: 'c9', decision: { regime: 'trend' } });
    ledger.label('c9', { pnl: 12.5, win: true, horizonMs: 3600000 });

    const all = ledger.read();
    const cycle = all.find((r) => r.type === 'cycle');
    const outcome = all.find((r) => r.type === 'outcome');
    assert.ok(cycle && outcome);
    assert.strictEqual(outcome.cycleId, 'c9');
    assert.strictEqual(outcome.outcome.pnl, 12.5);
    assert.strictEqual(outcome.outcome.win, true);
  });

  test('a quality label records the operator verdict', () => {
    const { ledger } = makeLedger();
    ledger.write({ type: 'cycle', cycleId: 'c10' });
    ledger.labelQuality('c10', 'rejected', 'veto was too aggressive');
    const q = ledger.read({ type: 'quality' })[0];
    assert.strictEqual(q.verdict, 'rejected');
    assert.match(q.note, /aggressive/);
  });

  test('labelling without a cycleId is refused', () => {
    const { ledger } = makeLedger();
    assert.strictEqual(ledger.label(null, { win: true }), false);
    assert.strictEqual(ledger.labelQuality('', 'approved'), false);
  });
});

// ====================================================================== caps
group('ledger — size limits and rotation', () => {
  test('the daily byte cap stops writes instead of filling the disk', () => {
    const { ledger } = makeLedger({ cfg: { maxBytesPerDay: 400 } });
    let written = 0;
    for (let i = 0; i < 50; i++) {
      if (ledger.write({ type: 'cycle', cycleId: `c${i}`, pad: 'x'.repeat(100) })) written++;
    }
    assert.ok(written > 0, 'some records should fit');
    assert.ok(written < 50, 'the cap must stop the flood');
    assert.match(ledger.stats.lastError, /daily cap/);
  });

  test('old files are compressed to .gz', () => {
    const dir = tmpDir();
    const old = new Date(Date.now() - 5 * 86400000).toISOString().slice(0, 10);
    const oldFile = path.join(dir, `${old}.jsonl`);
    fs.writeFileSync(oldFile, `${JSON.stringify({ type: 'cycle', cycleId: 'old' })}\n`);
    const past = Date.now() - 5 * 86400000;
    fs.utimesSync(oldFile, past / 1000, past / 1000);

    const ledger = new Ledger({
      cfg: { enabled: true, compressAfterDays: 2, keepDays: 30 },
      log: quietLog(),
      dir,
    });
    // A write on a new day triggers rotation.
    ledger.write({ type: 'cycle', cycleId: 'today' });

    assert.ok(!fs.existsSync(oldFile), 'the plain file should be gone');
    assert.ok(fs.existsSync(`${oldFile}.gz`), 'the .gz should exist');
    const back = zlib.gunzipSync(fs.readFileSync(`${oldFile}.gz`)).toString('utf8');
    assert.match(back, /"cycleId":"old"/);
  });

  test('files past keepDays are deleted', () => {
    const dir = tmpDir();
    const ancient = new Date(Date.now() - 60 * 86400000).toISOString().slice(0, 10);
    const f = path.join(dir, `${ancient}.jsonl`);
    fs.writeFileSync(f, '{}\n');
    const past = Date.now() - 60 * 86400000;
    fs.utimesSync(f, past / 1000, past / 1000);

    const ledger = new Ledger({ cfg: { enabled: true, keepDays: 30 }, log: quietLog(), dir });
    ledger.write({ type: 'cycle', cycleId: 'now' });
    assert.ok(!fs.existsSync(f), 'the ancient file should be pruned');
  });

  test('read still sees compressed days', () => {
    const dir = tmpDir();
    const old = new Date(Date.now() - 5 * 86400000).toISOString().slice(0, 10);
    const gz = path.join(dir, `${old}.jsonl.gz`);
    fs.writeFileSync(gz, zlib.gzipSync(`${JSON.stringify({ type: 'cycle', cycleId: 'gz1' })}\n`));

    const ledger = new Ledger({ cfg: { enabled: true }, log: quietLog(), dir });
    const back = ledger.read();
    assert.strictEqual(back.length, 1);
    assert.strictEqual(back[0].cycleId, 'gz1');
  });
});

// ================================================================= fail-safe
group('ledger — fail-safe', () => {
  test('an unwritable directory disables the ledger without throwing', () => {
    // A regular file used as a parent directory: mkdir fails immediately with
    // ENOTDIR, which is the realistic "disk is read-only / path is wrong" case.
    const dir = tmpDir();
    const blocker = path.join(dir, 'not-a-dir');
    fs.writeFileSync(blocker, 'x');

    const ledger = new Ledger({
      cfg: { enabled: true },
      log: quietLog(),
      dir: path.join(blocker, 'observations'),
    });
    assert.doesNotThrow(() => ledger.write({ type: 'cycle', cycleId: 'x' }));
    assert.strictEqual(ledger.write({ type: 'cycle', cycleId: 'x' }), false);
    assert.ok(ledger.stats.lastError, 'the failure should be recorded');
  });

  test('snapshot never throws and reports counts', () => {
    const { ledger } = makeLedger();
    ledger.write({ type: 'cycle', cycleId: 'a', decision: { regime: 'calm', riskMultiplier: 1 } });
    const s = ledger.snapshot();
    assert.strictEqual(s.enabled, true);
    assert.strictEqual(s.recordsToday, 1);
    assert.ok(s.bytesToday > 0);
    assert.strictEqual(s.lastRecord.cycleId, 'a');
    assert.strictEqual(s.lastRecord.regime, 'calm');
  });

  test('a torn line is skipped, not fatal', () => {
    const dir = tmpDir();
    const day = new Date().toISOString().slice(0, 10);
    fs.writeFileSync(
      path.join(dir, `${day}.jsonl`),
      `${JSON.stringify({ type: 'cycle', cycleId: 'good' })}\n{"broken": \n`
    );
    const ledger = new Ledger({ cfg: { enabled: true }, log: quietLog(), dir });
    const back = ledger.read();
    assert.strictEqual(back.length, 1);
    assert.strictEqual(back[0].cycleId, 'good');
  });
});

// ==================================================================== summary
console.log(`\n${'\u2500'.repeat(48)}`);
console.log(`  ledger: ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  \u2022 ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'\u2500'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);
