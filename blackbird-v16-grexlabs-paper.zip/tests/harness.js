'use strict';
// Minimal shared test runner for the new suites (same output style as the others).
let passed = 0, failed = 0; const failures = [];
async function t(name, fn) {
  try { await fn(); passed++; console.log(`  \u2713 ${name}`); }
  catch (e) { failed++; failures.push({ name, error: e }); console.log(`  \u2717 ${name}\n      ${e.message}`); }
}
function done(label) {
  console.log(`\n  ${label}: ${passed} passed, ${failed} failed`);
  if (failed) { for (const f of failures) console.log(`  \u2022 ${f.name}\n    ${f.error.stack || f.error}`); process.exit(1); }
}
module.exports = { t, done };
