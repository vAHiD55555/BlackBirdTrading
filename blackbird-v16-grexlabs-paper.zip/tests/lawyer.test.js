#!/usr/bin/env node
'use strict';
/**
 * BlackBird — lawyer test suite.
 *
 * Zero dependencies, no network.
 *
 * What is asserted:
 *   - a healthy snapshot produces no findings
 *   - a breached clause produces a finding with a defensible impact estimate
 *   - missing data produces a data gap, never an invented number
 *   - a clause that throws does not kill the rest of the audit
 *   - severity thresholds are honoured
 *   - autoObject off means no veto; on means a critical finding vetoes
 *   - a warning never vetoes, even with autoObject on
 *   - the lawyer works with jev absent, disabled, or broken
 *   - the brief renders and totals the estimated loss
 *
 * Run: node tests/lawyer.test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const { Lawyer } = require(path.join(SRC, 'lawyer/lawyer'));
const { CLAUSES, severityFor } = require(path.join(SRC, 'lawyer/charter'));
const { toText } = require(path.join(SRC, 'lawyer/report'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

function makeLawyer(cfg = {}) {
  return new Lawyer({ cfg: { enabled: true, ...cfg }, log: quietLog() });
}

/** A snapshot where every clause is comfortably healthy. */
function healthy() {
  return {
    risk: { equity: 5000, drawdownPct: 0.5, consumedUsd: 1000 },
    positions: [
      { symbol: 'BNB', side: 'long', notional: 500 },
      { symbol: 'AVAX', side: 'long', notional: 500 },
      { symbol: 'XRP', side: 'long', notional: 500 },
      { symbol: 'SOL', side: 'long', notional: 500 },
      { symbol: 'DOGE', side: 'long', notional: 500 },
      { symbol: 'ADA', side: 'long', notional: 500 },
    ],
    pnl: { net: 200, grossProfit: 400 },
    fees: { total: 20 },
    slippage: { total: 10 },
    time: { activeMs: 9 * 3600 * 1000, blockedMs: 1 * 3600 * 1000 },
    cycles: { expected: 100, missed: 0 },
    latency: { p99Ms: 800 },
    modules: [
      { name: 'rotator', errorCount: 0 },
      { name: 'risk', errorCount: 0 },
      { name: 'portfolio', errorCount: 0 },
    ],
    limits: {
      maxOpenPositions: 8,
      maxSymbolExposurePct: 25,
      maxNetExposurePct: 100,
      killSwitchDrawdownPct: 12,
    },
  };
}

// ================================================================== healthy
group('lawyer — healthy state', () => {
  test('a healthy snapshot produces no findings', () => {
    const l = makeLawyer();
    const r = l.run(healthy());
    assert.strictEqual(r.findings.length, 0, `unexpected: ${r.findings.map((f) => f.clause)}`);
    assert.strictEqual(r.gaps.length, 0);
    assert.strictEqual(r.errors.length, 0);
  });

  test('every clause is measured on a complete snapshot', () => {
    const l = makeLawyer();
    const r = l.run(healthy());
    assert.strictEqual(r.clauses.length, CLAUSES.length);
    const unmeasured = r.clauses.filter((c) => !c.measurable);
    assert.strictEqual(unmeasured.length, 0, `unmeasured: ${unmeasured.map((c) => c.id)}`);
  });

  test('the brief reports a healthy headline', () => {
    const l = makeLawyer();
    l.run(healthy());
    const b = l.brief();
    assert.strictEqual(b.status, 'ok');
    assert.match(b.headline, /سالم/);
    assert.strictEqual(b.annualImpactUsd, 0);
  });
});

// ================================================================== breaches
group('lawyer — breached clauses', () => {
  test('idle capital is flagged with an annual cost estimate', () => {
    const snap = healthy();
    // Only 10% of equity deployed -> 90% idle.
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 500 }];
    const l = makeLawyer({ benchmarkAnnualPct: 5 });
    const r = l.run(snap);

    const f = r.findings.find((x) => x.clause === 'capital_utilisation');
    assert.ok(f, 'capital_utilisation should be flagged');
    assert.strictEqual(f.severity, 'critical');
    assert.ok(f.impactEstimate.annualUsd > 0, 'must carry a cost estimate');
    assert.match(f.impactEstimate.basis, /بیکار/);
    assert.ok(f.recommendation.length > 0);
  });

  test('excessive concentration is flagged', () => {
    const snap = healthy();
    // 80% of equity in one symbol, with the other 20% on the opposite side so
    // the direction total does not mask the symbol concentration.
    snap.positions = [
      { symbol: 'BTC', side: 'long', notional: 4000 },
      { symbol: 'ETH', side: 'short', notional: 1000 },
    ];
    const l = makeLawyer();
    const r = l.run(snap);
    const f = r.findings.find((x) => x.clause === 'concentration');
    assert.ok(f, 'concentration should be flagged');
    assert.strictEqual(f.evidence.value, 80);
  });

  test('a diversified book is not flagged for concentration', () => {
    const l = makeLawyer();
    const r = l.run(healthy());
    assert.ok(!r.findings.some((f) => f.clause === 'concentration'));
  });

  test('high cost ratio is flagged', () => {
    const snap = healthy();
    snap.fees = { total: 200 };
    snap.slippage = { total: 100 };
    snap.pnl = { net: 100, grossProfit: 400 };
    const l = makeLawyer();
    const r = l.run(snap);
    const f = r.findings.find((x) => x.clause === 'cost_efficiency');
    assert.ok(f, 'cost_efficiency should be flagged');
    assert.strictEqual(f.evidence.value, 75);
  });

  test('charter breaches are counted', () => {
    const snap = healthy();
    // 12 positions against a limit of 8, and 4800 notional on 5000 equity.
    snap.positions = Array.from({ length: 12 }, (_, i) => ({
      symbol: `S${i}`, side: 'long', notional: 400,
    }));
    const l = makeLawyer();
    const r = l.run(snap);
    const f = r.findings.find((x) => x.clause === 'charter_compliance');
    assert.ok(f, 'charter_compliance should be flagged');
    assert.ok(f.evidence.value >= 1);
  });

  test('a negative risk-adjusted return is critical', () => {
    const snap = healthy();
    snap.pnl = { net: -300, grossProfit: 100 };
    const l = makeLawyer();
    const r = l.run(snap);
    const f = r.findings.find((x) => x.clause === 'risk_adjusted_return');
    assert.ok(f);
    assert.strictEqual(f.severity, 'critical');
  });
});

// ================================================================ data gaps
group('lawyer — missing data', () => {
  test('an empty snapshot yields gaps, not invented numbers', () => {
    const l = makeLawyer();
    const r = l.run({});
    assert.strictEqual(r.findings.length, 0, 'no data must not mean a breach');
    assert.ok(r.gaps.length > 0, 'gaps should be recorded');
    for (const c of r.clauses) {
      assert.strictEqual(c.measurable, false);
      assert.strictEqual(c.value, null, 'a value must never be invented');
    }
  });

  test('a gap names the fields it needed', () => {
    const l = makeLawyer();
    const r = l.run({});
    const gap = r.gaps.find((g) => g.clause === 'capital_utilisation');
    assert.ok(gap);
    assert.ok(gap.evidence.missing.includes('risk.equity'));
  });

  test('partial data measures what it can and gaps the rest', () => {
    const snap = healthy();
    delete snap.fees;
    const l = makeLawyer();
    const r = l.run(snap);
    const cost = r.clauses.find((c) => c.id === 'cost_efficiency');
    assert.strictEqual(cost.measurable, false);
    const cap = r.clauses.find((c) => c.id === 'capital_utilisation');
    assert.strictEqual(cap.measurable, true);
  });

  test('zero gross profit makes cost efficiency unmeasurable, not infinite', () => {
    const snap = healthy();
    snap.pnl = { net: 0, grossProfit: 0 };
    const l = makeLawyer();
    const r = l.run(snap);
    const cost = r.clauses.find((c) => c.id === 'cost_efficiency');
    assert.strictEqual(cost.measurable, false);
  });
});

// ============================================================ measurement errors
group('lawyer — a broken clause does not kill the audit', () => {
  test('a throwing clause is recorded and the rest continue', () => {
    const l = makeLawyer();
    // A getter that throws when the concentration clause reads positions.
    const snap = healthy();
    let reads = 0;
    Object.defineProperty(snap, 'positions', {
      get() {
        reads++;
        if (reads > 1) throw new Error('boom in positions');
        return [
          { symbol: 'BNB', side: 'long', notional: 500 },
          { symbol: 'AVAX', side: 'long', notional: 500 },
        ];
      },
      configurable: true,
    });

    const r = l.run(snap);
    assert.ok(r.errors.length > 0, 'the error should be recorded');
    assert.ok(r.clauses.length === CLAUSES.length, 'every clause still reported');
    // Clauses that do not read positions still measured.
    const time = r.clauses.find((c) => c.id === 'time_productivity');
    assert.strictEqual(time.measurable, true);
    assert.ok(l.stats.errors > 0);
  });

  test('audit never throws, even on a hostile snapshot', () => {
    const l = makeLawyer();
    const hostile = {
      get risk() { throw new Error('nope'); },
      positions: 'not an array',
      pnl: null,
    };
    assert.doesNotThrow(() => l.run(hostile));
  });
});

// ================================================================== severity
group('lawyer — severity thresholds', () => {
  test('severityFor respects direction and distance', () => {
    assert.strictEqual(severityFor(50, { warn: 25, critical: 10 }, 'lower-is-worse'), 'ok');
    assert.strictEqual(severityFor(20, { warn: 25, critical: 10 }, 'lower-is-worse'), 'warn');
    assert.strictEqual(severityFor(5, { warn: 25, critical: 10 }, 'lower-is-worse'), 'critical');
    assert.strictEqual(severityFor(10, { warn: 35, critical: 60 }, 'higher-is-worse'), 'ok');
    assert.strictEqual(severityFor(45, { warn: 35, critical: 60 }, 'higher-is-worse'), 'warn');
    assert.strictEqual(severityFor(70, { warn: 35, critical: 60 }, 'higher-is-worse'), 'critical');
  });

  test('severityThreshold=critical suppresses warnings', () => {
    const snap = healthy();
    // 20% deployed -> capital_utilisation 20, which is a warn (warn=25, critical=10).
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 1000 }];
    const l = makeLawyer({ severityThreshold: 'critical' });
    const r = l.run(snap);
    assert.strictEqual(r.findings.length, 0, 'warnings should be filtered out');
    // ...but the clause still shows its severity on the dashboard.
    const cap = r.clauses.find((c) => c.id === 'capital_utilisation');
    assert.strictEqual(cap.severity, 'warn');
  });

  test('custom thresholds from config are applied', () => {
    const snap = healthy();
    // 40% deployed: a breach at the default warn=25, fine at warn=5.
    // For a lower-is-worse clause, critical must sit BELOW warn.
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 2000 }];
    const relaxed = makeLawyer({ clauses: { capital_utilisation: { warn: 5, critical: 2 } } });
    const r = relaxed.run(snap);
    assert.ok(
      !r.findings.some((f) => f.clause === 'capital_utilisation'),
      'a relaxed threshold should not fire'
    );
  });
});

// ================================================================= autoObject
group('lawyer — autoObject', () => {
  test('autoObject off means no veto even on a critical finding', () => {
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = makeLawyer({ autoObject: false });
    const r = l.run(snap);
    assert.ok(r.findings.some((f) => f.severity === 'critical'));
    assert.strictEqual(l.vetoActive, false);
    assert.strictEqual(l.stats.vetoes, 0);
  });

  test('autoObject on vetoes on a critical finding', () => {
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = makeLawyer({ autoObject: true });
    l.run(snap);
    assert.strictEqual(l.vetoActive, true);
    assert.ok(l.stats.vetoes > 0);
    assert.ok(l.vetoReason);
    assert.ok(l.alerts.some((a) => a.kind === 'veto'));
  });

  test('a warning never vetoes, even with autoObject on', () => {
    const snap = healthy();
    // 30% deployed -> capital_utilisation warn, not critical.
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 1500 }];
    const l = makeLawyer({ autoObject: true });
    const r = l.run(snap);
    assert.ok(r.findings.every((f) => f.severity !== 'critical'));
    assert.strictEqual(l.vetoActive, false);
  });

  test('a healthy state never vetoes', () => {
    const l = makeLawyer({ autoObject: true });
    l.run(healthy());
    assert.strictEqual(l.vetoActive, false);
  });
});

// ============================================================ jev independence
group('lawyer — independence from jev', () => {
  test('works with no jev at all', () => {
    const l = makeLawyer();
    assert.doesNotThrow(() => l.run(healthy()));
    assert.ok(l.lastAudit);
  });

  test('works when jev is disabled', () => {
    const jev = { enabled: false, bus: { emit() {} } };
    const l = new Lawyer({ cfg: { enabled: true }, log: quietLog(), jev });
    assert.doesNotThrow(() => l.run(healthy()));
  });

  test('works when jev throws on notification', () => {
    const jev = {
      onLawyerFindings() { throw new Error('jev is broken'); },
    };
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = new Lawyer({ cfg: { enabled: true }, log: quietLog(), jev });
    assert.doesNotThrow(() => l.run(snap));
    assert.ok(l.lastAudit.findings.length > 0, 'the audit still completed');
  });

  test('findings are pushed to jev when it can receive them', () => {
    let received = null;
    const jev = { onLawyerFindings(f) { received = f; } };
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = new Lawyer({ cfg: { enabled: true }, log: quietLog(), jev });
    l.run(snap);
    assert.ok(Array.isArray(received) && received.length > 0);
  });
});

// ==================================================================== ledger
group('lawyer — observation ledger', () => {
  test('an audit writes a lawyer.audit record', () => {
    const written = [];
    const ledger = { enabled: true, write: (r) => { written.push(r); return true; } };
    const l = new Lawyer({ cfg: { enabled: true }, log: quietLog(), ledger });
    l.run(healthy());
    assert.strictEqual(written.length, 1);
    assert.strictEqual(written[0].type, 'lawyer.audit');
    assert.ok(Array.isArray(written[0].clauses));
    assert.ok(written[0].input, 'the input snapshot is recorded');
  });

  test('a broken ledger does not break the audit', () => {
    const ledger = { enabled: true, write() { throw new Error('disk full'); } };
    const l = new Lawyer({ cfg: { enabled: true }, log: quietLog(), ledger });
    assert.doesNotThrow(() => l.run(healthy()));
  });
});

// ===================================================================== brief
group('lawyer — brief', () => {
  test('the brief totals the estimated annual loss', () => {
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = makeLawyer({ benchmarkAnnualPct: 5 });
    l.run(snap);
    const b = l.brief();
    assert.ok(b.annualImpactUsd > 0);
    assert.ok(b.findings.length > 0);
    assert.ok(b.recommendations.length > 0);
  });

  test('the brief renders to text without throwing', () => {
    const l = makeLawyer();
    l.run(healthy());
    const text = toText(l.brief());
    assert.ok(text.includes('لایحه'));
    assert.ok(text.includes('شروط منشور'));
  });

  test('recommend() returns actionable items', () => {
    const snap = healthy();
    snap.positions = [{ symbol: 'BNB', side: 'long', notional: 100 }];
    const l = makeLawyer();
    l.run(snap);
    const recs = l.recommend();
    assert.ok(recs.length > 0);
    assert.ok(recs[0].action.length > 0);
  });

  test('snapshot() exposes the panel shape', () => {
    const l = makeLawyer();
    l.run(healthy());
    const s = l.snapshot();
    assert.strictEqual(s.enabled, true);
    assert.ok(s.brief);
    assert.ok(Array.isArray(s.brief.clauses));
    assert.strictEqual(s.brief.clauses.length, CLAUSES.length);
  });
});

// ==================================================================== summary
console.log(`\n${'\u2500'.repeat(48)}`);
console.log(`  lawyer: ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  \u2022 ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'\u2500'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);
