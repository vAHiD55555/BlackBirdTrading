#!/usr/bin/env node
'use strict';
/**
 * BlackBird test suite — zero dependencies, deterministic.
 *   node tests/run.js            all tests
 *   node tests/run.js -v         verbose
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const SRC = path.join(__dirname, '..', 'src');
const util = require(path.join(SRC, 'core/util'));
const { Ring, chainHash, quantile, percentileRank, emaLast } = util;
const { rsi, atr, bollinger, computeSnapshot } = require(path.join(SRC, 'data/indicators'));
const { classify } = require(path.join(SRC, 'data/regime'));
const { createExchange, walkBook } = require(path.join(SRC, 'data/exchanges'));
const { RiskManager } = require(path.join(SRC, 'risk/risk'));
const { riskXray } = require(path.join(SRC, 'risk/xray'));
const { Portfolio, Position } = require(path.join(SRC, 'exec/portfolio'));
const { PaperBroker } = require(path.join(SRC, 'exec/paper'));
const { Jev } = require(path.join(SRC, 'exec/jev'));
const { Store } = require(path.join(SRC, 'core/store'));
const { Bus } = require(path.join(SRC, 'core/bus'));
const { Scout } = require(path.join(SRC, 'agents/scout'));
const { Board } = require(path.join(SRC, 'agents/board'));
const { Trader } = require(path.join(SRC, 'agents/trader'));
const { Witness } = require(path.join(SRC, 'agents/witness'));
const { Auditor } = require(path.join(SRC, 'agents/auditor'));
const { Learner } = require(path.join(SRC, 'agents/learner'));
const { Reporter } = require(path.join(SRC, 'agents/reporter'));
const { loadConfig } = require(path.join(SRC, 'config'));

const VERBOSE = process.argv.includes('-v');
let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    if (VERBOSE) console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  ✗ ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n▸ ${name}`);
  fn();
}

// ---------------------------------------------------------------- fixtures
const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

function rng(seed = 42) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/** Synthetic OHLC series: rising vol, mild drift, then a sweep+reclaim bar. */
function synthBars(n = 320, seed = 7) {
  const r = rng(seed);
  const bars = [];
  let price = 100;
  const start = Date.now() - n * 300000;
  for (let i = 0; i < n; i++) {
    const vol = 0.0004 + (i / n) * 0.0009; // volatility expands over time
    const drift = 0.0009;
    const ret = drift + (r() - 0.5) * 2 * vol;
    const o = price;
    const c = Math.max(0.01, price * (1 + ret));
    const h = Math.max(o, c) * (1 + r() * vol);
    const l = Math.min(o, c) * (1 - r() * vol);
    const v = 10 + r() * 40 + (Math.abs(ret) / vol) * 20;
    bars.push({ t: start + i * 300000, o, h, l, c, v });
    price = c;
  }
  // craft a deep pullback in a strong uptrend: price closes near the low of
  // the 40-bar range while still far above the 50-EMA
  const last = bars[n - 1];
  const window = bars.slice(-40, -1);
  const low40 = Math.min(...window.map((b) => b.l));
  last.o = low40 * 1.006;
  last.l = low40 * 0.999;
  last.c = low40 * 1.004;
  last.h = low40 * 1.009;
  return bars;
}

function makeFeed(symbol, bars, book) {
  return {
    symbol,
    bars: new Ring(600),
    isStale: false,
    gapCount: 0,
    lastBarTs: bars[bars.length - 1].t,
    ticker: { symbol, bid: book.bid, ask: book.ask, last: book.mid, ts: Date.now() },
    depth: {
      bids: [[book.bid, book.depthUsd / book.bid / 2]],
      asks: [[book.ask, book.depthUsd / book.ask / 2]],
      ts: Date.now(),
    },
    book() {
      return { ...book, quoteAgeMs: 5, bidNotional: book.depthUsd / 2, askNotional: book.depthUsd / 2 };
    },
    snapshot() {
      const minBars = 20 + 14 + 10;
      if (this.bars.length < minBars) return null;
      return computeSnapshot(this.bars.toArray(), CFG.strategy, {
        symbol,
        bid: book.bid,
        ask: book.ask,
        mid: book.mid,
        spreadBps: book.spreadBps,
        depthUsd: book.depthUsd,
        quoteAgeMs: 5,
        stale: false,
      });
    },
  };
}

function makeHub(feeds) {
  return { get: (s) => feeds.get(s), all: () => [...feeds.values()] };
}

function memStore(cfg) {
  const log = [];
  return {
    state: {
      equity: cfg.risk.startEquity,
      dayStartEquity: cfg.risk.startEquity,
      counters: { day: new Date().toISOString().slice(0, 10), tradesToday: 0, wins: 0, losses: 0, trades: 0, grossProfit: 0, grossLoss: 0, lossesStreak: 0 },
      cooldowns: {},
      learned: {},
      positions: [],
    },
    entries: log,
    append: (type, data) => log.push({ type, data }),
    readJournal: ({ type } = {}) => log.filter((e) => !type || e.type === type),
    verifyChain: () => ({ ok: true, count: log.length }),
    saveState: () => {},
    rollDay: () => false,
  };
}

// many rules live in the config; keep one canonical instance
let CFG = loadConfig({ server: { enabled: false }, reporter: { dir: path.join(os.tmpdir(), 'bb-reports') }, runtime: { dataDir: path.join(os.tmpdir(), 'bb-data') } });

// ============================================================== core/util
group('core/util', () => {
  test('clamp / round / quantile', () => {
    assert.strictEqual(util.clamp(5, 0, 3), 3);
    assert.strictEqual(util.round(1.2345, 2), 1.23);
    assert.strictEqual(quantile([1, 2, 3, 4], 0.5), 2.5);
  });
  test('Ring keeps the newest window', () => {
    const r = new Ring(3);
    [1, 2, 3, 4, 5].forEach((x) => r.push(x));
    assert.deepStrictEqual(r.toArray(), [3, 4, 5]);
    assert.strictEqual(r.get(0), 3);
  });
  test('percentileRank bounds', () => {
    assert.strictEqual(percentileRank([1, 2, 3], 0), 0);
    assert.strictEqual(percentileRank([1, 2, 3], 4), 1);
  });
  test('chainHash is deterministic and order independent', () => {
    const a = chainHash('GENESIS', { b: 1, a: [2, 3] });
    const b = chainHash('GENESIS', { a: [2, 3], b: 1 });
    assert.strictEqual(a, b);
    assert.notStrictEqual(a, chainHash('OTHER', { a: [2, 3], b: 1 }));
  });
  test('emaLast approaches the value on a flat series', () => {
    assert.ok(Math.abs(emaLast(Array(100).fill(5), 10) - 5) < 1e-9);
  });
});

// ============================================================= indicators
group('data/indicators', () => {
  const bars = synthBars(80, 3);
  const closes = bars.map((b) => b.c);
  test('rsi stays in 0..100', () => {
    const r = rsi(closes, 14);
    assert.ok(r >= 0 && r <= 100, `rsi=${r}`);
  });
  test('atr is positive on a moving series', () => {
    assert.ok(atr(bars, 14) > 0);
  });
  test('bollinger bands bracket the mean', () => {
    const bb = bollinger(closes, 20, 2);
    assert.ok(bb.upper > bb.mid && bb.mid > bb.lower);
    assert.ok(bb.pctB >= -1 && bb.pctB <= 2);
  });
  test('snapshot exposes the fields every agent expects', () => {
    const s = computeSnapshot(bars, CFG.strategy, {});
    for (const k of ['price', 'atr', 'atrPct', 'atrPercentile', 'rsi', 'bb', 'vwap', 'trendStrength', 'volumeSpike', 'ema9', 'ema21', 'ema50']) {
      assert.ok(k in s, `missing ${k}`);
    }
  });
});

// ================================================================ regime
group('data/regime', () => {
  const baseBook = { spreadBps: 1.5, depthUsd: 500000 };
  const snap = { atrPercentile: 0.7, trendStrength: 0.6 };
  test('calm when volatility is below the gate', () => {
    const r = classify({ ...snap, atrPercentile: 0.2 }, baseBook, CFG.strategy);
    assert.strictEqual(r.regime, 'calm');
  });
  test('muddy when turbulent and liquid', () => {
    const r = classify(snap, baseBook, CFG.strategy);
    assert.strictEqual(r.regime, 'muddy');
    assert.ok(r.score > 0);
  });
  test('toxic when the book is thin', () => {
    const r = classify(snap, { spreadBps: 1.5, depthUsd: 100 }, CFG.strategy);
    assert.strictEqual(r.regime, 'toxic');
  });
  test('toxic when the spread explodes', () => {
    const r = classify(snap, { spreadBps: 500, depthUsd: 500000 }, CFG.strategy);
    assert.strictEqual(r.regime, 'toxic');
  });
  test('trend when directional strength is extreme', () => {
    const r = classify({ ...snap, trendStrength: 4 }, baseBook, CFG.strategy);
    assert.strictEqual(r.regime, 'trend');
  });
});

// ================================================================ exchanges
group('data/exchanges', () => {
  test('walkBook fills across levels and prices the average', () => {
    const w = walkBook([[100, 1], [101, 1], [102, 1]], 2.5);
    assert.strictEqual(w.filled, 2.5);
    assert.ok(w.avgPrice > 100 && w.avgPrice < 101.1);
    assert.strictEqual(w.complete, true);
  });
  test('walkBook reports an incomplete fill', () => {
    const w = walkBook([[100, 1]], 2);
    assert.strictEqual(w.complete, false);
    assert.strictEqual(w.filled, 1);
  });
  test('adapter surface is complete for every venue', () => {
    for (const id of ['binance', 'mexc', 'bitget', 'bybit']) {
      const ex = createExchange(id);
      for (const m of ['klines', 'ticker', 'depth', 'serverTime']) assert.strictEqual(typeof ex[m], 'function', `${id}.${m}`);
    }
  });
  test('unknown venue is rejected', () => {
    assert.throws(() => createExchange('nope'));
  });
});

// ============================================================ market feed
group('data/market', () => {
  test('a closed candle emits a bar event carrying its symbol', () => {
    const { MarketFeed } = require(path.join(SRC, 'data/market'));
    const feed = new MarketFeed('BTCUSDT', { id: 'binance' }, CFG, quietLog());
    const got = [];
    feed.on('bar', (e) => got.push(e));
    feed.liveBar = { t: 1000, o: 1, h: 1, l: 1, c: 1, v: 1 };
    feed.ingestBar({ t: 1000, o: 1, h: 2, l: 1, c: 1.5, v: 1 });
    feed.ingestBar({ t: 2000, o: 1.5, h: 2, l: 1, c: 1.8, v: 1 });
    assert.strictEqual(got.length, 1);
    assert.strictEqual(got[0].symbol, 'BTCUSDT');
    assert.ok(got[0].feed === feed);
    assert.strictEqual(feed.bars.length, 1);
  });
  test('book derives spread and staleness', () => {
    const { MarketFeed } = require(path.join(SRC, 'data/market'));
    const feed = new MarketFeed('X', { id: 'binance' }, CFG, quietLog());
    feed.setTicker({ bid: 100, ask: 100.02, last: 100.01, ts: Date.now() });
    feed.setDepth({ bids: [[100, 5]], asks: [[100.02, 5]], ts: Date.now() });
    const b = feed.book();
    assert.ok(b.spreadBps > 0 && b.spreadBps < 10);
    assert.ok(b.depthUsd > 0);
    assert.strictEqual(feed.isStale, false);
  });
});

// ================================================================ portfolio
group('exec/portfolio', () => {
  test('long close computes gross, fees and net correctly', () => {
    const pf = new Portfolio(quietLog());
    pf.open(new Position({ symbol: 'X', qty: 10, entry: 100, fee: 0.5, notional: 1000, strategy: 's', tp: 110, sl: 95 }));
    const t = pf.close('X', { price: 110, fee: 0.8, feeKind: 'maker', reason: 'take_profit' });
    assert.strictEqual(t.grossPnl, 100);
    assert.strictEqual(t.fees, 1.3);
    assert.strictEqual(t.pnl, 98.7);
    assert.strictEqual(t.win, true);
  });
  test('exposure helpers reflect open positions', () => {
    const pf = new Portfolio(quietLog());
    pf.open(new Position({ symbol: 'A', qty: 1, entry: 100, fee: 0, notional: 100, strategy: 's', tp: 110, sl: 90 }));
    pf.open(new Position({ symbol: 'B', qty: 1, entry: 200, fee: 0, notional: 200, strategy: 's', tp: 220, sl: 180 }));
    assert.strictEqual(pf.totalExposure(), 300);
    assert.strictEqual(pf.exposureBySymbol('A'), 100);
    assert.strictEqual(pf.exposureBySymbolMap().B, 200);
  });
  test('double close is a no-op', () => {
    const pf = new Portfolio(quietLog());
    pf.open(new Position({ symbol: 'X', qty: 1, entry: 100, fee: 0, notional: 100, strategy: 's', tp: 110, sl: 90 }));
    assert.ok(pf.close('X', { price: 101, fee: 0, reason: 'x' }));
    assert.strictEqual(pf.close('X', { price: 101, fee: 0, reason: 'x' }), null);
  });
});

// =================================================================== risk
group('risk', () => {
  const mk = () => {
    const store = memStore(CFG);
    const risk = new RiskManager({ cfg: CFG, store, log: quietLog() });
    const pf = new Portfolio(quietLog());
    return { store, risk, pf };
  };
  const prop = { symbol: 'BTCUSDT', notional: 500, confidence: 0.9 };

  test('approves a clean trade', () => {
    const { risk, pf } = mk();
    const r = risk.check(prop, pf);
    assert.strictEqual(r.ok, true, r.reason);
  });
  test('rejects when the symbol already has a position', () => {
    const { risk, pf } = mk();
    pf.open(new Position({ symbol: 'BTCUSDT', qty: 1, entry: 1, fee: 0, notional: 500, strategy: 's', tp: 2, sl: 0.5 }));
    assert.strictEqual(risk.check(prop, pf).ok, false);
    assert.match(risk.check(prop, pf).reason, /symbol_already_open/);
  });
  test('rejects past the daily trade cap', () => {
    const { risk, pf, store } = mk();
    store.state.counters.tradesToday = CFG.risk.maxDailyTrades;
    assert.match(risk.check(prop, pf).reason, /daily_trade_cap/);
  });
  test('halts on the daily loss limit', () => {
    const { risk, store } = mk();
    store.state.dayStartEquity = 1000;
    store.state.equity = 900;
    assert.match(risk.check(prop, new Portfolio(quietLog())).reason, /daily_loss_limit|drawdown/);
  });
  test('settle updates equity, streaks and win/loss counts', () => {
    const { risk, store } = mk();
    risk.settle({ pnl: -10, fee: 1, win: false, symbol: 'X', tradeId: 'a' });
    assert.strictEqual(store.state.equity, CFG.risk.startEquity - 10);
    assert.strictEqual(store.state.counters.lossesStreak, 1);
    risk.settle({ pnl: 20, fee: 1, win: true, symbol: 'X', tradeId: 'b' });
    assert.strictEqual(store.state.counters.lossesStreak, 0);
    assert.strictEqual(store.state.counters.wins, 1);
  });
  test('sizing never exceeds the risk budget', () => {
    const { risk } = mk();
    const s = risk.size({ price: 100, tpBps: 40, entryFeeBps: 7.5, exitFeeBps: 7.5 });
    assert.ok(s.notional <= CFG.risk.startEquity * CFG.risk.maxPositionPct + 1e-9);
    assert.ok(s.qty > 0);
  });
});

// =============================================================== risk x-ray
group('risk/xray', () => {
  test('separates long/short, gross/net and mark-to-market exposure', () => {
    const pf = new Portfolio(quietLog());
    const long = new Position({ symbol: 'BTCUSDT', side: 'long', qty: 1, entry: 100, fee: 0, notional: 600, strategy: 'x', tp: 110, sl: 90 });
    const short = new Position({ symbol: 'ETHUSDT', side: 'short', qty: 2, entry: 200, fee: 0, notional: 400, strategy: 'x', tp: 180, sl: 220 });
    long.mark(105);
    short.mark(190);
    pf.open(long);
    pf.open(short);
    const x = riskXray(pf, 1000);
    assert.strictEqual(x.longNotional, 600);
    assert.strictEqual(x.shortNotional, 400);
    assert.strictEqual(x.grossNotional, 1000);
    assert.strictEqual(x.netNotional, 200);
    assert.strictEqual(x.grossPct, 100);
    assert.strictEqual(x.netPct, 20);
    assert.strictEqual(x.unrealisedPnl, 25);
    assert.strictEqual(x.equityMtm, 1025);
  });
});

// ================================================================== broker
group('exec/paper', () => {
  const feed = {
    isStale: false,
    depth: { bids: [[99.9, 100]], asks: [[100.1, 100]] },
  };
  const broker = new PaperBroker({
    cfg: CFG,
    log: quietLog(),
    getBook: () => ({ bid: 99.9, ask: 100.1 }),
    getFeed: () => feed,
  });
  test('market buy walks the ask and pays taker', () => {
    const f = broker.submit({ symbol: 'X', side: 'buy', type: 'market', qty: 10, price: null });
    assert.strictEqual(f.status, 'filled');
    assert.ok(f.price >= 100.1);
    assert.ok(f.fee > 0);
    assert.strictEqual(f.feeKind, 'taker');
  });
  test('market order on a stale book is rejected', () => {
    const stale = { isStale: true, depth: feed.depth };
    const b2 = new PaperBroker({ cfg: CFG, log: quietLog(), getBook: () => ({ bid: 1, ask: 2 }), getFeed: () => stale });
    assert.strictEqual(b2.submit({ symbol: 'X', side: 'buy', type: 'market', qty: 1 }).status, 'rejected');
  });
  test('limit buy fills when the market trades down to it (maker)', () => {
    const o = broker.submit({ symbol: 'X', side: 'buy', type: 'limit', qty: 1, price: 99.5, ttlMs: 5000 });
    assert.strictEqual(o.status, 'open');
    const fills = broker.onTick({ symbol: 'X', bid: 99.4, ask: 99.6 }, feed);
    assert.strictEqual(fills.length, 1);
    assert.strictEqual(fills[0].feeKind, 'maker');
    assert.strictEqual(fills[0].price, 99.5);
  });
  test('limit orders expire', () => {
    broker.submit({ symbol: 'Y', side: 'buy', type: 'limit', qty: 1, price: 1, ttlMs: 1 });
    const ex = broker.expire(Date.now() + 10);
    assert.ok(ex.some((e) => e.symbol === 'Y'));
  });
});

// ===================================================================== JEV
group('exec/jev', () => {
  const jev = new Jev(CFG, quietLog());
  jev.prewarm(['BTCUSDT'], { BTCUSDT: 70000 });
  test('quantises price and qty to the symbol step', () => {
    assert.strictEqual(jev.quantisePrice('BTCUSDT', 70000.123456), 70000.1);
    assert.ok(jev.quantiseQty('BTCUSDT', 0.000123456) > 0);
  });
  test('rejects an order that missed its latency budget', () => {
    const r = jev.build({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 0.01, price: 70000, signalTs: Date.now() - CFG.jevExec.maxLatencyMs - 50 });
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /latency_budget/);
  });
  test('builds a valid vector inside the budget', () => {
    const r = jev.build({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 0.01, price: 70000, signalTs: Date.now() });
    assert.strictEqual(r.ok, true);
    assert.ok(r.order.qty > 0);
  });
  test('rejects notional below the venue minimum', () => {
    const r = jev.build({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1e-5, price: 1, signalTs: Date.now() });
    assert.strictEqual(r.ok, false);
  });
  test('records latency percentiles', () => {
    for (const ms of [10, 20, 30, 40, 50]) jev.record(ms, {});
    assert.ok(jev.percentile(50) >= 20);
    assert.ok(jev.percentile(99) <= 50);
  });
});

// =================================================================== store
group('core/store', () => {
  test('hash chain detects tampering', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-store-'));
    const cfg = { ...CFG, runtime: { ...CFG.runtime, dataDir: dir, stateFile: path.join(dir, 'state.json'), journalFile: path.join(dir, 'journal.jsonl'), logDir: path.join(dir, 'logs') } };
    const store = new Store(cfg, quietLog());
    store.loadState();
    store.append('a', { x: 1 });
    store.append('b', { y: 2 });
    assert.strictEqual(store.verifyChain().ok, true);

    const lines = fs.readFileSync(cfg.runtime.journalFile, 'utf8').trim().split('\n');
    const e = JSON.parse(lines[0]);
    e.data.x = 999;
    lines[0] = JSON.stringify(e);
    fs.writeFileSync(cfg.runtime.journalFile, lines.join('\n') + '\n');
    const v = store.verifyChain();
    assert.strictEqual(v.ok, false);
    assert.strictEqual(v.brokenAt, 0);
  });
});

// ================================================================= learner
group('agents/learner', () => {
  test('no bias before enough samples', () => {
    const store = memStore(CFG);
    const l = new Learner({ cfg: CFG, log: quietLog(), store });
    assert.strictEqual(l.bias('X', 'SWEEP_RECLAIM', 'muddy'), 0);
  });
  test('positive bias for a profitable arm, negative for a losing one', () => {
    const store = memStore(CFG);
    const l = new Learner({ cfg: CFG, log: quietLog(), store });
    for (let i = 0; i < 20; i++) l.observe({ symbol: 'A', strategy: 'S', context: { regime: 'muddy' }, pnl: 5, win: true, pnlBps: 30 });
    for (let i = 0; i < 20; i++) l.observe({ symbol: 'B', strategy: 'S', context: { regime: 'muddy' }, pnl: -5, win: false, pnlBps: -30 });
    assert.ok(l.bias('A', 'S', 'muddy') > 0);
    assert.ok(l.bias('B', 'S', 'muddy') < 0);
  });
});

// =================================================================== scout
group('agents/scout', () => {
  const bars = synthBars(320, 11);
  const price = bars[bars.length - 1].c;
  const book = { bid: price * 0.9999, ask: price * 1.0001, mid: price, spreadBps: 2, depthUsd: 900000, bidNotional: 450000, askNotional: 450000, quoteAgeMs: 5 };
  const feed = makeFeed('BTCUSDT', bars, book);
  bars.forEach((b) => feed.bars.push(b));
  // the signal unit test isolates signal generation from the trend filter
  const CFG_SIG = { ...CFG, strategy: { ...CFG.strategy, requireUptrend: false, useBreadthGate: false } };
  const store = memStore(CFG);
  const risk = new RiskManager({ cfg: CFG, store, log: quietLog() });
  const scout = new Scout({ cfg: CFG_SIG, log: quietLog(), store, hub: makeHub(new Map([['BTCUSDT', feed]])), risk, learner: null });

  test('produces a proposal on a clear sweep+reclaim in muddy water', () => {
    const p = scout.evaluate('BTCUSDT');
    assert.ok(p, `expected a proposal, skips=${JSON.stringify(scout.stats.skipped)}`);
    assert.ok(p.tpBps > 0 && p.slBps > 0);
    assert.ok(p.tpBps > p.slBps * 0.5, 'tp should be meaningful relative to sl');
    assert.ok(p.confidence > 0 && p.confidence <= 1);
    assert.ok(p.rationale.length >= 3);
  });
  test('a downtrend never produces a long entry', () => {
    const C = { ...CFG, strategy: { ...CFG.strategy, requireUptrend: true, allowShort: false } };
    const down = synthBars(320, 21).map((b, i, arr) => ({ ...b }));
    // force a persistent downtrend: close below the 50-EMA
    let px = 100;
    const t0 = Date.now() - 320 * 300000;
    const falling = [];
    for (let i = 0; i < 320; i++) {
      const o = px;
      const c = px * 0.9995;
      falling.push({ t: t0 + i * 300000, o, h: o * 1.0005, l: c * 0.9995, c, v: 15 });
      px = c;
    }
    const f3 = makeFeed('BTCUSDT', falling, book);
    falling.forEach((b) => f3.bars.push(b));
    const s3 = new Scout({ cfg: C, log: quietLog(), store, hub: makeHub(new Map([['BTCUSDT', f3]])), risk, learner: null });
    assert.strictEqual(s3.evaluate('BTCUSDT'), null);
    assert.ok((s3.stats.skipped.no_signal || 0) >= 1, JSON.stringify(s3.stats.skipped));
  });
  test('refuses to trade a calm market', () => {
    const flat = [];
    let price = 100;
    const t0 = Date.now() - 320 * 300000;
    for (let i = 0; i < 320; i++) {
      const o = price;
      const c = price * (1 + (i % 2 ? 0.00005 : -0.00005));
      flat.push({ t: t0 + i * 300000, o, h: Math.max(o, c) * 1.0001, l: Math.min(o, c) * 0.9999, c, v: 10 });
      price = c;
    }
    const f2 = makeFeed('ETHUSDT', flat, book);
    flat.forEach((b) => f2.bars.push(b));
    // calm water: mean-reversion must stay out. (trend-pullback may still run,
    // because a calm uptrend is a perfectly good place to buy a pullback)
    const CFG_NO_TREND = { ...CFG, strategy: { ...CFG.strategy, trendPullback: false } };
    const s2 = new Scout({ cfg: CFG_NO_TREND, log: quietLog(), store, hub: makeHub(new Map([['ETHUSDT', f2]])), risk, learner: null });
    assert.strictEqual(s2.evaluate('ETHUSDT'), null);
    assert.ok((s2.stats.skipped.no_signal || 0) + (s2.stats.skipped.regime_calm || 0) >= 1, JSON.stringify(s2.stats.skipped));
  });
});

// =================================================================== board
group('agents/board', () => {
  const cfg = CFG;
  const store = memStore(cfg);
  const risk = new RiskManager({ cfg, store, log: quietLog() });
  const pf = new Portfolio(quietLog());
  const price = 100;
  const feed = {
    isStale: false,
    ticker: { bid: price - 0.01, ask: price + 0.01 },
    gapCount: 0,
    lastBarTs: Date.now(),
    book: () => ({ bid: price - 0.01, ask: price + 0.01, mid: price, spreadBps: 2, depthUsd: 500000, bidNotional: 250000, askNotional: 250000, quoteAgeMs: 10 }),
  };
  const witness = { price: () => ({ price, exchange: 'bybit', ts: Date.now() }) };
  const jev = new Jev(cfg, quietLog());
  jev.prewarm(['BTCUSDT'], { BTCUSDT: price });
  const board = new Board({ cfg, log: quietLog(), store, risk, witness, hub: makeHub(new Map([['BTCUSDT', feed]])), jev });

  const proposal = {
    id: 'p1', ts: Date.now(), symbol: 'BTCUSDT', side: 'buy', strategy: 'SWEEP_RECLAIM',
    entryType: 'maker', price: price - 0.01, tpBps: 40, slBps: 25, confidence: 0.8, expectedEdgeBps: 15,
    regime: 'muddy', features: {}, rationale: ['x'],
  };

  test('approves a clean proposal with two officers', () => {
    const d = board.review(proposal, pf, 0);
    assert.strictEqual(d.approved, true, d.reason);
    assert.ok(d.notional > 0);
    assert.strictEqual(d.votes.length, 3);
  });
  test('vetoes when the witness diverges', () => {
    const badWitness = { price: () => ({ price: price * 1.01, exchange: 'bybit', ts: Date.now() }) };
    const b2 = new Board({ cfg, log: quietLog(), store, risk: new RiskManager({ cfg, store: memStore(cfg), log: quietLog() }), witness: badWitness, hub: makeHub(new Map([['BTCUSDT', feed]])), jev });
    const d = b2.review(proposal, pf, 0);
    assert.strictEqual(d.approved, false);
    assert.ok(d.votes.some((v) => v.officer === 'integrity' && v.vote === 'reject'));
  });
  test('rejects a low-confidence proposal', () => {
    const d = board.review({ ...proposal, confidence: 0.1 }, pf, 0);
    assert.strictEqual(d.approved, false);
  });
});

// ======================================================= e2e: trade cycle
group('end-to-end trade cycle', () => {
  test('proposal -> board -> fill -> take profit -> witness verifies', () => {
    const cfg = loadConfig({ server: { enabled: false }, runtime: { dataDir: path.join(os.tmpdir(), 'bb-e2e') }, reporter: { dir: path.join(os.tmpdir(), 'bb-e2e-rep') } });
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    const pf = new Portfolio(quietLog());
    const price = 100;
    const feed = {
      isStale: false,
      ticker: { symbol: 'BTCUSDT', bid: price - 0.01, ask: price + 0.01, last: price, ts: Date.now() },
      gapCount: 0,
      lastBarTs: Date.now(),
      depth: { bids: [[price - 0.01, 1000]], asks: [[price + 0.01, 1000]] },
      book: () => ({ bid: price - 0.01, ask: price + 0.01, mid: price, spreadBps: 2, depthUsd: 200000, quoteAgeMs: 10 }),
    };
    const hub = makeHub(new Map([['BTCUSDT', feed]]));
    const bus = new Bus(quietLog());
    const broker = new PaperBroker({ cfg, log: quietLog(), getBook: () => feed.book(), getFeed: () => feed });
    const jev = new Jev(cfg, quietLog());
    jev.prewarm(['BTCUSDT'], { BTCUSDT: price });
    const trader = new Trader({ cfg, log: quietLog(), store, broker, portfolio: pf, risk, jev, hub, bus });
    const witness = new Witness({ cfg, log: quietLog(), store, exchange: null });
    witness.refs.set('BTCUSDT', [{ ts: Date.now(), price }]);

    let closed = null;
    bus.on('trade:closed', (t) => { closed = t; });

    const decision = { id: 'd1', approved: true, qty: 50, notional: 5000 };
    const proposal = {
      id: 'p1', ts: Date.now(), symbol: 'BTCUSDT', side: 'buy', strategy: 'SWEEP_RECLAIM',
      entryType: 'market', price: price, tpBps: 40, slBps: 30, confidence: 0.8, features: { regime: 'muddy' }, rationale: ['test'],
    };

    const res = trader.enter(proposal, decision);
    assert.strictEqual(res.ok, true);
    assert.ok(pf.hasPosition('BTCUSDT'), 'position should be open');

    const pos = pf.get('BTCUSDT');
    const tpTick = { symbol: 'BTCUSDT', bid: pos.tp + 0.5, ask: pos.tp + 0.6, last: pos.tp + 0.5, ts: Date.now() };
    trader.onTick(tpTick, feed);
    // the exit is a limit order; the next tick at/above it fills
    trader.onTick(tpTick, feed);
    trader.onTick(tpTick, feed);

    assert.ok(closed, 'trade should have closed');
    assert.strictEqual(closed.win, true);
    assert.strictEqual(closed.exit.reason, 'take_profit');
    assert.ok(closed.pnl > 0);

    const verdict = witness.verifyTrade(closed);
    assert.ok(['verified', 'soft_discrepancy'].includes(verdict.verdict), JSON.stringify(verdict));
  });
});

// ================================================================ auditor
group('agents/auditor', () => {
  test('detects exposure above the cap and halts', () => {
    const cfg = CFG;
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    const pf = new Portfolio(quietLog());
    pf.open(new Position({ symbol: 'A', qty: 1, entry: 1, fee: 0, notional: 99999, strategy: 's', tp: 2, sl: 0.5 }));
    const auditor = new Auditor({
      cfg, log: quietLog(), store, risk, portfolio: pf,
      trader: { pendingEntries: new Map(), trades: [] },
      jev: { stats: () => ({ n: 0 }), latencies: [] },
      hub: { all: () => [] },
      witness: null, broker: { fills: [] }, bus: null,
    });
    const f = auditor.checkRiskLimits();
    assert.strictEqual(f.level, 'critical');
    assert.strictEqual(risk.halted, true);
  });
  test('flags a broken journal chain as critical', () => {
    const cfg = CFG;
    const store = memStore(cfg);
    store.verifyChain = () => ({ ok: false, brokenAt: 3 });
    store.state.counters.trades = 0;
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    const auditor = new Auditor({
      cfg, log: quietLog(), store, risk, portfolio: new Portfolio(quietLog()),
      trader: { pendingEntries: new Map(), trades: [] },
      jev: { stats: () => ({ n: 0 }), latencies: [] },
      hub: { all: () => [] }, witness: { stats: { discrepancy: 0 } }, broker: { fills: [] }, bus: null,
    });
    auditor._lastChainCheck = 0;
    const f = auditor.checkIntegrity();
    assert.strictEqual(f.level, 'critical');
  });
});

// =============================================================== reporter
group('agents/reporter', () => {
  test('renders a markdown report with every required section', () => {
    const cfg = loadConfig({ runtime: { dataDir: path.join(os.tmpdir(), 'bb-rep2') }, reporter: { dir: path.join(os.tmpdir(), 'bb-rep2-out') }, server: { enabled: false } });
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    const pf = new Portfolio(quietLog());
    const reporter = new Reporter({
      cfg, log: quietLog(), store, trader: { observations: [], trades: [] }, portfolio: pf, risk,
      scout: { stats: { proposed: 0, scanned: 0, skipped: {} }, snapshot: () => ({}) },
      board: { votes: [], stats: { sessions: 0, approved: 0, rejected: 0 } },
      auditor: { summary: () => ({ alerts: 0, criticals: 0, latest: {}, recent: [] }) },
      witness: null, learner: { snapshot: () => ({ arms: [], params: {}, recentChanges: [] }) },
      jev: { stats: () => ({ p50: 0, p99: 0, sent: 0, aborted: 0, budgetMs: 400 }) }, hub: null,
    });
    const r = reporter.build(Date.now() - 3600000, Date.now());
    const md = reporter.renderMarkdown(r);
    for (const must of ['خلاصه‌ی عملکرد', 'تشخیص بازار', 'هیئت مشاوره', 'دلیل هرکدام', 'لایه‌های نظارتی', 'شاهد', 'آموخته‌ها']) {
      assert.ok(md.includes(must), `missing section: ${must}`);
    }
    assert.ok(md.length > 800);
  });
});

// ================================================================== config
group('config', () => {
  test('loads defaults and derives interval from timeframe', () => {
    const c = loadConfig();
    assert.strictEqual(c.mode, 'paper');
    const TF = { '1m': 60000, '3m': 180000, '5m': 300000, '15m': 900000, '30m': 1800000, '1h': 3600000 };
    assert.strictEqual(c.data.intervalMs, TF[c.data.timeframe]);
  });
  test('live mode is refused without the interlock', () => {
    const { validateConfig } = require(path.join(SRC, 'config'));
    const c = loadConfig({ mode: 'live' });
    const v = validateConfig(c);
    assert.strictEqual(v.ok, false);
    assert.ok(v.problems.some((p) => p.includes('API_KEY')));
  });
});

// ========================================================== short trading
group('futures / short', () => {
  const mk = () => {
    const cfg = loadConfig({ server: { enabled: false }, runtime: { dataDir: path.join(os.tmpdir(), 'bb-short') } });
    cfg.market = 'futures';
    cfg.strategy.allowShort = true;
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    const pf = new Portfolio(quietLog());
    const price = 100;
    const feed = {
      isStale: false,
      gapCount: 0,
      lastBarTs: Date.now(),
      ticker: { symbol: 'BTCUSDT', bid: price - 0.01, ask: price + 0.01, last: price, ts: Date.now() },
      depth: { bids: [[price - 0.01, 1000]], asks: [[price + 0.01, 1000]] },
      book: () => ({ bid: price - 0.01, ask: price + 0.01, mid: price, spreadBps: 2, depthUsd: 200000, quoteAgeMs: 10 }),
    };
    const hub = makeHub(new Map([['BTCUSDT', feed]]));
    const bus = new Bus(quietLog());
    const broker = new PaperBroker({ cfg, log: quietLog(), getBook: () => feed.book(), getFeed: () => feed });
    const jev = new Jev(cfg, quietLog());
    jev.prewarm(['BTCUSDT'], { BTCUSDT: price });
    const trader = new Trader({ cfg, log: quietLog(), store, broker, portfolio: pf, risk, jev, hub, bus });
    return { cfg, trader, pf, risk, bus, feed, price };
  };

  test('opens a short position and takes profit when price falls', () => {
    const { trader, pf, bus, feed, price } = mk();
    let closed = null;
    bus.on('trade:closed', (t) => { closed = t; });
    const decision = { id: 'd1', approved: true, qty: 50, notional: 5000 };
    const proposal = {
      id: 'p1', ts: Date.now(), symbol: 'BTCUSDT', side: 'sell', strategy: 'TREND_PULLBACK_SHORT',
      entryType: 'market', price, tpBps: 60, slBps: 40, confidence: 0.8, features: { regime: 'muddy' }, rationale: ['short'],
    };
    assert.strictEqual(trader.enter(proposal, decision).ok, true);
    const pos = pf.get('BTCUSDT');
    assert.strictEqual(pos.side, 'short');
    assert.strictEqual(pos.dir, -1);
    assert.ok(pos.tp < pos.entry && pos.sl > pos.entry, 'short geometry');

    const winTick = { symbol: 'BTCUSDT', bid: pos.tp - 0.5, ask: pos.tp - 0.4, last: pos.tp - 0.5, ts: Date.now() };
    trader.onTick(winTick, feed);
    trader.onTick(winTick, feed);
    trader.onTick(winTick, feed);
    assert.ok(closed, 'short should have closed');
    assert.strictEqual(closed.win, true);
    assert.ok(closed.pnl > 0);
  });

  test('a short is stopped out when price rises', () => {
    const { trader, pf, feed, price } = mk();
    const decision = { id: 'd2', approved: true, qty: 50, notional: 5000 };
    const proposal = {
      id: 'p2', ts: Date.now(), symbol: 'BTCUSDT', side: 'sell', strategy: 'TREND_PULLBACK_SHORT',
      entryType: 'market', price, tpBps: 60, slBps: 40, confidence: 0.8, features: { regime: 'muddy' }, rationale: ['short'],
    };
    trader.enter(proposal, decision);
    const pos = pf.get('BTCUSDT');
    const loseTick = { symbol: 'BTCUSDT', bid: pos.sl + 0.5, ask: pos.sl + 0.6, last: pos.sl + 0.5, ts: Date.now() };
    trader.onTick(loseTick, feed);
    assert.strictEqual(pf.hasPosition('BTCUSDT'), false);
  });

  test('funding is charged to the holder at the 8h boundary', () => {
    const { fundingFor } = require(path.join(SRC, 'agents/exits'));
    const long = { dir: 1, notional: 1000 };
    const short = { dir: -1, notional: 1000 };
    assert.ok(fundingFor(long, 1) > 0, 'long pays when rate is positive');
    assert.ok(fundingFor(short, 1) < 0, 'short receives when rate is positive');
  });
});

// ================================================================ rotator (v3)
group('rotator / orbital strategy', () => {
  const { Rotator, atrSeries, ema } = require(path.join(SRC, 'strategy/rotator'));

  /** Deterministic synthetic bars: drift per bar plus a small wave. */
  const makeBars = (start, drift, n = 400, vol = 0.004) => {
    const out = [];
    let c = start;
    const t0 = Date.UTC(2025, 0, 1);
    for (let i = 0; i < n; i++) {
      c = c * (1 + drift) * (1 + Math.sin(i / 3) * vol);
      const o = c * (1 - vol / 2);
      out.push({ t: t0 + i * 3600000, o, h: Math.max(o, c) * (1 + vol), l: Math.min(o, c) * (1 - vol), c, v: 1000 });
    }
    return out;
  };

  const fakeFeed = (bars) => ({
    bars: { toArray: () => bars },
    book: () => ({ bid: bars[bars.length - 1].c * 0.9999, ask: bars[bars.length - 1].c * 1.0001, quoteAgeMs: 100 }),
  });

  const build = (opts = {}) => {
    const cfg = loadConfig();
    cfg.strategy.mode = 'rotator';
    Object.assign(cfg.strategy.rotator, opts.rotator || {});
    cfg.symbols = opts.symbols || ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT'];
    const bars = opts.bars || {
      BTCUSDT: makeBars(100, 0.0005),
      ETHUSDT: makeBars(100, 0.002),
      SOLUSDT: makeBars(100, -0.001),
      XRPUSDT: makeBars(100, -0.002),
    };
    const hub = { get: (s) => fakeFeed(bars[s]), all: () => Object.keys(bars).map((s) => fakeFeed(bars[s])) };
    const store = { append: () => {} };
    const risk = {
      state: { equity: 5000, dayStartEquity: 5000 },
      peakEquity: 5000,
      halted: false,
      settle() { return risk.state.equity; },
    };
    const portfolio = new Portfolio({ info() {}, warn() {}, debug() {}, error() {} });
    const fills = [];
    const broker = {
      submit(order) {
        const barsArr = bars[order.symbol];
        const px = barsArr[barsArr.length - 1].c;
        const fill = { status: 'filled', symbol: order.symbol, side: order.side, qty: order.qty, price: px, notional: px * order.qty, fee: px * order.qty * 5e-4, feeKind: 'taker' };
        fills.push(fill);
        return fill;
      },
    };
    const rot = new Rotator({
      cfg, log: { info() {}, warn() {}, error() {}, debug() {} }, store, risk, portfolio, broker,
      hub, bus: { emit() {} },
    });
    return { rot, bars, portfolio, risk, fills, cfg };
  };

  test('ATR series is positive and finite on a trending series', () => {
    const bars = makeBars(100, 0.001, 120);
    const a = atrSeries(bars, 14);
    assert.ok(isFinite(a[60]), 'atr finite');
    assert.ok(a[60] > 0, 'atr positive');
  });

  test('momentum ranks the universe by relative strength', () => {
    const { rot, bars } = build();
    const picks = rot.variantPicks({ lookHours: 72, top: 2, neutral: true, gate: false }, bars);
    const longs = picks.filter((p) => p.dir === 1).map((p) => p.sym);
    const shorts = picks.filter((p) => p.dir === -1).map((p) => p.sym);
    assert.deepStrictEqual(longs.sort(), ['BTCUSDT', 'ETHUSDT'].sort());
    assert.deepStrictEqual(shorts.sort(), ['SOLUSDT', 'XRPUSDT'].sort());
  });

  test('the BTC gate blocks longs in a bear market but keeps shorts', () => {
    const bars = {
      BTCUSDT: makeBars(100, -0.002),
      ETHUSDT: makeBars(100, 0.002),
      SOLUSDT: makeBars(100, -0.001),
      XRPUSDT: makeBars(100, -0.003),
    };
    const { rot } = build({ bars });
    const gated = rot.variantPicks({ lookHours: 72, top: 2, neutral: true, gate: true }, bars);
    assert.strictEqual(gated.filter((p) => p.dir === 1).length, 0, 'no longs when BTC is below its 200-EMA');
    assert.ok(gated.filter((p) => p.dir === -1).length >= 1, 'shorts still allowed');
  });

  test('target book caps every position at perPositionPct', () => {
    const { rot, bars } = build({ rotator: { perPositionPct: 11, variants: [
      { lookHours: 72, top: 1, neutral: false, gate: false },
      { lookHours: 72, top: 1, neutral: false, gate: false },
    ] } });
    rot.variants = rot.rc.variants;
    const book = rot.targetBook(bars);
    const top = book.get('ETHUSDT');
    assert.ok(top, 'strongest symbol is in the book');
    assert.strictEqual(top.dir, 1);
    assert.strictEqual(top.pct, 11, 'two agreeing variants still cap at one allocation');
  });

  test('drawdown throttle cuts exposure as the book falls', () => {
    const { rot, risk } = build();
    rot.dailyEquity = [5000, 5000, 5000];
    risk.peakEquity = 5000;
    risk.state.equity = 4900; // 2% dd -> no throttle
    assert.strictEqual(rot.overlay(), 1);
    risk.state.equity = 4250; // 15% dd -> 0.35 step
    assert.strictEqual(rot.overlay(), 0.35);
  });

  test('rebalance opens the target book and is idempotent', () => {
    const { rot, portfolio } = build();
    const r1 = rot.rebalance();
    assert.ok(r1.opened > 0, 'opened positions');
    assert.strictEqual(portfolio.openPositions().length, r1.opened);
    const count = portfolio.openPositions().length;
    const r2 = rot.rebalance();
    assert.strictEqual(r2.opened, 0, 'second pass opens nothing new');
    assert.strictEqual(portfolio.openPositions().length, count, 'book unchanged');
  });

  test('a disaster stop closes the position', () => {
    const { rot, portfolio } = build();
    rot.rebalance();
    const pos = portfolio.openPositions()[0];
    assert.ok(pos, 'position exists');
    const tick = { symbol: pos.symbol, bid: pos.sl * (pos.dir > 0 ? 0.99 : 1.01), ask: pos.sl * (pos.dir > 0 ? 0.9901 : 1.0101), last: pos.sl, ts: Date.now() };
    rot.onTick(tick);
    assert.strictEqual(portfolio.hasPosition(pos.symbol), false, 'stopped out');
    assert.strictEqual(rot.stats.stops, 1);
  });

  test('positions carry a direction-aware stop', () => {
    const { rot, portfolio } = build();
    rot.rebalance();
    for (const p of portfolio.openPositions()) {
      if (p.dir > 0) assert.ok(p.sl < p.entry, 'long stop below entry');
      else assert.ok(p.sl > p.entry, 'short stop above entry');
    }
  });
});

// ================================================================ journal integrity
group('journal integrity (v3 fixes)', () => {
  const { chainHash } = util;

  test('hash is stable across a JSON round-trip (undefined keys)', () => {
    const payload = { seq: 1, ts: 2, type: 'x', data: { a: 1, b: undefined, c: [1, { d: undefined, e: 2 }] }, prev: 'GENESIS' };
    const h1 = chainHash('GENESIS', payload);
    const h2 = chainHash('GENESIS', JSON.parse(JSON.stringify(payload)));
    assert.strictEqual(h1, h2);
  });

  test('a broken journal is repaired on boot and the tail archived', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-journal-'));
    const journal = path.join(dir, 'journal.jsonl');
    const good = { seq: 0, ts: 1, type: 'a', data: { x: 1 } };
    good.prev = 'GENESIS';
    good.hash = chainHash('GENESIS', good);
    const bad = { seq: 1, ts: 2, type: 'b', data: { y: 2 }, prev: good.hash, hash: 'deadbeef' };
    fs.writeFileSync(journal, JSON.stringify(good) + '\n' + JSON.stringify(bad) + '\n');

    const cfg = {
      runtime: { stateFile: path.join(dir, 'state.json'), journalFile: journal, logDir: dir },
      risk: { startEquity: 5000 },
    };
    const st = new Store(cfg, quietLog());
    const v = st.verifyChain();
    assert.strictEqual(v.ok, true, 'chain verifies after repair');
    assert.strictEqual(v.count, 1, 'only the valid prefix is kept');
    const archived = fs.readdirSync(dir).filter((f) => f.includes('-broken-'));
    assert.strictEqual(archived.length, 1, 'the dropped tail is archived next to the journal');
  });
});

// ================================================================ jev suite
// The jev tests live in their own file (they are async and use a mock provider).
// Run them as a child process and fold their totals into this run's summary, so
// `node tests/run.js` remains the single acceptance command.
//
// The same pattern is used for every async suite: one acceptance command, and
// a suite that fails to report is itself a failure (never a silent pass).
function runChildSuite(label, file, env = {}) {
  const { spawnSync } = require('node:child_process');
  const res = spawnSync(process.execPath, [path.join(__dirname, file)], {
    encoding: 'utf8',
    timeout: 180000,
    env: { ...process.env, ...env },
  });
  const out = `${res.stdout || ''}${res.stderr || ''}`;
  const m = out.match(new RegExp(`${label}:\\s*(\\d+)\\s*passed,\\s*(\\d+)\\s*failed`));
  if (!m) {
    failed++;
    failures.push({ name: `${label} suite did not report a result`, error: new Error(out.slice(-800) || 'no output') });
    console.log(`  \u2717 ${label} suite did not report a result`);
    return;
  }
  const p = Number(m[1]);
  const f = Number(m[2]);
  passed += p;
  failed += f;
  console.log(`  ${f ? '\u2717' : '\u2713'} ${label}: ${p} passed, ${f} failed`);
  if (f) {
    for (const line of out.split('\n')) {
      if (line.trim().startsWith('\u2022')) {
        failures.push({ name: `${label} ${line.trim().slice(1).trim()}`, error: new Error(`see ${file} output`) });
      }
    }
  }
}

group('jev \u2014 brain / mediator / manager', () => {
  runChildSuite('jev', 'jev.test.js');
});

group('trials \u2014 K registry / deflated Sharpe', () => {
  runChildSuite('trials', 'trials.test.js');
});

group('hyperliquid \u2014 second market adapter', () => {
  // Offline by default: the live block is opt-in via BB_HL_LIVE=1, so the
  // acceptance command never depends on the internet.
  runChildSuite('hyperliquid', 'hyperliquid.test.js');
});

group('backtest \u2014 offline CSV replay', () => {
  // Fully offline: the CSV fixtures are checked into tests/fixtures, recorded
  // once from the live API and read from disk from then on.
  runChildSuite('backtest', 'backtest.test.js');
});

group('server \u2014 bind, probe, dashboard', () => {
  // Boots the real entry point on an ephemeral port. No network: the exchange
  // is expected to be unreachable here, which is exactly the case that used to
  // leave a live process with no listener.
  runChildSuite('server', 'server.test.js');
});

group('sleeves \u2014 donchian / mean-reversion / carry + regressions', () => {
  // Fully offline and deterministic: synthetic walks, no network.
  runChildSuite('sleeves', 'sleeves.test.js');
});

group('public dashboard \u2014 data safety, routes, freshness, port, gesture', () => {
  runChildSuite('public', 'public.test.js');
});

group('branding - logo + favicon served end-to-end, navy/gold palette', () => {
  // Reproduces the v11 gap: the palette shipped but the logo artwork was never
  // wired into the page, so the header showed a CSS placeholder instead.
  runChildSuite('branding', 'branding.test.js');
});

group('watch (\u062f\u06cc\u062f\u0647\u200c\u0628\u0627\u0646) \u2014 discovery, ranking, stagnation, council gate', () => {
  // Fully offline: synthetic series and stub exchange/portfolio.
  runChildSuite('watch', 'watch.test.js');
  runChildSuite('watch-apply', 'watch-apply.test.js');
  runChildSuite('position-clock', 'position-clock.test.js');
  runChildSuite('backtest-stops', 'backtest-stops.test.js');
  runChildSuite('trailing-stop', 'trailing-stop.test.js');
  runChildSuite('trail-ladder', 'trail-ladder.test.js');
  runChildSuite('keyless-advisor', 'keyless-advisor.test.js');
  runChildSuite('keyless-chain', 'keyless-chain.test.js');
  runChildSuite('risk-resume', 'risk-resume.test.js');
});

group('config \u2014 panel-tunable variables, keyless model default', () => {
  runChildSuite('config', 'config.test.js');
});

group('charter fixes \u2014 fees, risk caps, WATCH_* env, witness refresh, zip hygiene', () => {
  // Each test reproduces a bug that shipped in v5.
  runChildSuite('charter-fixes', 'charter-fixes.test.js');
});

group('profiles \u2014 isolation, AngryBird limits, evidence, court, roles', () => {
  runChildSuite('profiles', 'profiles.test.js');
});

group('host \u2014 port resolution, public address, telegram', () => {
  // The Botkeep deployment: SERVER_PORT instead of PORT, a misleading address
  // line, and Telegram reports silently skipped because the chat-id variable
  // name did not match what the panel set.
  runChildSuite('host', 'host.test.js');
});

group('charter \u2014 gate fail-closed, resize caps, stale-quote exit', () => {
  runChildSuite('charter', 'charter.test.js');
});

group('worker \u2014 optional edge gateway, never in the decision path', () => {
  runChildSuite('worker', 'worker.test.js');
});

group('angrybird \u2014 $100 scenario, $25 ceiling, muddy-water activation', () => {
  runChildSuite('angry', 'angry.test.js');
});

group('heal \u2014 self-healing supervisor, model escalation, safety contract', () => {
  // Offline: the clock and the model endpoint are both injected.
  runChildSuite('heal', 'heal.test.js');
});

group('strategist \u2014 live strategist, crisis authority, lawyer review', () => {
  // The clock is injected, so the 60-second response window is tested in
  // microseconds. No network, no keys, no real orders.
  runChildSuite('strategist', 'strategist.test.js');
});

group('v10 \u2014 apprentice, market intel, historical analog, NVIDIA', () => {
  // Fully offline: the apprentice writes to a temp dir, the intel feeds are
  // injected, and the analog matcher is pure arithmetic.
  runChildSuite('v10', 'v10.test.js');
  // Boots the real Engine. This is the suite that catches a wiring bug the
  // unit tests cannot see (v10 shipped one: `dataDir is not defined`).
  runChildSuite('boot', 'boot.test.js');
});

group('v13 — intel feeds: RSS parsing, GDELT 429 fallback, honest status', () => {
  // Offline: fetch is injected. Covers the bug where a JSON-only reader plus a
  // rate-limited GDELT left the intel card empty while reporting enabled=true.
  runChildSuite('intel-rss', 'intel-rss.test.js');
});

group('v15 — hostile feeds: injected HTML, script schemes, size caps', () => {
  // Reproduces the v15 bug: `decodeEntities` stripped markup with /<[^>]+>/g,
  // which needs a CLOSING '>', so an unclosed `<img onerror=...>` walked
  // straight through into the report, the journal and the dashboard payload.
  runChildSuite('intel-sanitize', 'intel-sanitize.test.js');
});

group('v15 — intel wired into the offline backtest (blackout gate, no leverage)', () => {
  // The backtest is no-network by design, so the live intel module cannot run
  // inside it. This suite pins the two hooks that make the A/B possible, and
  // the rule that neither can ever raise exposure.
  runChildSuite('intel-backtest', 'intel-backtest.test.js');
});

group('v14 — crypto/wire feeds, report digest, FOMC blackout, ENV_MAP integrity', () => {
  // Offline: fetch and the clock are injected. Covers the bug where the intel
  // module gated entries and never appeared in a single report (Reporter had no
  // intel), the missing crypto/wire families, and the duplicate WATCH_* block
  // in ENV_MAP that silently killed every variable in the first copy.
  runChildSuite('v14', 'v14.test.js');
});

// ================================================================ summary
console.log(`\n${'─'.repeat(48)}`);
console.log(`  ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  • ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'─'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);