#!/usr/bin/env node
'use strict';
/**
 * Regression: a replayed position must carry the REPLAY clock, not the wall clock.
 *
 * Bug: `Position` stamped `openedAt` with `now()` (wall clock) while the
 * rotator closed it with its injected clock (the bar's own timestamp). In a
 * historical backtest the exit timestamp is months in the past, so
 * `durationMs` came out NEGATIVE (e.g. -2,661,580,501 ms) and every
 * "how long was this held" number in the journal was nonsense.
 *
 * These tests fail on the old code and pass once the rotator stamps the
 * position with its own clock.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Position } = require('../src/exec/portfolio');

(async () => {
  console.log('\n▸ position clock — openedAt is injectable');

  await t('Position accepts an explicit openedAt', () => {
    const pos = new Position({
      symbol: 'BTCUSDT', side: 'long', qty: 1, entry: 100, fee: 0.1, notional: 100,
      strategy: 'X', tp: 110, sl: 90, timeStopAt: 0, openedAt: 1700000000000,
    });
    assert.strictEqual(pos.openedAt, 1700000000000);
  });

  await t('Position falls back to the wall clock when openedAt is absent', () => {
    const before = Date.now();
    const pos = new Position({
      symbol: 'BTCUSDT', side: 'long', qty: 1, entry: 100, fee: 0.1, notional: 100,
      strategy: 'X', tp: 110, sl: 90, timeStopAt: 0,
    });
    assert.ok(pos.openedAt >= before, 'must still be a real timestamp');
  });

  await t('a replayed trade has a non-negative duration', () => {
    // Entry at bar T, exit at bar T+3h, both from the replay clock.
    const T = 1792627200000;
    const pos = new Position({
      symbol: 'SOLUSDT', side: 'short', qty: 1, entry: 100, fee: 0.1, notional: 100,
      strategy: 'ORBITAL', tp: null, sl: 110, timeStopAt: 0, openedAt: T,
    });
    const trade = {
      durationMs: T + 3 * 3600000 - pos.openedAt,
    };
    assert.ok(trade.durationMs > 0, `duration must be positive, got ${trade.durationMs}`);
    assert.strictEqual(trade.durationMs, 3 * 3600000);
  });

  done('position-clock');
})();
