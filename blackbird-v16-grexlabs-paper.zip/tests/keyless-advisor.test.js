#!/usr/bin/env node
'use strict';
/**
 * Regression: the live-advice model must be KEYLESS by default.
 *
 * THE BUG THIS LOCKS DOWN
 * -----------------------
 * `src/supervisor/heal.js` fell back to `gpt-4o-mini` when no model was named,
 * and `cfg.heal.model.baseUrl` defaulted to an empty string. So the "ask a model
 * for help when something happens outside the plan" path either did nothing
 * (no URL) or, once a URL was set, silently reached for a PAID OpenAI model —
 * which contradicts the project's free-only rule.
 *
 * The default is now Ollama (`qwen2.5:7b` on 127.0.0.1:11434), which needs no
 * key, no signup and no billing. Every part of it is still panel-tunable
 * (ADVISOR_URL / ADVISOR_MODEL / ADVISOR_ENABLED), so the operator can point it
 * at Cloudflare Workers AI, Groq, Gemini, Cerebras, Mistral or OpenRouter
 * without editing a file on the server.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { loadConfig } = require('../src/config');

const cleanEnv = () => {
  const saved = {};
  for (const k of ['ADVISOR_URL', 'ADVISOR_MODEL', 'ADVISOR_ENABLED', 'ADVISOR_API_KEY_ENV']) {
    saved[k] = process.env[k];
    delete process.env[k];
  }
  return () => {
    for (const [k, v] of Object.entries(saved)) {
      if (v === undefined) delete process.env[k]; else process.env[k] = v;
    }
  };
};

(async () => {
  console.log('\n▸ keyless advisor — the live-help model needs no key by default');

  await t('the default advisor model is keyless and reachable from a hosted container', () => {
    const restore = cleanEnv();
    try {
      const cfg = loadConfig({ server: { enabled: false } });
      const m = cfg.heal.model;
      // The old assertion demanded a LOCAL endpoint. That is exactly what a
      // hosted free tier (botkeep.cloud) cannot provide: 127.0.0.1 there is the
      // container itself, with nothing installed. The requirement is now
      // "keyless AND not local-only".
      assert.ok(!/127\.0\.0\.1|localhost/i.test(String(m.baseUrl)),
        `default baseUrl must not be a local-only endpoint, got "${m.baseUrl}"`);
      assert.ok(/^https:\/\//i.test(String(m.baseUrl)),
        `default baseUrl must be a remote https endpoint, got "${m.baseUrl}"`);
      assert.ok(!/gpt-4o|gpt-4|claude|gemini-pro/i.test(String(m.model)),
        `default model must not be a paid one, got "${m.model}"`);
    } finally { restore(); }
  });

  await t('the advisor is off by default (rules decide first)', () => {
    const restore = cleanEnv();
    try {
      const cfg = loadConfig({ server: { enabled: false } });
      assert.strictEqual(cfg.heal.model.enabled, false,
        'the model must not be consulted unless the operator turns it on');
    } finally { restore(); }
  });

  await t('ADVISOR_URL / ADVISOR_MODEL override the default from the panel', () => {
    const restore = cleanEnv();
    try {
      process.env.ADVISOR_URL = 'https://api.groq.com/openai/v1';
      process.env.ADVISOR_MODEL = 'llama-3.3-70b-versatile';
      process.env.ADVISOR_ENABLED = 'true';
      const cfg = loadConfig({ server: { enabled: false } });
      assert.strictEqual(cfg.heal.model.baseUrl, 'https://api.groq.com/openai/v1');
      assert.strictEqual(cfg.heal.model.model, 'llama-3.3-70b-versatile');
      assert.strictEqual(cfg.heal.model.enabled, true);
    } finally { restore(); }
  });

  await t('the jev brain is keyless by default too', () => {
    const restore = cleanEnv();
    try {
      const cfg = loadConfig({ server: { enabled: false } });
      const { isKeyless, isLocalOnly } = require('../src/jev/providers/catalog');
      assert.ok(isKeyless(cfg.jev.provider),
        `jev.provider must need no key by default, got "${cfg.jev.provider}"`);
      assert.ok(!isLocalOnly(cfg.jev.provider),
        `jev.provider must not be local-only by default, got "${cfg.jev.provider}"`);
    } finally { restore(); }
  });

  done('keyless-advisor');
})();
