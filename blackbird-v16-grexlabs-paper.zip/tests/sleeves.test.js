#!/usr/bin/env node
'use strict';
/**
 * Tests for the three added sleeves and the bugs fixed alongside them.
 * Zero dependencies, deterministic, offline.
 *   node tests/sleeves.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const SRC = path.join(__dirname, '..', 'src');
const donchian = require(path.join(SRC, 'strategy/sleeves/donchian'));
const meanrev = require(path.join(SRC, 'strategy/sleeves/meanrev'));
const carry = require(path.join(SRC, 'strategy/sleeves/carry'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

// ---------------------------------------------------------------- fixtures
/** Deterministic pseudo-random walk so the tests never flake. */
function walk({ n, start = 100, drift = 0, vol = 0.01, seed = 1 }) {
  let s = seed;
  const rnd = () => {
    s = (s * 1103515245 + 12345) % 2147483648;
    return s / 2147483648;
  };
  const bars = [];
  let px = start;
  for (let i = 0; i < n; i++) {
    px = px * (1 + drift + (rnd() - 0.5) * 2 * vol);
    const o = px * (1 - vol / 2);
    const h = px * (1 + vol);
    const l = px * (1 - vol);
    bars.push({ t: 1700000000000 + i * 3600000, o, h, l, c: px, v: 1000 });
  }
  return bars;
}

/** A clean uptrend with a final bar that breaks the channel. */
function breakoutBars() {
  const bars = walk({ n: 260, start: 100, drift: 0.002, vol: 0.004, seed: 7 });
  const last = bars[bars.length - 1];
  const hi = Math.max(...bars.slice(-56, -1).map((b) => b.h));
  last.c = hi * 1.02;
  last.h = last.c * 1.001;
  last.l = last.c * 0.995;
  return bars;
}

// ================================================================ donchian
console.log('\n\u25b8 sleeve: donchian breakout');

test('donchian: fires long on a channel breakout in an uptrend', () => {
  const sig = donchian.signals({ BTCUSDT: breakoutBars() }, { lookback: 55, requireEma: true });
  assert.strictEqual(sig.length, 1, 'expected exactly one signal');
  assert.strictEqual(sig[0].sym, 'BTCUSDT');
  assert.strictEqual(sig[0].dir, 1);
  assert.ok(sig[0].pct > 0, 'size must be positive');
  assert.ok(sig[0].stopAtr > 0, 'stop distance must be positive');
});

test('donchian: the channel excludes the current bar (no look-ahead)', () => {
  // A flat series whose last bar is the highest ever: if the channel included
  // the current bar, close could never exceed it and no signal would fire.
  const bars = walk({ n: 260, start: 100, drift: 0, vol: 0.002, seed: 3 });
  const last = bars[bars.length - 1];
  last.c = Math.max(...bars.map((b) => b.h)) * 1.05;
  last.h = last.c;
  const sig = donchian.signals({ X: bars }, { lookback: 55, requireEma: false });
  assert.strictEqual(sig.length, 1, 'a genuine breakout must be detected');
});

test('donchian: no signal when price is inside the channel', () => {
  const bars = walk({ n: 260, start: 100, drift: 0, vol: 0.01, seed: 11 });
  const sig = donchian.signals({ X: bars }, { lookback: 55, requireEma: false });
  assert.strictEqual(sig.length, 0);
});

test('donchian: the EMA filter blocks a long below the long average', () => {
  const bars = walk({ n: 260, start: 200, drift: -0.003, vol: 0.004, seed: 5 });
  const last = bars[bars.length - 1];
  const hi = Math.max(...bars.slice(-56, -1).map((b) => b.h));
  last.c = hi * 1.01; // breaks the channel but is still far below the 200-EMA
  const withFilter = donchian.signals({ X: bars }, { lookback: 55, requireEma: true });
  const without = donchian.signals({ X: bars }, { lookback: 55, requireEma: false });
  assert.strictEqual(withFilter.length, 0, 'filter must reject it');
  assert.strictEqual(without.length, 1, 'without the filter it is a valid breakout');
});

test('donchian: dead volatility is ignored', () => {
  const bars = walk({ n: 260, start: 100, drift: 0, vol: 0.00001, seed: 9 });
  const last = bars[bars.length - 1];
  last.c = Math.max(...bars.map((b) => b.h)) * 1.001;
  const sig = donchian.signals({ X: bars }, { lookback: 55, requireEma: false, minAtrPct: 0.15 });
  assert.strictEqual(sig.length, 0, 'a breakout in dead vol must not trade');
});

test('donchian: short fires on a breakdown', () => {
  const bars = walk({ n: 260, start: 200, drift: -0.002, vol: 0.004, seed: 13 });
  const last = bars[bars.length - 1];
  const lo = Math.min(...bars.slice(-56, -1).map((b) => b.l));
  last.c = lo * 0.98;
  last.l = last.c * 0.999;
  const sig = donchian.signals({ X: bars }, { lookback: 55, requireEma: true });
  assert.strictEqual(sig.length, 1);
  assert.strictEqual(sig[0].dir, -1);
});

test('donchian: too little history yields nothing (no crash)', () => {
  assert.deepStrictEqual(donchian.signals({ X: walk({ n: 10 }) }), []);
  assert.deepStrictEqual(donchian.signals({}), []);
});

// ================================================================ meanrev
console.log('\n\u25b8 sleeve: mean reversion');

test('meanrev: fires long on a stretched, non-trending selloff', () => {
  // A quiet range, then a sharp final drop: low z, low RSI, low ADX.
  // The drop is applied to the last few bars so the ATR/ADX windows see it too.
  const bars = walk({ n: 200, start: 100, drift: 0, vol: 0.01, seed: 21 });
  const last = bars[bars.length - 1];
  last.c = last.c * 0.97; // a 3% flush out of a quiet range
  last.l = last.c * 0.999;
  last.h = last.c * 1.001;
  const sig = meanrev.signals({ X: bars }, { zEntry: 1.5, rsiBuy: 40, adxMax: 40 });
  assert.strictEqual(sig.length, 1, 'expected one mean-reversion long');
  assert.strictEqual(sig[0].dir, 1);
  assert.ok(sig[0].target > sig[0].stop, 'long target must sit above the stop');
});

test('meanrev: the ADX gate blocks fading a strong trend', () => {
  const bars = walk({ n: 200, start: 100, drift: 0.006, vol: 0.003, seed: 23 });
  const last = bars[bars.length - 1];
  last.c = last.c * 0.97; // a dip inside a strong uptrend
  const gated = meanrev.signals({ X: bars }, { zEntry: 1.2, rsiBuy: 45, adxMax: 15 });
  assert.strictEqual(gated.length, 0, 'a trending market must not be faded');
});

test('meanrev: a runaway move beyond the hard stop is never faded', () => {
  const bars = walk({ n: 200, start: 100, drift: 0, vol: 0.004, seed: 27 });
  const last = bars[bars.length - 1];
  last.c = last.c * 0.5; // -50%: far beyond zHardStop
  const sig = meanrev.signals({ X: bars }, { zEntry: 1.5, rsiBuy: 40, adxMax: 60, zHardStop: 3.5 });
  assert.strictEqual(sig.length, 0, 'a crash is not a mean-reversion entry');
});

test('meanrev: size shrinks as the stretch grows', () => {
  const mk = (mult) => {
    const bars = walk({ n: 200, start: 100, drift: 0, vol: 0.004, seed: 31 });
    const last = bars[bars.length - 1];
    last.c = last.c * mult;
    return meanrev.signals({ X: bars }, { zEntry: 1.2, rsiBuy: 45, adxMax: 60, zHardStop: 6 })[0];
  };
  const mild = mk(0.97);
  const wild = mk(0.90);
  assert.ok(mild && wild, 'both must produce a signal');
  assert.ok(wild.pct < mild.pct, 'the wilder move must be sized smaller');
});

test('meanrev: adxLast is finite and bounded on a real series', () => {
  const adx = meanrev.adxLast(walk({ n: 200, drift: 0.003, seed: 41 }), 14);
  assert.ok(Number.isFinite(adx), 'adx must be a number');
  assert.ok(adx >= 0 && adx <= 100, `adx out of range: ${adx}`);
});

// ================================================================ carry
console.log('\n\u25b8 sleeve: funding carry');

test('carry: annualises an 8h funding rate correctly', () => {
  // 1 bps per 8h = 3 bps/day = 0.0003/day -> 10.95%/yr
  const pct = carry.annualisedCarryPct(1);
  assert.ok(Math.abs(pct - 10.95) < 0.01, `expected ~10.95, got ${pct}`);
});

test('carry: picks the highest net carry and hedges the right way', () => {
  const sig = carry.signals(
    {
      BTCUSDT: { fundingBps: 3 },
      ETHUSDT: { fundingBps: 1 },
      SOLUSDT: { fundingBps: 0.2 },
    },
    { minCarryPct: 5, maxPicks: 2 }
  );
  assert.strictEqual(sig.length, 2, 'only the two paying enough should survive');
  assert.strictEqual(sig[0].sym, 'BTCUSDT', 'highest carry first');
  assert.strictEqual(sig[0].dir, -1, 'positive funding => short the perp');
  assert.strictEqual(sig[0].hedge, 'spot_long', 'and hedge with spot long');
});

test('carry: a thin rate is rejected after costs, not traded', () => {
  const sig = carry.signals({ X: { fundingBps: 0.1 } }, { minCarryPct: 8 });
  assert.strictEqual(sig.length, 0, 'a fee-eaten carry must not be taken');
});

test('carry: negative funding flips both legs', () => {
  const sig = carry.signals({ X: { fundingBps: -3 } }, { minCarryPct: 5 });
  assert.strictEqual(sig.length, 1);
  assert.strictEqual(sig[0].dir, 1, 'negative funding => long the perp');
  assert.strictEqual(sig[0].hedge, 'spot_short');
});

test('carry: hedgeQty makes the pair delta-neutral', () => {
  const perpQty = 0.5;
  const perpPrice = 60000;
  const spotPrice = 60000;
  const spotQty = carry.hedgeQty({ perpQty, perpPrice, spotPrice });
  const delta = carry.netDelta({ perpQty, perpPrice, spotQty, spotPrice, perpDir: -1 });
  assert.ok(Math.abs(delta) < 1e-6, `net delta must be ~0, got ${delta}`);
});

test('carry: missing or malformed funding data is ignored', () => {
  assert.deepStrictEqual(carry.signals({}), []);
  assert.deepStrictEqual(carry.signals({ X: {} }), []);
  assert.deepStrictEqual(carry.signals({ X: { fundingBps: 'nope' } }), []);
});

// ================================================================ regressions
console.log('\n\u25b8 regressions: the bugs fixed in this pass');

test('config: an inline comment in .env no longer breaks the value', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-sleeve-'));
  const envFile = path.join(dir, '.env');
  fs.writeFileSync(envFile, 'MAX_DAILY_LOSS_PCT=0.08        # stop at 8%\nSTART_EQUITY=5000\n');
  const savedEnv = process.env.BB_ENV_FILE;
  const savedCfg = process.env.BB_CONFIG;
  const savedLoss = process.env.MAX_DAILY_LOSS_PCT;
  delete process.env.MAX_DAILY_LOSS_PCT;
  process.env.BB_ENV_FILE = envFile;
  process.env.BB_CONFIG = path.join(dir, 'none.json');
  try {
    delete require.cache[require.resolve(path.join(SRC, 'config'))];
    const { loadConfig } = require(path.join(SRC, 'config'));
    const cfg = loadConfig();
    assert.strictEqual(cfg.risk.maxDailyLossPct, 0.08, 'the documented value must survive');
  } finally {
    if (savedEnv === undefined) delete process.env.BB_ENV_FILE; else process.env.BB_ENV_FILE = savedEnv;
    if (savedCfg === undefined) delete process.env.BB_CONFIG; else process.env.BB_CONFIG = savedCfg;
    if (savedLoss !== undefined) process.env.MAX_DAILY_LOSS_PCT = savedLoss;
    delete require.cache[require.resolve(path.join(SRC, 'config'))];
  }
});

test('risk: the peak equity survives a restart (kill switch still armed)', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-peak-'));
  const savedDir = process.env.DATA_DIR;
  process.env.DATA_DIR = dir;
  const quiet = { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
  try {
    delete require.cache[require.resolve(path.join(SRC, 'config'))];
    delete require.cache[require.resolve(path.join(SRC, 'core/store'))];
    delete require.cache[require.resolve(path.join(SRC, 'risk/risk'))];
    const { loadConfig } = require(path.join(SRC, 'config'));
    const { Store } = require(path.join(SRC, 'core/store'));
    const { RiskManager } = require(path.join(SRC, 'risk/risk'));
    const cfg = loadConfig();
    const store = new Store(cfg, quiet);
    store.loadState();
    const r1 = new RiskManager({ cfg, store, log: quiet });
    // Drive it through the real path: settle() is what raises the peak, so a
    // test that pokes r1.peakEquity directly would not exercise the fix.
    r1.settle({ pnl: 1000, fee: 0, notional: 0, win: true, symbol: 'X', tradeId: 't1' });
    r1.settle({ pnl: -600, fee: 0, notional: 0, win: false, symbol: 'X', tradeId: 't2' });
    assert.strictEqual(store.state.equity, 5400, 'equity must be 5400 after the two settles');
    assert.strictEqual(store.state.peakEquity, 6000, 'the peak must have been persisted');
    store.saveState();

    const store2 = new Store(cfg, quiet);
    store2.loadState();
    const r2 = new RiskManager({ cfg, store: store2, log: quiet });
    assert.strictEqual(r2.peakEquity, 6000, 'the peak must be restored, not reset to equity');
    assert.ok(Math.abs(r2.drawdownPct() - 10) < 0.01, `drawdown must read 10%, got ${r2.drawdownPct()}`);
  } finally {
    if (savedDir === undefined) delete process.env.DATA_DIR; else process.env.DATA_DIR = savedDir;
    for (const m of ['config', 'core/store', 'risk/risk']) {
      try { delete require.cache[require.resolve(path.join(SRC, m))]; } catch { /* ignore */ }
    }
  }
});

test('risk: a restart mid-day does not fake a daily loss', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-day-'));
  const savedDir = process.env.DATA_DIR;
  process.env.DATA_DIR = dir;
  const quiet = { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };
  try {
    delete require.cache[require.resolve(path.join(SRC, 'config'))];
    delete require.cache[require.resolve(path.join(SRC, 'core/store'))];
    delete require.cache[require.resolve(path.join(SRC, 'risk/risk'))];
    const { loadConfig } = require(path.join(SRC, 'config'));
    const { Store } = require(path.join(SRC, 'core/store'));
    const { RiskManager } = require(path.join(SRC, 'risk/risk'));
    const cfg = loadConfig();
    const store = new Store(cfg, quiet);
    store.loadState();
    // a bot that is down 20% from inception, restarting inside the same day
    store.state.equity = 4000;
    store.state.dayStartEquity = undefined;
    store.state.counters.day = new Date().toISOString().slice(0, 10);
    store.saveState();

    const store2 = new Store(cfg, quiet);
    store2.loadState();
    const r = new RiskManager({ cfg, store: store2, log: quiet });
    r.rollDay();
    assert.ok(Math.abs(r.dailyPnlPct()) < 0.01, `daily P&L must be ~0, got ${r.dailyPnlPct()}`);
    assert.strictEqual(r.halted, false, 'a healthy bot must not halt itself on boot');
  } finally {
    if (savedDir === undefined) delete process.env.DATA_DIR; else process.env.DATA_DIR = savedDir;
    for (const m of ['config', 'core/store', 'risk/risk']) {
      try { delete require.cache[require.resolve(path.join(SRC, m))]; } catch { /* ignore */ }
    }
  }
});

test('exchanges: every adapter exposes the funding surface', () => {
  const { createExchange } = require(path.join(SRC, 'data/exchanges'));
  for (const name of ['binance', 'bybit', 'mexc', 'bitget']) {
    const ex = createExchange(name);
    assert.ok('funding' in ex, `${name} must expose funding`);
  }
});

// ================================================================ summary
console.log(`\n${'\u2500'.repeat(48)}`);
console.log(`  sleeves: ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  \u2022 ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'\u2500'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);
