#!/usr/bin/env node
'use strict';
/**
 * BlackBird — consensus test suite.
 *
 * Zero dependencies, no network. Every model is a MockProvider, so these tests
 * assert the contract the panel promises:
 *
 *   - a unanimous panel is honoured
 *   - one dead model does not kill the cycle
 *   - a partial timeout still produces a verdict from the survivors
 *   - if everyone fails, the answer is null (fall back to rules), not a guess
 *   - quorum is enforced
 *   - the result is never looser than the strictest valid vote
 *   - wide disagreement tightens risk and lowers confidence
 *   - a majority veto blocks
 *
 * Run: node tests/consensus.test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const { Consensus, median, stdev } = require(path.join(SRC, 'jev/consensus'));
const { MockProvider } = require(path.join(SRC, 'jev/providers'));

let passed = 0;
let failed = 0;
const failures = [];
const queue = [];

/**
 * Register a test. Tests are collected and run sequentially at the end, so an
 * async test is awaited before the next one starts — otherwise a shared mock
 * script queue gets consumed out of order and the results are nonsense.
 */
function test(name, fn) {
  queue.push({ name, fn });
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  fn();
}

async function runAll() {
  for (const t of queue) {
    try {
      await t.fn();
      passed++;
    } catch (e) {
      failed++;
      failures.push({ name: t.name, error: e });
      console.log(`  \u2717 ${t.name}\n      ${e.message.split('\n')[0]}`);
    }
  }
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/** A decision JSON string with overridable fields. */
function vote(over = {}) {
  return JSON.stringify({
    regime: 'muddy',
    confidence: 0.7,
    bias: 'neutral',
    riskMultiplier: 0.6,
    reasoning: 'ATR percentile 0.62, spread 1.2bps: workable but not generous.',
    veto: false,
    ...over,
  });
}

/**
 * Build a Consensus with N scripted providers.
 * @param {Array<Array>} scripts  one script array per model
 */
function makePanel(scripts, cfg = {}) {
  const providers = scripts.map((script, i) => ({
    provider: new MockProvider({ script }),
    model: `mock-${i}`,
    weight: 1,
  }));
  const c = new Consensus({
    cfg: {
      enabled: true,
      quorum: 2,
      timeoutMs: 60,
      disagreementThreshold: 0.35,
      maxRiskMultiplier: 1,
      allowVeto: true,
      ...cfg,
    },
    log: quietLog(),
    providers,
  });
  return c;
}

const CTX = {
  asOf: '2026-11-07T00:00:00Z',
  mode: 'paper',
  equity: 5000,
  drawdownPct: 0,
  openPositions: 2,
  positions: [],
  market: [
    { symbol: 'BTC', price: 96000, regime: 'muddy', atrPct: 1.8, volPercentile: 0.62, rsi: 54, spreadBps: 1.2, depthUsd: 4200000 },
  ],
};

// ============================================================ pure helpers
group('consensus — helpers', () => {
  test('median of an odd and an even set', () => {
    assert.strictEqual(median([0.2, 0.5, 0.9]), 0.5);
    assert.strictEqual(median([0.2, 0.4, 0.6, 0.8]), 0.5);
    assert.strictEqual(median([]), null);
  });
  test('stdev is zero for identical votes and positive for a split', () => {
    assert.strictEqual(stdev([0.5, 0.5, 0.5]), 0);
    assert.ok(stdev([0, 1]) > 0.4);
  });
});

// ================================================================ happy path
group('consensus — unanimous panel', () => {
  test('three agreeing models produce one verdict', async () => {
    const c = makePanel([[{ reply: vote() }], [{ reply: vote() }], [{ reply: vote() }]]);
    const r = await c.decide(CTX);
    assert.ok(r, 'expected a verdict');
    assert.strictEqual(r.regime, 'muddy');
    assert.strictEqual(r.riskMultiplier, 0.6);
    assert.strictEqual(r.veto, false);
    assert.strictEqual(r.consensus.votes, 3);
    assert.strictEqual(r.consensus.failed, 0);
    assert.strictEqual(r.consensus.uncertain, false);
    assert.strictEqual(r.source, 'consensus');
  });

  test('the verdict is decision-shaped so Jev can consume it directly', async () => {
    const c = makePanel([[{ reply: vote() }], [{ reply: vote() }]]);
    const r = await c.decide(CTX);
    for (const k of ['regime', 'confidence', 'bias', 'riskMultiplier', 'reasoning', 'veto', 'degraded']) {
      assert.ok(k in r, `missing ${k}`);
    }
    assert.strictEqual(r.degraded, false);
  });
});

// ============================================================ partial failure
group('consensus — partial failure', () => {
  test('one model erroring does not kill the cycle', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ error: 'HTTP 429 from api.groq.com: rate limited' }],
      [{ reply: vote({ riskMultiplier: 0.4 }) }],
    ]);
    const r = await c.decide(CTX);
    assert.ok(r, 'survivors should still produce a verdict');
    assert.strictEqual(r.consensus.votes, 2);
    assert.strictEqual(r.consensus.failed, 1);
    assert.match(r.consensus.failures[0].error, /429/);
  });

  test('a timeout is recorded as a failure, not a hang', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ timeout: true }],
      [{ reply: vote() }],
    ], { timeoutMs: 40 });
    const started = Date.now();
    const r = await c.decide(CTX);
    const elapsed = Date.now() - started;
    assert.ok(r, 'expected a verdict from the two survivors');
    assert.strictEqual(r.consensus.votes, 2);
    assert.strictEqual(r.consensus.failed, 1);
    assert.ok(elapsed < 3000, `should not hang (took ${elapsed}ms)`);
    assert.ok(c.stats.modelTimeouts >= 1, 'timeout should be counted');
  });

  test('a model returning garbage JSON is a failure, not a vote', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ reply: 'I think the market looks fine, buy everything.' }],
      [{ reply: vote() }],
    ]);
    const r = await c.decide(CTX);
    assert.ok(r);
    assert.strictEqual(r.consensus.votes, 2);
    assert.strictEqual(r.consensus.failed, 1);
  });

  test('a model returning out-of-range values is rejected by the schema', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ reply: vote({ riskMultiplier: 5 }) }],
      [{ reply: vote() }],
    ]);
    const r = await c.decide(CTX);
    assert.ok(r);
    assert.strictEqual(r.consensus.votes, 2, 'the 5x vote must not count');
  });
});

// ============================================================== total failure
group('consensus — total failure', () => {
  test('every model failing returns null so the caller falls back to rules', async () => {
    const c = makePanel([
      [{ error: 'boom' }],
      [{ error: 'boom' }],
      [{ error: 'boom' }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r, null);
    assert.strictEqual(c.stats.failed, 1);
    assert.match(c.lastError, /quorum not met/);
  });

  test('all timeouts return null without throwing', async () => {
    const c = makePanel([[{ timeout: true }], [{ timeout: true }]], { timeoutMs: 30 });
    const r = await c.decide(CTX);
    assert.strictEqual(r, null);
  });

  test('an empty panel is not ready and returns null', async () => {
    const c = new Consensus({ cfg: { enabled: true, models: [] }, log: quietLog(), providers: [] });
    assert.strictEqual(c.ready, false);
    assert.strictEqual(await c.decide(CTX), null);
  });

  test('a disabled panel returns null immediately', async () => {
    const c = makePanel([[{ reply: vote() }]], { enabled: false });
    assert.strictEqual(await c.decide(CTX), null);
  });
});

// ==================================================================== quorum
group('consensus — quorum', () => {
  test('one valid vote against a quorum of two is refused', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ error: 'down' }],
      [{ error: 'down' }],
    ], { quorum: 2 });
    const r = await c.decide(CTX);
    assert.strictEqual(r, null);
    assert.strictEqual(c.stats.quorumMissed, 1);
  });

  test('a quorum of one accepts a single survivor', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ error: 'down' }],
    ], { quorum: 1 });
    const r = await c.decide(CTX);
    assert.ok(r);
    assert.strictEqual(r.consensus.votes, 1);
  });
});

// ============================================================ strictness rule
group('consensus — never looser than the strictest vote', () => {
  test('riskMultiplier is the minimum, not the mean', async () => {
    const c = makePanel([
      [{ reply: vote({ riskMultiplier: 1.0 }) }],
      [{ reply: vote({ riskMultiplier: 0.2 }) }],
      [{ reply: vote({ riskMultiplier: 0.9 }) }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r.riskMultiplier, 0.2, 'the cautious model must win');
    assert.strictEqual(r.consensus.medianRiskMultiplier, 0.9, 'median is reported but not used');
    assert.strictEqual(r.consensus.strictestRiskMultiplier, 0.2);
  });

  test('a single veto in a majority of two blocks', async () => {
    const c = makePanel([
      [{ reply: vote({ veto: true, riskMultiplier: 0 }) }],
      [{ reply: vote({ veto: true, riskMultiplier: 0 }) }],
      [{ reply: vote({ veto: false, riskMultiplier: 1 }) }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r.veto, true);
    assert.strictEqual(r.riskMultiplier, 0);
  });

  test('a lone veto in a panel of three does not block', async () => {
    const c = makePanel([
      [{ reply: vote({ veto: true, riskMultiplier: 0 }) }],
      [{ reply: vote({ veto: false, riskMultiplier: 0.8 }) }],
      [{ reply: vote({ veto: false, riskMultiplier: 0.8 }) }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r.veto, false, 'minority veto must not block');
    // ...but the strictest risk still applies, so the vetoing model's 0 counts.
    assert.strictEqual(r.riskMultiplier, 0);
  });

  test('the ceiling caps every vote', async () => {
    const c = makePanel([
      [{ reply: vote({ riskMultiplier: 1 }) }],
      [{ reply: vote({ riskMultiplier: 1 }) }],
    ], { maxRiskMultiplier: 0.5 });
    const r = await c.decide(CTX);
    assert.ok(r.riskMultiplier <= 0.5, `got ${r.riskMultiplier}`);
  });
});

// ============================================================== disagreement
group('consensus — disagreement', () => {
  test('a split panel is flagged and risk is tightened', async () => {
    const c = makePanel([
      [{ reply: vote({ riskMultiplier: 1.0, regime: 'trend' }) }],
      [{ reply: vote({ riskMultiplier: 0.0, regime: 'toxic' }) }],
      [{ reply: vote({ riskMultiplier: 0.5, regime: 'muddy' }) }],
    ], { disagreementThreshold: 0.2 });
    const r = await c.decide(CTX);
    assert.strictEqual(r.consensus.uncertain, true);
    assert.ok(r.consensus.dispersion > 0.2);
    assert.ok(r.riskMultiplier <= 0.5, 'a split panel must tighten');
    assert.ok(r.confidence < 0.7, 'confidence should be halved');
    assert.ok(c.stats.disagreements >= 1);
  });

  test('dissent is recorded per model', async () => {
    const c = makePanel([
      [{ reply: vote({ regime: 'trend' }) }],
      [{ reply: vote({ regime: 'trend' }) }],
      [{ reply: vote({ regime: 'toxic' }) }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r.regime, 'trend', 'majority regime wins');
    assert.strictEqual(r.consensus.dissent.length, 1);
    assert.strictEqual(r.consensus.dissent[0].regime, 'toxic');
  });

  test('agreement is reported as a fraction', async () => {
    const c = makePanel([
      [{ reply: vote({ regime: 'calm' }) }],
      [{ reply: vote({ regime: 'calm' }) }],
      [{ reply: vote({ regime: 'trend' }) }],
    ]);
    const r = await c.decide(CTX);
    assert.strictEqual(r.consensus.agreement, '2/3');
  });
});

// ==================================================================== stats
group('consensus — stats and snapshot', () => {
  test('per-model stats track calls, failures and latency', async () => {
    const c = makePanel([
      [{ reply: vote() }],
      [{ error: 'nope' }],
    ]);
    await c.decide(CTX);
    const snap = c.snapshot();
    assert.strictEqual(snap.models.length, 2);
    const ok = snap.models.find((m) => m.ok === 1);
    const bad = snap.models.find((m) => m.failed === 1);
    assert.ok(ok, 'one model should have succeeded');
    assert.ok(bad, 'one model should have failed');
    assert.ok(Number.isFinite(ok.lastLatencyMs));
    assert.strictEqual(bad.errorRate, 1);
  });

  test('snapshot exposes the last verdict for the dashboard', async () => {
    const c = makePanel([[{ reply: vote() }], [{ reply: vote() }]]);
    await c.decide(CTX);
    const snap = c.snapshot();
    assert.strictEqual(snap.last.regime, 'muddy');
    assert.strictEqual(snap.last.votes, 2);
    assert.strictEqual(snap.enabled, true);
  });

  test('concurrent callers share one panel run', async () => {
    const c = makePanel([
      [{ delayMs: 30, reply: vote() }],
      [{ delayMs: 30, reply: vote() }],
    ]);
    const [a, b] = await Promise.all([c.decide(CTX), c.decide(CTX)]);
    assert.strictEqual(a, b, 'coalesced callers get the same object');
    assert.strictEqual(c.stats.runs, 1);
  });
});

// ==================================================================== summary
runAll().then(() => {
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  consensus: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
});
