#!/usr/bin/env node
'use strict';
/**
 * BlackBird — Hyperliquid adapter tests.
 *
 * Zero dependencies. The network tests are OPT-IN: they run only when
 * BB_HL_LIVE=1, because a test suite that needs the internet is a test suite
 * that fails on a plane. Everything else is deterministic.
 *
 * What is asserted:
 *   - symbol translation both ways (BTCUSDT <-> BTC)
 *   - price rounding: 5 significant figures AND (6 - szDecimals) decimals
 *   - size rounding floors to szDecimals (never over-sizes)
 *   - error mapping produces the same shape as the Binance adapter
 *   - the broker refuses to run live without the interlock
 *   - paper fills walk the real book and pay taker
 *   - a stale book rejects a market order
 *   - limit orders rest, fill on a crossing tick, and expire
 *   - quantisation is applied before an order is built
 *   - the signing primitives match published vectors
 *   - (opt-in) live public data: ticker, depth, klines, batch quotes
 *
 * Run: node tests/hyperliquid.test.js
 *      BB_HL_LIVE=1 node tests/hyperliquid.test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const hl = require(path.join(SRC, 'data/hyperliquid'));
const { HyperliquidBroker } = require(path.join(SRC, 'exec/hyperliquid-broker'));
const sign = require(path.join(SRC, 'exec/hl-sign'));
const { createExchange, walkBook } = require(path.join(SRC, 'data/exchanges'));
const { loadConfig } = require(path.join(SRC, 'config'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  return fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const CFG = loadConfig({ server: { enabled: false } });

// ============================================================ symbol mapping
group('hyperliquid / symbol mapping', () => {
  test('strips the quote suffix', () => {
    assert.strictEqual(hl.toCoin('BTCUSDT'), 'BTC');
    assert.strictEqual(hl.toCoin('ETHUSDC'), 'ETH');
    assert.strictEqual(hl.toCoin('SOLUSD'), 'SOL');
  });
  test('leaves a bare coin alone', () => {
    assert.strictEqual(hl.toCoin('BTC'), 'BTC');
  });
  test('leaves a spot pair alone', () => {
    assert.strictEqual(hl.toCoin('PURR/USDC'), 'PURR/USDC');
  });
  test('is case-insensitive', () => {
    assert.strictEqual(hl.toCoin('btcusdt'), 'BTC');
  });
  test('round-trips back to the project form', () => {
    assert.strictEqual(hl.toSymbol('BTC'), 'BTCUSDT');
    assert.strictEqual(hl.toSymbol(hl.toCoin('ETHUSDT')), 'ETHUSDT');
  });
  test('does not strip a coin that merely ends in a quote-like string', () => {
    // "USDT" alone must not become "" — the length guard matters.
    assert.strictEqual(hl.toCoin('USDT'), 'USDT');
  });
});

// ============================================================ price rounding
group('hyperliquid / price rounding', () => {
  test('integer prices are always allowed', () => {
    assert.strictEqual(hl.roundPrice(70000, 5), 70000);
    assert.strictEqual(hl.roundPrice(123456, 0), 123456);
  });
  test('caps at 5 significant figures', () => {
    // 12345.6789 to 5 significant figures is 12346 — the sig-fig cap bites
    // before the decimal cap here, which is the point of the rule.
    assert.strictEqual(hl.roundPrice(12345.6789, 0), 12346);
    // 1.23456789 to 5 sig figs is 1.2346
    assert.strictEqual(hl.roundPrice(1.23456789, 0), 1.2346);
  });
  test('caps decimals at 6 - szDecimals', () => {
    // szDecimals=5 -> at most 1 decimal
    const p = hl.roundPrice(0.123456789, 5);
    assert.ok(p === 0.1, `got ${p}`);
  });
  test('szDecimals=0 allows 6 decimals', () => {
    const p = hl.roundPrice(0.123456789, 0);
    assert.ok(Math.abs(p - 0.12346) < 1e-9, `got ${p}`);
  });
  test('rejects a non-positive price', () => {
    assert.ok(Number.isNaN(hl.roundPrice(0, 2)));
    assert.ok(Number.isNaN(hl.roundPrice(-5, 2)));
  });
  test('rejects a price that rounds to zero', () => {
    assert.ok(Number.isNaN(hl.roundPrice(1e-12, 6)));
  });
});

// ============================================================= size rounding
group('hyperliquid / size rounding', () => {
  test('floors to szDecimals', () => {
    assert.strictEqual(hl.roundSize(1.23456, 2), 1.23);
    assert.strictEqual(hl.roundSize(1.23999, 2), 1.23);
  });
  test('never rounds up — an over-size order is rejected by the venue', () => {
    assert.ok(hl.roundSize(0.999, 2) <= 0.999);
  });
  test('rejects a size that floors to zero', () => {
    assert.ok(Number.isNaN(hl.roundSize(0.001, 2)));
  });
  test('lot size matches szDecimals', () => {
    assert.ok(Math.abs(hl.lotSize(2) - 0.01) < 1e-12);
    assert.strictEqual(hl.lotSize(0), 1);
    assert.ok(Math.abs(hl.lotSize(5) - 0.00001) < 1e-15);
  });
});

// ============================================================== error mapping
group('hyperliquid / error mapping', () => {
  test('429 maps to rate_limited', () => {
    const e = hl.mapError(429, 'u', 'slow down');
    assert.strictEqual(e.code, 'rate_limited');
    assert.ok(e.message.includes('429'));
  });
  test('401/403 map to auth', () => {
    assert.strictEqual(hl.mapError(401, 'u', '').code, 'auth');
    assert.strictEqual(hl.mapError(403, 'u', '').code, 'auth');
  });
  test('5xx maps to venue', () => {
    assert.strictEqual(hl.mapError(503, 'u', '').code, 'venue');
  });
  test('the message shape matches the Binance adapter', () => {
    const e = hl.mapError(400, 'https://x', 'bad');
    assert.match(e.message, /^HTTP 400 https:\/\/x :: bad$/);
  });
  test('an error body is detected even on HTTP 200', () => {
    assert.strictEqual(hl.isErrorBody({ status: 'err', response: 'x' }), true);
    assert.strictEqual(hl.isErrorBody({ error: 'nope' }), true);
    assert.strictEqual(hl.isErrorBody({ status: 'ok' }), false);
    assert.strictEqual(hl.isErrorBody(null), false);
  });
});

// ============================================================ signing vectors
group('hyperliquid / signing primitives', () => {
  test('keccak256 of the empty string', () => {
    assert.strictEqual(
      sign.keccak256(Buffer.from('')).toString('hex'),
      'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
    );
  });
  test('keccak256 of "abc"', () => {
    assert.strictEqual(
      sign.keccak256(Buffer.from('abc')).toString('hex'),
      '4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45'
    );
  });
  test('keccak256 is NOT sha3-256 (different padding)', () => {
    const crypto = require('node:crypto');
    const sha3 = crypto.createHash('sha3-256').update('abc').digest('hex');
    assert.notStrictEqual(sign.keccak256(Buffer.from('abc')).toString('hex'), sha3);
  });
  test('address derivation from a known private key', () => {
    // Well-known test vector.
    const addr = sign.addressFromPrivate('4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318');
    assert.strictEqual(addr, '0x2c7536e3605d9c16a7a3d7b1898e529396a65c23');
  });
  test('msgpack encodes the documented primitives', () => {
    assert.strictEqual(sign.msgpack(0).toString('hex'), '00');
    assert.strictEqual(sign.msgpack(127).toString('hex'), '7f');
    assert.strictEqual(sign.msgpack(128).toString('hex'), 'cc80');
    assert.strictEqual(sign.msgpack(true).toString('hex'), 'c3');
    assert.strictEqual(sign.msgpack(null).toString('hex'), 'c0');
    assert.strictEqual(sign.msgpack('a').toString('hex'), 'a161');
  });
  test('msgpack preserves key order (Hyperliquid requires it)', () => {
    const a = sign.msgpack({ b: 1, a: 2 }).toString('hex');
    const b = sign.msgpack({ a: 2, b: 1 }).toString('hex');
    assert.notStrictEqual(a, b, 'key order must be preserved, not sorted');
  });
  test('the domain separator is deterministic', () => {
    assert.strictEqual(sign.domainSeparator().toString('hex'), sign.domainSeparator().toString('hex'));
    assert.strictEqual(sign.domainSeparator().length, 32);
  });
  test('signing produces a 65-byte-shaped signature with v in {27,28}', () => {
    const sig = sign.signL1Action({ type: 'noop' }, 1700000000000, '4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318');
    assert.match(sig.r, /^0x[0-9a-f]{64}$/);
    assert.match(sig.s, /^0x[0-9a-f]{64}$/);
    assert.ok(sig.v === 27 || sig.v === 28, `v=${sig.v}`);
  });
  test('a different nonce produces a different signature', () => {
    const k = '4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318';
    const a = sign.signL1Action({ type: 'noop' }, 1, k);
    const b = sign.signL1Action({ type: 'noop' }, 2, k);
    assert.notStrictEqual(a.r, b.r);
  });
});

// ============================================================ broker gating
group('hyperliquid / broker gating', () => {
  test('paper mode is ready with no key at all', () => {
    const b = new HyperliquidBroker({ cfg: { ...CFG, hyperliquid: { mode: 'paper' } }, log: quietLog() });
    assert.strictEqual(b.ready, true);
    assert.strictEqual(b.isPaper, true);
  });

  test('live mode refuses without the money interlock', () => {
    const saved = { ...process.env };
    delete process.env.HL_API_WALLET_KEY;
    delete process.env.HL_ACCOUNT_ADDRESS;
    delete process.env.BB_I_UNDERSTAND_REAL_MONEY;
    try {
      const b = new HyperliquidBroker({ cfg: { ...CFG, hyperliquid: { mode: 'live', maxNotionalUsd: 100 } }, log: quietLog() });
      assert.strictEqual(b.ready, false);
      assert.ok(b.blockers.some((x) => x.includes('HL_API_WALLET_KEY')));
      assert.ok(b.blockers.some((x) => x.includes('BB_I_UNDERSTAND_REAL_MONEY')));
    } finally {
      Object.assign(process.env, saved);
    }
  });

  test('live mode refuses without a notional cap', () => {
    const saved = { ...process.env };
    process.env.HL_API_WALLET_KEY = '4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318';
    process.env.HL_ACCOUNT_ADDRESS = '0x2c7536e3605d9c16a7a3d7b1898e529396a65c23';
    process.env.BB_I_UNDERSTAND_REAL_MONEY = 'YES';
    try {
      const b = new HyperliquidBroker({ cfg: { ...CFG, hyperliquid: { mode: 'live', maxNotionalUsd: 0 } }, log: quietLog() });
      assert.strictEqual(b.ready, false);
      assert.ok(b.blockers.some((x) => x.includes('maxNotionalUsd')));
    } finally {
      Object.assign(process.env, saved);
    }
  });

  test('an invalid key is reported, not thrown', () => {
    const saved = { ...process.env };
    process.env.HL_API_WALLET_KEY = 'not-a-key';
    process.env.HL_ACCOUNT_ADDRESS = '0x2c7536e3605d9c16a7a3d7b1898e529396a65c23';
    try {
      const b = new HyperliquidBroker({ cfg: { ...CFG, hyperliquid: { mode: 'dry-run' } }, log: quietLog() });
      assert.strictEqual(b.ready, false);
      assert.ok(b.blockers.some((x) => x.includes('valid secp256k1')));
    } finally {
      Object.assign(process.env, saved);
    }
  });
});

// ============================================================ paper broker
group('hyperliquid / paper broker', () => {
  const mkBroker = (opts = {}) => {
    const feed = {
      isStale: false,
      depth: { bids: [[99.9, 100]], asks: [[100.1, 100]] },
    };
    const book = { bid: 99.9, ask: 100.1 };
    const b = new HyperliquidBroker({
      cfg: { ...CFG, hyperliquid: { mode: 'paper' } },
      log: quietLog(),
      getBook: () => book,
      getFeed: () => feed,
      publicApi: {
        asset: async () => ({ name: 'BTC', szDecimals: 3, index: 0 }),
        http: {},
      },
    });
    return { b, feed, book };
  };

  test('a market buy walks the ask and pays taker', async () => {
    const { b } = mkBroker();
    const f = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 10 });
    assert.strictEqual(f.status, 'filled');
    assert.ok(f.price >= 100.1, `price=${f.price}`);
    assert.strictEqual(f.feeKind, 'taker');
    assert.strictEqual(f.venue, 'hyperliquid');
  });

  test('a market order on a stale book is rejected', async () => {
    const { b, feed } = mkBroker();
    feed.isStale = true;
    const r = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 1 });
    assert.strictEqual(r.status, 'rejected');
    assert.strictEqual(r.reason, 'stale_book');
  });

  test('an unknown asset is rejected, not thrown', async () => {
    const b = new HyperliquidBroker({
      cfg: { ...CFG, hyperliquid: { mode: 'paper' } },
      log: quietLog(),
      getBook: () => ({ bid: 1, ask: 2 }),
      getFeed: () => ({ isStale: false, depth: { bids: [], asks: [] } }),
      publicApi: { asset: async () => null, http: {} },
    });
    const r = await b.submit({ symbol: 'NOPEUSDT', side: 'buy', type: 'market', qty: 1 });
    assert.strictEqual(r.status, 'rejected');
    assert.strictEqual(r.reason, 'unknown_asset');
  });

  test('a size below the lot is rejected', async () => {
    const { b } = mkBroker();
    const r = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 0.0001 });
    assert.strictEqual(r.status, 'rejected');
    assert.strictEqual(r.reason, 'qty_below_lot');
  });

  test('a limit buy rests, then fills as maker on a crossing tick', async () => {
    const { b, feed } = mkBroker();
    const o = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1, price: 99.5, ttlMs: 5000 });
    assert.strictEqual(o.status, 'open');
    const fills = b.onTick({ symbol: 'BTCUSDT', bid: 99.4, ask: 99.6 }, feed);
    assert.strictEqual(fills.length, 1);
    assert.strictEqual(fills[0].feeKind, 'maker');
    assert.strictEqual(fills[0].price, 99.5);
  });

  test('a limit order expires', async () => {
    const { b } = mkBroker();
    await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1, price: 1, ttlMs: 1 });
    const ex = b.expire(Date.now() + 10);
    assert.strictEqual(ex.length, 1);
    assert.strictEqual(b.stats().expired, 1);
  });

  test('quantisation is applied before the order is built', async () => {
    const { b } = mkBroker();
    const o = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1.23456, price: 99.123456 });
    // szDecimals=3 -> qty 1.234, price at most 3 decimals
    assert.strictEqual(o.qty, 1.234);
    assert.ok(o.price <= 99.124, `price=${o.price}`);
  });

  test('cancel and cancelAll work', async () => {
    const { b } = mkBroker();
    const o = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1, price: 1 });
    assert.strictEqual(b.cancel(o.orderId), true);
    assert.strictEqual(b.cancel(o.orderId), false);
    await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'limit', qty: 1, price: 1 });
    b.cancelAll('BTCUSDT');
    assert.strictEqual(b.stats().openOrders, 0);
  });

  test('stats report the venue and mode', () => {
    const { b } = mkBroker();
    const s = b.stats();
    assert.strictEqual(s.venue, 'hyperliquid');
    assert.strictEqual(s.mode, 'paper');
  });
});

// ============================================================ adapter surface
group('hyperliquid / adapter surface', () => {
  test('the venue is registered and exposes the shared interface', () => {
    const ex = createExchange('hyperliquid');
    for (const m of ['klines', 'ticker', 'depth', 'serverTime']) {
      assert.strictEqual(typeof ex[m], 'function', `hyperliquid.${m}`);
    }
  });
  test('ws() returns null so MarketHub falls back to REST explicitly', () => {
    const ex = createExchange('hyperliquid');
    assert.strictEqual(ex.ws(), null);
  });
  test('an unsupported interval fails loudly', async () => {
    const { HyperliquidPublic } = hl;
    const p = new HyperliquidPublic({ http: { info: async () => [] } });
    await assert.rejects(() => p.klines('BTCUSDT', 10, '7m'), /unsupported interval/);
  });
  test('klines paginate past the 500-bar response cap', async () => {
    const { HyperliquidPublic } = hl;
    let calls = 0;
    const fakeHttp = {
      info: async (body) => {
        calls++;
        const { startTime, endTime } = body.req;
        const step = 3600000;
        const out = [];
        for (let t = startTime; t < endTime; t += step) {
          out.push({ t, o: '1', h: '2', l: '0.5', c: '1.5', v: '10' });
        }
        return out;
      },
    };
    const p = new HyperliquidPublic({ http: fakeHttp });
    const bars = await p.klines('BTCUSDT', 900, '1h');
    assert.ok(bars.length >= 500, `got ${bars.length}`);
    assert.ok(calls >= 2, `expected pagination, got ${calls} call(s)`);
    // ascending and de-duplicated
    for (let i = 1; i < bars.length; i++) assert.ok(bars[i].t > bars[i - 1].t);
  });
});

// ============================================================ live (opt-in)
async function liveTests() {
  if (process.env.BB_HL_LIVE !== '1') {
    console.log('\n\u25b8 hyperliquid / live public data');
    console.log('  \u2013 skipped (set BB_HL_LIVE=1 to run against the real venue)');
    return;
  }
  await group('hyperliquid / live public data', async () => {
    const ex = createExchange('hyperliquid');

    await testAsync('ticker returns a real bid/ask', async () => {
      const t = await ex.ticker('BTCUSDT');
      assert.ok(t.bid > 0 && t.ask > 0, JSON.stringify(t));
      assert.ok(t.ask >= t.bid, 'ask must not be below bid');
      assert.strictEqual(t.symbol, 'BTCUSDT');
    });

    await testAsync('depth returns real levels', async () => {
      const d = await ex.depth('BTCUSDT', 5);
      assert.ok(d.bids.length > 0 && d.asks.length > 0);
      assert.ok(d.bids[0][0] < d.asks[0][0], 'best bid below best ask');
    });

    await testAsync('klines return a contiguous ascending series', async () => {
      const k = await ex.klines('BTCUSDT', 200, '1h');
      assert.ok(k.length >= 100, `got ${k.length}`);
      for (let i = 1; i < k.length; i++) assert.ok(k[i].t > k[i - 1].t);
      assert.ok(k[k.length - 1].c > 0);
    });

    await testAsync('batch quotes cover every requested symbol', async () => {
      const m = await ex.tickersBatch(['BTCUSDT', 'ETHUSDT', 'SOLUSDT']);
      assert.ok(m.size >= 2, `got ${m.size}`);
      for (const [, q] of m) assert.ok(q.last > 0);
    });

    await testAsync('a paper fill prices off the real book', async () => {
      const t = await ex.ticker('BTCUSDT');
      const b = new HyperliquidBroker({
        cfg: { ...CFG, hyperliquid: { mode: 'paper' } },
        log: quietLog(),
        getBook: () => ({ bid: t.bid, ask: t.ask }),
        getFeed: () => ({ isStale: false, depth: { bids: [[t.bid, 100]], asks: [[t.ask, 100]] } }),
        publicApi: { asset: async () => ({ name: 'BTC', szDecimals: 5, index: 0 }), http: {} },
      });
      const f = await b.submit({ symbol: 'BTCUSDT', side: 'buy', type: 'market', qty: 0.001 });
      assert.strictEqual(f.status, 'filled');
      assert.ok(Math.abs(f.price - t.ask) / t.ask < 0.01, `fill ${f.price} vs ask ${t.ask}`);
    });
  });
}

// ================================================================ summary
(async () => {
  await liveTests();
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  hyperliquid: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
})();
