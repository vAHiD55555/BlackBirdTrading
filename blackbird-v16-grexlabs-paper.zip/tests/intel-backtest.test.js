'use strict';
/**
 * Regression tests for the intel ↔ backtest wiring (v15).
 *
 * WHAT THIS SUITE EXISTS FOR
 * --------------------------
 * The backtest engine is documented as no-network, so the live intel module
 * (which fetches headlines) cannot be used inside it. Before this change there
 * was no way at all to measure "does market intel help?" — the question could
 * only be answered by opinion.
 *
 * The wiring added here has two hooks, and BOTH must be able to make the book
 * smaller and NEITHER may make it bigger:
 *
 *   externalScale  the rotator clamps it to 0..1
 *   risk.check     a blackout refuses a NEW entry only
 *
 * These tests pin that contract, plus the honesty rule: the historical source
 * supplies the event calendar only, and its risk multiplier is always exactly
 * 1 — it never pretends to know the sentiment of a day it has no headlines for.
 *
 * Fully offline: synthetic bars, no network, no exchange.
 */
const assert = require('node:assert');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { HistoricalIntel, buildEvents, dayToMs, FOMC_2025, FOMC_2026 } = require(path.join(SRC, 'intel/historical'));
const { runBacktest } = require(path.join(SRC, 'backtest/engine'));
const { loadConfig } = require(path.join(SRC, 'config'));

/**
 * Deterministic bars: a drift plus a wave, one per hour.
 *
 * 2 500 bars, not 400: the rotator's `ready()` needs a long lookback window
 * (the backtest feed exposes 2 000 bars), and with 400 it never becomes ready
 * — which silently produced a run with zero trades and made two of these tests
 * pass for the wrong reason.
 */
function makeBars(start, drift, n = 2500, vol = 0.004) {
  const out = [];
  let c = start;
  const t0 = Date.UTC(2025, 0, 1);
  for (let i = 0; i < n; i++) {
    c = c * (1 + drift) * (1 + Math.sin(i / 3) * vol);
    const o = c * (1 - vol / 2);
    out.push({ t: t0 + i * 3600000, o, h: Math.max(o, c) * (1 + vol), l: Math.min(o, c) * (1 - vol), c, v: 1000 });
  }
  return out;
}

const BARS = {
  BTCUSDT: makeBars(100, 0.0005),
  ETHUSDT: makeBars(100, 0.002),
  SOLUSDT: makeBars(100, -0.001),
  XRPUSDT: makeBars(100, -0.002),
};

const CFG = () => {
  const cfg = loadConfig();
  cfg.strategy.mode = 'rotator';
  cfg.symbols = Object.keys(BARS);
  return cfg;
};

(async () => {
  // ------------------------------------------------------------- the calendar
  await t('calendar: every FOMC day parses to a real timestamp', () => {
    for (const day of [...FOMC_2025, ...FOMC_2026]) {
      const ms = dayToMs(day);
      assert.ok(Number.isFinite(ms), `${day} did not parse`);
      assert.strictEqual(new Date(ms).toISOString().slice(0, 10), day, `${day} round-trip`);
    }
  });

  await t('calendar: events are sorted and unique', () => {
    const ev = buildEvents();
    assert.ok(ev.length >= 16, `expected the full calendar, got ${ev.length}`);
    for (let i = 1; i < ev.length; i++) assert.ok(ev[i].ts > ev[i - 1].ts, 'events must be strictly increasing');
  });

  // ------------------------------------------------------------- the gate
  await t('gate: an event 10 minutes away blocks new entries', () => {
    const intel = new HistoricalIntel();
    const ev = intel.events[0];
    const v = intel.at(ev.ts - 10 * 60 * 1000);
    assert.strictEqual(v.blackout, true);
    assert.match(v.reason, /FOMC/);
  });

  await t('gate: an event 3 hours away does not block', () => {
    const intel = new HistoricalIntel();
    const ev = intel.events[0];
    assert.strictEqual(intel.at(ev.ts - 3 * 3600 * 1000).blackout, false);
  });

  await t('gate: 10 minutes AFTER the event still blocks', () => {
    const intel = new HistoricalIntel();
    const ev = intel.events[0];
    assert.strictEqual(intel.at(ev.ts + 10 * 60 * 1000).blackout, true);
  });

  await t('gate: 20 minutes after the event is clear again', () => {
    const intel = new HistoricalIntel();
    const ev = intel.events[0];
    assert.strictEqual(intel.at(ev.ts + 20 * 60 * 1000).blackout, false);
  });

  await t('gate: the risk multiplier is ALWAYS exactly 1 (no sentiment offline)', () => {
    const intel = new HistoricalIntel();
    for (const ev of intel.events) {
      assert.strictEqual(intel.at(ev.ts).riskMultiplier, 1, 'a blackout must not also shrink size');
      assert.strictEqual(intel.at(ev.ts - 5 * 3600 * 1000).riskMultiplier, 1);
    }
  });

  await t('gate: a non-finite timestamp is safe and never blocks', () => {
    const intel = new HistoricalIntel();
    for (const bad of [NaN, null, undefined, 'x', Infinity]) {
      const v = intel.at(bad);
      assert.strictEqual(v.blackout, false);
      assert.strictEqual(v.riskMultiplier, 1);
    }
  });

  await t('gate: a full-day window catches the event at any hour of that day', () => {
    const intel = new HistoricalIntel({ blackoutBeforeMs: 12 * 3600 * 1000, blackoutAfterMs: 12 * 3600 * 1000 });
    const ev = intel.events[0];
    assert.strictEqual(intel.at(ev.ts - 11 * 3600 * 1000).blackout, true);
    assert.strictEqual(intel.at(ev.ts + 11 * 3600 * 1000).blackout, true);
    assert.strictEqual(intel.at(ev.ts - 13 * 3600 * 1000).blackout, false);
  });

  // ------------------------------------------------------- the backtest wiring
  await t('backtest: with no intelAt the run is the plain baseline', () => {
    const r = runBacktest({ cfg: CFG(), barsBySymbol: BARS });
    assert.strictEqual(r.ok, true, r.error);
    assert.strictEqual(r.summary.intel, null, 'no hook must mean no intel stats');
  });

  await t('backtest: an intelAt hook is called and its stats are reported', () => {
    const intel = new HistoricalIntel();
    const r = runBacktest({ cfg: CFG(), barsBySymbol: BARS, intelAt: (ts) => intel.at(ts) });
    assert.strictEqual(r.ok, true, r.error);
    assert.ok(r.summary.intel, 'the summary must carry the intel stats');
    assert.ok(r.summary.intel.calls > 0, 'the hook must actually be called');
    assert.ok(r.summary.trades > 0, `the fixture must actually trade, got ${r.summary.trades}`);
  });

  await t('backtest: a hook that always blocks produces ZERO trades', () => {
    const base = runBacktest({ cfg: CFG(), barsBySymbol: BARS });
    assert.ok(base.summary.trades > 0, `the fixture must trade without intel, got ${base.summary.trades}`);
    const r = runBacktest({
      cfg: CFG(),
      barsBySymbol: BARS,
      intelAt: () => ({ riskMultiplier: 1, blackout: true, reason: 'test' }),
    });
    assert.strictEqual(r.ok, true, r.error);
    assert.strictEqual(r.summary.trades, 0, `a permanent blackout must open nothing, got ${r.summary.trades}`);
    assert.ok(r.summary.intel.blackouts > 0);
  });

  await t('backtest: a hook that always returns 1 changes nothing', () => {
    const base = runBacktest({ cfg: CFG(), barsBySymbol: BARS });
    const same = runBacktest({
      cfg: CFG(),
      barsBySymbol: BARS,
      intelAt: () => ({ riskMultiplier: 1, blackout: false, reason: null }),
    });
    assert.strictEqual(same.summary.trades, base.summary.trades, 'a neutral hook must not change the trade count');
    assert.strictEqual(same.summary.returnPct, base.summary.returnPct, 'a neutral hook must not change the return');
  });

  await t('backtest: a hook returning >1 can never raise exposure', () => {
    // The rotator clamps externalScale to 0..1, so a hostile or buggy hook that
    // returns 5 must behave exactly like 1 — never like a leverage increase.
    const base = runBacktest({ cfg: CFG(), barsBySymbol: BARS });
    const greedy = runBacktest({
      cfg: CFG(),
      barsBySymbol: BARS,
      intelAt: () => ({ riskMultiplier: 5, blackout: false, reason: null }),
    });
    assert.strictEqual(greedy.summary.trades, base.summary.trades, 'a >1 multiplier must not open extra trades');
    assert.ok(greedy.summary.returnPct <= base.summary.returnPct + 1e-9, 'a >1 multiplier must not raise the return');
  });

  await t('backtest: a hook that throws does not crash the run', () => {
    const r = runBacktest({
      cfg: CFG(),
      barsBySymbol: BARS,
      intelAt: () => { throw new Error('feed exploded'); },
    });
    // The rotator swallows an externalScale throw and falls back to 1; the
    // risk.check wrapper does not, so the run must still complete or fail
    // cleanly — never hang and never produce a half-written summary.
    assert.ok(r.ok === true || r.ok === false, 'the run must return a result object');
  });

  done('intel-backtest');
})();
