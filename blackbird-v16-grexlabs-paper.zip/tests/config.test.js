#!/usr/bin/env node
'use strict';
/**
 * Panel-tunable configuration.
 *
 * The operator must be able to change risk knobs, thresholds, the watch
 * universe and the model choice from the variables panel -- without editing a
 * file on the server. These tests pin that contract: every documented variable
 * actually reaches the config, is cast to the right type, and a bad value is
 * ignored rather than silently becoming NaN.
 */
const assert = require('node:assert');
const path = require('node:path');
const { t, done } = require('./harness');

const ROOT = path.join(__dirname, '..');

/** Load config with a clean env, so the host's own variables cannot leak in. */
function loadWith(env) {
  const saved = { ...process.env };
  for (const k of Object.keys(process.env)) {
    if (/^(BB_|RISK_|MAX_|MIN_|CORE_|GATE_|VOL_|ALLOW_|USE_|BREADTH_|SLIPPAGE_|STALE_|SCAN_|PROPOSAL_|SLEEVE_|WATCH_|JEV_|HL_|START_|PROFILE)/.test(k)) delete process.env[k];
  }
  Object.assign(process.env, env);
  // fresh module instance every time
  for (const k of Object.keys(require.cache)) if (k.startsWith(ROOT)) delete require.cache[k];
  try {
    const mod = require(path.join(ROOT, 'src/config.js'));
    return mod.loadConfig();
  } finally {
    for (const k of Object.keys(process.env)) if (!(k in saved)) delete process.env[k];
    Object.assign(process.env, saved);
  }
}

(async () => {
  console.log('\n▸ config — the panel can change risk knobs');

  await t('risk parameters come from the environment', () => {
    const cfg = loadWith({
      RISK_PER_TRADE_PCT: '0.75',
      MAX_SYMBOL_EXPOSURE_PCT: '12',
      MAX_NET_EXPOSURE_PCT: '35',
      MAX_CONSECUTIVE_LOSSES: '4',
      MIN_NOTIONAL_USD: '25',
    });
    assert.strictEqual(cfg.risk.riskPerTradePct, 0.75);
    assert.strictEqual(cfg.risk.maxSymbolExposurePct, 12);
    assert.strictEqual(cfg.risk.maxNetExposurePct, 35);
    assert.strictEqual(cfg.risk.maxConsecutiveLosses, 4);
    assert.strictEqual(cfg.risk.minNotionalUsd, 25);
  });

  await t('strategy thresholds come from the environment', () => {
    const cfg = loadWith({ MIN_RR: '2.5', MIN_TP_BPS: '40', MAX_SL_BPS: '300', ALLOW_SHORT: 'false' });
    assert.strictEqual(cfg.strategy.minRR, 2.5);
    assert.strictEqual(cfg.strategy.minTpBps, 40);
    assert.strictEqual(cfg.strategy.maxSlBps, 300);
    assert.strictEqual(cfg.strategy.allowShort, false);
  });

  await t('booleans accept 1/true/yes and reject anything else', () => {
    assert.strictEqual(loadWith({ USE_RISK_SIZING: '1' }).risk.useRiskSizing, true);
    assert.strictEqual(loadWith({ USE_RISK_SIZING: 'yes' }).risk.useRiskSizing, true);
    assert.strictEqual(loadWith({ USE_RISK_SIZING: '0' }).risk.useRiskSizing, false);
    assert.strictEqual(loadWith({ USE_RISK_SIZING: 'maybe' }).risk.useRiskSizing, false);
  });

  await t('a non-numeric value is ignored, not turned into NaN', () => {
    const cfg = loadWith({ RISK_PER_TRADE_PCT: 'lots' });
    assert.ok(Number.isFinite(cfg.risk.riskPerTradePct), 'must stay a real number');
    assert.notStrictEqual(cfg.risk.riskPerTradePct, NaN);
  });

  console.log('\n▸ config — the watch (دیده‌بان) is panel-tunable');

  await t('the watch universe is a parsed symbol list', () => {
    const cfg = loadWith({ WATCH_UNIVERSE: 'ada, dot , link' });
    assert.deepStrictEqual(cfg.watch.universe, ['ADA', 'DOT', 'LINK']);
  });

  await t('watch thresholds and switches come from the environment', () => {
    const cfg = loadWith({
      WATCH_ENABLED: 'true',
      WATCH_INTERVAL_MS: '3600000',
      WATCH_MIN_EDGE_BPS: '40',
      WATCH_MAX_SWAPS_PER_CYCLE: '2',
      WATCH_AUTO_APPLY: 'false',
      WATCH_REQUIRE_COUNCIL: 'true',
    });
    assert.strictEqual(cfg.watch.enabled, true);
    assert.strictEqual(cfg.watch.intervalMs, 3600000);
    assert.strictEqual(cfg.watch.minEdgeBps, 40);
    assert.strictEqual(cfg.watch.maxSwapsPerCycle, 2);
    assert.strictEqual(cfg.watch.autoApply, false);
    assert.strictEqual(cfg.watch.requireCouncil, true);
  });

  await t('the watch is safe by default: no auto-apply, council required', () => {
    const cfg = loadWith({});
    assert.strictEqual(cfg.watch.autoApply, false, 'a swap must never be applied without a decision');
    assert.strictEqual(cfg.watch.requireCouncil, true);
    assert.ok(cfg.watch.maxSwapsPerCycle <= 1, 'one replacement per cycle by default');
  });

  console.log('\n▸ config — keyless model by default');

  await t('jev defaults to a keyless provider, not a paid one', () => {
    const cfg = loadWith({});
    // The default used to be `ollama`, which is keyless but LOCAL: on a hosted
    // free tier (botkeep.cloud) 127.0.0.1 is the container itself, so the
    // shipped default could never answer there. The requirement is now
    // "keyless AND not local-only".
    const { isKeyless, isLocalOnly } = require('../src/jev/providers/catalog');
    assert.ok(isKeyless(cfg.jev.provider), `the shipped default must need no key, got ${cfg.jev.provider}`);
    assert.ok(!isLocalOnly(cfg.jev.provider), `the shipped default must not be local-only, got ${cfg.jev.provider}`);
    assert.ok(!/gpt-4o|gpt-4|claude/i.test(String(cfg.jev.model)), `model must not be a paid default, got ${cfg.jev.model}`);
  });

  await t('the model and its endpoint are overridable from the panel', () => {
    const cfg = loadWith({ JEV_PROVIDER: 'groq', JEV_MODEL: 'llama-3.3-70b-versatile', JEV_BASE_URL: 'https://api.groq.com/openai/v1' });
    assert.strictEqual(cfg.jev.provider, 'groq');
    assert.strictEqual(cfg.jev.model, 'llama-3.3-70b-versatile');
    assert.strictEqual(cfg.jev.baseUrl, 'https://api.groq.com/openai/v1');
  });

  await t('the keyless fallback chain is a parsed list', () => {
    const cfg = loadWith({ JEV_KEYLESS_FALLBACK: 'ollama, mock' });
    assert.deepStrictEqual(cfg.jev.keylessFallback, ['ollama', 'mock']);
  });

  await t('the catalog agrees that the default provider needs no key', () => {
    const { isKeyless } = require(path.join(ROOT, 'src/jev/providers/catalog.js'));
    const cfg = loadWith({});
    assert.strictEqual(isKeyless(cfg.jev.provider), true, `${cfg.jev.provider} must be keyless`);
  });

  done('config');
})();
