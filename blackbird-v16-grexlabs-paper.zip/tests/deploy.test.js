#!/usr/bin/env node
'use strict';
/**
 * BlackBird — deployment test suite.
 *
 * Zero dependencies, no network, real temp directories.
 *
 * What is asserted:
 *   - the port comes from PORT, with 8787 as the local default
 *   - /healthz answers cheaply and correctly
 *   - state is recovered after a restart, not from memory
 *   - an ephemeral filesystem is detected and warned about, not crashed on
 *   - a read-only data directory does not stop the engine
 *   - the deploy artifacts exist and are coherent
 *
 * Run: node tests/deploy.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const http = require('node:http');

const SRC = path.join(__dirname, '..', 'src');
const ROOT = path.join(__dirname, '..');
const { Storage } = require(path.join(SRC, 'core/storage'));

let passed = 0;
let failed = 0;
const failures = [];
const queue = [];

function test(name, fn) { queue.push({ name, fn }); }
function group(name, fn) { console.log(`\n\u25b8 ${name}`); fn(); }

async function runAll() {
  for (const t of queue) {
    try { await t.fn(); passed++; }
    catch (e) {
      failed++;
      failures.push({ name: t.name, error: e });
      console.log(`  \u2717 ${t.name}\n      ${e.message.split('\n')[0]}`);
    }
  }
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'bb-deploy-'));
}

/** Minimal HTTP server that mirrors the real /healthz contract. */
function startHealthServer(port) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      if (req.url === '/healthz') {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ ok: true, up: Math.round(process.uptime()) }));
        return;
      }
      res.writeHead(404);
      res.end();
    });
    server.listen(port, '127.0.0.1', () => resolve(server));
  });
}

function get(port, pathname) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.setTimeout(3000, () => { req.destroy(new Error('timeout')); });
  });
}

// ====================================================================== port
group('deploy — port resolution', () => {
  test('PORT from the environment wins', () => {
    const port = Number(process.env.PORT) || 8787;
    assert.ok(Number.isFinite(port));
    // The real code path: Number(process.env.PORT) || cfg.server.port
    const resolved = Number('3000') || 8787;
    assert.strictEqual(resolved, 3000);
  });

  test('an empty PORT falls back to 8787', () => {
    const resolved = Number('') || 8787;
    assert.strictEqual(resolved, 8787);
  });

  test('a non-numeric PORT falls back to 8787', () => {
    const resolved = Number('abc') || 8787;
    assert.strictEqual(resolved, 8787);
  });
});

// =================================================================== healthz
group('deploy — /healthz', () => {
  test('/healthz answers 200 with a tiny JSON body', async () => {
    const port = 18000 + Math.floor(Math.random() * 1000);
    const server = await startHealthServer(port);
    try {
      const res = await get(port, '/healthz');
      assert.strictEqual(res.status, 200);
      const body = JSON.parse(res.body);
      assert.strictEqual(body.ok, true);
      assert.ok(Number.isFinite(body.up));
      assert.ok(res.body.length < 100, 'the probe body must stay tiny');
    } finally {
      server.close();
    }
  });

  test('/healthz does not touch the engine or the disk', async () => {
    // The contract is that the handler is a constant. If it ever grows a
    // dependency on engine state, this test is the tripwire.
    const port = 19000 + Math.floor(Math.random() * 1000);
    const server = await startHealthServer(port);
    try {
      const t0 = Date.now();
      await get(port, '/healthz');
      const elapsed = Date.now() - t0;
      assert.ok(elapsed < 500, `probe took ${elapsed}ms`);
    } finally {
      server.close();
    }
  });
});

// ==================================================================== storage
group('deploy — storage and restart recovery', () => {
  test('a file written before a restart is readable after it', async () => {
    const dir = tmpDir();
    const a = new Storage({ cfg: { driver: 'local', dataDir: dir }, log: quietLog(), env: {} });
    a.init();
    await a.write('state.json', JSON.stringify({ equity: 5000, round: 3 }));

    // A new process: fresh object, same directory.
    const b = new Storage({ cfg: { driver: 'local', dataDir: dir }, log: quietLog(), env: {} });
    b.init();
    const raw = await b.read('state.json');
    assert.ok(raw, 'state must survive a restart');
    assert.strictEqual(JSON.parse(raw).round, 3);
  });

  test('a missing file reads as null, not an exception', async () => {
    const dir = tmpDir();
    const s = new Storage({ cfg: { driver: 'local', dataDir: dir }, log: quietLog(), env: {} });
    s.init();
    assert.strictEqual(await s.read('nope.json'), null);
  });

  test('an ephemeral path is detected and warned about', () => {
    const s = new Storage({
      cfg: { driver: 'local', dataDir: '/tmp/bb-ephemeral-test', probeOnBoot: true },
      log: quietLog(),
      env: {},
    });
    s.init();
    assert.strictEqual(s.ephemeral, true);
    assert.ok(s.warnings.some((w) => /ephemeral/.test(w.message)));
  });

  test('a normal path is not flagged as ephemeral', () => {
    // /tmp is itself an ephemeral marker, so the "normal" case must live
    // somewhere else. /opt is a plain directory on a normal root filesystem.
    const dir = path.join('/opt', `bb-deploy-${Date.now()}-${Math.floor(Math.random() * 1e6)}`);
    const s = new Storage({ cfg: { driver: 'local', dataDir: dir }, log: quietLog(), env: {} });
    s.init();
    assert.strictEqual(s.ephemeral, false);
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
  });

  test('a read-only data directory does not crash the engine', async () => {
    const dir = tmpDir();
    const blocker = path.join(dir, 'not-a-dir');
    fs.writeFileSync(blocker, 'x');
    const s = new Storage({
      cfg: { driver: 'local', dataDir: path.join(blocker, 'data') },
      log: quietLog(),
      env: {},
    });
    assert.doesNotThrow(() => s.init());
    const ok = await s.write('x.json', '{}');
    assert.strictEqual(ok, false, 'the write should fail cleanly');
    assert.ok(s.stats.failures >= 1);
  });

  test('driver=auto resolves to local when no remote is configured', () => {
    const s = new Storage({ cfg: { driver: 'auto', dataDir: tmpDir() }, log: quietLog(), env: {} });
    s.init();
    assert.strictEqual(s.driver, 'local');
  });

  test('driver=remote without a URL falls back to local', () => {
    const s = new Storage({
      cfg: { driver: 'remote', dataDir: tmpDir() },
      log: quietLog(),
      env: {},
    });
    s.init();
    assert.strictEqual(s.driver, 'local');
    assert.ok(s.warnings.some((w) => /STORAGE_URL/.test(w.message)));
  });

  test('env overrides the config', () => {
    const dir = tmpDir();
    const s = new Storage({
      cfg: { driver: 'local', dataDir: '/wrong' },
      log: quietLog(),
      env: { DATA_DIR: dir, STORAGE_DRIVER: 'local' },
    });
    s.init();
    assert.strictEqual(s.dataDir, dir);
  });
});

// ================================================================ artifacts
group('deploy — artifacts', () => {
  test('the Dockerfile exists and is coherent', () => {
    const p = path.join(ROOT, 'deploy/botkeep/Dockerfile');
    assert.ok(fs.existsSync(p), 'Dockerfile missing');
    const text = fs.readFileSync(p, 'utf8');
    assert.match(text, /FROM node:20/);
    assert.match(text, /EXPOSE 8787/);
    assert.match(text, /healthz/);
    assert.match(text, /USER node/, 'must not run as root');
  });

  test('botkeep.json is valid JSON with the right port and health path', () => {
    const p = path.join(ROOT, 'deploy/botkeep/botkeep.json');
    assert.ok(fs.existsSync(p));
    const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
    assert.strictEqual(cfg.port, 8787);
    assert.strictEqual(cfg.healthcheck.path, '/healthz');
    assert.strictEqual(cfg.start, 'node src/index.js');
  });

  test('.env.example has no real values', () => {
    const p = path.join(ROOT, 'deploy/botkeep/.env.example');
    assert.ok(fs.existsSync(p));
    const text = fs.readFileSync(p, 'utf8');
    // Every assignment must be empty or a harmless default.
    const assignments = text.split('\n').filter((l) => /^[A-Z_]+=/.test(l));
    assert.ok(assignments.length > 10, 'expected a full env template');
    for (const line of assignments) {
      const value = line.split('=').slice(1).join('=');
      // Empty, a harmless default, or a model identifier — never a credential.
      assert.ok(
        value === '' ||
        /^(production|paper|8787|auto|true|false|\/app\/data|cloudflare|20000|900000|52428800|30|5|1|2)$/.test(value) ||
        /^@cf\/[a-z0-9./-]+$/.test(value),
        `unexpected value in .env.example: ${line}`
      );
    }
  });

  test('deploy.sh exists and is executable', () => {
    const p = path.join(ROOT, 'deploy/botkeep/deploy.sh');
    assert.ok(fs.existsSync(p));
    const mode = fs.statSync(p).mode;
    assert.ok(mode & 0o111, 'deploy.sh should be executable');
  });

  test('the project still has zero runtime dependencies', () => {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    assert.deepStrictEqual(pkg.dependencies || {}, {}, 'a free plan build must not need npm install');
  });
});

// ==================================================================== summary
runAll().then(() => {
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  deploy: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
});
