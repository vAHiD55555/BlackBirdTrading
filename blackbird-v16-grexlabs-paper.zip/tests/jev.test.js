#!/usr/bin/env node
'use strict';
/**
 * BlackBird — jev test suite.
 *
 * Zero dependencies, deterministic, no network. Every model interaction goes
 * through MockProvider, so these tests assert the *contract* jev promises:
 *
 *   - a good answer is honoured
 *   - a bad answer degrades to rule-based behaviour
 *   - a timeout degrades to rule-based behaviour
 *   - a veto blocks entries but never closes positions
 *   - risk can only go down, never above the configured ceiling
 *   - a conflict between modules is resolved in favour of safety
 *   - a dead module is noticed and quarantined
 *   - jev itself dying leaves the engine working
 *
 * Run: node tests/jev.test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const { Jev } = require(path.join(SRC, 'jev/jev'));
const { ModuleRegistry, STATUS } = require(path.join(SRC, 'jev/registry'));
const { JevBus } = require(path.join(SRC, 'jev/bus'));
const { MockProvider } = require(path.join(SRC, 'jev/providers'));
const schema = require(path.join(SRC, 'jev/schema'));
const prompt = require(path.join(SRC, 'jev/prompt'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    const r = fn();
    if (r && typeof r.then === 'function') {
      return r.then(
        () => { passed++; },
        (e) => { failed++; failures.push({ name, error: e }); console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`); }
      );
    }
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
  return Promise.resolve();
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  return fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/** A jev wired to a scripted mock provider. */
function makeJev({ script = [], cfg = {}, env = {}, registry } = {}) {
  const provider = new MockProvider({ script });
  const jev = new Jev({
    cfg: { enabled: true, provider: 'mock', model: 'mock-1', timeoutMs: 50, ...cfg },
    log: quietLog(),
    provider,
    env: { JEV_API_KEY: 'test-key', ...env },
    registry,
  });
  return { jev, provider };
}

const GOOD = JSON.stringify({
  regime: 'muddy', confidence: 0.72, bias: 'neutral',
  riskMultiplier: 0.5, reasoning: 'ATR percentile 0.31 and spread 7.2bps: thin edge.', veto: false,
});

const VETO = JSON.stringify({
  regime: 'toxic', confidence: 0.88, bias: 'neutral',
  riskMultiplier: 0, reasoning: 'Depth 4k USD on three symbols; cannot exit.', veto: true,
});

// A minimal engine status shaped like Engine.status().
function status(over = {}) {
  return {
    time: '2026-11-11T00:00:00.000Z',
    mode: 'paper',
    strategy: 'hybrid',
    risk: { equity: 5000, equityMtm: 5013.82, drawdownPct: 0, dailyPnlPct: 0.28, halted: false, haltReason: null },
    rotator: { volScale: 1, ddScale: 1, lastScale: 0.7, lastRebalanceAt: 1, positions: [{ symbol: 'BTCUSDT', side: 'long', entry: 100, stop: 90, pnl: 1.2 }] },
    market: [
      { symbol: 'BTCUSDT', price: 100, regime: 'muddy', atrPct: 1.2, volPercentile: 0.31, rsi: 48, spreadBps: 7.2, depthUsd: 4000 },
      { symbol: 'ETHUSDT', price: 20, regime: 'calm', atrPct: 0.8, volPercentile: 0.22, rsi: 51, spreadBps: 5.1, depthUsd: 9000 },
    ],
    ...over,
  };
}

(async () => {
  // ============================================================ schema
  await group('schema — strict validation', async () => {
    await test('accepts a well-formed decision', () => {
      const r = schema.validateDecide(GOOD, { maxRiskMultiplier: 1, allowVeto: true });
      assert.strictEqual(r.ok, true);
      assert.strictEqual(r.value.regime, 'muddy');
      assert.strictEqual(r.value.riskMultiplier, 0.5);
    });

    await test('rejects an unknown regime', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), regime: 'bullish' }));
      assert.strictEqual(r.ok, false);
      assert.ok(r.problems.join(' ').includes('regime'));
    });

    await test('rejects confidence outside 0..1', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), confidence: 1.7 }));
      assert.strictEqual(r.ok, false);
    });

    await test('rejects a non-numeric riskMultiplier', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), riskMultiplier: 'lots' }));
      assert.strictEqual(r.ok, false);
    });

    await test('rejects empty reasoning', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), reasoning: '   ' }));
      assert.strictEqual(r.ok, false);
    });

    await test('clamps riskMultiplier to the operator ceiling', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), riskMultiplier: 0.9 }), { maxRiskMultiplier: 0.4 });
      assert.strictEqual(r.ok, true);
      assert.strictEqual(r.value.riskMultiplier, 0.4, 'ceiling must win');
    });

    await test('a ceiling above 1 is itself capped at 1', () => {
      const r = schema.validateDecide(JSON.stringify({ ...JSON.parse(GOOD), riskMultiplier: 1 }), { maxRiskMultiplier: 5 });
      assert.strictEqual(r.value.riskMultiplier, 1);
    });

    await test('downgrades a veto when the operator disallowed it', () => {
      const r = schema.validateDecide(VETO, { allowVeto: false });
      assert.strictEqual(r.ok, true);
      assert.strictEqual(r.value.veto, false);
      assert.strictEqual(r.value.vetoRequested, true, 'the request is still recorded');
    });

    await test('extracts JSON from a fenced reply', () => {
      const r = schema.validateDecide('```json\n' + GOOD + '\n```');
      assert.strictEqual(r.ok, true);
    });

    await test('extracts JSON from prose', () => {
      const r = schema.validateDecide('Sure! Here is my read:\n' + GOOD + '\nHope that helps.');
      assert.strictEqual(r.ok, true);
    });

    await test('rejects a reply with no JSON at all', () => {
      const r = schema.validateDecide('I think the market is fine.');
      assert.strictEqual(r.ok, false);
    });

    await test('rejects truncated JSON', () => {
      const r = schema.validateDecide('{"regime":"muddy","confidence":0.7');
      assert.strictEqual(r.ok, false);
    });
  });

  // ============================================================ brain role
  await group('role: brain — decide()', async () => {
    await test('honours a good decision', async () => {
      const { jev } = makeJev({ script: [{ reply: GOOD }] });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, false);
      assert.strictEqual(d.regime, 'muddy');
      assert.strictEqual(d.riskMultiplier, 0.5);
      assert.strictEqual(jev.stats.decideOk, 1);
    });

    await test('a veto blocks entries', async () => {
      const { jev } = makeJev({ script: [{ reply: VETO }] });
      await jev.decide(status());
      assert.strictEqual(jev.blocksEntries(), true);
      assert.strictEqual(jev.riskMultiplier(), 0);
    });

    await test('a reduction lowers the multiplier but does not block', async () => {
      const { jev } = makeJev({ script: [{ reply: GOOD }] });
      await jev.decide(status());
      assert.strictEqual(jev.blocksEntries(), false);
      assert.strictEqual(jev.riskMultiplier(), 0.5);
    });

    await test('a timeout degrades to neutral and does not throw', async () => {
      const { jev } = makeJev({ script: [{ timeout: true }], cfg: { timeoutMs: 40 } });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(d.riskMultiplier, 1, 'a failed brain must not change risk');
      assert.strictEqual(d.veto, false);
      assert.strictEqual(jev.stats.timeouts, 1);
    });

    await test('broken JSON degrades to neutral', async () => {
      const { jev } = makeJev({ script: [{ reply: '{"regime": "muddy", oops' }] });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(d.riskMultiplier, 1);
      assert.strictEqual(jev.stats.decideFailed, 1);
    });

    await test('a provider error degrades to neutral', async () => {
      const { jev } = makeJev({ script: [{ error: 'HTTP 500 from api.example' }] });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.ok(d.reasoning.includes('HTTP 500'));
    });

    await test('a schema violation degrades to neutral', async () => {
      const { jev } = makeJev({ script: [{ reply: JSON.stringify({ regime: 'nonsense' }) }] });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(d.riskMultiplier, 1);
    });

    await test('a disabled jev never calls the provider', async () => {
      const { jev, provider } = makeJev({ script: [{ reply: GOOD }], cfg: { enabled: false } });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(provider.calls.length, 0);
    });

    await test('a missing API key degrades without calling the provider', async () => {
      const provider = new MockProvider({ script: [{ reply: GOOD }] });
      const jev = new Jev({
        cfg: { enabled: true, provider: 'openai', apiKeyEnv: 'JEV_API_KEY' },
        log: quietLog(), provider, env: {},
      });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.ok(d.reasoning.includes('JEV_API_KEY'));
    });

    await test('concurrent callers share one provider call', async () => {
      const { jev, provider } = makeJev({ script: [{ delayMs: 30, reply: GOOD }] });
      const [a, b, c] = await Promise.all([jev.decide(status()), jev.decide(status()), jev.decide(status())]);
      assert.strictEqual(provider.calls.length, 1, 'bursts must coalesce');
      assert.strictEqual(a.riskMultiplier, b.riskMultiplier);
      assert.strictEqual(b.riskMultiplier, c.riskMultiplier);
    });

    await test('the prompt carries real market numbers', async () => {
      const { jev, provider } = makeJev({ script: [{ reply: GOOD }] });
      await jev.decide(status());
      const sent = JSON.stringify(provider.calls[0].messages);
      assert.ok(sent.includes('BTC'), 'symbol present');
      assert.ok(sent.includes('0.31'), 'vol percentile present');
      assert.ok(sent.includes('7.2'), 'spread present');
    });
  });

  // ========================================================= mediator role
  await group('role: mediator — mediate()', async () => {
    await test('a risk block beats a strategy allow, even with jev off', async () => {
      const { jev } = makeJev({ cfg: { enabled: false } });
      const v = await jev.mediate({
        topic: 'entry:BTCUSDT',
        opinions: [
          { module: 'strategy.rotator', stance: 'allow', reason: 'momentum rank 1' },
          { module: 'risk', stance: 'block', reason: 'daily loss limit reached' },
        ],
      });
      assert.strictEqual(v.resolution, 'block');
      assert.strictEqual(v.riskMultiplier, 0);
      assert.strictEqual(v.winner, 'risk');
    });

    await test('a reduce opinion lowers size', async () => {
      const { jev } = makeJev({ cfg: { enabled: false } });
      const v = await jev.mediate({
        topic: 'entry:ETHUSDT',
        opinions: [
          { module: 'strategy.rotator', stance: 'allow', reason: 'ok' },
          { module: 'auditor', stance: 'reduce', reason: 'slippage elevated', weight: 0.6 },
        ],
      });
      assert.strictEqual(v.resolution, 'reduce');
      assert.strictEqual(v.riskMultiplier, 0.6);
    });

    await test('unanimous allow stays allow', async () => {
      const { jev } = makeJev({ cfg: { enabled: false } });
      const v = await jev.mediate({
        topic: 'entry:SOLUSDT',
        opinions: [{ module: 'strategy.rotator', stance: 'allow', reason: 'ok' }],
      });
      assert.strictEqual(v.resolution, 'allow');
      assert.strictEqual(v.riskMultiplier, 1);
    });

    await test('the model cannot be more permissive than the rules', async () => {
      const { jev } = makeJev({
        script: [{ reply: JSON.stringify({ resolution: 'allow', riskMultiplier: 1, reasoning: 'looks fine to me', winner: 'strategy.rotator' }) }],
      });
      const v = await jev.mediate({
        topic: 'entry:BTCUSDT',
        opinions: [
          { module: 'strategy.rotator', stance: 'allow', reason: 'momentum' },
          { module: 'risk', stance: 'block', reason: 'kill switch armed' },
        ],
      });
      assert.strictEqual(v.resolution, 'block', 'rules must win over a permissive model');
      assert.strictEqual(v.riskMultiplier, 0);
    });

    await test('the model may be stricter than the rules', async () => {
      const { jev } = makeJev({
        script: [{ reply: JSON.stringify({ resolution: 'block', riskMultiplier: 0, reasoning: 'liquidity is a mirage', winner: 'auditor' }) }],
      });
      const v = await jev.mediate({
        topic: 'entry:BTCUSDT',
        opinions: [{ module: 'strategy.rotator', stance: 'allow', reason: 'momentum' }],
      });
      assert.strictEqual(v.resolution, 'block');
    });

    await test('a broken mediation reply falls back to the rule verdict', async () => {
      const { jev } = makeJev({ script: [{ reply: 'not json at all' }] });
      const v = await jev.mediate({
        topic: 'entry:BTCUSDT',
        opinions: [{ module: 'risk', stance: 'block', reason: 'halted' }],
      });
      assert.strictEqual(v.resolution, 'block', 'the rule verdict survives');
      assert.strictEqual(v.degraded, true);
    });

    await test('a mediation timeout falls back to the rule verdict', async () => {
      const { jev } = makeJev({ script: [{ timeout: true }], cfg: { timeoutMs: 40 } });
      const v = await jev.mediate({
        topic: 'entry:BTCUSDT',
        opinions: [{ module: 'auditor', stance: 'reduce', reason: 'slippage', weight: 0.5 }],
      });
      assert.strictEqual(v.resolution, 'reduce');
      assert.strictEqual(v.riskMultiplier, 0.5);
      assert.strictEqual(v.degraded, true);
    });

    await test('a "reduce" that does not reduce is normalised to allow', () => {
      const r = schema.validateMediate(JSON.stringify({ resolution: 'reduce', riskMultiplier: 1, reasoning: 'x' }));
      assert.strictEqual(r.ok, true);
      assert.strictEqual(r.value.resolution, 'allow');
    });

    await test('verdicts are recorded on the bus', async () => {
      const { jev } = makeJev({ cfg: { enabled: false } });
      await jev.mediate({ topic: 'entry:X', opinions: [{ module: 'risk', stance: 'block', reason: 'no' }] });
      const v = jev.bus.verdict('entry:X');
      assert.ok(v);
      assert.strictEqual(v.resolution, 'block');
    });
  });

  // ========================================================== manager role
  await group('role: manager — supervise()', async () => {
    function regWith(modules) {
      const r = new ModuleRegistry({ log: quietLog() });
      for (const m of modules) r.register(m.name, { version: m.version || '1.0.0' });
      return r;
    }

    await test('a healthy registry supervises to healthy', async () => {
      const registry = regWith([{ name: 'risk' }, { name: 'portfolio' }]);
      const jev = new Jev({ cfg: { enabled: false }, log: quietLog(), registry });
      const v = await jev.supervise();
      assert.strictEqual(v.overall, 'healthy');
      assert.ok(v.modules.every((m) => m.action === 'ok'));
    });

    await test('a module with repeated errors is quarantined', async () => {
      const registry = regWith([{ name: 'witness' }]);
      registry.fail('witness', new Error('cross-source divergence'));
      registry.fail('witness', new Error('cross-source divergence'));
      registry.fail('witness', new Error('cross-source divergence'));
      registry.beat('witness', { errorCount: 3 });
      const jev = new Jev({ cfg: { enabled: false }, log: quietLog(), registry });
      const v = await jev.supervise();
      const w = v.modules.find((m) => m.name === 'witness');
      assert.strictEqual(w.action, 'quarantine');
      assert.strictEqual(registry.isQuarantined('witness'), true);
      assert.strictEqual(jev.trusts('witness'), false);
    });

    await test('a stale module is watched, not quarantined', async () => {
      const registry = regWith([{ name: 'reporter' }]);
      const m = registry.get('reporter');
      m.lastBeatAt = Date.now() - 10 * 60 * 1000; // 10 min ago
      m.staleMs = 60 * 1000;
      const jev = new Jev({ cfg: { enabled: false }, log: quietLog(), registry });
      const v = await jev.supervise();
      const r = v.modules.find((x) => x.name === 'reporter');
      assert.strictEqual(r.action, 'watch');
      assert.strictEqual(registry.isQuarantined('reporter'), false);
    });

    await test('the model cannot invent a module', () => {
      const r = schema.validateSupervise(
        JSON.stringify({ modules: [{ name: 'ghost', action: 'quarantine', reason: 'x' }], overall: 'critical' }),
        { knownModules: ['risk', 'portfolio'] }
      );
      assert.strictEqual(r.ok, false);
      assert.ok(r.problems.join(' ').includes('unknown module'));
    });

    await test('the model cannot release a module the rules quarantined', async () => {
      const registry = regWith([{ name: 'witness' }]);
      registry.fail('witness', new Error('x'));
      registry.beat('witness', { errorCount: 5 });
      const { jev } = makeJev({
        registry,
        script: [{ reply: JSON.stringify({ modules: [{ name: 'witness', action: 'ok', reason: 'fine' }], overall: 'healthy', reasoning: 'all good' }) }],
      });
      const v = await jev.supervise();
      const w = v.modules.find((m) => m.name === 'witness');
      assert.strictEqual(w.action, 'quarantine', 'the stricter view wins');
    });

    await test('a supervision timeout falls back to the rule pass', async () => {
      const registry = regWith([{ name: 'risk' }]);
      const { jev } = makeJev({ registry, script: [{ timeout: true }], cfg: { timeoutMs: 40 } });
      const v = await jev.supervise();
      assert.strictEqual(v.degraded, true);
      assert.strictEqual(v.overall, 'healthy');
    });

    await test('quarantine can be disabled by config', () => {
      const r = schema.validateSupervise(
        JSON.stringify({ modules: [{ name: 'risk', action: 'quarantine', reason: 'x' }], overall: 'critical' }),
        { knownModules: ['risk'], quarantineAllowed: false }
      );
      assert.strictEqual(r.ok, true);
      assert.strictEqual(r.value.modules[0].action, 'watch');
    });
  });

  // ============================================================== registry
  await group('registry', async () => {
    await test('an unregistered module is absent, not healthy', () => {
      const r = new ModuleRegistry({ log: quietLog() });
      assert.strictEqual(r.has('nope'), false);
      assert.strictEqual(r.snapshot().length, 0);
    });

    await test('health is derived, never self-declared', () => {
      const r = new ModuleRegistry({ log: quietLog() });
      r.register('x', { health: () => ({ ok: false, detail: 'probe says no' }) });
      const row = r.snapshot()[0];
      assert.strictEqual(row.status, STATUS.WATCH);
      assert.strictEqual(row.detail, 'probe says no');
    });

    await test('a throwing health probe does not crash the registry', () => {
      const r = new ModuleRegistry({ log: quietLog() });
      r.register('x', { health: () => { throw new Error('boom'); } });
      const row = r.snapshot()[0];
      assert.strictEqual(row.status, STATUS.WATCH);
      assert.ok(row.detail.includes('boom'));
    });

    await test('quarantine and release round-trip', () => {
      const r = new ModuleRegistry({ log: quietLog() });
      r.register('x');
      r.quarantine('x', 'test');
      assert.strictEqual(r.isQuarantined('x'), true);
      r.release('x');
      assert.strictEqual(r.isQuarantined('x'), false);
    });

    await test('aggregate health reflects the worst module', () => {
      const r = new ModuleRegistry({ log: quietLog() });
      r.register('a'); r.register('b');
      r.quarantine('b', 'broken');
      assert.strictEqual(r.health().overall, 'critical');
    });
  });

  // =================================================================== bus
  await group('bus', async () => {
    await test('a module changing its mind replaces its opinion', () => {
      const b = new JevBus({ log: quietLog() });
      b.publish({ module: 'risk', topic: 't', stance: 'block', reason: 'first' });
      b.publish({ module: 'risk', topic: 't', stance: 'allow', reason: 'second' });
      const ops = b.collect('t');
      assert.strictEqual(ops.length, 1);
      assert.strictEqual(ops[0].stance, 'allow');
    });

    await test('an invalid stance is rejected', () => {
      const b = new JevBus({ log: quietLog() });
      assert.strictEqual(b.publish({ module: 'x', topic: 't', stance: 'maybe' }), false);
    });

    await test('a throwing listener does not break the bus', () => {
      const b = new JevBus({ log: quietLog() });
      b.on('opinion', () => { throw new Error('listener bug'); });
      assert.strictEqual(b.publish({ module: 'x', topic: 't', stance: 'allow' }), true);
    });

    await test('hasObjection sees a block', () => {
      const b = new JevBus({ log: quietLog() });
      b.publish({ module: 'risk', topic: 't', stance: 'block' });
      assert.strictEqual(b.hasObjection('t'), true);
    });

    await test('prune drops expired topics', () => {
      const b = new JevBus({ log: quietLog(), ttlMs: 1 });
      b.publish({ module: 'x', topic: 't', stance: 'allow' });
      b.opinions.get('t')[0].at = Date.now() - 1000;
      b.prune();
      assert.strictEqual(b.opinions.has('t'), false);
    });
  });

  // ============================================================ fail-safe
  await group('fail-safe — jev dying must not break the engine', async () => {
    await test('a provider that throws synchronously is contained', async () => {
      const bad = { complete() { throw new Error('sync explosion'); } };
      const jev = new Jev({ cfg: { enabled: true, provider: 'mock' }, log: quietLog(), provider: bad, env: { JEV_API_KEY: 'k' } });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(d.riskMultiplier, 1);
    });

    await test('a provider returning a non-string is contained', async () => {
      const bad = { complete: async () => ({ nope: true }) };
      const jev = new Jev({ cfg: { enabled: true, provider: 'mock' }, log: quietLog(), provider: bad, env: { JEV_API_KEY: 'k' } });
      const d = await jev.decide(status());
      assert.strictEqual(d.degraded, true);
    });

    await test('an unknown provider name does not throw at construction', () => {
      const jev = new Jev({ cfg: { enabled: true, provider: 'does-not-exist' }, log: quietLog(), env: { JEV_API_KEY: 'k' } });
      assert.strictEqual(jev.ready, false);
      assert.ok(jev.lastError === null || typeof jev.lastError === 'string');
    });

    await test('decide/mediate/supervise never reject, even with no provider', async () => {
      const jev = new Jev({ cfg: { enabled: true, provider: 'openai' }, log: quietLog(), env: {} });
      const [d, m, s] = await Promise.all([jev.decide(status()), jev.mediate({ topic: 't' }), jev.supervise()]);
      assert.ok(d && m && s);
      assert.strictEqual(d.degraded, true);
      assert.strictEqual(m.resolution, 'allow');
      assert.strictEqual(s.overall, 'healthy');
    });

    await test('a failed decision never leaves a stale veto in force', async () => {
      const { jev } = makeJev({ script: [{ reply: VETO }, { error: 'network down' }] });
      await jev.decide(status());
      assert.strictEqual(jev.blocksEntries(), true);
      await jev.decide(status());
      assert.strictEqual(jev.blocksEntries(), false, 'a dead jev must not keep vetoing');
      assert.strictEqual(jev.riskMultiplier(), 1);
    });

    await test('Jev.apply is safe with null and with garbage', () => {
      assert.strictEqual(Jev.apply(null).riskMultiplier, 1);
      assert.strictEqual(Jev.apply(null).blockEntries, false);
      assert.strictEqual(Jev.apply({ riskMultiplier: 5 }).riskMultiplier, 1, 'never above 1');
      assert.strictEqual(Jev.apply({ riskMultiplier: -3 }).riskMultiplier, 0);
      assert.strictEqual(Jev.apply({ riskMultiplier: 0.5, veto: true }).blockEntries, true);
    });

    await test('the ceiling is enforced end to end', async () => {
      const { jev } = makeJev({ script: [{ reply: GOOD }], cfg: { maxRiskMultiplier: 0.3 } });
      const d = await jev.decide(status());
      assert.strictEqual(d.riskMultiplier, 0.3);
      assert.strictEqual(jev.riskMultiplier(), 0.3);
    });
  });

  // ============================================================== prompt
  await group('prompt', async () => {
    await test('buildContext strips USDT and keeps the numbers', () => {
      const c = prompt.buildContext(status());
      assert.strictEqual(c.market[0].symbol, 'BTC');
      assert.strictEqual(c.market[0].volPercentile, 0.31);
      assert.strictEqual(c.positions[0].symbol, 'BTC');
    });

    await test('buildContext survives an empty status', () => {
      const c = prompt.buildContext({});
      assert.deepStrictEqual(c.market, []);
      assert.strictEqual(c.openPositions, 0);
    });

    await test('the decide prompt states the ceiling', () => {
      const msgs = prompt.buildDecideMessages(prompt.buildContext(status()), { maxRiskMultiplier: 0.4 });
      assert.ok(JSON.stringify(msgs).includes('0.4'));
    });

    await test('the supervise prompt lists only given modules', () => {
      const msgs = prompt.buildSuperviseMessages({ modules: [{ name: 'risk', status: 'ok' }] });
      const body = JSON.stringify(msgs);
      assert.ok(body.includes('risk'));
      assert.ok(!body.includes('ghost'));
    });
  });

  // ============================================================== summary
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  jev: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
})();
