'use strict';
/**
 * Regression tests for v14 — the two new feed families, the report digest, and
 * the FOMC blackout as it is actually reached from the engine.
 *
 * The bugs this suite exists for:
 *
 *   1. The intel module ran, gated entries, and never appeared in a single
 *      report: `Reporter` had no `intel` and `engine.js` never passed one. A
 *      module that silently does nothing visible is indistinguishable from a
 *      module that is broken.
 *   2. The crypto and wire families did not exist, so a coin-desk headline
 *      ("exchange hack", "ETF inflow") scored zero — none of the macro
 *      lexicons contain that vocabulary.
 *   3. `digest()` is what the Telegram report prints. If it ever claims a
 *      source answered when it did not, the operator is lied to on a phone.
 *
 * Fully offline: fetch is injected, the clock is injected.
 */
const assert = require('node:assert');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Intel, scoreHeadline, aggregate, LEXICON } = require(path.join(SRC, 'intel/news'));
const { Reporter } = require(path.join(SRC, 'agents/reporter'));
const { loadConfig } = require(path.join(SRC, 'config'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const RSS = (titles) => `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel><title>x</title>
${titles.map((x) => `<item><title>${x}</title><pubDate>Sat, 22 Nov 2026 08:00:00 GMT</pubDate></item>`).join('\n')}
</channel></rss>`;

/** A fetch stub keyed by URL. */
function stubFetch(map) {
  return async (url) => {
    const e = map[url];
    if (!e) return { ok: false, status: 404, json: async () => ({}), text: async () => '' };
    if (e.status && e.status !== 200) {
      return { ok: false, status: e.status, json: async () => ({}), text: async () => e.body || '' };
    }
    return { ok: true, status: 200, json: async () => e.json || {}, text: async () => e.body || '' };
  };
}

const COINDESK = 'https://coindesk.test/rss';
const COINTELEGRAPH = 'https://cointelegraph.test/rss';
const GOOGLENEWS = 'https://gnews.test/reuters';
const BBC = 'https://bbc.test/business.xml';

(async () => {
  // ------------------------------------------------------- crypto lexicon
  await t('crypto: an exchange hack scores risk-off with real impact', () => {
    const s = scoreHeadline('Major exchange hack drains $200M, withdrawals halted');
    assert.ok(s.tone < 0, `tone must be negative, got ${s.tone}`);
    assert.ok(s.impact > 0.3, `impact must be material, got ${s.impact}`);
    assert.ok(s.tags.includes('crypto_risk_off'), JSON.stringify(s.tags));
  });

  await t('crypto: an ETF inflow scores risk-on', () => {
    const s = scoreHeadline('Spot bitcoin ETF inflow hits record high');
    assert.ok(s.tone > 0, `tone must be positive, got ${s.tone}`);
    assert.ok(s.tags.includes('crypto_risk_on'), JSON.stringify(s.tags));
  });

  await t('crypto: a stablecoin depeg is treated as a shock, not noise', () => {
    const s = scoreHeadline('Stablecoin depeg triggers liquidation cascade');
    assert.ok(s.tone < 0);
    assert.ok(s.impact > 0.3, `impact ${s.impact}`);
  });

  await t('crypto: a neutral headline still scores zero tone', () => {
    const s = scoreHeadline('Bitcoin trades sideways ahead of the weekend');
    assert.strictEqual(s.tone, 0);
    assert.strictEqual(s.impact, 0);
  });

  await t('crypto: the lexicon lists are non-empty and disjoint from macro', () => {
    assert.ok(LEXICON.cryptoRiskOff.length >= 10);
    assert.ok(LEXICON.cryptoRiskOn.length >= 8);
    // "hack" must not be in the macro risk-off list, or the two families would
    // double-count the same word and inflate impact.
    assert.ok(!LEXICON.riskOff.includes('hack'));
  });

  // ------------------------------------------------------- feed families
  const feedCfg = (over = {}) => ({
    enabled: true,
    timeoutMs: 5000,
    retry429: 0,
    feeds: {
      crypto: { url: COINDESK, weight: 0.9, format: 'rss', fallbackUrl: COINTELEGRAPH, fallbackFormat: 'rss', ...over.crypto },
      wire: { url: GOOGLENEWS, weight: 0.9, format: 'rss', fallbackUrl: BBC, fallbackFormat: 'rss', ...over.wire },
    },
  });

  await t('feeds: crypto and wire are both read and counted per family', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(['Exchange hack drains funds', 'ETF inflow record high']) },
      [GOOGLENEWS]: { body: RSS(['Fed holds rates steady', 'Markets rally on trade deal']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    const view = await intel.refresh();

    assert.strictEqual(view.items, 4, 'all four headlines must be counted');
    assert.strictEqual(view.byFeed.crypto, 2);
    assert.strictEqual(view.byFeed.wire, 2);
    assert.strictEqual(intel.feedStatus.crypto.source, 'primary');
    assert.strictEqual(intel.feedStatus.wire.source, 'primary');
  });

  await t('feeds: CoinDesk failing falls through to Cointelegraph', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { status: 308, body: '' },
      [COINTELEGRAPH]: { body: RSS(['Bitcoin ETF approval expected']) },
      [GOOGLENEWS]: { body: RSS(['Stocks slip']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(intel.feedStatus.crypto.ok, true);
    assert.strictEqual(intel.feedStatus.crypto.source, 'fallback');
  });

  await t('feeds: a dead wire feed is reported failed, never silently empty', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(['ETF inflow']) },
      [GOOGLENEWS]: { status: 401, body: 'unauthorized' },
      [BBC]: { status: 503, body: 'down' },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(intel.feedStatus.wire.ok, false);
    assert.match(intel.feedStatus.wire.error, /401/);
  });

  await t('feeds: top headlines carry their family so the report can label them', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(['Exchange hack drains $200M']) },
      [GOOGLENEWS]: { body: RSS(['Fed signals rate hike']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    const view = await intel.refresh();
    assert.ok(view.top.length >= 2);
    for (const item of view.top) assert.ok(['crypto', 'wire'].includes(item.feed), JSON.stringify(item));
  });

  // ------------------------------------------------------------- digest
  await t('digest: disabled module says so instead of pretending', () => {
    const intel = new Intel({ cfg: { enabled: false }, log: quietLog() });
    assert.match(intel.digest(), /خاموش/);
  });

  await t('digest: enabled but never refreshed says so', () => {
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl: stubFetch({}) });
    assert.match(intel.digest(), /هنوز خبری خوانده نشده/);
  });

  await t('digest: names the fallback sources instead of claiming the primary', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { status: 429, body: 'rate limited' },
      [COINTELEGRAPH]: { body: RSS(['ETF inflow record']) },
      [GOOGLENEWS]: { body: RSS(['Fed holds']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    const d = intel.digest();
    assert.match(d, /پشتیبان/, d);
    assert.match(d, /crypto/, d);
    assert.match(d, /wire/, d);
  });

  await t('digest: a blackout is stated as a blocked-entry window', async () => {
    const now = Date.parse('2026-11-22T12:00:00Z');
    const view = aggregate(
      [{ title: 'FOMC rate decision due', ts: now + 10 * 60 * 1000, feed: 'macro', weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    assert.strictEqual(view.blackout, true);
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl: stubFetch({}) });
    intel.last = view;
    intel.feedStatus = { macro: { ok: true, source: 'primary', items: 1 } };
    const d = intel.digest();
    assert.match(d, /توقف/, d);
    assert.match(d, /FOMC/, d);
  });

  await t('digest: never exceeds a phone-sized message', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(Array.from({ length: 40 }, (_, i) => `Exchange hack number ${i}`)) },
      [GOOGLENEWS]: { body: RSS(Array.from({ length: 40 }, (_, i) => `Fed rate hike number ${i}`)) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.ok(intel.digest().length < 1200, `digest is ${intel.digest().length} chars`);
  });

  // -------------------------------------------------- reporter integration
  const mkReporter = (intel) => {
    const cfg = loadConfig({ server: { enabled: false } });
    const store = {
      state: { equity: 5000, lastReportAt: 0, reportedRounds: 0 },
      append() {},
      saveState() {},
    };
    return new Reporter({
      cfg,
      log: quietLog(),
      store,
      trader: { observations: [], trades: [] },
      portfolio: { openPositions: () => [], unrealisedTotal: () => 0 },
      risk: { state: { equity: 5000, counters: { tradesToday: 0 } }, drawdownPct: () => 0 },
      scout: { stats: { proposed: 0, skipped: {} } },
      board: { votes: [], stats: { sessions: 0, approved: 0, rejected: 0 } },
      auditor: { summary: () => ({ alerts: 0, criticals: 0, latest: {}, recent: [] }) },
      witness: null,
      learner: { snapshot: () => ({ arms: [], params: {}, recentChanges: [] }) },
      jev: { stats: () => ({ p50: 0, p99: 0, sent: 0, aborted: 0, budgetMs: 400 }) },
      hub: null,
      intel,
    });
  };

  await t('reporter: the markdown report carries a market-intel section', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(['Exchange hack drains $200M']) },
      [GOOGLENEWS]: { body: RSS(['Fed signals rate hike']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();

    const rep = mkReporter(intel);
    const r = rep.build(Date.now() - 3600000, Date.now());
    const md = rep.renderMarkdown(r);

    assert.ok(md.includes('هوش بازار'), 'the section heading must be present');
    assert.ok(md.includes('خبر خوانده‌شده'), 'the digest body must be present');
    assert.ok(r.intel && r.intel.enabled === true, 'the JSON report must carry the intel block');
    assert.ok(Number.isFinite(r.intel.riskMultiplier), 'risk multiplier must be a number');
  });

  await t('reporter: a report renders with no intel module at all', () => {
    const rep = mkReporter(null);
    const r = rep.build(Date.now() - 3600000, Date.now());
    const md = rep.renderMarkdown(r);
    assert.ok(md.length > 500, 'the report must still render');
    assert.strictEqual(r.intel, null);
    assert.ok(!md.includes('هوش بازار (اخبار)'), 'no empty section when the module is absent');
  });

  await t('reporter: the intel risk multiplier in the report can never exceed 1', async () => {
    const fetchImpl = stubFetch({
      [COINDESK]: { body: RSS(['ETF inflow record high', 'Institutional adoption surges', 'All-time high reached']) },
      [GOOGLENEWS]: { body: RSS(['Ceasefire deal reached', 'Markets rally on recovery']) },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    const rep = mkReporter(intel);
    const r = rep.build(Date.now() - 3600000, Date.now());
    assert.ok(r.intel.riskMultiplier <= 1, `got ${r.intel.riskMultiplier}`);
    assert.ok(r.intel.riskMultiplier >= 0.75, `got ${r.intel.riskMultiplier}`);
  });

  // ------------------------------------------- FOMC blackout, engine path
  await t('blackout: an FOMC item 10 minutes out blocks entries via bias()', () => {
    const now = Date.parse('2026-11-22T12:00:00Z');
    const view = aggregate(
      [{ title: 'FOMC statement and rate decision', ts: now + 10 * 60 * 1000, feed: 'macro', weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl: stubFetch({}) });
    intel.last = view;
    const b = intel.bias();
    assert.strictEqual(b.blackout, true);
    assert.match(b.reason, /FOMC/);
    // The engine reads exactly this: a blackout floors the multiplier.
    assert.strictEqual(intel.riskMultiplier(), 1 - intel.cfg.maxRiskImpact);
  });

  await t('blackout: an FOMC item 3 hours out does NOT block entries', () => {
    const now = Date.parse('2026-11-22T12:00:00Z');
    const view = aggregate(
      [{ title: 'FOMC statement and rate decision', ts: now + 3 * 3600 * 1000, feed: 'macro', weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl: stubFetch({}) });
    intel.last = view;
    assert.strictEqual(intel.bias().blackout, false);
  });

  await t('blackout: the window closes 15 minutes after the event', () => {
    const now = Date.parse('2026-11-22T12:00:00Z');
    const inside = aggregate(
      [{ title: 'FOMC decision', ts: now - 10 * 60 * 1000, feed: 'macro', weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    const outside = aggregate(
      [{ title: 'FOMC decision', ts: now - 20 * 60 * 1000, feed: 'macro', weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    assert.strictEqual(inside.blackout, true, '10 min after the event is still inside');
    assert.strictEqual(outside.blackout, false, '20 min after the event is outside');
  });

  await t('blackout: a crypto hack does NOT create a blackout (it is not scheduled)', () => {
    const now = Date.parse('2026-11-22T12:00:00Z');
    const view = aggregate(
      [{ title: 'Exchange hack drains funds', ts: now + 5 * 60 * 1000, feed: 'crypto', weight: 0.9 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    // A hack is a shock, not a scheduled event: it must move the tone, not
    // freeze the book. Freezing on every headline is how a bot stops trading.
    assert.strictEqual(view.blackout, false);
    assert.ok(view.tone < 0, 'but it must still push the tone down');
  });

  // ------------------------------------------------------------ config
  await t('config: the two new families exist with sane defaults', () => {
    const cfg = loadConfig({ server: { enabled: false } });
    assert.ok(cfg.intel.feeds.crypto, 'crypto family must exist');
    assert.ok(cfg.intel.feeds.wire, 'wire family must exist');
    assert.strictEqual(cfg.intel.feeds.crypto.format, 'rss');
    assert.strictEqual(cfg.intel.feeds.wire.format, 'rss');
    assert.ok(cfg.intel.feeds.crypto.weight > 0);
    assert.ok(cfg.intel.feeds.wire.weight > 0);
  });

  await t('config: INTEL_CRYPTO_URL / INTEL_WIRE_URL are mapped from the panel', () => {
    const { ENV_MAP } = require(path.join(SRC, 'config'));
    // ENV_MAP is not exported; assert through the loader instead.
    const before = process.env.INTEL_CRYPTO_URL;
    process.env.INTEL_CRYPTO_URL = 'https://example.test/crypto.xml';
    process.env.INTEL_WIRE_URL = 'https://example.test/wire.xml';
    try {
      const cfg = loadConfig({ server: { enabled: false } });
      assert.strictEqual(cfg.intel.feeds.crypto.url, 'https://example.test/crypto.xml');
      assert.strictEqual(cfg.intel.feeds.wire.url, 'https://example.test/wire.xml');
    } finally {
      if (before === undefined) delete process.env.INTEL_CRYPTO_URL;
      else process.env.INTEL_CRYPTO_URL = before;
      delete process.env.INTEL_WIRE_URL;
    }
  });

  await t('config: no duplicate keys in ENV_MAP (a duplicate silently kills a variable)', () => {
    const src = require('node:fs').readFileSync(path.join(SRC, 'config.js'), 'utf8');
    const block = src.slice(src.indexOf('const ENV_MAP = {'), src.indexOf('function deepMerge'));
    const keys = [...block.matchAll(/^\s{2}([A-Z0-9_]+):\s*\[/gm)].map((m) => m[1]);
    const seen = new Set();
    const dupes = [];
    for (const k of keys) {
      if (seen.has(k)) dupes.push(k);
      seen.add(k);
    }
    assert.deepStrictEqual(dupes, [], `duplicate ENV_MAP keys: ${dupes.join(', ')}`);
  });

  done('v14');
})();
