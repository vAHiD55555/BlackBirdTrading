#!/usr/bin/env node
'use strict';
/**
 * Regression: the trailing stop must follow the charter's LADDER (§12), not a
 * single distance.
 *
 * THE BUG THIS LOCKS DOWN
 * -----------------------
 * The 6-month replay (4320 x 1h bars, BTC/ETH/SOL/XRP from MEXC) closed 69
 * trades and EVERY ONE of them exited with reason `stop` — including the
 * winners, which booked +0.08%, +0.09%, +0.30%. The old `_trail()` jumped
 * straight to a 2-ATR trail once the trade was 2 ATR in profit. Because the
 * disaster stop is 6 ATR, "2 ATR of profit" is only a third of one R: the stop
 * was already above the entry before the trade had earned a full R, so any
 * normal pullback closed it for almost nothing.
 *
 * Baseline vs fixed, same data, same config:
 *   return  +0.74%  ->  +5.53%
 *   PF       1.05   ->   1.31
 *   Sharpe  0.0028  ->  0.0141
 *
 * These tests FAIL on the old code and PASS on the ladder.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Rotator } = require('../src/strategy/rotator');
const { Portfolio, Position } = require('../src/exec/portfolio');

const noop = () => {};
const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };

function makeCfg(rotatorOver = {}) {
  return {
    symbols: ['BTCUSDT'],
    fees: { makerBps: 2, takerBps: 5, slippageBpsPer1kNotional: 0.6, latencyMs: 0 },
    data: { staleQuoteMs: 60000, intervalMs: 3600000 },
    risk: { startEquity: 5000, minNotionalUsd: 15 },
    strategy: {
      rotator: {
        rebalanceHours: 168, perPositionPct: 9, maxGrossPct: 70, disasterStopAtr: 6,
        maxPositions: 6, minNotionalUsd: 15, corePct: 0,
        ...rotatorOver,
      },
    },
  };
}

/**
 * One long at 100 with ATR 1, so R = disasterStopAtr * atr = 6 price units.
 * The disaster stop sits at 94, exactly 1R below the entry.
 */
function makeRig(rotatorOver = {}, side = 'long') {
  const cfg = makeCfg(rotatorOver);
  const portfolio = new Portfolio(log);
  const rotator = new Rotator({
    cfg, log, store: { state: {}, append: noop, saveState: noop },
    risk: { state: { equity: 5000 }, settle: noop },
    portfolio,
    broker: { submit: () => ({ status: 'filled', price: 100, fee: 0.1, qty: 1 }) },
    hub: { get: () => null, primary: null },
    bus: { emit: noop },
    now: () => 1792627200000,
  });
  const pos = new Position({
    symbol: 'BTCUSDT', side, qty: 1, entry: 100, fee: 0.1, notional: 100,
    strategy: 'ORBITAL', tp: null, sl: side === 'long' ? 94 : 106, timeStopAt: 0,
    context: { variant: 'orbital', atr: 1, pct: 9, scale: 1 },
    openedAt: 1792627200000,
  });
  portfolio.open(pos);
  return { rotator, portfolio, pos };
}

const tick = (rotator, px) => rotator.onTick({ symbol: 'BTCUSDT', bid: px, ask: px, last: px });

(async () => {
  console.log('\n▸ trail ladder — charter §12 (breakeven at 1R, lock 1R at 2R)');

  await t('below 1R the structural stop does not move', () => {
    const { rotator, pos } = makeRig();
    tick(rotator, 103); // +3 of a 6-unit R
    assert.strictEqual(pos.sl, 94, 'a half-R move must not tighten the stop');
  });

  await t('at 1R the stop moves to the entry price (breakeven)', () => {
    const { rotator, pos } = makeRig();
    tick(rotator, 106); // exactly 1R
    assert.strictEqual(pos.sl, 100, `stop should be at breakeven, got ${pos.sl}`);
  });

  await t('at 2R at least 1R of profit is locked in', () => {
    const { rotator, pos } = makeRig();
    tick(rotator, 112); // exactly 2R
    assert.ok(pos.sl >= 106, `stop should lock 1R (>=106), got ${pos.sl}`);
  });

  await t('past 2R the stop trails 1.5 ATR behind the best price', () => {
    const { rotator, pos } = makeRig();
    tick(rotator, 120); // 3.33R
    // locked = 106, trailed = 120 - 1.5 = 118.5 -> the tighter one wins
    assert.ok(Math.abs(pos.sl - 118.5) < 1e-9, `expected 118.5, got ${pos.sl}`);
  });

  await t('a pullback never loosens the stop', () => {
    const { rotator, pos } = makeRig();
    tick(rotator, 120);
    const after = pos.sl;
    tick(rotator, 110);
    assert.strictEqual(pos.sl, after, 'the stop may only move toward less risk');
  });

  await t('a short mirrors the ladder downward', () => {
    const { rotator, pos } = makeRig({}, 'short');
    tick(rotator, 94); // 1R in favour
    assert.strictEqual(pos.sl, 100, `short stop should be at breakeven, got ${pos.sl}`);
    tick(rotator, 88); // 2R
    assert.ok(pos.sl <= 94, `short stop should lock 1R (<=94), got ${pos.sl}`);
  });

  await t('the ladder is tunable from the panel', () => {
    const { rotator, pos } = makeRig({ trailBeAtR: 0.5, trailLockAtR: 1, trailLockR: 0.5, trailAtr: 1 });
    tick(rotator, 103); // 0.5R -> breakeven under the overridden ladder
    assert.strictEqual(pos.sl, 100, `override should move the stop at 0.5R, got ${pos.sl}`);
  });

  await t('trailing can still be switched off from the panel', () => {
    const { rotator, pos } = makeRig({ trailEnabled: false });
    tick(rotator, 120);
    assert.strictEqual(pos.sl, 94, 'trailEnabled=false must leave the stop alone');
  });

  done('trail-ladder');
})();
