#!/usr/bin/env node
'use strict';
/**
 * Regression tests for the charter-compliance fixes in v6.
 *
 * Every test here reproduces a bug that was actually shipped in v5 and fails
 * against that code. Run: node tests/charter-fixes.test.js
 */
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { t, done } = require('./harness');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'src');

// ---------------------------------------------------------------- helpers
/** Load config with a clean env so a developer's shell cannot skew the result. */
function freshConfig(env = {}) {
  const saved = {};
  const keys = [
    'MODE', 'EXCHANGE', 'SYMBOLS', 'START_EQUITY', 'MAX_DAILY_LOSS_PCT',
    'MAX_DAILY_TRADES', 'MAKER_FEE_BPS', 'TAKER_FEE_BPS', 'WATCH_ENABLED',
    'WATCH_INTERVAL_MS', 'WATCH_AUTO_APPLY', 'WATCH_MAX_SWAPS_PER_CYCLE',
    'WITNESS_UPDATE_MS', 'WITNESS_ENABLED', 'BB_CONFIG', 'BB_ENV_FILE',
  ];
  for (const k of keys) { saved[k] = process.env[k]; delete process.env[k]; }
  process.env.BB_ENV_FILE = path.join(os.tmpdir(), 'bb-no-such-env-file');
  Object.assign(process.env, env);
  delete require.cache[require.resolve(path.join(SRC, 'config'))];
  const cfg = require(path.join(SRC, 'config')).loadConfig();
  for (const k of keys) {
    if (saved[k] === undefined) delete process.env[k];
    else process.env[k] = saved[k];
  }
  return cfg;
}

// ================================================================ tests
(async () => {
  console.log('\n▸ charter fixes — regression suite');

  // ---- BUG 1: fees were 3.75x the charter (7.5/10 instead of 2/5) ---------
  await t('fees default to the charter values (maker 2bps, taker 5bps)', () => {
    const cfg = freshConfig();
    assert.strictEqual(cfg.fees.makerBps, 2, `makerBps was ${cfg.fees.makerBps}, charter §14 says 2`);
    assert.strictEqual(cfg.fees.takerBps, 5, `takerBps was ${cfg.fees.takerBps}, charter §14 says 5`);
  });

  // ---- BUG 2: daily loss / trade caps were looser than the charter --------
  await t('risk caps match charter §7 (4% daily loss, 30 trades)', () => {
    const cfg = freshConfig();
    assert.strictEqual(cfg.risk.maxDailyLossPct, 0.04, `maxDailyLossPct was ${cfg.risk.maxDailyLossPct}`);
    assert.strictEqual(cfg.risk.maxDailyTrades, 30, `maxDailyTrades was ${cfg.risk.maxDailyTrades}`);
  });

  // ---- BUG 3: WATCH_* env vars were documented but not mapped ------------
  await t('WATCH_ENABLED=false from the panel actually disables the watch', () => {
    const cfg = freshConfig({ WATCH_ENABLED: 'false' });
    assert.strictEqual(cfg.watch.enabled, false, 'WATCH_ENABLED=false was ignored: the watch kept running');
  });

  await t('WATCH_INTERVAL_MS from the panel overrides the 6h default', () => {
    const cfg = freshConfig({ WATCH_INTERVAL_MS: '3600000' });
    assert.strictEqual(cfg.watch.intervalMs, 3600000, 'WATCH_INTERVAL_MS was ignored');
  });

  await t('WATCH_AUTO_APPLY and WATCH_MAX_SWAPS_PER_CYCLE are panel-tunable', () => {
    const cfg = freshConfig({ WATCH_AUTO_APPLY: 'true', WATCH_MAX_SWAPS_PER_CYCLE: '3' });
    assert.strictEqual(cfg.watch.autoApply, true, 'WATCH_AUTO_APPLY was ignored');
    assert.strictEqual(cfg.watch.maxSwapsPerCycle, 3, 'WATCH_MAX_SWAPS_PER_CYCLE was ignored');
  });

  // ---- BUG 4: witness refresh was hard-coded at 5s -----------------------
  await t('witness.updateMs exists in config and defaults to the charter 5s', () => {
    const cfg = freshConfig();
    assert.strictEqual(cfg.witness.updateMs, 5000, 'witness.updateMs is missing from DEFAULTS');
  });

  await t('WITNESS_UPDATE_MS from the panel overrides the witness refresh', () => {
    const cfg = freshConfig({ WITNESS_UPDATE_MS: '30000' });
    assert.strictEqual(cfg.witness.updateMs, 30000, 'WITNESS_UPDATE_MS was ignored');
  });

  await t('Witness.start() uses cfg.witness.updateMs, not a hard-coded 5000', async () => {
    const { Witness } = require(path.join(SRC, 'agents/witness'));
    const noop = () => {};
    const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };
    const w = new Witness({
      cfg: { symbols: [], witness: { updateMs: 12345 } },
      log,
      store: { append: noop, readJournal: () => [] },
      exchange: null,
    });
    await w.start();
    // setInterval returns a Timeout; its _idleTimeout is the delay in ms.
    const delay = w.timer && (w.timer._idleTimeout || w.timer._idleStart);
    clearInterval(w.timer);
    assert.strictEqual(delay, 12345, `witness polled every ${delay}ms instead of the configured 12345ms`);
  });

  // ---- BUG 5: unknown config.json keys were dropped in silence -----------
  await t('an unknown config.json key is reported, not silently ignored', () => {
    const tmp = path.join(os.tmpdir(), `bb-cfg-${process.pid}.json`);
    fs.writeFileSync(tmp, JSON.stringify({ witness: { maxDivergenceBps: 35 }, PROFILE: 'x' }));
    const errs = [];
    const orig = console.error;
    console.error = (...a) => errs.push(a.join(' '));
    try {
      freshConfig({ BB_CONFIG: tmp });
    } finally {
      console.error = orig;
      fs.unlinkSync(tmp);
    }
    const text = errs.join('\n');
    assert.ok(/witness\.maxDivergenceBps/.test(text), 'the dead key witness.maxDivergenceBps was not reported');
    assert.ok(/PROFILE/.test(text), 'the dead key PROFILE was not reported');
  });

  // ---- BUG 6: the shipped zip leaked .env (a live bot token) -------------
  await t('make-zip never includes .env, even when it exists on disk', () => {
    const { buildZip } = require(path.join(ROOT, 'scripts/make-zip'));
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-zip-'));
    fs.writeFileSync(path.join(tmpRoot, '.env'), 'TELEGRAM_BOT_TOKEN=secret\n');
    fs.writeFileSync(path.join(tmpRoot, '.env.example'), 'TELEGRAM_BOT_TOKEN=\n');
    fs.writeFileSync(path.join(tmpRoot, 'index.js'), '// code\n');
    const out = path.join(tmpRoot, 'out.zip');
    buildZip(tmpRoot, out);
    const buf = fs.readFileSync(out);
    const names = buf.toString('latin1');
    assert.ok(!/\.env[^.]/.test(names.replace(/\.env\.example/g, '')), 'the zip contains .env');
    assert.ok(names.includes('.env.example'), '.env.example should still ship');
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  // ---- BUG 7: run10b/data (a previous run's journal) shipped in the zip --
  await t('make-zip excludes nested run data directories', () => {
    const { buildZip } = require(path.join(ROOT, 'scripts/make-zip'));
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-zip2-'));
    fs.mkdirSync(path.join(tmpRoot, 'run10b', 'data'), { recursive: true });
    fs.writeFileSync(path.join(tmpRoot, 'run10b', 'data', 'journal.jsonl'), '{"x":1}\n');
    fs.writeFileSync(path.join(tmpRoot, 'index.js'), '// code\n');
    const out = path.join(tmpRoot, 'out.zip');
    buildZip(tmpRoot, out);
    const names = fs.readFileSync(out).toString('latin1');
    assert.ok(!names.includes('run10b/data/journal.jsonl'), 'a previous run journal shipped in the zip');
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  // The label must match the suite name in tests/run.js exactly, otherwise the
  // parent runner cannot parse the result line.
  done('charter-fixes');
})();
