'use strict';
/**
 * Regression tests for the keyless provider chain.
 *
 * BUG THIS LOCKS DOWN
 * -------------------
 * `jev.keylessFallback` was documented in .env.example and in DEFAULTS for two
 * releases while NOTHING read it. A dead provider meant a dead cycle: the
 * documented promise ("try the keyless ones before giving up") was never true.
 *
 * Second bug, found while fixing the first: the shipped default was `ollama`,
 * a LOCAL endpoint. On a hosted free tier (botkeep.cloud) 127.0.0.1 is the
 * container itself, so the default could never answer — every jev cycle would
 * burn a full timeout and degrade.
 *
 * These tests fail on the old code and pass on the fixed code.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Jev } = require('../src/jev/jev');
const { MockProvider } = require('../src/jev/providers');
const { isKeyless, isLocalOnly, entry } = require('../src/jev/providers/catalog');

const silent = { info() {}, warn() {}, error() {}, debug() {}, child() { return this; } };

/** A provider that always throws, standing in for a dead endpoint. */
class DeadProvider {
  constructor(name) { this.name = name; this.calls = 0; }
  async complete() { this.calls++; throw new Error(`${this.name} is down`); }
}

(async () => {
  console.log('\n▸ keyless chain — the documented fallback actually runs');

  await t('the catalog knows GrexLabs is keyless and remote', () => {
    assert.strictEqual(isKeyless('grex'), true, 'grex must need no key');
    assert.strictEqual(isLocalOnly('grex'), false, 'grex must be remote');
    const cat = entry('grex');
    assert.strictEqual(cat.baseUrl, 'https://www.grexlabs.in/api/v1');
    assert.strictEqual(cat.chatPath, '/chat/completions');
    assert.strictEqual(cat.models[0], 'auto:free');
  });

  await t('the catalog knows pollinations is keyless and remote', () => {
    assert.strictEqual(isKeyless('pollinations'), true, 'pollinations must need no key');
    assert.strictEqual(isLocalOnly('pollinations'), false, 'pollinations must not be local-only');
    assert.strictEqual(isLocalOnly('ollama'), true, 'ollama must be marked local-only');
    const cat = entry('pollinations');
    assert.strictEqual(cat.chatPath, '/openai', 'pollinations serves its OpenAI API at /openai');
  });

  await t('a dead primary falls through to the next provider in the chain', async () => {
    const dead = new DeadProvider('primary');
    const backup = new MockProvider({ defaultReply: '{"action":"hold"}' });
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', model: 'openai', keylessFallback: ['mock'] },
      log: silent,
      provider: dead,
      env: {},
    });
    // Inject the chain by hand: the constructor only builds one when no
    // provider is injected, and here we want to control both ends.
    jev._chain = [
      { name: 'pollinations', provider: dead },
      { name: 'mock', provider: backup },
    ];
    const out = await jev._complete([{ role: 'user', content: 'hi' }]);
    assert.strictEqual(dead.calls, 1, 'the primary must be tried first');
    assert.strictEqual(out.via, 'mock', 'the answer must come from the fallback');
    assert.strictEqual(out.text, '{"action":"hold"}');
  });

  await t('the chain never contains a local-only provider unless allowLocal is on', () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: ['ollama', 'mock'], allowLocal: false },
      log: silent,
      env: {},
    });
    jev._buildChain();
    const names = jev._chain.map((c) => c.name);
    assert.ok(!names.includes('ollama'), `ollama must be skipped on a hosted host, got ${names.join(',')}`);
    assert.ok(names.includes('mock'), 'mock must always be the last resort');
  });

  await t('allowLocal=true brings the local provider back', () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: ['ollama', 'mock'], allowLocal: true },
      log: silent,
      env: {},
    });
    jev._buildChain();
    const names = jev._chain.map((c) => c.name);
    assert.ok(names.includes('ollama'), `allowLocal must re-enable ollama, got ${names.join(',')}`);
  });

  await t('a provider that needs a key is skipped when the key is absent', () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: ['groq', 'mock'] },
      log: silent,
      env: {}, // no GROQ_API_KEY
    });
    jev._buildChain();
    const names = jev._chain.map((c) => c.name);
    assert.ok(!names.includes('groq'), `groq must be skipped without a key, got ${names.join(',')}`);
  });

  await t('a provider that needs a key is included when the key is present', () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: ['groq', 'mock'] },
      log: silent,
      env: { GROQ_API_KEY: 'gsk_test_key_value' },
    });
    jev._buildChain();
    const names = jev._chain.map((c) => c.name);
    assert.ok(names.includes('groq'), `groq must be included with a key, got ${names.join(',')}`);
  });

  await t('the chain is never empty: mock is always appended', () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: [] },
      log: silent,
      env: {},
    });
    jev._buildChain();
    assert.ok(jev._chain.length >= 1, 'the chain must never be empty');
    assert.strictEqual(jev._chain[jev._chain.length - 1].name, 'mock');
  });

  await t('every provider failing throws, and the caller degrades instead of crashing', async () => {
    const jev = new Jev({
      cfg: { enabled: true, provider: 'pollinations', keylessFallback: ['mock'] },
      log: silent,
      provider: new DeadProvider('a'),
      env: {},
    });
    jev._chain = [
      { name: 'a', provider: new DeadProvider('a') },
      { name: 'b', provider: new DeadProvider('b') },
    ];
    await assert.rejects(() => jev._complete([{ role: 'user', content: 'hi' }]), /is down/);
  });

  done('keyless-chain');
})();
