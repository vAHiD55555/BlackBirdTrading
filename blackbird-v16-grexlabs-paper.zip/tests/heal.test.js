'use strict';
/**
 * Self-healing supervisor — rules, model escalation and the safety contract.
 * Offline and deterministic: the clock and the model are both injected.
 */
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Healer } = require(path.join(SRC, 'supervisor/heal'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/** Minimal engine surface the healer is allowed to touch. */
function fakeEngine({ degraded = ['BTCUSDT'], exchange = 'mexc', halted = false } = {}) {
  const calls = { switchVenue: [], paused: 0 };
  const engine = {
    calls,
    cfg: { exchange, witnessExchange: 'bitget', symbols: ['BTCUSDT', 'ETHUSDT'] },
    hub: { healthy: degraded.length === 0, degraded: new Set(degraded) },
    risk: { halted },
    health: () => ({ feedsDegraded: degraded.length }),
    async switchVenue(id) {
      calls.switchVenue.push(id);
      engine.cfg.exchange = id;
      return { ok: true, from: exchange, to: id };
    },
  };
  return engine;
}

function memStore() {
  const entries = [];
  return { entries, append: (type, data) => entries.push({ type, data }) };
}

function clockAt() {
  let t0 = 1700000000000;
  return { now: () => t0, advance: (ms) => { t0 += ms; } };
}

function make(opts = {}) {
  const clock = clockAt();
  const engine = opts.engine || fakeEngine(opts.engineOpts);
  const store = memStore();
  const cfg = {
    exchange: engine.cfg.exchange,
    witnessExchange: 'bitget',
    symbols: engine.cfg.symbols,
    heal: {
      checkEveryMs: 0,
      feedOutageMs: opts.feedOutageMs ?? 60000,
      staleProgressMs: opts.staleProgressMs ?? 600000,
      maxActionsPerHour: opts.maxActionsPerHour ?? 10,
      actionCooldownMs: 0,
      pauseEntriesMinutes: opts.pauseEntriesMinutes ?? 30,
      reduceGrossFactor: 0.5,
      fallbackExchanges: opts.fallbacks || ['bitget', 'mexc', 'bybit'],
      model: {
        enabled: Boolean(opts.model),
        baseUrl: opts.model ? 'https://model.test/v1' : '',
        model: 'test-model',
        apiKeyEnv: 'ADVISOR_API_KEY',
        timeoutMs: 1000,
      },
    },
  };
  const fetchImpl = opts.fetchImpl || null;
  const healer = new Healer({ cfg, log: quietLog(), engine, store, clock: clock.now, fetchImpl });
  return { healer, engine, store, clock, cfg };
}

const jsonFetch = (body, status = 200) => async () => ({
  ok: status >= 200 && status < 300,
  status,
  async json() {
    return { choices: [{ message: { content: typeof body === 'string' ? body : JSON.stringify(body) } }] };
  },
});

(async () => {
  process.env.ADVISOR_API_KEY = 'test-key';

  await t('feed outage on the primary venue switches to the next independent venue', async () => {
    const { healer, engine } = make({ feedOutageMs: 1000 });
    await healer.check(); // records the incident
    assert(engine.calls.switchVenue.length === 0, 'must not act before the outage window elapses');
    healer.clock = () => Date.now();
    // age the incident past the window
    healer.incidents.feeds_down -= 5000;
    const r = await healer.check();
    assert(engine.calls.switchVenue.length === 1, 'venue switch should have been requested');
    // bitget is the witness and must never be chosen
    assert(engine.calls.switchVenue[0] !== 'bitget', 'witness must stay independent');
    assert(r.action.action === 'switch_venue', JSON.stringify(r.action));
  });

  await t('the witness venue is never a failover target', async () => {
    const { healer, engine } = make({ fallbacks: ['bitget'], feedOutageMs: 0 });
    await healer.check();
    assert(engine.calls.switchVenue.length === 0, 'bitget is the witness');
    assert(healer.entriesPaused === true, 'with no allowed venue it must pause entries instead');
  });

  await t('no fallback venue means entries are paused, not left open', async () => {
    const { healer, engine } = make({ fallbacks: [], feedOutageMs: 0 });
    const until = () => healer.entriesPaused;
    assert(until() === false, 'nothing paused before the check');
    await healer.check();
    assert(engine.calls.switchVenue.length === 0);
    assert(until() === true, 'entries must be paused');
  });

  await t('no_progress pauses entries', async () => {
    const engine = fakeEngine({ degraded: [] });
    const { healer, clock } = make({ engine, staleProgressMs: 1000 });
    clock.advance(5000);
    const r = await healer.check();
    assert(r.action.action === 'pause_entries', JSON.stringify(r.action));
  });

  await t('a model cannot widen risk: an off-list action becomes noop', async () => {
    const { healer, engine } = make({
      model: true,
      feedOutageMs: 0,
      fetchImpl: jsonFetch({ action: 'increase_leverage', reason: 'more profit' }),
    });
    const r = await healer.check();
    assert(r.action.action === 'noop', JSON.stringify(r.action));
    assert(engine.calls.switchVenue.length === 0, 'nothing may be executed');
    assert(healer.scale === 1, 'exposure must not be raised');
  });

  await t('a model cannot send the data feed to the witness venue', async () => {
    const { healer, engine } = make({
      model: true,
      feedOutageMs: 0,
      fetchImpl: jsonFetch({ action: 'switch_venue', venue: 'bitget', reason: 'try the other one' }),
    });
    await healer.check();
    assert(!engine.calls.switchVenue.includes('bitget'), 'the witness venue must never be the primary feed');
  });

  await t('a model may choose a risk-reducing action and it is applied', async () => {
    const engine = fakeEngine({ degraded: [] });
    const { healer } = make({
      engine,
      model: true,
      staleProgressMs: 1000,
      fetchImpl: jsonFetch({ action: 'reduce_gross', reason: 'tape went quiet' }),
    });
    const clock = clockAt();
    healer.clock = clock.now;
    healer.lastProgressAt = clock.now() - 5000;
    const r = await healer.check();
    assert(r.action.action === 'reduce_gross', JSON.stringify(r.action));
    assert(r.action.source === 'model', `source=${r.action.source}`);
    assert(healer.scale === 0.5, `scale=${healer.scale}`);
  });

  await t('a failing model falls back to the deterministic rule', async () => {
    const engine = fakeEngine({ degraded: [] });
    const { healer } = make({
      engine,
      model: true,
      staleProgressMs: 1000,
      fetchImpl: async () => { throw new Error('network down'); },
    });
    const clock = clockAt();
    healer.clock = clock.now;
    healer.lastProgressAt = clock.now() - 5000;
    const r = await healer.check();
    assert(r.action.action === 'pause_entries', JSON.stringify(r.action));
    assert(r.action.source === 'rule_fallback', `source=${r.action.source}`);
  });

  await t('the hourly action cap is enforced', async () => {
    const engine = fakeEngine({ degraded: [] });
    const { healer } = make({ engine, staleProgressMs: 1000, maxActionsPerHour: 1, pauseEntriesMinutes: 1 });
    healer.lastProgressAt = healer.clock() - 5000;
    await healer.check();
    assert(healer.actionLog.length === 1, `actions=${healer.actionLog.length}`);
    // force the pause to expire so a second attempt is not swallowed by the cooldown
    healer.entriesPausedUntil = 0;
    await healer.check();
    assert(healer.actionLog.length === 1, 'the cap must block the second action');
  });

  await t('a halted book is never resumed by the supervisor', async () => {
    const engine = fakeEngine({ degraded: [], halted: true });
    const { healer } = make({ engine, feedOutageMs: 0 });
    await healer.check();
    assert(engine.risk.halted === true, 'halt must stay sticky');
    assert(typeof engine.risk.resume !== 'function', 'the healer never calls a resume path');
  });

  await t('every action is journaled with its reason', async () => {
    const { healer, store } = make({ fallbacks: [], feedOutageMs: 0 });
    await healer.check();
    const actions = store.entries.filter((e) => e.type === 'heal_action');
    assert(actions.length === 1, JSON.stringify(store.entries.map((e) => e.type)));
    assert(actions[0].data.action === 'pause_entries');
    assert(typeof actions[0].data.reason === 'string' && actions[0].data.reason.length > 4);
    assert(actions[0].data.incident === 'feeds_down');
  });

  await t('healthy data produces no incident and no action', async () => {
    const engine = fakeEngine({ degraded: [] });
    const { healer, store } = make({ engine });
    const r = await healer.check();
    assert(r.incidents.length === 0, JSON.stringify(r));
    assert(store.entries.length === 0, 'nothing to journal');
    assert(healer.entriesPaused === false);
  });

  await t('a disabled healer does nothing at all', async () => {
    const { healer, engine, cfg } = make({ fallbacks: [], feedOutageMs: 0 });
    cfg.heal.enabled = false;
    healer.enabled = false;
    const r = healer.tick();
    assert(r === null);
    assert(engine.calls.switchVenue.length === 0);
  });

  done('heal');
})();

function assert(cond, msg = 'assertion failed') {
  if (!cond) throw new Error(msg);
}
