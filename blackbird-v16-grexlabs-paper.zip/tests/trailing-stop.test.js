#!/usr/bin/env node
'use strict';
/**
 * Regression: a position that runs in our favour must not give the whole move
 * back.
 *
 * Evidence from the fixture run (10 trades reviewed): three trades reached a
 * large favourable excursion and closed near zero —
 *   SOLUSDT short  MFE +35.56  -> closed -1.27%
 *   XRPUSDT short  MFE +45.37  -> closed +1.62%
 *   ETHUSDT short  MFE +75.82  -> closed +1.16%
 * The only stop was the 6-ATR disaster stop, which never moves. So a trade
 * could be up 3 ATR and still lose 6 ATR. That is a risk defect, not a
 * strategy opinion: the charter's "تعادل جسارت و ریسک" cannot be met while a
 * winner is allowed to become a loser.
 *
 * These tests fail on the old code and pass once the rotator trails the stop.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Rotator } = require('../src/strategy/rotator');
const { Portfolio, Position } = require('../src/exec/portfolio');

const noop = () => {};
const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };

function makeCfg(rotatorOver = {}) {
  return {
    symbols: ['BTCUSDT'],
    fees: { makerBps: 2, takerBps: 5, slippageBpsPer1kNotional: 0.6, latencyMs: 0 },
    data: { staleQuoteMs: 60000, intervalMs: 3600000 },
    risk: { startEquity: 5000, minNotionalUsd: 15 },
    strategy: {
      rotator: {
        rebalanceHours: 168, perPositionPct: 9, maxGrossPct: 70, disasterStopAtr: 6,
        maxPositions: 6, minNotionalUsd: 15, corePct: 0,
        ...rotatorOver,
      },
    },
  };
}

/** A rotator with a book holding one long at 100, ATR 1, stop 94 (6 ATR). */
function makeRig(rotatorOver = {}) {
  const cfg = makeCfg(rotatorOver);
  const portfolio = new Portfolio(log);
  const rotator = new Rotator({
    cfg, log, store: { state: {}, append: noop, saveState: noop },
    risk: { state: { equity: 5000 }, settle: noop },
    portfolio,
    broker: { submit: () => ({ status: 'filled', price: 100, fee: 0.1, qty: 1 }) },
    hub: { get: () => null, primary: null },
    bus: { emit: noop },
    now: () => 1792627200000,
  });
  const pos = new Position({
    symbol: 'BTCUSDT', side: 'long', qty: 1, entry: 100, fee: 0.1, notional: 100,
    strategy: 'ORBITAL', tp: null, sl: 94, timeStopAt: 0,
    context: { variant: 'orbital', atr: 1, pct: 9, scale: 1 },
    openedAt: 1792627200000,
  });
  portfolio.open(pos);
  return { rotator, portfolio, pos };
}

(async () => {
  console.log('\n▸ trailing stop — a winner must not become a loser');

  await t('the stop does not move before the trade is meaningfully in profit', () => {
    const { rotator, pos } = makeRig();
    rotator.onTick({ symbol: 'BTCUSDT', bid: 101, ask: 101, last: 101 });
    assert.strictEqual(pos.sl, 94, 'a 1 ATR move must not tighten the stop');
  });

  await t('after a full R of profit the stop is lifted to the entry', () => {
    const { rotator, pos } = makeRig();
    // R = disasterStopAtr * atr = 6. The charter's ladder (§12) moves the stop
    // to breakeven at 1R, not at an arbitrary 3 ATR — 3 ATR is only half an R.
    rotator.onTick({ symbol: 'BTCUSDT', bid: 106, ask: 106, last: 106 });
    assert.ok(pos.sl >= 100, `stop should be at or above entry, got ${pos.sl}`);
  });

  await t('the stop only ever moves in the direction of less risk', () => {
    const { rotator, pos } = makeRig();
    rotator.onTick({ symbol: 'BTCUSDT', bid: 103, ask: 103, last: 103 });
    const after = pos.sl;
    rotator.onTick({ symbol: 'BTCUSDT', bid: 101, ask: 101, last: 101 });
    assert.strictEqual(pos.sl, after, 'a pullback must never loosen the stop');
  });

  await t('a short trails downward, never upward', () => {
    const { rotator, portfolio } = makeRig();
    portfolio.positions.clear();
    const pos = new Position({
      symbol: 'BTCUSDT', side: 'short', qty: 1, entry: 100, fee: 0.1, notional: 100,
      strategy: 'ORBITAL', tp: null, sl: 106, timeStopAt: 0,
      context: { variant: 'orbital', atr: 1, pct: 9, scale: 1 },
      openedAt: 1792627200000,
    });
    portfolio.open(pos);
    // 1R in favour for a short: entry 100, R = 6, so 94 is breakeven.
    rotator.onTick({ symbol: 'BTCUSDT', bid: 94, ask: 94, last: 94 });
    assert.ok(pos.sl <= 100, `short stop should be at or below entry, got ${pos.sl}`);
  });

  await t('trailing can be switched off from the panel', () => {
    const { rotator, pos } = makeRig({ trailEnabled: false });
    rotator.onTick({ symbol: 'BTCUSDT', bid: 103, ask: 103, last: 103 });
    assert.strictEqual(pos.sl, 94, 'trailEnabled=false must leave the stop alone');
  });

  done('trailing-stop');
})();
