'use strict';
/**
 * Charter §6.1 / §25 — the three gaps the rules inventory left open:
 *   2. the BTC gate must fail CLOSED when its history is missing
 *   3. a resize up must clear gross / symbol / net caps
 *   4. a stale quote must not trap an open position forever
 */
const path = require('node:path');
const assert = require('node:assert');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Rotator } = require(path.join(SRC, 'strategy/rotator'));
const { Portfolio, Position } = require(path.join(SRC, 'exec/portfolio'));
const { loadConfig } = require(path.join(SRC, 'config'));

const quiet = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const makeBars = (start, drift, n = 400, vol = 0.004) => {
  const out = [];
  let c = start;
  const t0 = Date.UTC(2025, 0, 1);
  for (let i = 0; i < n; i++) {
    c = c * (1 + drift) * (1 + Math.sin(i / 3) * vol);
    const o = c * (1 - vol / 2);
    out.push({ t: t0 + i * 3600000, o, h: Math.max(o, c) * (1 + vol), l: Math.min(o, c) * (1 - vol), c, v: 1000 });
  }
  return out;
};

function build({ bars, quoteAgeMs = 100, equity = 5000 } = {}) {
  const cfg = loadConfig({ server: { enabled: false } });
  cfg.strategy.mode = 'rotator';
  const series = bars || {
    BTCUSDT: makeBars(100, 0.0005),
    ETHUSDT: makeBars(100, 0.002),
    SOLUSDT: makeBars(100, -0.001),
    XRPUSDT: makeBars(100, -0.002),
  };
  const feedFor = (sym) => {
    const b = series[sym];
    if (!b) return null;
    const last = b[b.length - 1].c;
    return {
      symbol: sym,
      bars: { toArray: () => b },
      ticker: { symbol: sym, last, bid: last * 0.9999, ask: last * 1.0001, ts: Date.now() },
      book: () => ({ bid: last * 0.9999, ask: last * 1.0001, quoteAgeMs }),
    };
  };
  const hub = { get: feedFor, all: () => Object.keys(series).map(feedFor).filter(Boolean) };
  const store = { append: () => {} };
  const risk = {
    state: { equity, dayStartEquity: equity },
    peakEquity: equity,
    halted: false,
    settle() { return risk.state.equity; },
  };
  const portfolio = new Portfolio(quiet());
  const fills = [];
  const broker = {
    submit(order) {
      const b = series[order.symbol];
      const px = b ? b[b.length - 1].c : 100;
      const fill = {
        status: 'filled', symbol: order.symbol, side: order.side, qty: order.qty,
        price: px, notional: px * order.qty, fee: px * order.qty * 5e-4, feeKind: 'taker',
      };
      fills.push(fill);
      return fill;
    },
  };
  const rot = new Rotator({ cfg, log: quiet(), store, risk, portfolio, broker, hub, bus: { emit() {} } });
  return { rot, cfg, risk, portfolio, fills, series };
}

(async () => {
  await t('the BTC gate fails CLOSED: no BTC history means no longs, shorts still run', async () => {
    const bars = {
      ETHUSDT: makeBars(100, 0.003),
      SOLUSDT: makeBars(100, -0.001),
      XRPUSDT: makeBars(100, -0.002),
    };
    const { rot } = build({ bars, equity: 5000 });
    const picks = rot.variantPicks({ lookHours: 72, top: 2, neutral: true, gate: true }, bars);
    assert.strictEqual(picks.filter((p) => p.dir === 1).length, 0, 'no long without the gate series');
    assert.ok(picks.filter((p) => p.dir === -1).length >= 1, 'shorts are unaffected by the long gate');
  });

  await t('a short BTC history (under 220 bars) is not treated as a passed gate', async () => {
    const bars = {
      BTCUSDT: makeBars(100, 0.001, 120),
      ETHUSDT: makeBars(100, 0.003),
      SOLUSDT: makeBars(100, -0.001),
      XRPUSDT: makeBars(100, -0.002),
    };
    const { rot } = build({ bars });
    const picks = rot.variantPicks({ lookHours: 72, top: 2, neutral: true, gate: true }, bars);
    assert.strictEqual(picks.filter((p) => p.dir === 1).length, 0);
  });

  await t('gross / symbol / net caps block a resize up and allow a resize down', async () => {
    const { rot, risk, portfolio } = build();
    // A full-ish book: 70% gross on 5000 = 3500 already committed.
    portfolio.open(new Position({ symbol: 'ETHUSDT', qty: 1, entry: 2000, fee: 0, notional: 2000, strategy: 'ORBITAL', tp: 3000, sl: 1000, dir: 1 }));
    portfolio.open(new Position({ symbol: 'SOLUSDT', qty: 1, entry: 1500, fee: 0, notional: 1500, strategy: 'ORBITAL', tp: 2000, sl: 1000, dir: 1 }));
    risk.state.equity = 5000;

    const gross = rot._caps('BTCUSDT', 600, 600);
    assert.strictEqual(gross.ok, false, JSON.stringify(gross));
    assert.match(gross.reason, /gross_cap/);

    // Room in gross, but the same name would exceed the 25% symbol ceiling.
    const sym = rot._caps('ETHUSDT', 300, 300);
    assert.strictEqual(sym.ok, false, JSON.stringify(sym));
    assert.match(sym.reason, /symbol_cap|gross_cap/);

    // With more equity the same small addition fits both ceilings.
    risk.state.equity = 7000;
    const small = rot._caps('BTCUSDT', 10, 10);
    assert.strictEqual(small.ok, true, JSON.stringify(small));
  });

  await t('the net ceiling is enforced separately from gross', async () => {
    const { rot, risk, portfolio } = build();
    // Long 3400 / short 0 on 5000 equity: gross is fine, net is 68% of equity.
    portfolio.open(new Position({ symbol: 'ETHUSDT', qty: 1, entry: 3400, fee: 0, notional: 3400, strategy: 'ORBITAL', tp: 4000, sl: 3000, dir: 1 }));
    risk.state.equity = 5000;
    const r = rot._caps('BTCUSDT', 50, 50);
    assert.strictEqual(r.ok, true, JSON.stringify(r)); // 3450 < 3500 net cap

    const over = rot._caps('BTCUSDT', 150, 150); // 3550 > 3500
    assert.strictEqual(over.ok, false, JSON.stringify(over));
    assert.match(over.reason, /net_cap|gross_cap/);
  });

  await t('a stale book longer than the policy window forces an exit at the reference price', async () => {
    const { rot, portfolio } = build({ quoteAgeMs: 10 * 60 * 1000 });
    portfolio.open(new Position({ symbol: 'BTCUSDT', qty: 1, entry: 100, fee: 0, notional: 100, strategy: 'ORBITAL', tp: 120, sl: 90, dir: 1 }));
    rot.rc.emergencyExitMs = 1000;
    rot.now = () => Date.now();
    rot.tick(); // first sight: starts the clock, does not close
    assert.strictEqual(portfolio.hasPosition('BTCUSDT'), true, 'no exit on the first stale sighting');

    // Pretend the grace period has passed.
    rot._staleSince.set('BTCUSDT', Date.now() - 5000);
    rot.tick();
    assert.strictEqual(portfolio.hasPosition('BTCUSDT'), false, 'position must be closed');
    assert.ok(rot.stats.closes >= 1, 'the forced exit is counted as a close');
  });

  await t('a fresh book is never force-closed', async () => {
    const { rot, portfolio } = build({ quoteAgeMs: 10 });
    portfolio.open(new Position({ symbol: 'BTCUSDT', qty: 1, entry: 100, fee: 0, notional: 100, strategy: 'ORBITAL', tp: 120, sl: 90, dir: 1 }));
    rot.rc.emergencyExitMs = 1000;
    rot._staleSince.set('BTCUSDT', Date.now() - 5000);
    rot.tick();
    assert.strictEqual(portfolio.hasPosition('BTCUSDT'), true, 'fresh quotes keep positions open');
  });

  done('charter');
})();
