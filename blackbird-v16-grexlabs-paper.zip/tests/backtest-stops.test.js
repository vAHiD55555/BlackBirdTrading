#!/usr/bin/env node
'use strict';
/**
 * Regression: the backtest must honour the disaster stop.
 *
 * Bug: `runBacktest` called `rotator.onBar()` on every bar but never
 * `rotator.onTick()`. The rotator's only stop check lives in `onTick`, so in a
 * replay a position could run straight through its stop and be closed days
 * later by a rebalance. On the real fixture data trade #8 lost 15.17% with a
 * stop that should have fired near 6 ATR. A backtest that under-reports risk is
 * worse than no backtest: it makes the strategy look safer than it is.
 *
 * These tests fail on the old code and pass once the replay feeds ticks.
 */
const assert = require('node:assert');
const path = require('node:path');
const os = require('node:os');
const { t, done } = require('./harness');
const { runBacktest } = require('../src/backtest/engine');
const { readCsvFile } = require('../src/backtest/csv');
const { loadConfig } = require('../src/config');

const FIXTURES = path.join(__dirname, 'fixtures');
const cfg = loadConfig({ server: { enabled: false } });

/** Load the real 1h fixtures the rest of the suite uses. */
function realBars() {
  const out = {};
  for (const sym of ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT']) {
    const { bars, report } = readCsvFile(path.join(FIXTURES, `${sym}_1h_real.csv`), { symbol: sym });
    assert.strictEqual(report.ok, true, `${sym} fixture must load`);
    out[sym] = bars;
  }
  return out;
}

function run() {
  return runBacktest({
    cfg,
    barsBySymbol: realBars(),
    equityFile: path.join(os.tmpdir(), `bb-stop-${Date.now()}.jsonl`),
  });
}

(async () => {
  console.log('\n▸ backtest stops — the replay must feed ticks, not only bars');

  const result = run();

  await t('the fixture run actually trades', () => {
    assert.strictEqual(result.ok, true, result.error);
    assert.ok((result.trades || []).length > 0, 'the run must produce closed trades');
  });

  await t('no trade is closed at a loss the stop should have prevented', () => {
    // The disaster stop is 6 ATR. Anything past ~10% means the stop never ran.
    const catastrophic = (result.trades || []).filter((x) => Number(x.pnlPct) <= -10);
    assert.strictEqual(
      catastrophic.length,
      0,
      `a stop should have fired; got ${catastrophic
        .map((x) => `${x.symbol} ${x.pnlPct}% (${x.exit.reason})`)
        .join(', ')}`
    );
  });

  await t('at least one trade is closed by the stop', () => {
    const reasons = (result.trades || []).map((x) => x.exit.reason);
    assert.ok(
      reasons.includes('stop'),
      `expected a stop exit, got: ${[...new Set(reasons)].join(', ') || '(none)'}`
    );
  });

  await t('every trade has a non-negative holding period', () => {
    const bad = (result.trades || []).filter((x) => !(Number(x.durationMs) >= 0));
    assert.strictEqual(
      bad.length,
      0,
      `negative duration on: ${bad.map((x) => `${x.symbol} ${x.durationMs}ms`).join(', ')}`
    );
  });

  done('backtest-stops');
})();
