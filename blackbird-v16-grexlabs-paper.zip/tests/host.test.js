#!/usr/bin/env node
'use strict';
/**
 * BlackBird — host-port and Telegram test suite.
 *
 * These pin the three things that broke on the real Botkeep deployment:
 *
 *   1. The dashboard bound 8787 while the host proxied a different port, so it
 *      was unreachable from outside. Pterodactyl/Wings (Botkeep, KataBump) puts
 *      the allocation in SERVER_PORT, not PORT.
 *   2. The log printed `http://<server-ip>:8787/` regardless of the real port.
 *   3. Telegram reports were silently skipped because the code only read
 *      TELEGRAM_REPORT_CHAT_ID, while the user had set TELEGRAM_CHAT_ID.
 *
 * Zero dependencies, no network, real sockets on ephemeral ports.
 *
 * Run: node tests/host.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const http = require('node:http');
const net = require('node:net');
const { spawn } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'src');

let passed = 0;
let failed = 0;
const failures = [];

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message}`);
  }
}

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message}`);
  }
}

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(() => resolve(p));
    });
  });
}

function get(port, pathname, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname, timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

/**
 * Boot the real entry point with an explicit environment. `env` is the WHOLE
 * environment for the child (minus PATH/HOME), so a stray PORT in the parent
 * cannot mask the case under test.
 */
function boot(env, port, waitMs = 25000) {
  const base = { PATH: process.env.PATH, HOME: process.env.HOME, NODE_ENV: 'test' };
  const child = spawn(process.execPath, [path.join(SRC, 'index.js')], {
    cwd: ROOT,
    env: { ...base, ...env },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let out = '';
  child.stdout.on('data', (d) => { out += d; });
  child.stderr.on('data', (d) => { out += d; });

  const ready = new Promise((resolve, reject) => {
    const started = Date.now();
    const tick = async () => {
      if (child.exitCode !== null) return reject(new Error(`process exited ${child.exitCode}\n${out.slice(-1500)}`));
      try {
        await get(port, '/healthz', 800);
        return resolve();
      } catch {
        if (Date.now() - started > waitMs) return reject(new Error(`port ${port} never answered\n${out.slice(-1500)}`));
        setTimeout(tick, 250);
      }
    };
    tick();
  });

  return { child, ready, output: () => out, stop: () => { try { child.kill('SIGKILL'); } catch { /* ignore */ } } };
}

(async () => {
  console.log('\n\u25b8 host \u2014 port resolution, public address, telegram');

  // ------------------------------------------------------- SERVER_PORT (Botkeep)
  // The exact Botkeep/Pterodactyl case: only SERVER_PORT is set. The dashboard
  // must bind it, answer on it, and say so in the log.
  await testAsync('SERVER_PORT alone is honoured (Pterodactyl/Botkeep)', async () => {
    const port = await freePort();
    const b = boot({ SERVER_PORT: String(port) }, port);
    try {
      await b.ready;
      const r = await get(port, '/healthz');
      assert.strictEqual(r.status, 200, '/healthz must answer on the SERVER_PORT');
      const out = b.output();
      assert.match(out, new RegExp(`status panel on http://0\\.0\\.0\\.0:${port}`), 'the log must name the real bound port');
      assert.match(out, /port from SERVER_PORT/, 'the log must say which variable was used');
      assert.match(out, new RegExp(`:${port}/`), 'the public-address line must carry the real port');
      assert.doesNotMatch(out, /:8787\//, 'the old hardcoded 8787 must be gone');
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------------- PORT wins
  await testAsync('PORT wins over SERVER_PORT', async () => {
    const port = await freePort();
    const other = await freePort();
    const b = boot({ PORT: String(port), SERVER_PORT: String(other) }, port);
    try {
      await b.ready;
      const r = await get(port, '/healthz');
      assert.strictEqual(r.status, 200);
      assert.match(b.output(), /port from PORT/);
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------- BB_PORT wins over both
  await testAsync('BB_PORT wins over PORT and SERVER_PORT', async () => {
    const port = await freePort();
    const b = boot({ BB_PORT: String(port), PORT: '1', SERVER_PORT: '2' }, port);
    try {
      await b.ready;
      assert.strictEqual((await get(port, '/healthz')).status, 200);
      assert.match(b.output(), /port from BB_PORT/);
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------- invalid SERVER_PORT
  await testAsync('a non-numeric SERVER_PORT is ignored, not fatal', async () => {
    // Only SERVER_PORT is set, and it is garbage. The engine must fall back to
    // the config default and say why — not crash, and not bind a nonsense port.
    const b = boot({ SERVER_PORT: 'not-a-port' }, 61257);
    try {
      await b.ready;
      assert.strictEqual((await get(61257, '/healthz')).status, 200, 'must fall back to the config default');
      assert.match(b.output(), /ignoring SERVER_PORT/, 'the bad value must be reported');
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------- public address honesty
  await testAsync('BB_PUBLIC_URL is printed verbatim when set', async () => {
    const port = await freePort();
    const b = boot({ BB_PORT: String(port), BB_PUBLIC_URL: 'https://bb.example.com' }, port);
    try {
      await b.ready;
      assert.match(b.output(), /open from outside:\s+https:\/\/bb\.example\.com/, 'the real address must be printed');
    } finally {
      b.stop();
    }
  });

  await testAsync('without a known hostname the log admits it instead of guessing', async () => {
    const port = await freePort();
    const b = boot({ BB_PORT: String(port) }, port);
    try {
      await b.ready;
      const out = b.output();
      assert.match(out, /<your-server-ip>/, 'a placeholder is honest; a made-up hostname is not');
      assert.match(out, /not knowable from inside the container/, 'the reason must be stated');
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------------- supervisor quiet
  // A dead model endpoint must produce at most one line, never a warning storm,
  // and must never contain the bare string `fetch failed`.
  await testAsync('an unreachable supervisor endpoint does not spam the log', async () => {
    const port = await freePort();
    // A real port with nothing listening: fetch gets ECONNREFUSED, which is the
    // case a free host actually hits. (Port 1 is rejected by fetch itself as a
    // "bad port" before any connection is attempted, so it proves nothing.)
    const dead = await freePort();
    const b = boot({
      BB_PORT: String(port),
      SUPERVISOR_URL: `http://127.0.0.1:${dead}/v1/chat/completions`,
      SUPERVISOR_ENABLED: 'true',
    }, port);
    try {
      await b.ready;
      await new Promise((r) => setTimeout(r, 2500));
      const out = b.output();
      const raw = (out.match(/fetch failed/g) || []).length;
      assert.strictEqual(raw, 0, `the bare "fetch failed" must never appear (found ${raw})`);
      const lines = out.split('\n').filter((l) => /supervisor/i.test(l));
      assert.ok(lines.length <= 3, `expected at most a few supervisor lines, got ${lines.length}:\n${lines.join('\n')}`);
      assert.ok(lines.some((l) => /not reachable|off|unreachable/i.test(l)), 'the reason must be stated once');
      assert.ok(lines.some((l) => /refused|ECONNREFUSED/i.test(l)), 'the real cause must be named, not just "failed"');
      assert.ok(lines.length === 1, `exactly one line, not a storm (got ${lines.length})`);
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------------- telegram config
  test('TELEGRAM_CHAT_ID is accepted as an alias for the report chat', () => {
    const { loadConfig } = require(path.join(SRC, 'config'));
    const prev = { ...process.env };
    try {
      process.env.TELEGRAM_CHAT_ID = '123456789';
      delete process.env.TELEGRAM_REPORT_CHAT_ID;
      const cfg = loadConfig();
      assert.strictEqual(cfg.notifications.telegram.reportChatId, '123456789',
        'the name most guides use must work');
    } finally {
      for (const k of Object.keys(process.env)) if (!(k in prev)) delete process.env[k];
      Object.assign(process.env, prev);
    }
  });

  test('TELEGRAM_REPORT_CHAT_ID still works', () => {
    const { loadConfig } = require(path.join(SRC, 'config'));
    const prev = { ...process.env };
    try {
      delete process.env.TELEGRAM_CHAT_ID;
      process.env.TELEGRAM_REPORT_CHAT_ID = '987654321';
      const cfg = loadConfig();
      assert.strictEqual(cfg.notifications.telegram.reportChatId, '987654321');
    } finally {
      for (const k of Object.keys(process.env)) if (!(k in prev)) delete process.env[k];
      Object.assign(process.env, prev);
    }
  });

  test('a numeric id, an @username and a t.me link all normalise', () => {
    const { normalizeChatId } = require(path.join(SRC, 'notify/telegram'));
    assert.strictEqual(normalizeChatId('123456789'), '123456789');
    assert.strictEqual(normalizeChatId('-1001234567890'), '-1001234567890');
    assert.strictEqual(normalizeChatId('@mychannel'), '@mychannel');
    assert.strictEqual(normalizeChatId('https://t.me/mychannel'), '@mychannel');
    assert.strictEqual(normalizeChatId('t.me/mychannel'), '@mychannel');
    assert.strictEqual(normalizeChatId('  '), '');
    assert.strictEqual(normalizeChatId(undefined), '');
  });

  test('a missing chat id is reported as such, not as a silent skip', async () => {
    const { sendTestMessage } = require(path.join(SRC, 'notify/telegram'));
    const r = await sendTestMessage({
      notifications: { telegram: { enabled: true, botToken: 'x:y', reportChatId: '', alertChatId: '' } },
    });
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /chat id/i, 'the reason must name the missing chat id');
  });

  test('a disabled notifier says so instead of pretending to send', async () => {
    const { sendTestMessage } = require(path.join(SRC, 'notify/telegram'));
    const r = await sendTestMessage({ notifications: { telegram: { enabled: false } } });
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /disabled/i);
  });

  // A Telegram failure must never throw into the engine.
  test('a network failure returns a result object and never throws', async () => {
    const { sendTelegramMessage } = require(path.join(SRC, 'notify/telegram'));
    const r = await sendTelegramMessage({ token: 'x:y', chatId: '1', text: 't', timeoutMs: 300 });
    assert.strictEqual(typeof r, 'object');
    assert.strictEqual(r.ok, false);
    assert.ok(r.reason || r.description, 'a failure must carry a reason');
  });

  // ------------------------------------------------------------- test command
  test('scripts/telegram-test.js exists and is runnable', () => {
    const p = path.join(ROOT, 'scripts/telegram-test.js');
    assert.ok(fs.existsSync(p), 'the one-shot test command must exist');
    const src = fs.readFileSync(p, 'utf8');
    assert.match(src, /sendTestMessage/, 'it must use the real sender');
  });

  // ------------------------------------------------------------- no secrets
  test('no real bot token is committed anywhere', () => {
    const files = ['.env.example', 'config.json', 'config.json.example', 'deploy/botkeep/.env.example'];
    const bad = [];
    for (const f of files) {
      const p = path.join(ROOT, f);
      if (!fs.existsSync(p)) continue;
      const text = fs.readFileSync(p, 'utf8');
      // A real Telegram token looks like 123456789:AAH... — digits, colon, 30+ chars.
      for (const m of text.matchAll(/\b\d{6,}:[A-Za-z0-9_-]{30,}\b/g)) bad.push(`${f}: ${m[0].slice(0, 12)}…`);
    }
    assert.deepStrictEqual(bad, [], `possible real tokens: ${bad.join(' | ')}`);
  });

  // ------------------------------------------------------------------ summary
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  host: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  process.exit(failed ? 1 : 0);
})();
