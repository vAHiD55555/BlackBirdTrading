#!/usr/bin/env node
'use strict';
/**
 * BlackBird — trial registry (K) and Deflated Sharpe Ratio tests.
 *
 * Zero dependencies, no network.
 *
 * What is asserted:
 *   - keccak/normal-distribution primitives match published values
 *   - DSR matches hand-computed values for known inputs
 *   - DSR falls as K rises (the whole point of the correction)
 *   - DSR is "not computable" — never a fabricated number — when data is missing
 *   - K increments on every recorded change
 *   - K survives a restart (it is read back from the file, not from memory)
 *   - a hand-edited config is detected as an unregistered trial
 *   - the lawyer's deflated_sharpe clause reports a gap, not a number, when
 *     the return series or K is absent
 *   - the threshold is read from config, not hardcoded
 *
 * Run: node tests/trials.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const SRC = path.join(__dirname, '..', 'src');
const { TrialRegistry, fingerprint, stableStringify } = require(path.join(SRC, 'jev/trials'));
const dsr = require(path.join(SRC, 'lawyer/dsr'));
const { Lawyer } = require(path.join(SRC, 'lawyer/lawyer'));
const { CLAUSES } = require(path.join(SRC, 'lawyer/charter'));
const { EquityCurve } = require(path.join(SRC, 'core/equity-curve'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}\n      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const tmpFile = (name) => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'bb-trials-')), name);

// ============================================================ normal dist
group('dsr / normal distribution', () => {
  test('normCdf matches the standard table', () => {
    assert.ok(Math.abs(dsr.normCdf(0) - 0.5) < 1e-9);
    assert.ok(Math.abs(dsr.normCdf(1.96) - 0.975002) < 1e-5);
    assert.ok(Math.abs(dsr.normCdf(-1.96) - 0.024998) < 1e-5);
    assert.ok(Math.abs(dsr.normCdf(1) - 0.841345) < 1e-5);
  });
  test('normInv inverts normCdf', () => {
    for (const p of [0.01, 0.1, 0.5, 0.9, 0.975, 0.99]) {
      const x = dsr.normInv(p);
      assert.ok(Math.abs(dsr.normCdf(x) - p) < 1e-6, `p=${p} -> x=${x}`);
    }
  });
  test('normInv(0.975) is 1.959964', () => {
    assert.ok(Math.abs(dsr.normInv(0.975) - 1.959964) < 1e-5);
  });
});

// ============================================================ statistics
group('dsr / return statistics', () => {
  test('sharpe of a constant series is null (zero variance)', () => {
    assert.strictEqual(dsr.sharpe([0.01, 0.01, 0.01]), null);
  });
  test('sharpe of a known series', () => {
    // mean 0.01, sample sd of [0,0.02,0,0.02] = 0.011547
    const r = [0, 0.02, 0, 0.02];
    const s = dsr.sharpe(r);
    assert.ok(Math.abs(s - 0.01 / 0.011547005) < 1e-6, `got ${s}`);
  });
  test('skewness of a symmetric series is ~0', () => {
    assert.ok(Math.abs(dsr.skewness([-1, 0, 1, -1, 0, 1])) < 1e-9);
  });
  test('kurtosis of a normal-ish sample is near 3, not 0', () => {
    const r = [-1.5, -1, -0.5, 0, 0.5, 1, 1.5, -1.2, 1.1, -0.3];
    const k = dsr.kurtosis(r);
    assert.ok(k > 1 && k < 5, `kurtosis=${k}`);
  });
});

// ==================================================== expected max sharpe
group('dsr / expected maximum Sharpe', () => {
  test('K=1 means no selection, so SR0 is 0', () => {
    assert.strictEqual(dsr.expectedMaxSharpe(1, 0.25), 0);
  });
  test('SR0 grows with K', () => {
    const a = dsr.expectedMaxSharpe(10, 0.25);
    const b = dsr.expectedMaxSharpe(100, 0.25);
    const c = dsr.expectedMaxSharpe(1000, 0.25);
    assert.ok(a < b && b < c, `${a} < ${b} < ${c}`);
  });
  test('SR0 grows with the variance of trial Sharpes', () => {
    const lo = dsr.expectedMaxSharpe(100, 0.01);
    const hi = dsr.expectedMaxSharpe(100, 1.0);
    assert.ok(lo < hi);
  });
  test('SR0 is null for invalid input', () => {
    assert.strictEqual(dsr.expectedMaxSharpe(0, 0.25), null);
    assert.strictEqual(dsr.expectedMaxSharpe(10, -1), null);
  });
});

// ================================================================ DSR core
group('dsr / deflated Sharpe', () => {
  test('a strong Sharpe with few trials clears the bar', () => {
    // varSharpe=0.01 means the trial Sharpes had sd 0.1 — realistic for a
    // parameter sweep. With K=5 the selection penalty is small.
    const r = dsr.deflatedSharpe({ sharpe: 0.5, K: 5, T: 500, skew: 0, kurt: 3, varSharpe: 0.01 });
    assert.strictEqual(r.computable, true);
    assert.ok(r.dsr > 0.95, `dsr=${r.dsr}`);
  });

  test('the SAME Sharpe fails once K is large — the correction works', () => {
    const few = dsr.deflatedSharpe({ sharpe: 0.2, K: 5, T: 252, skew: 0, kurt: 3, varSharpe: 0.01 });
    const many = dsr.deflatedSharpe({ sharpe: 0.2, K: 1000, T: 252, skew: 0, kurt: 3, varSharpe: 0.01 });
    assert.ok(few.dsr > many.dsr, `${few.dsr} should exceed ${many.dsr}`);
    assert.ok(many.dsr < 0.5, `with K=1000 a Sharpe of 0.2 is noise, got ${many.dsr}`);
  });

  test('DSR is a probability in [0,1]', () => {
    for (const sr of [-1, -0.2, 0, 0.1, 0.5, 2]) {
      const r = dsr.deflatedSharpe({ sharpe: sr, K: 50, T: 300, skew: 0, kurt: 3, varSharpe: 0.25 });
      assert.ok(r.dsr >= 0 && r.dsr <= 1, `sr=${sr} dsr=${r.dsr}`);
    }
  });

  test('negative skew lowers DSR (fat left tail is punished)', () => {
    const normal = dsr.deflatedSharpe({ sharpe: 0.3, K: 20, T: 300, skew: 0, kurt: 3, varSharpe: 0.01 });
    const skewed = dsr.deflatedSharpe({ sharpe: 0.3, K: 20, T: 300, skew: -1.5, kurt: 3, varSharpe: 0.01 });
    assert.ok(skewed.dsr < normal.dsr, `${skewed.dsr} should be below ${normal.dsr}`);
  });

  test('fat tails (high kurtosis) lower DSR', () => {
    const thin = dsr.deflatedSharpe({ sharpe: 0.3, K: 20, T: 300, skew: 0, kurt: 3, varSharpe: 0.01 });
    const fat = dsr.deflatedSharpe({ sharpe: 0.3, K: 20, T: 300, skew: 0, kurt: 10, varSharpe: 0.01 });
    assert.ok(fat.dsr < thin.dsr, `${fat.dsr} should be below ${thin.dsr}`);
  });

  test('a longer sample raises DSR for the same Sharpe', () => {
    const short = dsr.deflatedSharpe({ sharpe: 0.2, K: 20, T: 100, skew: 0, kurt: 3, varSharpe: 0.01 });
    const long = dsr.deflatedSharpe({ sharpe: 0.2, K: 20, T: 2000, skew: 0, kurt: 3, varSharpe: 0.01 });
    assert.ok(long.dsr > short.dsr, `${long.dsr} should exceed ${short.dsr}`);
  });

  test('a hand-computed value matches', () => {
    // SR=0.1, K=1 (SR0=0), T=252, normal returns:
    //   z = 0.1 * sqrt(251) / sqrt(1 - 0 + (3-1)/4 * 0.01)
    //     = 0.1 * 15.84298 / sqrt(1.005) = 1.58035
    //   Phi(1.58035) = 0.94299
    const r = dsr.deflatedSharpe({ sharpe: 0.1, K: 1, T: 252, skew: 0, kurt: 3, varSharpe: 0.01 });
    assert.ok(Math.abs(r.z - 1.580352) < 1e-4, `z=${r.z}`);
    assert.ok(Math.abs(r.dsr - 0.942987) < 1e-4, `dsr=${r.dsr}`);
  });
});

// ==================================================== DSR refuses to guess
group('dsr / refuses to fabricate', () => {
  test('missing K is not computable', () => {
    const r = dsr.deflatedSharpe({ sharpe: 0.2, T: 252, varSharpe: 0.25 });
    assert.strictEqual(r.computable, false);
    assert.strictEqual(r.dsr, null);
    assert.ok(r.reason.includes('K'));
  });
  test('missing varSharpe is not computable', () => {
    const r = dsr.deflatedSharpe({ sharpe: 0.2, K: 10, T: 252 });
    assert.strictEqual(r.computable, false);
    assert.ok(r.reason.includes('varSharpe'));
  });
  test('missing T is not computable', () => {
    const r = dsr.deflatedSharpe({ sharpe: 0.2, K: 10, varSharpe: 0.25 });
    assert.strictEqual(r.computable, false);
  });
  test('an empty call lists every missing input', () => {
    const r = dsr.deflatedSharpe({});
    assert.strictEqual(r.computable, false);
    assert.ok(r.missing.length >= 4, JSON.stringify(r.missing));
  });
  test('a too-short return series is not computable', () => {
    const r = dsr.deflatedSharpeFromReturns({ returns: [0.01, 0.02], K: 10, varSharpe: 0.25 });
    assert.strictEqual(r.computable, false);
  });
  test('a zero-variance series is not computable', () => {
    const r = dsr.deflatedSharpeFromReturns({ returns: [0.01, 0.01, 0.01, 0.01], K: 10, varSharpe: 0.25 });
    assert.strictEqual(r.computable, false);
  });
});

// ============================================================ trial registry
group('trials / K counter', () => {
  test('K starts at zero on a fresh file', () => {
    const reg = new TrialRegistry({ file: tmpFile('trials.jsonl'), log: quietLog() });
    assert.strictEqual(reg.K, 0);
  });

  test('K increments on every recorded change', () => {
    const reg = new TrialRegistry({ file: tmpFile('trials.jsonl'), log: quietLog() });
    reg.record({ kind: 'param_change', field: 'risk.maxPositionPct', from: 10, to: 12 });
    assert.strictEqual(reg.K, 1);
    reg.record({ kind: 'param_change', field: 'risk.maxPositionPct', from: 12, to: 15 });
    assert.strictEqual(reg.K, 2);
    reg.record({ kind: 'backtest', note: 'ran a 2y backtest' });
    assert.strictEqual(reg.K, 3);
  });

  test('K survives a restart — it is read from the file, not memory', () => {
    const file = tmpFile('trials.jsonl');
    const a = new TrialRegistry({ file, log: quietLog() });
    a.record({ kind: 'param_change', field: 'x', from: 1, to: 2 });
    a.record({ kind: 'param_change', field: 'y', from: 3, to: 4 });
    assert.strictEqual(a.K, 2);

    // A brand-new instance, as after a process restart.
    const b = new TrialRegistry({ file, log: quietLog() });
    assert.strictEqual(b.K, 2, 'K must be reloaded from disk');
    b.record({ kind: 'param_change', field: 'z', from: 5, to: 6 });
    assert.strictEqual(b.K, 3);
  });

  test('a torn last line does not lose the earlier trials', () => {
    const file = tmpFile('trials.jsonl');
    const a = new TrialRegistry({ file, log: quietLog() });
    a.record({ kind: 'param_change', field: 'x', from: 1, to: 2 });
    fs.appendFileSync(file, '{"k":2,"kind":"param_cha'); // simulate a crash mid-write
    const b = new TrialRegistry({ file, log: quietLog() });
    assert.strictEqual(b.K, 1, 'the valid record survives, the torn one is skipped');
  });

  test('the record carries the ordinal, timestamp and the change', () => {
    const reg = new TrialRegistry({ file: tmpFile('trials.jsonl'), log: quietLog() });
    const rec = reg.record({ kind: 'param_change', field: 'risk.maxDailyLossPct', from: 3, to: 2, note: 'tightened' });
    assert.strictEqual(rec.k, 1);
    assert.strictEqual(rec.field, 'risk.maxDailyLossPct');
    assert.strictEqual(rec.from, 3);
    assert.strictEqual(rec.to, 2);
    assert.ok(rec.ts > 0);
  });

  test('a write failure returns null instead of throwing', () => {
    const reg = new TrialRegistry({ file: '/proc/nonexistent-dir/trials.jsonl', log: quietLog() });
    const rec = reg.record({ kind: 'manual', note: 'x' });
    assert.strictEqual(rec, null);
    assert.ok(reg.stats.failed >= 1);
  });
});

// ============================================================ drift detection
group('trials / unregistered trials', () => {
  const baseCfg = () => ({
    strategy: { mode: 'rotator', rotator: { perPositionPct: 10, maxPositions: 6 } },
    risk: { maxPositionPct: 10, maxDailyLossPct: 3 },
    exchange: 'binance',
    symbols: ['BTCUSDT'],
  });

  test('fingerprint is stable regardless of key order', () => {
    const a = fingerprint({ risk: { maxPositionPct: 10, maxDailyLossPct: 3 } });
    const b = fingerprint({ risk: { maxDailyLossPct: 3, maxPositionPct: 10 } });
    assert.strictEqual(a.hash, b.hash);
  });

  test('no drift when the config is unchanged', () => {
    const file = tmpFile('trials.jsonl');
    const reg = new TrialRegistry({ file, log: quietLog() });
    const cfg = baseCfg();
    reg.recordBaseline(cfg);
    const d = reg.detectDrift(cfg);
    assert.strictEqual(d.unregistered, false, JSON.stringify(d.changed));
  });

  test('a hand-edited config is flagged as an unregistered trial', () => {
    const file = tmpFile('trials.jsonl');
    const reg = new TrialRegistry({ file, log: quietLog() });
    const cfg = baseCfg();
    reg.recordBaseline(cfg);

    // The operator edits config.json by hand — no trial was recorded.
    const edited = baseCfg();
    edited.risk.maxPositionPct = 25;

    const d = reg.detectDrift(edited);
    assert.strictEqual(d.unregistered, true);
    assert.ok(d.changed.some((c) => c.field === 'risk.maxPositionPct'));
  });

  test('recording the drift raises K so it stops under-counting', () => {
    const file = tmpFile('trials.jsonl');
    const reg = new TrialRegistry({ file, log: quietLog() });
    const cfg = baseCfg();
    reg.recordBaseline(cfg);
    const before = reg.K;

    const edited = baseCfg();
    edited.risk.maxPositionPct = 25;
    const d = reg.detectDrift(edited);
    reg.recordDrift(d);

    assert.ok(reg.K > before, `K should rise from ${before}, got ${reg.K}`);
    // And the drift is now closed.
    assert.strictEqual(reg.detectDrift(edited).unregistered, false);
  });

  test('a change to a non-trial field is not a trial', () => {
    const file = tmpFile('trials.jsonl');
    const reg = new TrialRegistry({ file, log: quietLog() });
    const cfg = baseCfg();
    reg.recordBaseline(cfg);
    const edited = baseCfg();
    edited.server = { port: 9999 }; // not in TRIAL_FIELDS
    assert.strictEqual(reg.detectDrift(edited).unregistered, false);
  });
});

// ============================================================ equity curve
group('equity curve', () => {
  test('returns are derived from consecutive samples', () => {
    const file = tmpFile('equity.jsonl');
    const c = new EquityCurve({ file, log: quietLog(), sampleIntervalMs: 0 });
    c.sample(1000, 1000);
    c.sample(1100, 2000);
    c.sample(990, 3000);
    const r = c.returns();
    assert.strictEqual(r.length, 2);
    assert.ok(Math.abs(r[0] - 0.1) < 1e-9);
    assert.ok(Math.abs(r[1] - (-0.1)) < 1e-9);
  });

  test('the cadence gate prevents fake periods from a fast poller', () => {
    const file = tmpFile('equity.jsonl');
    const c = new EquityCurve({ file, log: quietLog(), sampleIntervalMs: 60000 });
    assert.strictEqual(c.sample(1000, 1000), true);
    assert.strictEqual(c.sample(1001, 2000), false, 'too soon');
    assert.strictEqual(c.sample(1002, 1000 + 60001), true);
    assert.strictEqual(c.returns().length, 1);
  });

  test('the curve survives a restart', () => {
    const file = tmpFile('equity.jsonl');
    const a = new EquityCurve({ file, log: quietLog(), sampleIntervalMs: 0 });
    a.sample(1000, 1000);
    a.sample(1050, 2000);
    const b = new EquityCurve({ file, log: quietLog(), sampleIntervalMs: 0 });
    assert.strictEqual(b.samples.length, 2);
    assert.strictEqual(b.returns().length, 1);
  });

  test('the file is capped and old samples are dropped', () => {
    const file = tmpFile('equity.jsonl');
    const c = new EquityCurve({ file, log: quietLog(), sampleIntervalMs: 0, maxSamples: 5 });
    for (let i = 0; i < 12; i++) c.sample(1000 + i, 1000 + i * 10);
    assert.strictEqual(c.samples.length, 5);
    assert.ok(c.stats.dropped >= 7);
  });

  test('a non-positive equity is refused', () => {
    const c = new EquityCurve({ file: tmpFile('equity.jsonl'), log: quietLog(), sampleIntervalMs: 0 });
    assert.strictEqual(c.sample(0, 1000), false);
    assert.strictEqual(c.sample(-5, 2000), false);
  });
});

// ==================================================== lawyer DSR clause
group('lawyer / deflated_sharpe clause', () => {
  const clause = CLAUSES.find((c) => c.id === 'deflated_sharpe');

  test('the clause exists in the charter', () => {
    assert.ok(clause, 'deflated_sharpe must be in the charter');
    assert.ok(clause.formula.includes('SR0'));
  });

  test('a healthy DSR measures and passes', () => {
    const snap = {
      performance: {
        returns: Array.from({ length: 300 }, (_, i) => (i % 2 ? 0.004 : -0.002)),
        K: 3,
        varSharpe: 0.01,
      },
    };
    const v = clause.measure(snap, { warn: 0.95, critical: 0.8 });
    assert.ok(Number.isFinite(v), `expected a number, got ${v}`);
    assert.ok(v >= 0 && v <= 1);
  });

  test('no performance block means not measurable', () => {
    assert.strictEqual(clause.measure({}, { warn: 0.95 }), null);
  });

  test('no return series means not measurable', () => {
    assert.strictEqual(clause.measure({ performance: { K: 10, varSharpe: 0.25 } }, { warn: 0.95 }), null);
  });

  test('no K means not measurable — never a guessed K', () => {
    const snap = { performance: { returns: [0.01, -0.01, 0.02, -0.02], varSharpe: 0.25 } };
    assert.strictEqual(clause.measure(snap, { warn: 0.95 }), null);
  });

  test('no varSharpe means not measurable', () => {
    const snap = { performance: { returns: [0.01, -0.01, 0.02, -0.02], K: 10 } };
    assert.strictEqual(clause.measure(snap, { warn: 0.95 }), null);
  });

  test('the lawyer files a data gap, not a number, when DSR is uncomputable', () => {
    const lawyer = new Lawyer({ cfg: { enabled: true }, log: quietLog() });
    const res = lawyer.audit({ risk: { equity: 5000 }, performance: { K: 10 } });
    const row = res.clauses.find((c) => c.id === 'deflated_sharpe');
    assert.ok(row, 'the clause must appear in the audit');
    assert.strictEqual(row.measurable, false);
    assert.strictEqual(row.value, null);
    assert.ok(res.gaps.some((g) => g.clause === 'deflated_sharpe'), 'a gap must be filed');
  });

  test('the threshold comes from config, not from the clause default', () => {
    const lawyer = new Lawyer({ cfg: { enabled: true, dsrThreshold: 0.99 }, log: quietLog() });
    const th = lawyer._thresholdFor(clause);
    assert.strictEqual(th.warn, 0.99);
    assert.ok(th.critical < th.warn, 'critical must sit below warn');
  });

  test('a low DSR produces a finding with a recommendation', () => {
    const lawyer = new Lawyer({ cfg: { enabled: true, dsrThreshold: 0.95 }, log: quietLog() });
    // A weak Sharpe over many trials: DSR will be far below 0.95.
    const returns = Array.from({ length: 200 }, (_, i) => (i % 2 ? 0.0011 : -0.001));
    const res = lawyer.audit({
      risk: { equity: 5000 },
      performance: { returns, K: 500, varSharpe: 0.01 },
    });
    const row = res.clauses.find((c) => c.id === 'deflated_sharpe');
    assert.strictEqual(row.measurable, true);
    assert.ok(row.value < 0.95, `dsr=${row.value}`);
    const f = res.findings.find((x) => x.clause === 'deflated_sharpe');
    assert.ok(f, 'a finding must be filed');
    assert.ok(f.recommendation.length > 10);
  });
});

// ================================================================ summary
console.log(`\n${'\u2500'.repeat(48)}`);
console.log(`  trials: ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  \u2022 ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'\u2500'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);
