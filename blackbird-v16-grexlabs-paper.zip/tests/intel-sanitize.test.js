'use strict';
/**
 * Regression tests for hostile news feeds (v15).
 *
 * THE BUG THIS SUITE EXISTS FOR
 * -----------------------------
 * `decodeEntities()` stripped markup with `/<[^>]+>/g`, which requires a
 * CLOSING `>`. A feed that ships an UNCLOSED tag therefore walked straight
 * through:
 *
 *   <title>Fed &lt;img src=x onerror=alert(1) hikes</title>
 *     -> "Fed <img src=x onerror=alert(1) hikes"
 *
 * The same hole let a `javascript:` scheme, raw control characters and ANSI
 * escape sequences survive, and nothing capped the title length or the number
 * of items — a 200 KB title and a 5 000-item document were both accepted.
 *
 * Why it matters: a headline is not inert text. It is written into the
 * Telegram report, the markdown report on disk, the journal and the dashboard
 * payload. Any of those that later renders it as HTML turns a news feed into
 * an injection vector, and an ANSI escape rewrites what an operator sees in a
 * terminal. A feed is untrusted input; it must be treated as such.
 *
 * THE RULE THIS SUITE ENFORCES
 * ----------------------------
 *   - A headline that contains markup, a script scheme or an event handler is
 *     DROPPED, not repaired. A real headline never contains `<img` or
 *     `onerror=`; repairing it would keep a hostile string in the pipeline for
 *     no benefit.
 *   - Control characters and ANSI escapes are CLEANED (they are noise, not an
 *     attack) and the headline is kept.
 *   - Titles are capped at 400 characters and a document at 500 items, so a
 *     hostile feed cannot exhaust memory or the report.
 *
 * Fully offline: fetch is injected, no network is touched.
 */
const assert = require('node:assert');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Intel, parseRss, decodeEntities, extractItems, sanitizeTitle } = require(path.join(SRC, 'intel/news'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

/** Wrap one title in a minimal RSS document. */
const rss = (titleXml) =>
  `<?xml version="1.0"?><rss version="2.0"><channel><item>${titleXml}` +
  `<pubDate>Sat, 22 Nov 2026 08:00:00 GMT</pubDate></item></channel></rss>`;

/** True when the string still contains something a renderer could execute. */
function hasMarkup(s) {
  return /<\s*[a-z!/]/i.test(String(s)) || /javascript\s*:/i.test(String(s)) || /on\w+\s*=/i.test(String(s));
}

/** True when the string still contains a control character or ANSI escape. */
function hasControl(s) {
  // eslint-disable-next-line no-control-regex
  return /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/.test(String(s));
}

(async () => {
  // ------------------------------------------------------- the reported bug
  await t('hostile: an UNCLOSED <img onerror> headline is dropped', () => {
    const items = parseRss(rss('<title>Fed &lt;img src=x onerror=alert(1) hikes</title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a <script> payload is dropped', () => {
    const items = parseRss(rss('<title>CPI &lt;script&gt;alert(1)&lt;/script&gt; surge</title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a CDATA-wrapped <img onerror> is dropped', () => {
    const items = parseRss(rss('<title><![CDATA[<img src=x onerror=alert(1)> CPI surge]]></title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a double-encoded &amp;lt;script&amp;gt; is dropped', () => {
    const items = parseRss(rss('<title>Rate cut &amp;lt;script&amp;gt;alert(1)&amp;lt;/script&amp;gt;</title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a javascript: scheme is dropped', () => {
    const items = parseRss(rss('<title>javascript:alert(1) FOMC</title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a bare event handler is dropped', () => {
    const items = parseRss(rss('<title>CPI onerror=alert(1) surge</title>'));
    assert.strictEqual(items.length, 0, `hostile headline survived: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  await t('hostile: a title that is ONLY markup is dropped', () => {
    const items = parseRss(rss('<title>&lt;img src=x onerror=alert(1)&gt;</title>'));
    assert.strictEqual(items.length, 0);
  });

  // ------------------------------------------- cleaned, not dropped (noise)
  await t('noise: control characters and ANSI escapes are removed, headline kept', () => {
    const items = parseRss(rss('<title>a\u0000b\u001b[31m CPI\u001b[0m</title>'));
    assert.strictEqual(items.length, 1, 'a control character is noise, not an attack');
    assert.ok(!hasControl(items[0].title), `control char survived: ${JSON.stringify(items[0].title)}`);
    assert.match(items[0].title, /CPI/);
  });

  // ------------------------------------------------------------ size limits
  await t('hostile: an oversized title is capped', () => {
    const items = parseRss(rss(`<title>${'A'.repeat(200000)}</title>`));
    assert.strictEqual(items.length, 1);
    assert.ok(items[0].title.length <= 400, `title not capped: ${items[0].title.length} chars`);
  });

  await t('hostile: a 5000-item document is capped', () => {
    let big = '<rss><channel>';
    for (let i = 0; i < 5000; i++) big += `<item><title>headline ${i}</title></item>`;
    big += '</channel></rss>';
    const items = parseRss(big);
    assert.ok(items.length <= 500, `item count not capped: ${items.length}`);
    assert.ok(items.length > 0, 'the cap must not empty a valid feed');
  });

  // ------------------------------------------------------- JSON feed path too
  await t('hostile: the JSON feed path is sanitised as well', () => {
    const items = extractItems(
      { articles: [{ title: 'Fed <img src=x onerror=alert(1)> hikes', seendate: '20261122080000' }] },
      { path: 'articles', titleField: 'title', timeField: 'seendate' }
    );
    assert.strictEqual(items.length, 0, `hostile headline survived the JSON path: ${JSON.stringify(items.map((i) => i.title))}`);
  });

  // ------------------------------------------------- end-to-end through Intel
  await t('hostile: a poisoned feed never puts markup in the aggregate view', async () => {
    const URL = 'https://evil.test/rss';
    const body = `<?xml version="1.0"?><rss version="2.0"><channel>
      <item><title>FOMC &lt;img src=x onerror=alert(1)&gt; decision</title><pubDate>Sat, 22 Nov 2026 08:00:00 GMT</pubDate></item>
      <item><title>&lt;script&gt;alert(1)&lt;/script&gt; CPI surge</title><pubDate>Sat, 22 Nov 2026 07:00:00 GMT</pubDate></item>
      <item><title>war escalation &lt;svg onload=alert(1)&gt;</title><pubDate>Sat, 22 Nov 2026 06:00:00 GMT</pubDate></item>
      <item><title>Fed signals rate hike as inflation surges</title><pubDate>Sat, 22 Nov 2026 05:00:00 GMT</pubDate></item>
    </channel></rss>`;
    const fetchImpl = async () => ({ ok: true, status: 200, text: async () => body, json: async () => ({}) });
    const intel = new Intel({
      cfg: { enabled: true, feeds: { macro: { url: URL, format: 'rss', weight: 1 } } },
      log: quietLog(),
      fetchImpl,
    });
    const view = await intel.refresh();

    assert.strictEqual(view.items, 1, `only the clean headline may survive, got ${view.items}`);
    for (const item of view.top) {
      assert.ok(!hasMarkup(item.title), `markup reached the view: ${JSON.stringify(item.title)}`);
    }
    if (view.blackoutReason) {
      assert.ok(!hasMarkup(view.blackoutReason), `markup reached blackoutReason: ${JSON.stringify(view.blackoutReason)}`);
    }
    const snap = intel.snapshot();
    assert.ok(!hasMarkup(JSON.stringify(snap)), 'markup reached the /status snapshot');
  });

  await t('hostile: sanitising does not damage a normal headline', () => {
    assert.strictEqual(sanitizeTitle("Fed's Powell warns of \"tighter\" policy"), "Fed's Powell warns of \"tighter\" policy");
    assert.strictEqual(sanitizeTitle('Rate hike  as   inflation surges'), 'Rate hike as inflation surges');
    assert.strictEqual(sanitizeTitle(''), '');
    assert.strictEqual(sanitizeTitle(null), '');
    assert.strictEqual(sanitizeTitle(undefined), '');
  });

  await t('hostile: decodeEntities still decodes the harmless entities', () => {
    assert.strictEqual(decodeEntities('war &amp; peace'), 'war & peace');
    assert.strictEqual(decodeEntities('Fed&#39;s'), "Fed's");
  });

  done('intel-sanitize');
})();
