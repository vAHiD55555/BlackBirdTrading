#!/usr/bin/env node
'use strict';
/**
 * The watch (دیده‌بان) — the FULL apply path.
 *
 * The other watch suite stops at "the council approved". This one follows the
 * swap all the way to the book: proposal -> council vote -> real close of the
 * incumbent -> real open of the candidate.
 *
 * Regression target: before the fix, `autoApply` was documented but never read
 * anywhere in the codebase, and `review()` was never called by the engine. A
 * swap was proposed, journalled, and then silently dropped. These tests fail on
 * that code and pass once the apply path exists.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Watch } = require('../src/agents/watch');
const { Portfolio, Position } = require('../src/exec/portfolio');

const noop = () => {};
const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };

function makeCfg(over = {}) {
  const { watch: watchOver, ...rest } = over;
  return {
    symbols: ['BTCUSDT', 'ETHUSDT'],
    fees: { makerBps: 2, takerBps: 5, slippageBpsPer1kNotional: 0.6 },
    strategy: { minTpBps: 30, maxSlBps: 250 },
    risk: { minNotionalUsd: 10 },
    ...rest,
    watch: {
      enabled: true, intervalMs: 6 * 3600000, universe: [], maxCandidates: 5,
      minQuoteVolumeUsd: 5_000_000, minEdgeBps: 25, stagnantDays: 14,
      stagnantReturnPct: 1.0, autoApply: false, requireCouncil: true, maxSwapsPerCycle: 1,
      ...(watchOver || {}),
    },
  };
}

function makeStore() {
  const rows = [];
  return { append: (type, data) => rows.push({ type, data }), rows };
}

/** A portfolio holding one stagnant XRP position worth $500. */
function makePortfolio() {
  const pf = new Portfolio(log);
  pf.open(new Position({
    symbol: 'XRPUSDT', side: 'long', qty: 500, entry: 1, fee: 0.1, notional: 500,
    strategy: 'SWEEP_RECLAIM', tp: 1.05, sl: 0.98, timeStopAt: Date.now() + 3600000,
  }));
  return pf;
}

/** Records what the executor was asked to do, in order. */
function makeExecutor(opts = {}) {
  const calls = [];
  return {
    calls,
    close(symbol, reason) {
      calls.push({ op: 'close', symbol, reason });
      if (opts.closeThrows) throw new Error('close exploded');
      if (opts.closeFails) return { ok: false, reason: 'no_book' };
      return { ok: true };
    },
    open(swap, decision) {
      calls.push({ op: 'open', symbol: swap.in.symbol, notional: swap.notional, qty: decision.qty });
      if (opts.openFails) return { ok: false, reason: 'stale_book' };
      return { ok: true };
    },
  };
}

function makeSwap(over = {}) {
  return {
    id: 'swap-1', ts: 1,
    out: { symbol: 'XRPUSDT', notional: 500, returnPct: 0.1, reason: 'flat(0.10%)' },
    in: { symbol: 'ADAUSDT', score: 0.8, expectedEdgeBps: 300, momentumPct: 3 },
    notional: 500, edgeBps: 100, status: 'pending',
    ...over,
  };
}

const approvingBoard = { review: () => ({ approved: true, qty: 500, notional: 500 }) };
const vetoingBoard = { review: () => ({ approved: false, reason: 'veto: risk' }) };

(async () => {
  console.log('\n▸ watch apply — the default is still "propose only"');

  await t('autoApply=false means an approved swap is NOT applied', () => {
    const store = makeStore();
    const ex = makeExecutor();
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: false } }), log, store,
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const rev = w.review(makeSwap());
    assert.strictEqual(rev.approved, true, 'the council did approve');
    const ap = w.applySwap(makeSwap(), rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'auto_apply_off');
    assert.strictEqual(ex.calls.length, 0, 'nothing may touch the book');
    assert.strictEqual(w.stats.applied, 0);
  });

  console.log('\n▸ watch apply — a veto never reaches the book');

  await t('a council veto blocks the apply even with autoApply on', () => {
    const ex = makeExecutor();
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: vetoingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    assert.strictEqual(rev.approved, false);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'not_approved');
    assert.strictEqual(ex.calls.length, 0);
  });

  console.log('\n▸ watch apply — the happy path, in the right order');

  await t('an approved swap closes the incumbent and then opens the candidate', () => {
    const store = makeStore();
    const ex = makeExecutor();
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store,
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);

    assert.strictEqual(ap.ok, true, ap.reason);
    assert.deepStrictEqual(ex.calls.map((c) => c.op), ['close', 'open'], 'close must come first');
    assert.strictEqual(ex.calls[0].symbol, 'XRPUSDT');
    assert.strictEqual(ex.calls[1].symbol, 'ADAUSDT');
    assert.strictEqual(w.stats.applied, 1);
    assert.ok(store.rows.some((r) => r.type === 'watch_applied'), 'the apply is journalled');
  });

  await t('the applied notional never exceeds the incumbent position', () => {
    const ex = makeExecutor();
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    // A swap that claims $5000 must be clamped to the $500 actually held.
    const swap = makeSwap({ notional: 5000 });
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, true, ap.reason);
    assert.strictEqual(ex.calls[1].notional, 500, 'a swap is a replacement, not an addition');
  });

  console.log('\n▸ watch apply — stale and unsafe swaps are refused');

  await t('a swap whose incumbent is already closed is refused', () => {
    const ex = makeExecutor();
    const pf = new Portfolio(log); // empty book
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: pf, board: approvingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'incumbent_gone');
    assert.strictEqual(ex.calls.length, 0);
  });

  await t('a swap into a symbol we already hold is refused', () => {
    const ex = makeExecutor();
    const pf = makePortfolio();
    pf.open(new Position({
      symbol: 'ADAUSDT', side: 'long', qty: 100, entry: 1, fee: 0.1, notional: 100,
      strategy: 'X', tp: 1.1, sl: 0.9, timeStopAt: Date.now() + 3600000,
    }));
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: pf, board: approvingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'candidate_already_held');
    assert.strictEqual(ex.calls.length, 0);
  });

  await t('a notional below the venue minimum is refused', () => {
    const ex = makeExecutor();
    const pf = new Portfolio(log);
    pf.open(new Position({
      symbol: 'XRPUSDT', side: 'long', qty: 1, entry: 1, fee: 0.01, notional: 1,
      strategy: 'X', tp: 1.1, sl: 0.9, timeStopAt: Date.now() + 3600000,
    }));
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: pf, board: approvingBoard, executor: ex,
    });
    const swap = makeSwap({ notional: 1 });
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'below_min_notional');
    assert.strictEqual(ex.calls.length, 0);
  });

  console.log('\n▸ watch apply — failures fail in the safe direction');

  await t('a throwing close leaves the book untouched and opens nothing', () => {
    const ex = makeExecutor({ closeThrows: true });
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store: makeStore(),
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'close_failed');
    assert.deepStrictEqual(ex.calls.map((c) => c.op), ['close'], 'no open after a failed close');
    assert.strictEqual(w.stats.applied, 0);
  });

  await t('a failed open leaves us flat, never doubled', () => {
    const store = makeStore();
    const ex = makeExecutor({ openFails: true });
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true } }), log, store,
      hub: { get: () => null }, exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const swap = makeSwap();
    const rev = w.review(swap);
    const ap = w.applySwap(swap, rev.decision);
    assert.strictEqual(ap.ok, false);
    assert.strictEqual(ap.reason, 'open_failed_flat');
    assert.deepStrictEqual(ex.calls.map((c) => c.op), ['close', 'open']);
    assert.ok(store.rows.some((r) => r.type === 'watch_apply_failed'), 'the failure is journalled');
    assert.strictEqual(w.stats.applied, 0);
  });

  console.log('\n▸ watch apply — the whole cycle, end to end');

  await t('runCycle: discover -> rank -> propose -> council -> apply', async () => {
    const store = makeStore();
    const ex = makeExecutor();
    const bars = [];
    let px = 100;
    for (let i = 0; i < 300; i++) { px *= 1.0006; bars.push({ t: i * 3600000, o: px, h: px * 1.004, l: px * 0.996, c: px, v: 1000 }); }
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: true, universe: ['ADAUSDT'], minEdgeBps: 1 } }),
      log, store,
      hub: { get: (s) => (s === 'ADAUSDT' ? { bars: { toArray: () => bars } } : null) },
      exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const r = await w.runCycle();
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.swaps.length, 1, 'one swap was proposed');
    assert.strictEqual(r.outcomes.length, 1);
    assert.strictEqual(r.outcomes[0].applied, true, r.outcomes[0].reason);
    assert.deepStrictEqual(ex.calls.map((c) => c.op), ['close', 'open']);
    assert.strictEqual(w.stats.applied, 1);
  });

  await t('runCycle with autoApply off proposes but never applies', async () => {
    const ex = makeExecutor();
    const bars = [];
    let px = 100;
    for (let i = 0; i < 300; i++) { px *= 1.0006; bars.push({ t: i * 3600000, o: px, h: px * 1.004, l: px * 0.996, c: px, v: 1000 }); }
    const w = new Watch({
      cfg: makeCfg({ watch: { autoApply: false, universe: ['ADAUSDT'], minEdgeBps: 1 } }),
      log, store: makeStore(),
      hub: { get: (s) => (s === 'ADAUSDT' ? { bars: { toArray: () => bars } } : null) },
      exchange: null,
      portfolio: makePortfolio(), board: approvingBoard, executor: ex,
    });
    const r = await w.runCycle();
    assert.strictEqual(r.swaps.length, 1);
    assert.strictEqual(r.outcomes[0].applied, false);
    assert.strictEqual(r.outcomes[0].reason, 'auto_apply_off');
    assert.strictEqual(ex.calls.length, 0);
  });

  done('watch-apply');
})();
