#!/usr/bin/env node
'use strict';
/** Profiles, AngryBird hard limits, evidence chain, separation of duties, court, roles. Offline, deterministic. */
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { t, done } = require('./harness');
const { applyProfile, claimDataDir, ANGRYBIRD_OVERLAY } = require('../src/profiles');
const { angryNotionalCap } = require('../src/risk/angry-limits');
const { EvidenceChain } = require('../src/audit/chain');
const { checkSeparationOfDuties, checkApproval, PRINCIPLES } = require('../src/charter/foundation');
const { Court } = require('../src/court/court');
const { RoleBook, parseRoleMap } = require('../src/roles');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'bb-'));
const full = () => ({ equity: 100, startEquity: 100, drawdownPct: 0, dailyPnlPct: 0, lossStreak: 0, yellowCards: 0, redCard: false, halted: false });
const A = ANGRYBIRD_OVERLAY.risk.angry;

(async () => {
  console.log('\n\u25b8 profiles \u2014 isolation');
  await t('BlackBird (default) is untouched; AngryBird gets $100 / $25 and its own directories', () => {
    const bb = applyProfile({ risk: { startEquity: 5000 }, runtime: {}, reporter: {}, trials: {} }, { env: {}, pkgVersion: '4.0.0' });
    assert.strictEqual(bb.risk.startEquity, 5000); assert.strictEqual(bb.profile.name, 'blackbird'); assert.strictEqual(bb.risk.angry, undefined);
    const ab = applyProfile({ risk: { startEquity: 5000 }, runtime: {}, reporter: {}, trials: {} }, { env: { BB_PROFILE: 'angrybird', DATA_DIR: '/d' }, pkgVersion: '4.0.0' });
    assert.strictEqual(ab.risk.startEquity, 100); assert.strictEqual(ab.risk.angry.maxTradeNotionalUsd, 25); assert.strictEqual(ab.risk.maxPositionPct, 0.25);
    for (const p of [ab.runtime.stateFile, ab.runtime.journalFile, ab.runtime.logDir, ab.reporter.dir, ab.trials.file]) assert.ok(p.startsWith(path.join('/d', 'profiles', 'angrybird')), p);
    assert.strictEqual(ab.profile.version, '4.0.0+angrybird');
  });
  await t('an unknown profile is refused, not defaulted', () => { assert.throws(() => applyProfile({ risk: {}, runtime: {}, reporter: {}, trials: {} }, { env: { BB_PROFILE: 'wild' } }), /not a known profile/); });
  await t('a data directory cannot be shared between profiles', () => {
    const d = tmp();
    assert.ok(claimDataDir(d, 'angrybird').ok);
    assert.ok(claimDataDir(d, 'angrybird').ok);
    const r = claimDataDir(d, 'blackbird'); assert.ok(!r.ok); assert.match(r.reason, /belongs to profile "angrybird"/);
    const legacy = tmp(); fs.writeFileSync(path.join(legacy, 'state.json'), '{}');
    assert.ok(!claimDataDir(legacy, 'angrybird').ok, 'AngryBird must not adopt BlackBird state');
    assert.ok(claimDataDir(legacy, 'blackbird').ok);
  });
  await t('AngryBird refuses live mode in validation', () => {
    process.env.BB_PROFILE = 'angrybird';
    try {
      const { loadConfig, validateConfig } = require('../src/config');
      const cfg = loadConfig({ mode: 'live' });
      assert.ok(validateConfig(cfg).problems.some((p) => /angrybird is paper-only/.test(p)));
    } finally { delete process.env.BB_PROFILE; }
  });

  console.log('\n\u25b8 AngryBird \u2014 nominal size is a hard, deterministic limit');
  await t('$25 only when every condition holds', () => { const r = angryNotionalCap(A, full()); assert.strictEqual(r.cap, 25); assert.ok(r.full); });
  await t('each failed condition drops the cap to the reduced size', () => {
    for (const bad of [{ equity: 85 }, { drawdownPct: 6 }, { dailyPnlPct: -3 }, { lossStreak: 2 }, { yellowCards: 1 }]) {
      const r = angryNotionalCap(A, { ...full(), ...bad }); assert.strictEqual(r.cap, 10, JSON.stringify(bad)); assert.ok(!r.full && r.reasons.length);
    }
  });
  await t('red card or halt => zero; unknown/NaN inputs fail closed (never full size)', () => {
    assert.strictEqual(angryNotionalCap(A, { ...full(), redCard: true }).cap, 0);
    assert.strictEqual(angryNotionalCap(A, { ...full(), halted: true }).cap, 0);
    assert.notStrictEqual(angryNotionalCap(A, { ...full(), equity: NaN }).cap, 25);
    assert.notStrictEqual(angryNotionalCap(A, { ...full(), drawdownPct: undefined }).cap, 25);
    assert.strictEqual(angryNotionalCap({ ...A, maxTradeNotionalUsd: 0 }, full()).cap, 0);
  });
  await t('risk.check vetoes a $26 order and a $15 order when full size is not earned; allows $25', () => {
    const { RiskManager } = require('../src/risk/risk');
    const cfg = { risk: { startEquity: 100, maxDailyTrades: 60, maxDailyLossPct: 0.05, killSwitchDrawdownPct: 0.15, maxOpenPositions: 2, maxSymbolExposurePct: 1, maxNetExposurePct: 1, maxPositionPct: 1, angry: A } };
    const store = { state: { equity: 100, counters: { tradesToday: 0, lossesStreak: 0 }, cooldowns: {}, dayStartEquity: 100 }, append() {} };
    const risk = new RiskManager({ cfg, store, log: { error() {}, warn() {}, info() {} } });
    // This case is about the nominal cap, so the market window is held open;
    // the activation gate itself has its own suite (tests/angry.test.js).
    risk.marketContext = () => ({ atrPercentile: 0.9, exodusBreadth: 0.8, recoveryScore: 0.7, spreadOk: true, depthOk: true });
    const pf = { openPositions: () => [], hasPosition: () => false, exposureBySymbol: () => 0, totalExposure: () => 0, netExposure: () => 0 };
    const order = (n) => risk.check({ symbol: 'X', side: 'buy', notional: n }, pf);
    assert.ok(order(25).ok); assert.ok(!order(26).ok); assert.match(order(26).reason, /angry_notional_cap/);
    risk.courtState = () => ({ yellowCards: 1, redCard: false });
    assert.ok(!order(15).ok); assert.ok(order(10).ok);
    risk.courtState = () => { throw new Error('boom'); };
    assert.ok(!order(25).ok, 'a broken court input fails closed');
  });

  console.log('\n\u25b8 evidence chain \u2014 append-only and verifiable');
  await t('verifies; editing, deleting, reordering or inserting a record is detected', () => {
    const c = new EvidenceChain({ clock: () => 1 });
    for (let i = 0; i < 5; i++) c.append('k', 'a', { i });
    assert.ok(c.verify().ok);
    const mut = (f) => { const r = c.list(); f(r); return EvidenceChain.verify(r); };
    assert.ok(!mut((r) => { r[2].data.i = 99; }).ok);
    assert.ok(!mut((r) => { r.splice(2, 1); }).ok);
    assert.ok(!mut((r) => { [r[1], r[2]] = [r[2], r[1]]; }).ok);
    assert.ok(!mut((r) => { r.splice(2, 0, { ...r[1] }); }).ok);
  });
  await t('there is no API to delete or edit, and list() returns copies', () => {
    const c = new EvidenceChain();
    c.append('k', 'a', { x: 1 });
    for (const m of ['delete', 'remove', 'update', 'truncate', 'clear', 'edit']) assert.strictEqual(typeof c[m], 'undefined');
    c.list()[0].data.x = 2; assert.strictEqual(c.list()[0].data.x, 1);
  });
  await t('persists across restart, and a tampered file refuses to load', () => {
    const f = path.join(tmp(), 'e.jsonl');
    const c = new EvidenceChain({ file: f }); c.append('a', 'x', {}); c.append('b', 'x', {});
    const again = new EvidenceChain({ file: f }); assert.strictEqual(again.head().seq, 1); again.append('c', 'x', {}); assert.ok(new EvidenceChain({ file: f }).verify().ok);
    const lines = fs.readFileSync(f, 'utf8').split('\n').filter(Boolean); lines.splice(1, 1); fs.writeFileSync(f, lines.join('\n') + '\n');
    assert.throws(() => new EvidenceChain({ file: f }), /corrupted/);
  });

  console.log('\n\u25b8 charter \u2014 separation of duties');
  await t('principles are carried; self-oversight, self-approval and self-assessment are rejected', () => {
    assert.strictEqual(PRINCIPLES.length, 2);
    const ok = { actor: 'p', overseer: 'o', approver: 'r', evaluator: 'c' };
    assert.ok(checkSeparationOfDuties(ok).ok);
    for (const bad of [{ overseer: 'p' }, { approver: 'p' }, { evaluator: 'p' }, { overseer: 'x', approver: 'x', evaluator: 'x' }]) assert.ok(!checkSeparationOfDuties({ ...ok, ...bad }).ok, JSON.stringify(bad));
    assert.ok(!checkSeparationOfDuties({ actor: 'p' }).ok);
    assert.ok(!checkApproval({ proposer: 'a', approver: 'a' }).ok); assert.ok(!checkApproval({ proposer: 'a', approver: 's', subject: 's' }).ok); assert.ok(checkApproval({ proposer: 'a', approver: 'b', subject: 'c' }).ok);
  });

  console.log('\n\u25b8 court \u2014 limits, red card, 30-second window');
  const roster = ANGRYBIRD_OVERLAY.court.roster;
  const setup = (over = {}) => {
    const calls = []; let now = 0; const timers = [];
    const hooks = {
      alert: (ch) => { calls.push(['alert', ch]); return { ok: over.channels ? over.channels.includes(ch) : true }; },
      blockOrders: () => calls.push(['block']), cancelPending: () => calls.push(['cancel']), controlledExit: (p) => calls.push(['exit', p]),
      offerControl: () => calls.push(['offer']), summonCouncil: () => calls.push(['council']), closeSeason: () => calls.push(['closed']), continueOpenPositions: () => calls.push(['continue']),
    };
    const ev = new EvidenceChain({ clock: () => now });
    const court = new Court({ cfg: ANGRYBIRD_OVERLAY.court, evidence: ev, hooks, clock: () => now, timers: { setTimeout: (fn, ms) => { const x = { fn, ms }; timers.push(x); return x; }, clearTimeout: (x) => { x.cleared = true; } } });
    assert.ok(court.startSeason({ id: 's1', roster }).ok);
    return { court, calls, ev, timers };
  };
  await t('a season needs a valid roster: duties separated, council at quorum and independent of the parties', () => {
    const c = new Court({ cfg: ANGRYBIRD_OVERLAY.court, evidence: new EvidenceChain() });
    assert.strictEqual(c.startSeason({ roster: { ...roster, overseer: roster.actor } }).reason, 'separation_of_duties');
    assert.strictEqual(c.startSeason({ roster: { ...roster, council: ['a', 'b'] } }).reason, 'council_below_quorum');
    assert.strictEqual(c.startSeason({ roster: { ...roster, council: ['a', 'b', roster.overseer] } }).reason, 'council_member_is_a_party');
  });
  await t('at most 3 invisible interventions per season; they leave no public trace', () => {
    const { court, ev } = setup();
    for (let i = 0; i < 3; i++) assert.ok(court.intervene({ rationale: 'r' }).ok);
    assert.strictEqual(court.intervene({ rationale: 'r' }).reason, 'intervention_limit_reached');
    assert.ok(ev.list().some((r) => r.kind === 'intervention_refused'));
    assert.ok(!/interven|overseer|قاضی/i.test(JSON.stringify(court.publicView())));
  });
  await t('at most 2 yellow cards; each alerts on several channels, and degraded delivery is recorded', () => {
    const { court, calls } = setup();
    const y = court.yellowCard({ reason: 'x' }); assert.deepStrictEqual(y.delivered, ['dashboard', 'telegram', 'email']); assert.ok(!y.degradedAlert);
    assert.ok(court.yellowCard({ reason: 'y' }).ok);
    assert.strictEqual(court.yellowCard({ reason: 'z' }).reason, 'yellow_limit_reached');
    assert.strictEqual(calls.filter((c) => c[0] === 'alert').length, 6);
    const low = setup({ channels: ['dashboard'] }); assert.ok(low.court.yellowCard({ reason: 'x' }).degradedAlert);
  });
  await t('red card: orders blocked, pending cancelled, STAGED exit (not blind close) \u2014 all before any waiting', () => {
    const { court, calls, timers } = setup();
    const r = court.redCard({ ground: 'serious_financial_loss_risk', reason: 'r' });
    assert.ok(r.ok); assert.strictEqual(court.phase, 'closing');
    assert.deepStrictEqual(calls.map((c) => c[0]), ['block', 'cancel', 'exit', 'offer']);
    assert.strictEqual(calls[2][1].blind_close_all, false);
    assert.strictEqual(timers[0].ms, 30000);
    assert.ok(court.redCardActive);
  });
  await t('red card needs an allowed ground; nothing else escalates', () => {
    const { court, calls } = setup();
    assert.strictEqual(court.redCard({ ground: 'dislike' }).reason, 'ground_not_allowed'); assert.strictEqual(calls.length, 0); assert.strictEqual(court.phase, 'normal');
    assert.ok(court.redCard({ ground: 'ecosystem_collapse' }).ok);
  });
  await t('user takes control in the window: no council; continuing positions needs accepted responsibility', () => {
    let s = setup(); s.court.redCard({ ground: 'ecosystem_collapse' });
    const r = s.court.takeControl({ userId: 'u1' }); assert.ok(r.ok); assert.ok(s.timers[0].cleared); assert.ok(!s.calls.some((c) => c[0] === 'council'));
    s = setup(); s.court.redCard({ ground: 'ecosystem_collapse' });
    assert.ok(!s.court.takeControl({ userId: 'u', continueOpenPositions: true }).continued); assert.ok(!s.calls.some((c) => c[0] === 'continue'));
    s = setup(); s.court.redCard({ ground: 'ecosystem_collapse' });
    assert.ok(s.court.takeControl({ userId: 'u', continueOpenPositions: true, acceptResponsibility: true }).continued); assert.ok(s.calls.some((c) => c[0] === 'continue'));
    assert.ok(!setup().court.takeControl({ userId: 'u' }).ok, 'no takeover outside the closing phase');
  });
  await t('window expires: standby council is summoned; its report must be well-formed and scored for both parties', () => {
    const s = setup(); s.court.redCard({ ground: 'serious_financial_loss_risk' });
    s.timers[0].fn(); assert.ok(s.calls.some((c) => c[0] === 'council')); assert.strictEqual(s.court.season.commander, 'council');
    const good = { members: roster.council, observations: ['log shows X'], hearsay: ['someone said Y'], scores: { actor: 55, overseer: 70 }, ruling: 'ok' };
    assert.strictEqual(s.court.submitCouncilReport({ ...good, members: ['council_1'] }).reason, 'below_quorum');
    assert.strictEqual(s.court.submitCouncilReport({ ...good, members: ['a', 'b', 'c'] }).reason, 'member_not_on_standby_roster');
    assert.strictEqual(s.court.submitCouncilReport({ ...good, hearsay: undefined }).reason, 'observations_and_hearsay_required');
    assert.strictEqual(s.court.submitCouncilReport({ ...good, scores: { actor: 55 } }).reason, 'both_parties_must_be_scored_0_100');
    assert.ok(s.court.submitCouncilReport(good).ok); assert.strictEqual(s.court.phase, 'ended');
  });
  await t('the window never delays the block; a late timer after user takeover does nothing', () => {
    const s = setup(); s.court.redCard({ ground: 'ecosystem_collapse' });
    assert.strictEqual(s.calls[0][0], 'block'); // already done, timer not yet fired
    s.court.takeControl({ userId: 'u' }); s.timers[0].fn();
    assert.ok(!s.calls.some((c) => c[0] === 'council'));
  });
  await t('every card and transition is in the evidence chain, which still verifies', () => {
    const s = setup(); s.court.intervene({ rationale: 'a' }); s.court.yellowCard({ reason: 'b' }); s.court.redCard({ ground: 'ecosystem_collapse' }); s.timers[0].fn();
    const kinds = s.ev.list().map((r) => r.kind);
    for (const k of ['season_start', 'intervention', 'yellow_card', 'red_card', 'orders_blocked', 'controlled_exit_started', 'control_offered', 'council_summoned']) assert.ok(kinds.includes(k), k);
    assert.ok(s.ev.verify().ok);
  });
  await t('a throwing hook cannot stop the red-card sequence', () => {
    const ev = new EvidenceChain(); const seen = [];
    const c = new Court({ cfg: ANGRYBIRD_OVERLAY.court, evidence: ev, hooks: { blockOrders: () => { throw new Error('x'); }, cancelPending: () => seen.push('cancel'), controlledExit: () => seen.push('exit') }, timers: { setTimeout: () => ({}), clearTimeout() {} } });
    c.startSeason({ roster }); assert.ok(c.redCard({ ground: 'ecosystem_collapse' }).ok); assert.deepStrictEqual(seen, ['cancel', 'exit']);
    assert.ok(ev.list().some((r) => r.kind === 'hook_error'));
  });

  console.log('\n\u25b8 roles \u2014 masks are not agents; the model map stays secret');
  await t('AngryBird preamble says the other roles are the same model; the role map never serialises', () => {
    const env = { ROLE_MAP_JSON: JSON.stringify({ trader: { provider: 'gemini', model: 'g-1' }, analyst: { provider: 'gemini', model: 'g-1' }, overseer_model: { provider: 'openai', model: 'big' } }) };
    const rb = new RoleBook({ profile: 'angrybird', env });
    assert.match(rb.preamble('trader'), /SAME model as you/); assert.match(rb.preamble('trader'), /enforced by deterministic code/);
    assert.throws(() => rb.preamble('nonsense'));
    assert.ok(rb.singleModel() === true);
    assert.ok(!/gemini|openai|big|g-1/.test(JSON.stringify(rb)), 'role map must not appear in serialised state');
    assert.ok(!/gemini|openai/.test(JSON.stringify(rb.publicRoles())));
    assert.strictEqual(parseRoleMap('{bad').error, 'ROLE_MAP_JSON is not valid JSON');
  });

  done('profiles');
})();
