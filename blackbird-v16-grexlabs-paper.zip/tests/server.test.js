#!/usr/bin/env node
'use strict';
/**
 * BlackBird — server / deployment test suite.
 *
 * These tests exist because the dashboard did not come up on a real Linux
 * server, and every one of the three causes was invisible from the logs:
 *
 *   1. HOST was set by the platform to the app's *public hostname*. Node tried
 *      to bind it as a local interface, got ENOTFOUND, and the error was
 *      swallowed by a `server.on('error')` that only logged a warning. The
 *      process stayed alive with no listener: the health check failed, the
 *      platform restarted it, forever.
 *   2. EADDRINUSE was swallowed the same way, so a restart that raced the old
 *      socket left a live process with a dead port.
 *   3. The dashboard loaded https://telegram.org/js/telegram-web-app.js as a
 *      blocking <script>. On a network where that host is unreachable the
 *      parser stalls and the page renders blank even though /status is fine.
 *
 * Each test below pins one of those, so they cannot come back silently.
 *
 * Zero dependencies, no network, real sockets on an ephemeral port.
 *
 * Run: node tests/server.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const http = require('node:http');
const net = require('node:net');
const { spawn } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'src');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message}`);
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message}`);
  }
}

/** Ask the OS for a free port, then release it. */
function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(() => resolve(p));
    });
  });
}

function get(port, pathname, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname, timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body, headers: res.headers }));
    });
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
    req.on('error', reject);
  });
}

/** Boot the real entry point and wait until the port answers (or it dies). */
function boot(env, port, waitMs = 20000) {
  const child = spawn(process.execPath, [path.join(SRC, 'index.js')], {
    cwd: ROOT,
    env: { ...process.env, ...env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let out = '';
  child.stdout.on('data', (d) => { out += d; });
  child.stderr.on('data', (d) => { out += d; });

  const ready = new Promise((resolve, reject) => {
    const started = Date.now();
    const tick = async () => {
      if (child.exitCode !== null) return reject(new Error(`process exited ${child.exitCode}\n${out.slice(-1200)}`));
      try {
        await get(port, '/healthz', 800);
        return resolve();
      } catch {
        if (Date.now() - started > waitMs) return reject(new Error(`port never answered\n${out.slice(-1200)}`));
        setTimeout(tick, 250);
      }
    };
    tick();
  });

  return { child, ready, output: () => out, stop: () => { try { child.kill('SIGKILL'); } catch { /* ignore */ } } };
}

(async () => {
  console.log('\n\u25b8 server \u2014 bind, probe, dashboard');

  // ---------------------------------------------------------------- HOST trap
  // The exact failure that broke the real deployment: a PaaS sets HOST to the
  // public hostname. The server must ignore it and bind 0.0.0.0 anyway.
  await testAsync('HOST set to a public hostname does not prevent binding', async () => {
    const port = await freePort();
    const b = boot({ HOST: 'myapp.example.com', BB_HOST: '' }, port);
    try {
      await b.ready;
      const r = await get(port, '/healthz');
      assert.strictEqual(r.status, 200, 'healthz must answer 200');
      assert.match(b.output(), /ignoring HOST/, 'the override must be logged, not silent');
    } finally {
      b.stop();
    }
  });

  // A literal bindable address must still be honoured — the fix must not make
  // BB_HOST useless.
  await testAsync('BB_HOST=127.0.0.1 is honoured', async () => {
    const port = await freePort();
    const b = boot({ HOST: 'myapp.example.com', BB_HOST: '127.0.0.1' }, port);
    try {
      await b.ready;
      const r = await get(port, '/healthz');
      assert.strictEqual(r.status, 200);
      assert.doesNotMatch(b.output(), /ignoring HOST/, 'BB_HOST must win over HOST');
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------------- port in use
  // A swallowed EADDRINUSE used to leave a live process with no listener.
  await testAsync('a busy port is retried, then the process exits non-zero', async () => {
    const port = await freePort();
    const blocker = net.createServer();
    await new Promise((res) => blocker.listen(port, '0.0.0.0', res));

    const child = spawn(process.execPath, [path.join(SRC, 'index.js')], {
      cwd: ROOT,
      env: { ...process.env, PORT: String(port), BB_HOST: '0.0.0.0' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { out += d; });

    const code = await new Promise((resolve) => {
      const t = setTimeout(() => { child.kill('SIGKILL'); resolve('timeout'); }, 20000);
      child.on('exit', (c) => { clearTimeout(t); resolve(c); });
    });
    blocker.close();

    assert.notStrictEqual(code, 'timeout', 'must not hang forever on a busy port');
    assert.notStrictEqual(code, 0, 'must exit non-zero so the supervisor restarts it');
    assert.match(out, /busy|EADDRINUSE/, 'the reason must be logged');
  });

  // ------------------------------------------------------------- health split
  // /healthz answers "alive"; /readyz answers "has data". Conflating them turns
  // a blocked exchange into a restart loop.
  await testAsync('/healthz is 200 while /readyz reports the real data state', async () => {
    const port = await freePort();
    // A deliberately unreachable exchange: the engine must still serve health.
    const b = boot({ EXCHANGE: 'binance', SYMBOLS: 'BTCUSDT,ETHUSDT' }, port);
    try {
      await b.ready;
      const hz = await get(port, '/healthz');
      assert.strictEqual(hz.status, 200, '/healthz must be 200 whenever the process is alive');
      const body = JSON.parse(hz.body);
      assert.strictEqual(body.ok, true);

      const rz = await get(port, '/readyz');
      // Either it has data (200) or it says why not (503). Never a 500, never a
      // silent 200 with no data.
      assert.ok([200, 503].includes(rz.status), `unexpected /readyz status ${rz.status}`);
      const rb = JSON.parse(rz.body);
      if (rz.status === 503) {
        assert.ok(rb.reason, 'a 503 must carry a reason');
        assert.ok(Array.isArray(rb.degradedSymbols), 'a 503 must name the degraded symbols');
      }
    } finally {
      b.stop();
    }
  });

  // ---------------------------------------------------------------- dashboard
  await testAsync('the dashboard is served and has no blocking external script', async () => {
    const port = await freePort();
    const b = boot({ SYMBOLS: 'BTCUSDT,ETHUSDT' }, port);
    try {
      await b.ready;
      const r = await get(port, '/');
      assert.strictEqual(r.status, 200);
      assert.match(r.headers['content-type'] || '', /text\/html/);
      assert.match(r.body, /BlackBird/, 'the real page, not the JSON fallback');

      // A blocking <script src="https://..."> in <head>/<body> stalls the parser
      // when the host is unreachable. The SDK must be injected lazily instead.
      const blocking = /<script[^>]*\ssrc="https?:\/\/[^"]+"[^>]*>(?![\s\S]*?<\/script>)/.test(r.body);
      const hasBlockingTag = /<script[^>]*\ssrc="https?:\/\//.test(r.body) &&
        !/createElement\('script'\)/.test(r.body);
      assert.ok(!hasBlockingTag, 'no blocking external <script src> may remain');
      void blocking;

      // Every id the script touches must exist, or the panel dies on the first
      // missing element and shows nothing at all.
      const ids = new Set([...r.body.matchAll(/id="([^"]+)"/g)].map((m) => m[1]));
      const used = new Set([...r.body.matchAll(/\$\('([^']+)'\)/g)].map((m) => m[1]));
      const missing = [...used].filter((u) => !ids.has(u));
      assert.deepStrictEqual(missing, [], `dashboard references missing ids: ${missing.join(', ')}`);
    } finally {
      b.stop();
    }
  });

  // ------------------------------------------------------------ report writes
  // The reports directory is created, not assumed: a fresh checkout has none.
  test('the reporter creates its directory tree instead of assuming it', () => {
    const src = fs.readFileSync(path.join(SRC, 'agents/reporter.js'), 'utf8');
    const writeFn = src.slice(src.indexOf('  write(report)'));
    assert.match(writeFn, /mkdirSync\(this\.cfg\.reporter\.dir/, 'the parent reports dir must be created');
  });

  test('reports follow DATA_DIR so a read-only app tree cannot break them', () => {
    const { loadConfig } = require(path.join(SRC, 'config'));
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-cfg-'));
    const prev = process.env.DATA_DIR;
    const prevReport = process.env.REPORT_DIR;
    delete process.env.REPORT_DIR;
    process.env.DATA_DIR = tmp;
    try {
      const cfg = loadConfig();
      assert.strictEqual(cfg.reporter.dir, path.join(tmp, 'reports'),
        'reporter.dir must live under DATA_DIR when DATA_DIR is set');
    } finally {
      if (prev === undefined) delete process.env.DATA_DIR; else process.env.DATA_DIR = prev;
      if (prevReport !== undefined) process.env.REPORT_DIR = prevReport;
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  });

  test('REPORT_DIR still overrides the derived location', () => {
    const { loadConfig } = require(path.join(SRC, 'config'));
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-cfg-'));
    const prev = process.env.DATA_DIR;
    const prevReport = process.env.REPORT_DIR;
    process.env.DATA_DIR = tmp;
    process.env.REPORT_DIR = path.join(tmp, 'custom-reports');
    try {
      const cfg = loadConfig();
      assert.strictEqual(cfg.reporter.dir, path.join(tmp, 'custom-reports'));
    } finally {
      if (prev === undefined) delete process.env.DATA_DIR; else process.env.DATA_DIR = prev;
      if (prevReport === undefined) delete process.env.REPORT_DIR; else process.env.REPORT_DIR = prevReport;
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  });

  // ------------------------------------------------------------ deploy bundle
  test('the deployment bundle is complete', () => {
    const need = [
      'Dockerfile',
      'docker-compose.yml',
      'Procfile',
      '.env.example',
      'deploy/blackbird.service',
      'deploy/install.sh',
      'DEPLOY.md',
    ];
    const missing = need.filter((f) => !fs.existsSync(path.join(ROOT, f)));
    assert.deepStrictEqual(missing, [], `missing deployment files: ${missing.join(', ')}`);
  });

  test('no real secret is committed in the deployment files', () => {
    const files = ['.env.example', 'docker-compose.yml', 'deploy/blackbird.service', 'deploy/install.sh'];
    const suspicious = [];
    for (const f of files) {
      const p = path.join(ROOT, f);
      if (!fs.existsSync(p)) continue;
      const text = fs.readFileSync(p, 'utf8');
      // A long unbroken token-looking value assigned to a KEY/SECRET/TOKEN var.
      // [ \t] not \s: \s would let the match run past the newline and "find" a
      // secret in the next line's variable name.
      for (const m of text.matchAll(/^[ \t]*[A-Z_]*(?:KEY|SECRET|TOKEN|PASSWORD)[A-Z_]*[ \t]*=[ \t]*(\S+)/gm)) {
        const v = m[1].replace(/^["']|["']$/g, '');
        if (v && !/^(|x+|<.*>|changeme|your-.*|\.\.\.)$/i.test(v) && v.length > 20) {
          suspicious.push(`${f}: ${m[0].slice(0, 40)}`);
        }
      }
    }
    assert.deepStrictEqual(suspicious, [], `possible committed secrets: ${suspicious.join(' | ')}`);
  });

  test('the systemd unit runs as a non-root user and restarts on failure', () => {
    const p = path.join(ROOT, 'deploy/blackbird.service');
    const unit = fs.readFileSync(p, 'utf8');
    assert.match(unit, /^User=/m, 'must not run as root');
    assert.doesNotMatch(unit, /^User=root$/m, 'must not run as root');
    assert.match(unit, /^Restart=always/m, 'must restart on failure');
    assert.match(unit, /^EnvironmentFile=/m, 'secrets come from an env file, not the unit');
    assert.match(unit, /^WorkingDirectory=/m);
  });

  test('docker-compose publishes the port and mounts a data volume', () => {
    const p = path.join(ROOT, 'docker-compose.yml');
    const yml = fs.readFileSync(p, 'utf8');
    // Read the default from config.json rather than hardcoding it: the port is a
    // deployment choice (61257 on Botkeep), and a test that pins 8787 would fail
    // the moment the default legitimately changes.
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
    const port = String(cfg.server.port);
    assert.match(yml, /ports:/, 'the port must be published to the host');
    assert.ok(yml.includes(port), `the default port ${port} must appear`);
    assert.match(yml, /volumes:/, 'data must survive a container restart');
    assert.match(yml, /healthcheck:/, 'compose should probe the service');
  });

  // ------------------------------------------------------------------ summary
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  server: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  process.exit(failed ? 1 : 0);
})();
