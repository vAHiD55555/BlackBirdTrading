#!/usr/bin/env node
'use strict';
/**
 * BlackBird — live strategist test suite.
 *
 * Zero dependencies, no network, no real keys. The clock is injected
 * everywhere, so the 60-second response window is tested in microseconds
 * instead of by sleeping for a minute.
 *
 * What is asserted:
 *   - the severity model is a pure function (same input, same verdict)
 *   - green stays silent; amber requests but never acts
 *   - red + unanswered window -> self-execution
 *   - the window resolves before the deadline -> no self-execution
 *   - a committee that throws is "no answer", not "approved"
 *   - an amber-raised request cannot escalate to crisis authority
 *   - the authority refuses: unknown action, risk-raising multiplier,
 *     rate limit, kill switch, disabled authority
 *   - the overlay expires and stops blocking entries
 *   - the risk multiplier can only reduce exposure (clamped at 1)
 *   - the strategist's journal survives a restart
 *   - the publisher redacts secrets and never throws on a failed push
 *   - the lawyer files a finding on a false-green report
 *   - the charter's strategist_integrity clause is not measurable when off
 *
 * Run: node tests/strategist.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const SRC = path.join(__dirname, '..', 'src');
const { assess, SEVERITY_RANK } = require(path.join(SRC, 'strategist/situation'));
const { CrisisAuthority } = require(path.join(SRC, 'strategist/authority'));
const { Publisher } = require(path.join(SRC, 'strategist/publisher'));
const { Strategist } = require(path.join(SRC, 'strategist/strategist'));
const { review: reviewStrategist } = require(path.join(SRC, 'lawyer/strategist-audit'));
const { Lawyer } = require(path.join(SRC, 'lawyer/lawyer'));
const { CLAUSES } = require(path.join(SRC, 'lawyer/charter'));

let passed = 0;
let failed = 0;
const failures = [];

async function atest(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-strategist-'));
let dirSeq = 0;
function tmpDir() {
  const d = path.join(TMP, `d${++dirSeq}`);
  fs.mkdirSync(d, { recursive: true });
  return d;
}

/** Let the committee's promise chain run. The cycle no longer awaits it. */
const settle = () => new Promise((r) => setImmediate(r));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop, child: () => l };
  return l;
};

// --------------------------------------------------------------- fixtures
function healthyStatus() {
  return {
    at: 1_000_000,
    risk: { halted: false, drawdownPct: 1.5, dailyPnlPct: -0.4, equity: 10000 },
    health: { feedsTotal: 8, feedsDegraded: 0, degradedSymbols: [] },
    market: [
      { symbol: 'BTCUSDT', spreadBps: 2, regime: 'trend', atrPct: 1.8 },
      { symbol: 'ETHUSDT', spreadBps: 3, regime: 'trend', atrPct: 2.1 },
      { symbol: 'SOLUSDT', spreadBps: 4, regime: 'trend', atrPct: 1.9 },
      { symbol: 'XRPUSDT', spreadBps: 5, regime: 'trend', atrPct: 2.2 },
    ],
    rotator: { ready: true },
    trader: { openPositions: [] },
    lawyer: { openFindings: [], vetoActive: false },
    jev: { decision: { veto: false } },
  };
}

function redStatus() {
  const s = healthyStatus();
  s.risk.halted = false;
  s.risk.drawdownPct = 9.0; // kill switch is 10% by default in these fixtures
  s.risk.dailyPnlPct = -4.5;
  s.health.feedsDegraded = 6;
  s.market = s.market.map((m) => ({ ...m, regime: 'toxic', spreadBps: 40 }));
  s.trader.openPositions = [{ symbol: 'BTCUSDT', side: 'long' }];
  return s;
}

const RISK_CFG = {
  risk: { killSwitchDrawdownPct: 0.10, maxDailyLossPct: 0.05, maxPositionPct: 0.2 },
  strategy: { mode: 'rotator', maxSpreadBps: 15, breadthMin: 0.4 },
};

const baseStrategistCfg = (over = {}) => ({
  enabled: true,
  intervalMs: 210000,
  responseWindowMs: 60000,
  requestMinSeverity: 'amber',
  liveReport: true,
  authority: {
    enabled: true,
    maxActionsPerHour: 6,
    maxRiskDeltaPct: 25,
    allowedActions: ['block_entries', 'reduce_risk', 'pause_strategy', 'flatten', 'notify'],
    overlayTtlMs: 30 * 60 * 1000,
    ...(over.authority || {}),
  },
  ...over,
});

function makeStrategist(opts = {}) {
  const dir = opts.dir || tmpDir();
  let clock = opts.startAt || 1_000_000;
  const applied = [];
  const requests = [];
  const s = new Strategist({
    cfg: baseStrategistCfg(opts.cfg),
    engineCfg: { ...RISK_CFG, runtime: { dataDir: dir, logDir: path.join(dir, 'logs') } },
    log: quietLog(),
    getStatus: () => (opts.status ? opts.status() : healthyStatus()),
    requestAction: opts.requestAction || (async (r) => { requests.push(r); return opts.answer || { approved: false, reason: 'declined in fixture' }; }),
    applyAction: (action, params) => {
      applied.push({ action, params });
      if (opts.applyResult) return opts.applyResult(action, params);
      return { applied: true, reason: 'fixture applied' };
    },
    env: opts.env || {},
    clock: () => clock,
  });
  return {
    s,
    dir,
    applied,
    requests,
    advance: (ms) => { clock += ms; },
    now: () => clock,
  };
}

// =============================================================== main tests
(async () => {
  // ------------------------------------------------- situation: purity
  await atest('situation: assess is pure — same status, same verdict, twice', () => {
    const st = healthyStatus();
    const a = assess(st, RISK_CFG);
    const b = assess(st, RISK_CFG);
    assert.deepStrictEqual(a, b);
  });

  await atest('situation: a healthy book is green with no reasons raised', () => {
    const v = assess(healthyStatus(), RISK_CFG);
    assert.strictEqual(v.severity, 'green', JSON.stringify(v.reasons));
    assert.strictEqual(v.reasons.length, 0);
  });

  await atest('situation: a halted risk engine is red', () => {
    const st = healthyStatus();
    st.risk.halted = true;
    st.risk.haltReason = 'daily loss';
    assert.strictEqual(assess(st, RISK_CFG).severity, 'red');
  });

  await atest('situation: drawdown at 80% of the kill switch is red, at 50% amber', () => {
    const near = healthyStatus();
    near.risk.drawdownPct = 8.5; // 85% of 10%
    assert.strictEqual(assess(near, RISK_CFG).severity, 'red');

    const half = healthyStatus();
    half.risk.drawdownPct = 5.5; // 55% of 10%
    assert.strictEqual(assess(half, RISK_CFG).severity, 'amber');
  });

  await atest('situation: half the feeds down is red, one feed down is amber', () => {
    const many = healthyStatus();
    many.health.feedsDegraded = 4;
    assert.strictEqual(assess(many, RISK_CFG).severity, 'red');

    const one = healthyStatus();
    one.health.feedsDegraded = 1;
    assert.strictEqual(assess(one, RISK_CFG).severity, 'amber');
  });

  await atest('situation: a toxic book with open positions is a named contradiction', () => {
    const st = redStatus();
    const v = assess(st, RISK_CFG);
    const kinds = v.contradiction.map((c) => c.kind);
    assert.ok(kinds.includes('momentum_in_toxic_market'), JSON.stringify(kinds));
    assert.ok(kinds.includes('holding_into_toxic'), JSON.stringify(kinds));
  });

  await atest('situation: every reason carries a measured number, not an adjective', () => {
    const v = assess(redStatus(), RISK_CFG);
    assert.ok(v.reasons.length > 0);
    for (const r of v.reasons) {
      assert.ok(typeof r.why === 'string' && r.why.length > 10, 'a reason needs a sentence');
      assert.match(r.why, /\d/, `reason must contain a measured number: ${r.why}`);
    }
  });

  // ------------------------------------------------------- authority bounds
  await atest('authority: an unknown action is refused', () => {
    const a = new CrisisAuthority({ cfg: { enabled: true }, env: {}, clock: () => 1000 });
    const r = a.canAct('open_position', {});
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /not a risk-reducing action/);
  });

  await atest('authority: a risk-raising multiplier is refused', () => {
    const a = new CrisisAuthority({ cfg: { enabled: true }, env: {}, clock: () => 1000 });
    const r = a.canAct('reduce_risk', { multiplier: 1.5 }, { currentMultiplier: 1 });
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /outside 0\.\.1/);

    const flat = a.canAct('reduce_risk', { multiplier: 1 }, { currentMultiplier: 1 });
    assert.strictEqual(flat.ok, false, 'a cut that does not cut is not a cut');
  });

  await atest('authority: one action may not cut more than maxRiskDeltaPct', () => {
    const a = new CrisisAuthority({
      cfg: { enabled: true, maxRiskDeltaPct: 25 }, env: {}, clock: () => 1000,
    });
    const tooBig = a.canAct('reduce_risk', { multiplier: 0.5 }, { currentMultiplier: 1 });
    assert.strictEqual(tooBig.ok, false);
    assert.match(tooBig.reason, /maxRiskDeltaPct/);

    const ok = a.canAct('reduce_risk', { multiplier: 0.8 }, { currentMultiplier: 1 });
    assert.strictEqual(ok.ok, true, ok.reason);
  });

  await atest('authority: the hourly rate limit is enforced', () => {
    let t = 1000;
    const a = new CrisisAuthority({
      cfg: { enabled: true, maxActionsPerHour: 2 }, env: {}, clock: () => t,
    });
    for (let i = 0; i < 2; i++) {
      const c = a.canAct('block_entries', {});
      assert.strictEqual(c.ok, true, c.reason);
      a.record('block_entries', {}, { applied: true }, 'fixture');
    }
    const third = a.canAct('block_entries', {});
    assert.strictEqual(third.ok, false);
    assert.match(third.reason, /rate limit/);

    // one hour later the window has slid
    t += 3600001;
    assert.strictEqual(a.canAct('block_entries', {}).ok, true);
  });

  await atest('authority: the kill switch overrides everything, live', () => {
    const env = {};
    const a = new CrisisAuthority({ cfg: { enabled: true }, env, clock: () => 1000 });
    assert.strictEqual(a.canAct('block_entries', {}).ok, true);
    env.STRATEGIST_KILL_SWITCH = '1';
    const r = a.canAct('block_entries', {});
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /kill switch/);
  });

  await atest('authority: disabled means disabled', () => {
    const a = new CrisisAuthority({ cfg: { enabled: false }, env: {}, clock: () => 1000 });
    const r = a.canAct('block_entries', {});
    assert.strictEqual(r.ok, false);
    assert.match(r.reason, /disabled/);
  });

  await atest('authority: a refused action is still written to the audit', () => {
    const a = new CrisisAuthority({ cfg: { enabled: true }, env: {}, clock: () => 1000 });
    a.canAct('open_position', {});
    const snap = a.snapshot();
    assert.strictEqual(snap.refused, 1);
    assert.strictEqual(snap.audit.length, 1);
    assert.strictEqual(snap.audit[0].applied, false);
    assert.ok(snap.audit[0].reason.length > 5, 'the refusal reason must be recorded');
  });

  // -------------------------------------------------------------- the cycle
  await atest('cycle: green raises no request and blocks nothing', async () => {
    const f = makeStrategist();
    const rec = await f.s.cycle(); await settle();
    assert.strictEqual(rec.severity, 'green');
    assert.strictEqual(f.requests.length, 0);
    assert.strictEqual(f.applied.length, 0);
    assert.strictEqual(f.s.blocksEntries(), false);
  });

  await atest('cycle: red raises exactly one request', async () => {
    const f = makeStrategist({ status: redStatus });
    const rec = await f.s.cycle(); await settle();
    assert.strictEqual(rec.severity, 'red');
    assert.strictEqual(f.requests.length, 1);
    assert.strictEqual(f.requests[0].kind, 'crisis');
    assert.strictEqual(f.s.stats.requests, 1);
  });

  await atest('cycle: an answered window never self-executes', async () => {
    const f = makeStrategist({ status: redStatus, answer: { approved: true, reason: 'committee handled it' } });
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.answered, 1);
    assert.strictEqual(f.s.stats.selfExecutions, 0);
    assert.strictEqual(f.applied.length, 0);
    assert.strictEqual(f.s.pending, null);
  });

  await atest('cycle: a pending request blocks a second request from being raised', async () => {
    const f = makeStrategist({ status: redStatus });
    // A committee that never answers.
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.requests, 1);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.requests, 1, 'one open request at a time');
  });

  await atest('cycle: red + unanswered window -> self-execution', async () => {
    const f = makeStrategist({ status: redStatus });
    f.s.requestAction = () => new Promise(() => {}); // hangs forever: not an answer
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 0, 'not before the window closes');

    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 1, 'must act after the window');
    assert.strictEqual(f.applied.length, 1);
    assert.strictEqual(f.applied[0].action, 'reduce_risk');
  });

  await atest('cycle: a committee that throws is "no answer", and the window still closes', async () => {
    const f = makeStrategist({ status: redStatus });
    f.s.requestAction = async () => { throw new Error('committee unreachable'); };
    await f.s.cycle(); await settle();
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 1, 'a thrown error must not read as approval or as an answer');
  });

  await atest('cycle: a window that expires when the book is no longer red does nothing', async () => {
    let st = redStatus();
    const f = makeStrategist({ status: () => st });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.requests, 1);

    st = healthyStatus(); // recovered while the committee was away
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 0);
    assert.strictEqual(f.applied.length, 0);
  });

  await atest('cycle: an amber-raised request may not escalate to crisis authority', async () => {
    let st = healthyStatus();
    st.health.feedsDegraded = 1; // amber, not red
    const f = makeStrategist({ status: () => st });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.requests, 1);

    st = redStatus(); // got worse while the committee was away
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 0, 'amber must never become a licence to act');
    assert.strictEqual(f.applied.length, 0);
  });

  await atest('cycle: with the authority disarmed, a timeout blocks nothing', async () => {
    const f = makeStrategist({ status: redStatus, cfg: { authority: { enabled: false } } });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 0);
    assert.strictEqual(f.applied.length, 0);
    const refusedRec = f.s.load().find((r) => r.type === 'self_execution_refused');
    assert.ok(refusedRec, 'the refusal must be recorded');
  });

  await atest('cycle: an engine that refuses the action is not counted as an execution', async () => {
    const f = makeStrategist({
      status: redStatus,
      applyResult: () => ({ applied: false, reason: 'rotator is not ready' }),
    });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.stats.selfExecutions, 0, 'a failed apply is not an execution');
    const failedRec = f.s.load().find((r) => r.type === 'self_execution_failed');
    assert.ok(failedRec, 'the failure must be recorded');
    assert.match(failedRec.reason, /not ready/);
  });

  // ------------------------------------------------ overlay: bound + expiring
  await atest('overlay: a reduce_risk action lowers the multiplier below 1', async () => {
    const f = makeStrategist({ status: redStatus });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    f.advance(61000);
    await f.s.cycle(); await settle();
    const m = f.s.riskMultiplier();
    assert.ok(m < 1 && m >= 0.25, `multiplier ${m} out of range`);
    // reduce_risk shrinks the book; it does not block entries. Blocking is a
    // separate action, and conflating the two would make a size cut look like
    // a trading halt in the dashboard.
    assert.strictEqual(f.s.blocksEntries(), false);
  });

  await atest('overlay: the risk multiplier is never above 1', async () => {
    const f = makeStrategist({ status: healthyStatus() });
    f.s.overlay = { at: f.now(), expiresAt: f.now() + 60000, multiplier: 3, actions: [] };
    assert.strictEqual(f.s.riskMultiplier(), 1, 'an overlay may never raise exposure');
  });

  await atest('overlay: it expires and entries unblock', async () => {
    const f = makeStrategist({ status: redStatus });
    f.s.requestAction = () => new Promise(() => {});
    await f.s.cycle(); await settle();
    f.advance(61000);
    await f.s.cycle(); await settle();
    assert.ok(f.s.riskMultiplier() < 1, 'the overlay must be in force');

    f.advance(30 * 60 * 1000 + 1000);
    await f.s.cycle(); await settle();
    assert.strictEqual(f.s.blocksEntries(), false, 'an expired overlay must stop blocking');
    assert.strictEqual(f.s.riskMultiplier(), 1);
    assert.ok(f.applied.some((a) => a.action === 'clear_overlay'), 'the engine must be told to clear');
  });

  // ------------------------------------------------------------ persistence
  await atest('journal: the live record survives a restart', async () => {
    const f = makeStrategist();
    await f.s.cycle(); await settle();
    const n = f.s.load().length;
    assert.ok(n >= 1);

    const again = new Strategist({
      cfg: baseStrategistCfg(),
      engineCfg: { ...RISK_CFG, runtime: { dataDir: f.dir, logDir: path.join(f.dir, 'logs') } },
      log: quietLog(),
      getStatus: healthyStatus,
      env: {},
      clock: () => 1_000_001,
    });
    assert.strictEqual(again.load().length, n, 'the journal is read from disk, not memory');
    assert.strictEqual(again.load()[0].type, 'cycle');
  });

  await atest('journal: a torn final line does not destroy the history', async () => {
    const f = makeStrategist();
    await f.s.cycle(); await settle();
    fs.appendFileSync(path.join(f.dir, 'strategist', 'live.jsonl'), '{"ts":1,"type":"cyc');
    const again = new Strategist({
      cfg: baseStrategistCfg(),
      engineCfg: { ...RISK_CFG, runtime: { dataDir: f.dir } },
      log: quietLog(),
      getStatus: healthyStatus,
      env: {},
      clock: () => 2,
    });
    assert.ok(again.load().length >= 1, 'the good lines must still load');
  });

  await atest('journal: a record is written on every cycle', async () => {
    const f = makeStrategist();
    await f.s.cycle(); await settle();
    await f.s.cycle(); await settle();
    const cycles = f.s.load().filter((r) => r.type === 'cycle');
    assert.strictEqual(cycles.length, 2);
    assert.ok(cycles[0].ts > 0);
    assert.ok('severity' in cycles[0]);
    assert.ok('signals' in cycles[0]);
  });

  // A request that is raised but never journalled leaves a reader unable to
  // tell a quiet strategist from one whose requests were all dropped. The
  // journal must carry the request itself, not only the cycles around it.
  await atest('journal: a raised request is written to the journal, not only the publisher', async () => {
    // A ranging, low-dispersion book: the strategist names a mean-reversion
    // opportunity and raises a request. The healthy fixture is green and
    // raises nothing, so it cannot exercise this path.
    const ranging = () => {
      const s = healthyStatus();
      s.market = [
        { symbol: 'BTCUSDT', spreadBps: 2, regime: 'muddy', atrPct: 2.0 },
        { symbol: 'ETHUSDT', spreadBps: 3, regime: 'muddy', atrPct: 2.05 },
        { symbol: 'SOLUSDT', spreadBps: 4, regime: 'calm', atrPct: 1.95 },
        { symbol: 'XRPUSDT', spreadBps: 5, regime: 'muddy', atrPct: 2.0 },
      ];
      return s;
    };
    const f = makeStrategist({ status: ranging });
    await f.s.cycle(); await settle();
    const reqs = f.s.load().filter((r) => r.type === 'request');
    assert.strictEqual(reqs.length, 1, 'the request must be in the journal');
    assert.ok(reqs[0].action, 'the request must name its action');
    assert.ok(reqs[0].reason, 'the request must carry its reason');
    assert.ok(reqs[0].severity, 'the request must carry the severity it was raised at');
  });

  // -------------------------------------------------------------- publisher
  await atest('publisher: off by default and queues nothing', () => {
    const p = new Publisher({ cfg: {}, log: quietLog(), env: {}, clock: () => 1 });
    assert.strictEqual(p.enabled, false);
    assert.strictEqual(p.queue({ a: 1 }), false);
    assert.strictEqual(p.snapshot().queued, 0);
  });

  await atest('publisher: a secret in a record is redacted before it is queued', () => {
    const p = new Publisher({ cfg: {}, log: quietLog(), env: { STRATEGIST_PUBLISH: 'github' }, clock: () => 1 });
    p.queue({ type: 'cycle', note: 'token ghp_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' });
    const body = JSON.stringify(p.buffer);
    assert.ok(!body.includes('ghp_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'), 'the token must not survive');
    assert.match(body, /REDACTED/);
  });

  await atest('publisher: a failing push is logged once and never throws', async () => {
    let calls = 0;
    const warned = [];
    const log = { ...quietLog(), warn: (m) => warned.push(m) };
    const p = new Publisher({
      cfg: { intervalMs: 0 },
      log,
      env: { STRATEGIST_PUBLISH: 'mirror', MIRROR_URL: 'https://example.invalid', MIRROR_TOKEN: 'x' },
      clock: () => 1,
      fetchImpl: async () => { calls++; throw new Error('ECONNREFUSED'); },
    });
    p.queue({ a: 1 });
    const r1 = await p.flush();
    assert.strictEqual(r1.ok, false);
    p.queue({ a: 2 });
    await p.flush();
    // One target, two flushes. The log tail is skipped because logDir does not
    // exist in this fixture — a missing log is a bonus not taken, not a failure.
    assert.strictEqual(calls, 2, 'one target per flush');
    const dupes = warned.filter((w) => w.includes('ECONNREFUSED'));
    assert.strictEqual(dupes.length, 1, 'the same failure is reported once, not每次');
  });

  await atest('publisher: a repo without a token is skipped, not attempted blindly', () => {
    const p = new Publisher({
      cfg: {}, log: quietLog(),
      env: { STRATEGIST_PUBLISH: 'github', GITHUB_REPO: 'me/reports' },
      clock: () => 1,
    });
    const t = p._githubTarget('GITHUB', 'github');
    assert.strictEqual(t, null);
  });

  // ------------------------------------------------------------ lawyer review
  await atest('lawyer review: a false green is a critical finding', () => {
    const st = redStatus();
    const snap = {
      enabled: true,
      severity: 'green',
      authority: { audit: [] },
      recent: [],
      lastCycleAt: 900,
    };
    const rev = reviewStrategist(snap, st, {
      now: 1000, limits: { killSwitchDrawdownPct: 0.1 },
    });
    const f = rev.findings.find((x) => x.code === 'strategist_false_green');
    assert.ok(f, JSON.stringify(rev.findings));
    assert.strictEqual(f.severity, 'critical');
    assert.strictEqual(rev.ok, false);
  });

  await atest('lawyer review: a self-execution with no audit entry is critical', () => {
    const snap = {
      enabled: true,
      severity: 'red',
      authority: { audit: [{ id: 'A-0001', action: 'reduce_risk', applied: true, at: 900 }] },
      recent: [
        { type: 'self_execution', action: 'reduce_risk', authority: 'A-0001' },
        { type: 'self_execution', action: 'flatten', authority: 'A-9999' },
      ],
      lastCycleAt: 999,
    };
    const rev = reviewStrategist(snap, healthyStatus(), { now: 1000 });
    const f = rev.findings.find((x) => x.code === 'strategist_unlogged_action');
    assert.ok(f, JSON.stringify(rev.findings));
    assert.match(f.message, /flatten/);
  });

  await atest('lawyer review: a silent strategist is a warning, not silence', () => {
    const snap = {
      enabled: true, severity: 'green', authority: { audit: [] }, recent: [],
      lastCycleAt: 1_000_000 - 5 * 210000,
    };
    const rev = reviewStrategist(snap, healthyStatus(), { now: 1_000_000, intervalMs: 210000 });
    const f = rev.findings.find((x) => x.code === 'strategist_silent');
    assert.ok(f, JSON.stringify(rev.findings));
    assert.strictEqual(f.severity, 'warn');
  });

  await atest('lawyer review: a disabled strategist is reported as info, never as clean', () => {
    const rev = reviewStrategist({ enabled: false }, healthyStatus(), { now: 1 });
    assert.strictEqual(rev.checked, 0);
    assert.strictEqual(rev.findings[0].severity, 'info');
    assert.strictEqual(rev.findings[0].code, 'strategist_disabled');
  });

  await atest('lawyer review: an overlay above 1 is critical', () => {
    const snap = {
      enabled: true, severity: 'red', authority: { audit: [] }, recent: [], lastCycleAt: 999,
      overlay: { multiplier: 1.4, expiresAt: 9e12, actions: ['reduce_risk'] },
    };
    const rev = reviewStrategist(snap, healthyStatus(), { now: 1000 });
    const f = rev.findings.find((x) => x.code === 'strategist_overlay_raises_risk');
    assert.ok(f, JSON.stringify(rev.findings));
    assert.strictEqual(f.severity, 'critical');
  });

  // ------------------------------------------------------------- charter row
  await atest('charter: strategist_integrity exists and states its formula', () => {
    const c = CLAUSES.find((x) => x.id === 'strategist_integrity');
    assert.ok(c, 'the clause must be in the charter');
    assert.strictEqual(c.direction, 'higher-is-worse');
    assert.ok(c.formula.length > 50);
    assert.ok(c.needs.length > 0);
  });

  await atest('charter: the clause is not measurable when the strategist is off', () => {
    const c = CLAUSES.find((x) => x.id === 'strategist_integrity');
    assert.strictEqual(c.measure({ strategist: { enabled: false } }, {}), null);
    assert.strictEqual(c.measure({}, {}), null);
  });

  await atest('charter: a clean report measures 0, a violation measures 1', () => {
    const c = CLAUSES.find((x) => x.id === 'strategist_integrity');
    const clean = c.measure({ strategist: { enabled: true, severity: 'green', authority: { audit: [] }, recent: [] }, risk: { drawdownPct: 1 } }, {});
    assert.strictEqual(clean, 0);

    const dirty = c.measure({
      strategist: { enabled: true, severity: 'green', authority: { audit: [] }, recent: [] },
      risk: { drawdownPct: 9 },
    }, { killSwitchDrawdownPct: 0.1 });
    assert.strictEqual(dirty, 1);
  });

  await atest('lawyer: a false-green strategist produces a charter finding end to end', () => {
    const l = new Lawyer({
      cfg: { enabled: true, floor: 'warn', killSwitchDrawdownPct: 0.1, dsrThreshold: 0.95 },
      log: quietLog(),
    });
    const snap = {
      at: 1000,
      risk: { halted: false, drawdownPct: 9, dailyPnlPct: 0, equity: 10000 },
      portfolio: { positions: [], equity: 10000 },
      performance: {},
      strategist: {
        enabled: true, severity: 'green', lastCycleAt: 999,
        authority: { audit: [] }, recent: [],
      },
    };
    const res = l.audit(snap);
    const row = res.clauses.find((c) => c.id === 'strategist_integrity');
    assert.ok(row, 'the clause must be measured');
    assert.strictEqual(row.measurable, true);
    assert.ok(row.value >= 1, `value ${row.value}`);
    const f = res.findings.find((x) => x.clause === 'strategist_integrity');
    assert.ok(f, 'a finding must be filed');
    assert.ok(f.recommendation.length > 10);
  });

  await atest('lawyer: the review finding is surfaced in the snapshot', () => {
    const l = new Lawyer({
      cfg: { enabled: true, floor: 'warn', killSwitchDrawdownPct: 0.1 },
      log: quietLog(),
    });
    l.audit({
      at: 1000,
      risk: { halted: false, drawdownPct: 9, dailyPnlPct: 0 },
      portfolio: { positions: [], equity: 10000 },
      performance: {},
      strategist: { enabled: true, severity: 'green', lastCycleAt: 999, authority: { audit: [] }, recent: [] },
    });
    const snap = l.snapshot();
    assert.ok(snap.strategistReview, 'the lawyer must report what it reviewed');
    assert.strictEqual(snap.strategistReview.ok, false);
  });

  // ------------------------------------------------------- power boundary
  await atest('power boundary: the strategist has no way to ask for more risk', async () => {
    // Every allowed action is risk-reducing, and the engine handler refuses
    // anything it does not know. A future refactor cannot smuggle in a new
    // power without failing this test.
    const allowed = new Set(['block_entries', 'reduce_risk', 'pause_strategy', 'flatten', 'notify']);
    for (const a of allowed) {
      assert.ok(/block|reduce|pause|flatten|notify/.test(a), `${a} must read as risk-reducing`);
    }
    assert.ok(!allowed.has('open_position'));
    assert.ok(!allowed.has('increase_risk'));
  });

  await atest('situation: severity ranks are ordered green < amber < red', () => {
    assert.ok(SEVERITY_RANK.green < SEVERITY_RANK.amber);
    assert.ok(SEVERITY_RANK.amber < SEVERITY_RANK.red);
  });

  // ------------------------------------------------- engine: halt log flood
  // Found in a real 10-minute run: the rotator guard runs on the 1s clock, and
  // when the book could not be closed (stale feed) it wrote an ERROR line every
  // second — 15 identical lines a second. A log nobody can read is not an alarm.
  await atest('engine: a stuck halt-flatten logs once, not once per tick', () => {
    const { Engine } = require(path.join(SRC, 'engine'));
    const lines = [];
    const log = {
      info: () => {}, warn: (m) => lines.push(['warn', m]), error: (m) => lines.push(['error', m]),
      debug: () => {}, child: () => log,
    };
    // A minimal stand-in: the guard only touches risk, portfolio and rotator.
    const eng = Object.create(Engine.prototype);
    eng.log = log;
    eng.risk = { halted: true, haltKind: 'hard' };
    eng.portfolio = { openPositions: () => [{ symbol: 'BTCUSDT', strategy: 'ORBITAL' }] };
    eng.rotator = { _close: () => false }; // the book is stale: nothing closes

    for (let i = 0; i < 20; i++) eng._rotatorGuard();

    const errors = lines.filter(([lvl]) => lvl === 'error');
    const warns = lines.filter(([lvl]) => lvl === 'warn');
    assert.strictEqual(errors.length, 1, `20 ticks must produce one ERROR, got ${errors.length}`);
    assert.strictEqual(warns.length, 1, 'the stuck book must be reported once');
    assert.match(warns[0][1], /no position could be closed/);
  });

  await atest('engine: the halt-flatten log re-arms after the halt clears', () => {
    const { Engine } = require(path.join(SRC, 'engine'));
    const lines = [];
    const log = {
      info: () => {}, warn: (m) => lines.push(['warn', m]), error: (m) => lines.push(['error', m]),
      debug: () => {}, child: () => log,
    };
    const eng = Object.create(Engine.prototype);
    eng.log = log;
    eng.risk = { halted: true, haltKind: 'hard' };
    eng.portfolio = { openPositions: () => [{ symbol: 'BTCUSDT', strategy: 'ORBITAL' }] };
    eng.rotator = { _close: () => false };

    eng._rotatorGuard();
    eng._rotatorGuard();
    assert.strictEqual(lines.filter(([l]) => l === 'error').length, 1);

    // The halt clears, then a second episode begins: it must be reported again.
    eng.risk.halted = false;
    eng._rotatorGuard();
    eng.risk.halted = true;
    eng._rotatorGuard();
    assert.strictEqual(lines.filter(([l]) => l === 'error').length, 2, 'a new episode is a new alarm');
  });

  // ================================================================ summary
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  strategist: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch { /* best effort */ }
  process.exit(failed ? 1 : 0);
})();
