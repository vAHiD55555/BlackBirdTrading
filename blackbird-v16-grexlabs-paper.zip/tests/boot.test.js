'use strict';
/**
 * Regression: the engine must get past module wiring on a real boot.
 *
 * The bug this reproduces: `Apprentice` was constructed with `dir: dataDir`,
 * but `dataDir` is a local `const` inside the constructor's earlier block and
 * is not in scope in `init()`. Every unit test passed because none of them
 * ran the real Engine's init — the failure only appeared on a real boot:
 *
 *     STARTUP FAILED — dataDir is not defined
 *
 * This sandbox has no exchange, so `init()` cannot be expected to finish: it
 * retries the network. The test therefore races init against a short timeout
 * and asserts the one thing that matters — that init never dies on a
 * ReferenceError from our own wiring. A timeout is a pass; a scope bug is not.
 */
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');

function makeEngine() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-boot-'));
  const { Engine } = require(path.join(SRC, 'engine'));
  const { loadConfig } = require(path.join(SRC, 'config'));
  const cfg = loadConfig({
    server: { enabled: false },
    runtime: {
      dataDir: dir,
      stateFile: path.join(dir, 'state.json'),
      journalFile: path.join(dir, 'journal.jsonl'),
      logDir: path.join(dir, 'logs'),
    },
    reporter: { dir: path.join(dir, 'reports') },
  });
  return { engine: new Engine(cfg), dir };
}

/** Run init() but give up after `ms`; returns {err, timedOut}. */
async function initWithTimeout(engine, ms = 12000) {
  let timer = null;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve({ timedOut: true }), ms);
  });
  const run = engine.init().then(
    () => ({ err: null }),
    (err) => ({ err })
  );
  const res = await Promise.race([run, timeout]);
  if (timer) clearTimeout(timer);
  return res;
}

(async () => {
  await t('engine: init() never dies on a ReferenceError from our own wiring', async () => {
    const { engine } = makeEngine();
    const { err } = await initWithTimeout(engine);
    if (err) {
      assert.ok(
        !(err instanceof ReferenceError),
        `init must not throw a ReferenceError (the dataDir scope bug): ${err.message}`
      );
      assert.ok(
        !/is not defined/.test(err.message),
        `init must not throw "is not defined": ${err.message}`
      );
    }
  });

  await t('engine: the apprentice is constructed and points at the configured data dir', async () => {
    const { engine, dir } = makeEngine();
    await initWithTimeout(engine);
    assert.ok(engine.apprentice, 'apprentice must exist after init');
    assert.strictEqual(
      path.resolve(engine.apprentice.dir),
      path.resolve(dir),
      'the apprentice must write into the configured data dir, not the cwd'
    );
  });

  await t('engine: the apprentice records into the data dir once wired', async () => {
    const { engine, dir } = makeEngine();
    await initWithTimeout(engine);
    assert.ok(engine.apprentice, 'apprentice must exist');
    engine.apprentice.observe('scout', 'probe', 'a reason long enough to be accepted');
    const file = path.join(dir, 'apprentice-log.jsonl');
    assert.ok(fs.existsSync(file), `expected ${file} to exist`);
    const rec = JSON.parse(fs.readFileSync(file, 'utf8').trim().split('\n')[0]);
    assert.strictEqual(rec.actor, 'scout');
  });

  await t('engine: intel is constructed and reports disabled with no feed URL', async () => {
    const { engine } = makeEngine();
    await initWithTimeout(engine);
    assert.ok(engine.intel, 'intel must exist after init');
    assert.strictEqual(engine.intel.enabled, false, 'no feed URL means disabled');
  });

  done('boot');
  // init() leaves retry timers behind; exit explicitly so the suite terminates.
  process.exit(0);
})();
