#!/usr/bin/env node
'use strict';
/**
 * v12 — branding regression: the logo and favicon must actually be SERVED.
 *
 * The bug this reproduces: the visual system carried the palette (navy + gold)
 * but the logo artwork itself was never wired into the page. A test that only
 * checks `dashboard.html` contains an `<img>` tag would still pass while the
 * route answered 404 — which is exactly what happened. So this suite asserts
 * the END-TO-END path: HTML references the asset, the asset exists on disk, and
 * the HTTP route returns it with the right content-type and real bytes.
 *
 * Run:  node tests/branding.test.js
 */
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const ROOT = path.join(__dirname, '..');
const WEB = path.join(ROOT, 'src', 'web');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

/** Boot just the static-asset router with a stub engine (no exchange, no net). */
function bootStaticServer() {
  const { startServer } = require(path.join(WEB, 'status'));
  const cfg = {
    server: { port: 0, host: '127.0.0.1', token: '', controlUserIds: [] },
    reporter: { dir: path.join(require('node:os').tmpdir(), 'bb-brand-reports') },
    runtime: { dataDir: path.join(require('node:os').tmpdir(), 'bb-brand-data') },
  };
  const noop = () => {};
  const log = { info: noop, warn: noop, error: noop, debug: noop };
  log.child = () => log;
  const engine = {
    cfg,
    log,
    status: () => ({ ok: true }),
    health: () => ({ booting: false, feedsTotal: 0, feedsDegraded: 0, degradedSymbols: [], dataOk: true, exchange: 'none', uptimeSec: 1 }),
  };
  return startServer(engine);
}

function get(port, urlPath) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: urlPath, method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.end();
  });
}

(async () => {
  console.log('\n\u25b8 branding \u2014 logo and favicon are wired end-to-end');

  const html = fs.readFileSync(path.join(WEB, 'dashboard.html'), 'utf8');

  // ---- the page references the artwork ------------------------------------
  test('dashboard.html references the logo image', () => {
    assert.match(html, /<img[^>]+src="\/assets\/img\/logo\.jpg"/, 'no logo <img> in the page');
    assert.match(html, /class="brand-logo"/, 'logo carries no hook class for the stylesheet');
  });
  test('dashboard.html declares the favicon and apple-touch icon', () => {
    assert.match(html, /rel="icon"[^>]+favicon-32\.png/);
    assert.match(html, /rel="icon"[^>]+favicon-64\.png/);
    assert.match(html, /rel="apple-touch-icon"[^>]+icon-180\.png/);
  });
  test('the logo appears in the header AND on the welcome panel', () => {
    const count = (html.match(/\/assets\/img\/logo\.jpg/g) || []).length;
    assert.ok(count >= 2, `logo referenced ${count} time(s); expected header + welcome`);
  });

  // ---- v16: the dal-shir emblem is the product mark -----------------------
  test('the header uses the transparent dal-shir emblem, not a dark plate', () => {
    assert.match(html, /class="brand-mark"/, 'no emblem holder in the header');
    assert.match(html, /src="\/assets\/img\/emblem\.png"/, 'the emblem PNG is not wired into the header');
    const b = fs.readFileSync(path.join(WEB, 'assets', 'img', 'emblem.png'));
    assert.strictEqual(b[0], 0x89, 'emblem.png is not a PNG');
    // colour type 6 = RGBA: the emblem must carry an alpha channel, otherwise it
    // is a rectangle of navy sitting on the glass instead of a mark on it.
    assert.strictEqual(b[25], 6, `emblem.png colour type ${b[25]} is not RGBA`);
  });

  // ---- v16: NanDark is the parent brand and must be visible ----------------
  test('the NanDark parent brand is present in the header and on the welcome panel', () => {
    assert.match(html, /class="parent-brand"/, 'no parent-brand block in the header');
    assert.match(html, /NANDARK/, 'the parent wordmark is missing');
    assert.match(html, /A company of/i, 'the parent relationship is not stated');
    const nd = (html.match(/\/assets\/img\/nandark\.jpg/g) || []).length;
    assert.ok(nd >= 2, `NanDark mark referenced ${nd} time(s); expected header + welcome`);
    assert.match(html, /class="welcome-parent"/, 'the welcome panel does not carry the parent line');
  });
  test('the NanDark mark is a real image on disk and is served', () => {
    const b = fs.readFileSync(path.join(WEB, 'assets', 'img', 'nandark.jpg'));
    assert.ok(b.length > 2000, `nandark.jpg is only ${b.length} bytes`);
    assert.strictEqual(b[0], 0xff); assert.strictEqual(b[1], 0xd8);
  });

  // ---- v16: the liquid-glass material is a real, shared recipe -------------
  test('the stylesheet defines the liquid-glass material as named tokens', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    for (const tok of ['--glass-tint', '--glass-blur', '--glass-lip', '--glass-rim', '--glass-caustic']) {
      assert.match(css, new RegExp(tok + '\\s*:'), `missing glass token ${tok}`);
    }
    assert.match(css, /backdrop-filter:\s*blur\(var\(--glass-blur\)\)/, 'the glass does not actually blur its backdrop');
    assert.match(css, /-webkit-backdrop-filter/, 'no -webkit- fallback for Safari');
  });
  test('the glass is applied to every surface, not just the hero', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    const rule = css.match(/\.glass,\s*\n?\.hero,\.card,\.glass-panel,\.topbar,\.stats,\.wrap\{/);
    assert.ok(rule, 'the shared glass selector list is missing or was narrowed');
    for (const sel of ['.topbar', '.card', '.hero', '.glass-panel', '.stats']) {
      assert.ok(css.includes(sel), `no rule for ${sel}`);
    }
  });
  test('a browser without backdrop-filter still gets an opaque surface', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    assert.match(css, /@supports not \(\(backdrop-filter/, 'no no-backdrop-filter fallback');
  });
  test('motion stays restrained: no bounce, no infinite spin, all off under reduced motion', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    assert.ok(!/animation:[^;]*infinite[^;]*spin/i.test(css), 'a spinning animation crept in');
    assert.ok(!/cubic-bezier\([^)]*1\.[2-9]/.test(css), 'an overshooting easing crept in');
    assert.match(css, /@media \(prefers-reduced-motion:reduce\)\{\*\{animation:none!important;transition:none!important\}\}/);
  });

  // ---- the files exist and are real images --------------------------------
  test('every referenced asset exists on disk and is a real image', () => {
    for (const rel of ['img/logo.jpg', 'img/favicon-32.png', 'img/favicon-64.png', 'img/icon-180.png']) {
      const full = path.join(WEB, 'assets', rel);
      assert.ok(fs.existsSync(full), `missing on disk: assets/${rel}`);
      const b = fs.readFileSync(full);
      assert.ok(b.length > 200, `assets/${rel} is suspiciously small (${b.length} bytes)`);
      // JPEG = FF D8 FF ; PNG = 89 50 4E 47
      const isJpeg = b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
      const isPng = b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
      assert.ok(isJpeg || isPng, `assets/${rel} is not a JPEG or PNG (first bytes ${b.slice(0, 4).toString('hex')})`);
    }
  });

  // ---- the CSS actually uses the new palette ------------------------------
  test('the stylesheet carries the navy + gold palette, not the old teal', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    assert.match(css, /--accent:\s*#c5a059/i, 'gold accent missing');
    assert.match(css, /--bg:\s*#060b16/i, 'deep-navy ground missing');
    assert.ok(!/#5eead4/i.test(css), 'the old teal accent is still present');
    assert.match(css, /--accent-hi:\s*#e8c87e/i, 'gold highlight missing');
  });
  test('the stylesheet styles the logo hook and keeps reduced-motion off-switches', () => {
    const css = fs.readFileSync(path.join(WEB, 'assets', 'base.css'), 'utf8');
    assert.match(css, /\.brand-logo\b/, 'no .brand-logo rule');
    assert.match(css, /prefers-reduced-motion:\s*reduce/, 'reduced-motion handling removed');
    assert.match(css, /\.brand-logo\{animation:none\}/, 'the logo glint is not disabled under reduced motion');
  });

  // ---- the HTTP route really serves them ----------------------------------
  const server = bootStaticServer();
  const port = await new Promise((r) => {
    if (server.listening) return r(server.address().port);
    server.once('listening', () => r(server.address().port));
  });

  try {
    await testAsync('GET /assets/img/logo.jpg returns 200 image/jpeg with real bytes', async () => {
      const r = await get(port, '/assets/img/logo.jpg');
      assert.strictEqual(r.status, 200, `status ${r.status}`);
      assert.match(r.headers['content-type'] || '', /^image\/jpeg/);
      assert.ok(r.body.length > 1000, `body only ${r.body.length} bytes`);
      assert.strictEqual(r.body[0], 0xff, 'first byte is not 0xFF — the JPEG was served as utf8 text');
      assert.strictEqual(r.body[1], 0xd8, 'second byte is not 0xD8 — byte corruption');
    });
    await testAsync('GET /assets/img/favicon-32.png returns 200 image/png', async () => {
      const r = await get(port, '/assets/img/favicon-32.png');
      assert.strictEqual(r.status, 200);
      assert.match(r.headers['content-type'] || '', /^image\/png/);
      assert.strictEqual(r.body[0], 0x89);
      assert.strictEqual(r.body[1], 0x50);
    });
    await testAsync('GET /assets/img/emblem.png returns 200 image/png with an intact alpha channel', async () => {
      const r = await get(port, '/assets/img/emblem.png');
      assert.strictEqual(r.status, 200, `status ${r.status}`);
      assert.match(r.headers['content-type'] || '', /^image\/png/);
      assert.strictEqual(r.body[0], 0x89, 'the PNG was served as utf8 text');
      assert.strictEqual(r.body[25], 6, 'the served emblem lost its alpha channel');
    });
    await testAsync('GET /assets/img/nandark.jpg returns 200 image/jpeg (the parent mark is served)', async () => {
      const r = await get(port, '/assets/img/nandark.jpg');
      assert.strictEqual(r.status, 200, `status ${r.status}`);
      assert.match(r.headers['content-type'] || '', /^image\/jpeg/);
      assert.strictEqual(r.body[0], 0xff);
      assert.strictEqual(r.body[1], 0xd8);
    });
    await testAsync('GET /favicon.ico answers with the icon, not a 404', async () => {
      const r = await get(port, '/favicon.ico');
      assert.strictEqual(r.status, 200, 'the browser default favicon request must not 404');
      assert.match(r.headers['content-type'] || '', /^image\/png/);
    });
    await testAsync('an unknown asset path is still refused (the allow-list holds)', async () => {
      const r = await get(port, '/assets/img/../../../package.json');
      assert.ok(r.status === 404 || r.status === 400, `expected 404/400, got ${r.status}`);
    });
    await testAsync('a text asset still serves as text (binary path did not break it)', async () => {
      const r = await get(port, '/assets/base.css');
      assert.strictEqual(r.status, 200);
      assert.match(r.headers['content-type'] || '', /^text\/css/);
      assert.ok(r.body.toString('utf8').includes('--accent:#c5a059'));
    });
  } finally {
    server.close();
  }

  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  branding: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) console.log(`  \u2022 ${f.name}\n    ${f.error.message}`);
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
})();
