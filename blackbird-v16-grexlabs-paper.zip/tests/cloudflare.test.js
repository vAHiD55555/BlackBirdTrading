#!/usr/bin/env node
'use strict';
/**
 * BlackBird — Cloudflare Workers AI adapter test suite.
 *
 * Zero dependencies, no network: `fetch` is stubbed per test.
 *
 * What is asserted:
 *   - a successful response is parsed
 *   - a missing token or account id is a clear config error
 *   - 401/403 is reported as an auth problem, not a generic failure
 *   - 429 is reported as a quota problem
 *   - a 200 with success:false is still an error (Cloudflare does this)
 *   - a timeout aborts and rejects
 *   - invalid JSON is rejected
 *   - an empty completion is rejected
 *   - a pre-parsed object result is normalised to JSON text
 *   - the adapter is reachable through createProvider
 *
 * Run: node tests/cloudflare.test.js
 */
const assert = require('node:assert');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const { CloudflareProvider, MODELS } = require(path.join(SRC, 'jev/providers/cloudflare'));
const { createProvider } = require(path.join(SRC, 'jev/providers'));

let passed = 0;
let failed = 0;
const failures = [];
const queue = [];

function test(name, fn) { queue.push({ name, fn }); }
function group(name, fn) { console.log(`\n\u25b8 ${name}`); fn(); }

async function runAll() {
  for (const t of queue) {
    try { await t.fn(); passed++; }
    catch (e) {
      failed++;
      failures.push({ name: t.name, error: e });
      console.log(`  \u2717 ${t.name}\n      ${e.message.split('\n')[0]}`);
    }
  }
}

const realFetch = global.fetch;

/** Stub fetch for one test; always restored afterwards. */
function stubFetch(impl) {
  global.fetch = impl;
  return () => { global.fetch = realFetch; };
}

function jsonResponse(body, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
  };
}

const MSGS = [
  { role: 'system', content: 'You are a market analyst.' },
  { role: 'user', content: 'Return JSON.' },
];

function makeProvider(over = {}) {
  return new CloudflareProvider({
    accountId: 'acct123',
    apiKey: 'test-token',
    model: MODELS[0],
    timeoutMs: 200,
    ...over,
  });
}

// ==================================================================== success
group('cloudflare — success', () => {
  test('a text response is returned', async () => {
    const restore = stubFetch(async () => jsonResponse({
      result: { response: '{"regime":"muddy"}' },
      success: true,
      errors: [],
    }));
    try {
      const p = makeProvider();
      const out = await p.complete({ messages: MSGS });
      assert.strictEqual(out, '{"regime":"muddy"}');
    } finally { restore(); }
  });

  test('the request goes to the right URL with the right auth', async () => {
    let seen = null;
    const restore = stubFetch(async (url, opts) => {
      seen = { url, opts };
      return jsonResponse({ result: { response: 'ok' }, success: true });
    });
    try {
      const p = makeProvider();
      await p.complete({ messages: MSGS });
      assert.match(seen.url, /accounts\/acct123\/ai\/run\//);
      assert.match(seen.url, /@cf\/meta\/llama-3\.3-70b/);
      assert.strictEqual(seen.opts.headers.authorization, 'Bearer test-token');
      const body = JSON.parse(seen.opts.body);
      assert.strictEqual(body.messages.length, 2);
      assert.strictEqual(body.temperature, 0);
    } finally { restore(); }
  });

  test('a pre-parsed object result is normalised to JSON text', async () => {
    const restore = stubFetch(async () => jsonResponse({
      result: { regime: 'calm', confidence: 0.8 },
      success: true,
    }));
    try {
      const out = await makeProvider().complete({ messages: MSGS });
      assert.strictEqual(typeof out, 'string');
      assert.strictEqual(JSON.parse(out).regime, 'calm');
    } finally { restore(); }
  });

  test('a bare string result is accepted', async () => {
    const restore = stubFetch(async () => jsonResponse({ result: 'plain text', success: true }));
    try {
      assert.strictEqual(await makeProvider().complete({ messages: MSGS }), 'plain text');
    } finally { restore(); }
  });
});

// ====================================================================== auth
group('cloudflare — authentication', () => {
  test('a missing token is a clear config error', async () => {
    const p = new CloudflareProvider({ accountId: 'a', apiKey: '', env: {} });
    await assert.rejects(
      () => p.complete({ messages: MSGS }),
      /CLOUDFLARE_API_TOKEN/
    );
  });

  test('a missing account id is a clear config error', async () => {
    const p = new CloudflareProvider({ accountId: '', apiKey: 'k', env: {} });
    await assert.rejects(
      () => p.complete({ messages: MSGS }),
      /CLOUDFLARE_ACCOUNT_ID/
    );
  });

  test('401 is reported as a token problem', async () => {
    const restore = stubFetch(async () => jsonResponse({ success: false, errors: [] }, 401));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /401.*token rejected/
      );
    } finally { restore(); }
  });

  test('403 is reported as a token problem', async () => {
    const restore = stubFetch(async () => jsonResponse({ success: false, errors: [] }, 403));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /403.*token rejected/
      );
    } finally { restore(); }
  });

  test('a 200 with success:false is still an error', async () => {
    const restore = stubFetch(async () => jsonResponse({
      success: false,
      errors: [{ code: 7000, message: 'No such model' }],
    }, 200));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /No such model/
      );
    } finally { restore(); }
  });
});

// ===================================================================== quota
group('cloudflare — quota', () => {
  test('429 is reported as a quota problem', async () => {
    const restore = stubFetch(async () => jsonResponse({ success: false, errors: [] }, 429));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /429.*quota/
      );
    } finally { restore(); }
  });
});

// =================================================================== timeout
group('cloudflare — timeout', () => {
  test('a hanging request aborts and rejects', async () => {
    const restore = stubFetch((url, opts) => new Promise((resolve, reject) => {
      // Never resolve; only the abort signal can end this.
      if (opts.signal) {
        opts.signal.addEventListener('abort', () => reject(opts.signal.reason || new Error('aborted')));
      }
    }));
    try {
      const p = makeProvider({ timeoutMs: 40 });
      const started = Date.now();
      await assert.rejects(() => p.complete({ messages: MSGS }), /timeout|abort/i);
      assert.ok(Date.now() - started < 2000, 'must not hang');
    } finally { restore(); }
  });
});

// ================================================================ bad payloads
group('cloudflare — bad payloads', () => {
  test('non-JSON body is rejected', async () => {
    const restore = stubFetch(async () => jsonResponse('<html>gateway error</html>', 200));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /non-JSON/
      );
    } finally { restore(); }
  });

  test('an empty completion is rejected', async () => {
    const restore = stubFetch(async () => jsonResponse({ result: { response: '   ' }, success: true }));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /empty completion/
      );
    } finally { restore(); }
  });

  test('a missing result is rejected', async () => {
    const restore = stubFetch(async () => jsonResponse({ success: true }));
    try {
      await assert.rejects(
        () => makeProvider().complete({ messages: MSGS }),
        /no result/
      );
    } finally { restore(); }
  });
});

// ================================================================== factory
group('cloudflare — provider factory', () => {
  test('createProvider builds a Cloudflare adapter from the catalog', () => {
    const p = createProvider(
      { provider: 'cloudflare', model: MODELS[1] },
      { env: { CLOUDFLARE_API_TOKEN: 'tok', CLOUDFLARE_ACCOUNT_ID: 'acc' } }
    );
    assert.ok(p instanceof CloudflareProvider);
    assert.strictEqual(p.accountId, 'acc');
    assert.strictEqual(p.apiKey, 'tok');
    assert.strictEqual(p.model, MODELS[1]);
  });

  test('the "cf" alias resolves to cloudflare', () => {
    const p = createProvider(
      { provider: 'cf' },
      { env: { CLOUDFLARE_API_TOKEN: 't', CLOUDFLARE_ACCOUNT_ID: 'a' } }
    );
    assert.ok(p instanceof CloudflareProvider);
  });

  test('a paid provider is refused with an explanation', () => {
    assert.throws(
      () => createProvider({ provider: 'openai' }, { env: {} }),
      /not free/
    );
  });

  test('configured is false without both credentials', () => {
    const p = new CloudflareProvider({ accountId: 'a', apiKey: '', env: {} });
    assert.strictEqual(p.configured, false);
  });
});

// ==================================================================== summary
runAll().then(() => {
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  cloudflare: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
});
