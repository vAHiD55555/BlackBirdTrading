'use strict';
/**
 * Regression tests for the v10 additions:
 *   - the apprentice (کارآموز): mandatory reasons, violations, dataset export
 *   - market intel (اخبار): headline scoring, aggregation, blackout, risk cap
 *   - historical analog (نظیر تاریخی): matching, no-match honesty
 *   - provider catalog: NVIDIA present and free
 *   - config: every new panel variable is actually mapped
 */
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Apprentice, redact } = require(path.join(SRC, 'agents/apprentice'));
const { Intel, scoreHeadline, aggregate, extractItems } = require(path.join(SRC, 'intel/news'));
const { findHistoricalAnalog } = require(path.join(SRC, 'data/regime'));
const catalog = require(path.join(SRC, 'jev/providers/catalog'));
const { loadConfig } = require(path.join(SRC, 'config'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'bb-v10-'));

(async () => {
  // ============================================================ apprentice
  console.log('\n▸ apprentice — mandatory reasons, violations, portable dataset');

  await t('apprentice: an answer without a reason is refused and recorded as a violation', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true, minReasonChars: 8 }, log: quietLog(), dir });
    const id = a.ask('scout', 'why did you propose BTCUSDT?', { symbol: 'BTCUSDT' });
    assert.ok(id, 'ask must return an id');
    const r = a.answer(id, '');
    assert.strictEqual(r.ok, false, 'empty reason must be refused');
    assert.strictEqual(a.stats.refused, 1);
    // The question is still open: a refusal is not an answer.
    assert.strictEqual(a.open.size, 1);
    const ok = a.answer(id, 'momentum crossed the 20-EMA with breadth above 50%');
    assert.strictEqual(ok.ok, true);
    assert.strictEqual(a.open.size, 0);
    assert.strictEqual(a.stats.answered, 1);
  });

  await t('apprentice: a short reason is refused, a real one is accepted', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true, minReasonChars: 8 }, log: quietLog(), dir });
    const id = a.ask('board', 'why reject?', {});
    assert.strictEqual(a.answer(id, 'no').ok, false);
    assert.strictEqual(a.answer(id, 'spread was 14bps, above the 9bps budget').ok, true);
  });

  await t('apprentice: observe() without a reason is a violation, not a silent drop', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true, minReasonChars: 8 }, log: quietLog(), dir });
    const rec = a.observe('trader', 'close BTCUSDT', '');
    assert.strictEqual(rec, null);
    assert.strictEqual(a.stats.refused, 1);
    const good = a.observe('trader', 'close BTCUSDT', 'disaster stop hit at 6 ATR');
    assert.ok(good, 'a real reason must be recorded');
    assert.strictEqual(good.kind, 'observation');
  });

  await t('apprentice: records are written to disk as JSONL, one per line', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true }, log: quietLog(), dir });
    a.observe('scout', 'propose ETHUSDT', 'pullback to EMA20 in an uptrend');
    a.observe('board', 'approve ETHUSDT', 'all three officers approved');
    const raw = fs.readFileSync(path.join(dir, 'apprentice-log.jsonl'), 'utf8').trim().split('\n');
    assert.strictEqual(raw.length, 2);
    for (const line of raw) {
      const rec = JSON.parse(line);
      assert.ok(rec.id && rec.ts && rec.kind && rec.actor && rec.reason);
    }
  });

  await t('apprentice: a secret in a reason is redacted before it reaches disk', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true }, log: quietLog(), dir });
    a.observe('trader', 'auth', 'used key sk-abcdefghijklmnopqrstuvwx to sign the order');
    const raw = fs.readFileSync(path.join(dir, 'apprentice-log.jsonl'), 'utf8');
    assert.ok(!raw.includes('sk-abcdefghijklmnopqrstuvwx'), 'the key must not be on disk');
    assert.ok(raw.includes('[redacted]'));
  });

  await t('apprentice: redact() strips a telegram token and a bearer header', () => {
    const s = redact('token 123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw and Bearer abcdefghijklmnopqrst');
    assert.ok(!s.includes('AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw'));
    assert.ok(!s.includes('abcdefghijklmnopqrst'));
  });

  await t('apprentice: exportDataset() emits model-agnostic instruction/input/output triples', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true }, log: quietLog(), dir });
    a.observe('scout', 'propose SOLUSDT', 'momentum 12% over 3 days with a stacked MA');
    a.observe('board', 'reject SOLUSDT', 'depth was $12k, below the $25k floor');
    const ds = a.exportDataset();
    assert.strictEqual(ds.length, 2);
    for (const row of ds) {
      assert.ok(typeof row.instruction === 'string' && row.instruction.length > 0);
      assert.ok(typeof row.input === 'string');
      assert.ok(typeof row.output === 'string' && row.output.length > 0);
      assert.ok(row.meta && row.meta.actor);
    }
    // A question with no answer is not a lesson.
    a.ask('trader', 'why?', {});
    assert.strictEqual(a.exportDataset().length, 2);
  });

  await t('apprentice: writeDataset() produces a file any trainer can read', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true }, log: quietLog(), dir });
    a.observe('scout', 'propose XRPUSDT', 'range fade at the low of a 40-bar range');
    const p = a.writeDataset();
    assert.ok(p && fs.existsSync(p));
    const lines = fs.readFileSync(p, 'utf8').trim().split('\n');
    assert.strictEqual(lines.length, 1);
    const row = JSON.parse(lines[0]);
    assert.ok(row.instruction.includes('scout'));
  });

  await t('apprentice: the daily byte cap drops records instead of filling the disk', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: true, maxBytesPerDay: 200 }, log: quietLog(), dir });
    for (let i = 0; i < 20; i++) a.observe('scout', `propose ${i}`, 'a reason long enough to count');
    const file = path.join(dir, 'apprentice-log.jsonl');
    const size = fs.existsSync(file) ? fs.statSync(file).size : 0;
    assert.ok(size <= 400, `file must stay near the cap, got ${size}`);
  });

  await t('apprentice: disabled means no file and no records', () => {
    const dir = tmpDir();
    const a = new Apprentice({ cfg: { enabled: false }, log: quietLog(), dir });
    assert.strictEqual(a.observe('scout', 'x', 'a perfectly good reason'), null);
    assert.strictEqual(fs.existsSync(path.join(dir, 'apprentice-log.jsonl')), false);
  });

  await t('apprentice: a bus event becomes an observation with the reason it already carried', () => {
    const dir = tmpDir();
    const handlers = new Map();
    const bus = {
      on: (topic, fn) => { handlers.set(topic, fn); return () => handlers.delete(topic); },
    };
    const a = new Apprentice({ cfg: { enabled: true }, log: quietLog(), dir, bus });
    handlers.get('trade:closed')({
      symbol: 'ETHUSDT',
      exit: { reason: 'trail' },
      rationale: ['trail locked 1R after 2R of profit'],
      pnlBps: 120,
    });
    const recs = a.records.filter((r) => r.kind === 'observation');
    assert.strictEqual(recs.length, 1);
    assert.strictEqual(recs[0].actor, 'trader');
    assert.ok(recs[0].reason.includes('trail locked'));
  });

  // ================================================================== intel
  console.log('\n▸ intel — headline scoring, blackout, risk cap');

  await t('intel: a hawkish headline scores negative tone and high impact', () => {
    const s = scoreHeadline('Fed signals rate hike as inflation surges');
    assert.ok(s.tone < 0, `tone should be negative, got ${s.tone}`);
    assert.ok(s.impact > 0.3, `impact should be meaningful, got ${s.impact}`);
    assert.ok(s.tags.includes('hawkish'));
  });

  await t('intel: a risk-on headline scores positive tone', () => {
    const s = scoreHeadline('Ceasefire agreement reached, markets rebound on optimism');
    assert.ok(s.tone > 0, `tone should be positive, got ${s.tone}`);
    assert.ok(s.tags.includes('risk_on'));
  });

  await t('intel: a neutral headline has zero tone and zero impact', () => {
    const s = scoreHeadline('Company announces new office in Denver');
    assert.strictEqual(s.tone, 0);
    assert.strictEqual(s.impact, 0);
  });

  await t('intel: a severe-weather alert is tagged and carries impact', () => {
    const s = scoreHeadline('Hurricane warning issued for the Gulf Coast');
    assert.ok(s.tags.includes('weather'));
    assert.ok(s.impact > 0.2);
  });

  await t('intel: aggregate() folds headlines into one weighted tone', () => {
    const now = Date.now();
    const v = aggregate([
      { title: 'Fed signals rate hike', ts: now - 3600000, weight: 1 },
      { title: 'Inflation surges to a new high', ts: now - 3600000, weight: 1 },
      { title: 'Ceasefire agreement reached', ts: now - 3600000, weight: 1 },
    ], { now });
    assert.ok(v.tone < 0, `net tone should be negative, got ${v.tone}`);
    assert.ok(v.items === 3);
    assert.ok(v.top.length > 0);
  });

  await t('intel: a high-impact event inside the window sets a blackout', () => {
    const now = Date.now();
    const v = aggregate(
      [{ title: 'FOMC interest rate decision today', ts: now + 10 * 60 * 1000, weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    assert.strictEqual(v.blackout, true);
    assert.ok(v.blackoutReason.includes('FOMC'));
  });

  await t('intel: a high-impact event far outside the window does NOT blackout', () => {
    const now = Date.now();
    const v = aggregate(
      [{ title: 'FOMC interest rate decision', ts: now + 5 * 3600000, weight: 1 }],
      { now, blackoutBeforeMs: 30 * 60 * 1000, blackoutAfterMs: 15 * 60 * 1000 }
    );
    assert.strictEqual(v.blackout, false);
  });

  await t('intel: riskMultiplier() can only reduce risk, never raise it', () => {
    const i = new Intel({ cfg: { enabled: true, maxRiskImpact: 0.25 }, log: quietLog() });
    // No data at all: exactly 1, not more.
    assert.strictEqual(i.riskMultiplier(), 1);
    // A strongly risk-on view must still be exactly 1.
    i.last = { tone: 0.9, confidence: 0.9, extreme: true, blackout: false };
    assert.strictEqual(i.riskMultiplier(), 1);
    // A strongly risk-off view reduces, and never below the cap.
    i.last = { tone: -0.9, confidence: 0.9, extreme: true, blackout: false };
    const m = i.riskMultiplier();
    assert.ok(m < 1 && m >= 0.75, `expected a reduction within the cap, got ${m}`);
    // A blackout is the floor.
    i.last = { tone: 0, confidence: 0, extreme: false, blackout: true };
    assert.strictEqual(i.riskMultiplier(), 0.75);
  });

  await t('intel: enabled is false when no feed URL is configured', () => {
    const i = new Intel({ cfg: { enabled: true }, log: quietLog() });
    assert.strictEqual(i.enabled, false, 'enabled with no URL must report false');
  });

  await t('intel: extractItems() reads a dotted path and normalises timestamps', () => {
    const body = { data: { news: [{ title: 'Rate cut expected', published: '2026-11-20T10:00:00Z' }] } };
    const items = extractItems(body, { path: 'data.news', titleField: 'title', timeField: 'published' });
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].title, 'Rate cut expected');
    assert.ok(Number.isFinite(items[0].ts));
  });

  await t('intel: a failing feed does not throw and leaves the view empty', async () => {
    const i = new Intel({
      cfg: { enabled: true, feeds: { macro: { url: 'https://example.invalid/x', path: '' } } },
      log: quietLog(),
      fetchImpl: async () => { throw new Error('network down'); },
    });
    const v = await i.refresh();
    assert.ok(v, 'refresh must return a view even when every feed fails');
    assert.strictEqual(v.items, 0);
    assert.strictEqual(i.stats.failures, 1);
  });

  await t('intel: a working feed produces a scored view', async () => {
    const i = new Intel({
      cfg: { enabled: true, feeds: { macro: { url: 'https://example.test/feed', path: 'items' } } },
      log: quietLog(),
      fetchImpl: async () => ({
        ok: true,
        json: async () => ({ items: [{ title: 'Fed signals rate hike', published: Date.now() }] }),
      }),
    });
    const v = await i.refresh();
    assert.strictEqual(v.items, 1);
    assert.ok(v.tone < 0);
  });

  // ================================================================= analog
  console.log('\n▸ analog — historical matching, honest no-match');

  const mkSnap = (o = {}) => ({
    atrPercentile: 0.6, trendStrength: 1.2, rsi: 55, vwapDevAtr: -0.3, atrPct: 1.4, ...o,
  });

  await t('analog: too little history returns null, not a guess', () => {
    const r = findHistoricalAnalog(mkSnap(), [{ snap: mkSnap(), outcomePct: 1 }], { minSamples: 20 });
    assert.strictEqual(r, null);
  });

  await t('analog: a close match reports the win rate of similar past setups', () => {
    const hist = [];
    for (let i = 0; i < 30; i++) {
      hist.push({ snap: mkSnap({ rsi: 55 + (i % 3) }), outcomePct: i % 4 === 0 ? -1.2 : 0.8 });
    }
    const r = findHistoricalAnalog(mkSnap(), hist, { minSamples: 20, k: 12 });
    assert.ok(r && r.matched, 'a close match must be reported');
    assert.ok(r.winRate > 0.5, `expected a healthy win rate, got ${r.winRate}`);
    assert.ok(r.samples === 12);
  });

  await t('analog: a distant market shape is reported as no match, never forced', () => {
    const hist = [];
    for (let i = 0; i < 30; i++) {
      hist.push({
        snap: { atrPercentile: 0.05, trendStrength: 0, rsi: 20, vwapDevAtr: -2.9, atrPct: 0.1 },
        outcomePct: 1,
      });
    }
    const r = findHistoricalAnalog(mkSnap({ atrPercentile: 0.99, trendStrength: 3.9, rsi: 95, vwapDevAtr: 2.9, atrPct: 4.9 }), hist, { minSamples: 20, maxDistance: 0.2 });
    assert.ok(r);
    assert.strictEqual(r.matched, false);
    assert.strictEqual(r.winRate, null);
  });

  await t('analog: a losing shape produces a low win rate that the gate can act on', () => {
    const hist = [];
    for (let i = 0; i < 30; i++) hist.push({ snap: mkSnap(), outcomePct: -0.9 });
    const r = findHistoricalAnalog(mkSnap(), hist, { minSamples: 20, k: 12 });
    assert.ok(r.matched);
    assert.strictEqual(r.winRate, 0);
    assert.ok(r.meanOutcomePct < 0);
  });

  // ================================================================ catalog
  console.log('\n▸ catalog — NVIDIA present, free, keyed');

  await t('catalog: nvidia is a known provider with a free tier and a key env', () => {
    const e = catalog.entry('nvidia');
    assert.ok(e, 'nvidia must resolve');
    assert.strictEqual(e.free, true);
    assert.strictEqual(e.cardRequired, false);
    assert.strictEqual(e.apiKeyEnv, 'NVIDIA_API_KEY');
    assert.ok(e.models.length > 0);
  });

  await t('catalog: nim and nvidia-nim are aliases for nvidia', () => {
    assert.strictEqual(catalog.resolveKind('nim'), 'nvidia');
    assert.strictEqual(catalog.resolveKind('nvidia-nim'), 'nvidia');
  });

  await t('catalog: nvidia is not keyless, so it is never the default on a keyless host', () => {
    assert.strictEqual(catalog.isKeyless('nvidia'), false);
  });

  // ================================================================= config
  console.log('\n▸ config — every new panel variable is mapped');

  await t('config: apprentice defaults exist and are enabled', () => {
    const cfg = loadConfig({});
    assert.ok(cfg.apprentice);
    assert.strictEqual(cfg.apprentice.enabled, true);
    assert.ok(cfg.apprentice.minReasonChars > 0);
  });

  await t('config: intel defaults exist and are off with no feed URL', () => {
    const cfg = loadConfig({});
    assert.ok(cfg.intel);
    assert.strictEqual(cfg.intel.enabled, false);
    assert.ok(cfg.intel.feeds.macro);
  });

  await t('config: analog defaults exist and are enabled', () => {
    const cfg = loadConfig({});
    assert.ok(cfg.analog);
    assert.strictEqual(cfg.analog.enabled, true);
    assert.ok(cfg.analog.minWinRate > 0);
  });

  await t('config: APPRENTICE_ENABLED=false from the panel actually disables it', () => {
    process.env.APPRENTICE_ENABLED = 'false';
    try {
      const cfg = loadConfig({});
      assert.strictEqual(cfg.apprentice.enabled, false);
    } finally {
      delete process.env.APPRENTICE_ENABLED;
    }
  });

  await t('config: INTEL_MACRO_URL from the panel reaches the feed config', () => {
    process.env.INTEL_MACRO_URL = 'https://example.test/macro';
    try {
      const cfg = loadConfig({});
      assert.strictEqual(cfg.intel.feeds.macro.url, 'https://example.test/macro');
    } finally {
      delete process.env.INTEL_MACRO_URL;
    }
  });

  await t('config: ANALOG_MIN_WIN_RATE from the panel is a number, not a string', () => {
    process.env.ANALOG_MIN_WIN_RATE = '0.42';
    try {
      const cfg = loadConfig({});
      assert.strictEqual(cfg.analog.minWinRate, 0.42);
    } finally {
      delete process.env.ANALOG_MIN_WIN_RATE;
    }
  });

  await t('config: INTEL_MAX_RISK_IMPACT cannot be used to raise risk', () => {
    // The value is a cap on how much risk may be REDUCED. The module clamps the
    // multiplier to [1 - cap, 1], so a large value still never exceeds 1.
    const i = new Intel({ cfg: { enabled: true, maxRiskImpact: 0.9 }, log: quietLog() });
    i.last = { tone: 0.9, confidence: 1, extreme: true, blackout: false };
    assert.strictEqual(i.riskMultiplier(), 1);
  });

  done('v10');
})();
