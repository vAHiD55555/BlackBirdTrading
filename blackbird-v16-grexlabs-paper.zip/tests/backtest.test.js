#!/usr/bin/env node
'use strict';
/**
 * BlackBird — offline backtest tests.
 *
 *   node tests/backtest.test.js
 *
 * Covers: CSV parsing (all the shapes and all the failure modes), the fill
 * model, determinism, the equity curve hand-off, K registration, and the
 * claim that matters most — that the offline path and the live path agree.
 */

const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const SRC = path.join(__dirname, '..', 'src');
const { parseCsv, parseTime, parseNumber, detectSeparator, mapHeader, readCsvFile, formatReport } = require(path.join(SRC, 'backtest/csv'));
const { runBacktest, CsvBroker, CsvFeed, CsvHub, sharpe } = require(path.join(SRC, 'backtest/engine'));
const { loadConfig } = require(path.join(SRC, 'config'));
const { TrialRegistry } = require(path.join(SRC, 'jev/trials'));
const { EquityCurve } = require(path.join(SRC, 'core/equity-curve'));
const { PaperBroker } = require(path.join(SRC, 'exec/paper'));
const { Rotator } = require(path.join(SRC, 'strategy/rotator'));
const { Portfolio } = require(path.join(SRC, 'exec/portfolio'));

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    failures.push({ name, error: e });
    console.log(`  \u2717 ${name}`);
    console.log(`      ${e.message.split('\n')[0]}`);
  }
}

function group(name, fn) {
  console.log(`\n\u25b8 ${name}`);
  fn();
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const tmp = (p) => fs.mkdtempSync(path.join(os.tmpdir(), p));

/** Deterministic synthetic bars. */
function synth(n = 400, drift = 0.0008, seed = 3) {
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const out = [];
  let c = 100;
  const t0 = Date.UTC(2025, 0, 1);
  for (let i = 0; i < n; i++) {
    const o = c;
    c = c * (1 + drift) * (1 + Math.sin(i / 5) * 0.004 + (rnd() - 0.5) * 0.002);
    out.push({
      t: t0 + i * 3600000,
      o, h: Math.max(o, c) * 1.002, l: Math.min(o, c) * 0.998, c, v: 1000 + (i % 40),
    });
  }
  return out;
}

function toCsv(bars, { header = true, sep = ',', timeMode = 'ms' } = {}) {
  const lines = [];
  if (header) lines.push(['time', 'open', 'high', 'low', 'close', 'volume'].join(sep));
  for (const b of bars) {
    const t = timeMode === 's' ? Math.floor(b.t / 1000)
      : timeMode === 'iso' ? new Date(b.t).toISOString()
        : b.t;
    lines.push([t, b.o, b.h, b.l, b.c, b.v].join(sep));
  }
  return lines.join('\n') + '\n';
}

// ============================================================ CSV: time parsing
group('csv \u2014 timestamp parsing', () => {
  test('epoch milliseconds pass through', () => {
    assert.strictEqual(parseTime('1700000000000'), 1700000000000);
  });
  test('epoch seconds are scaled to ms', () => {
    assert.strictEqual(parseTime('1700000000'), 1700000000000);
  });
  test('ISO-8601 parses', () => {
    assert.strictEqual(parseTime('2025-01-01T00:00:00.000Z'), Date.UTC(2025, 0, 1));
  });
  test('"YYYY-MM-DD HH:mm:ss" parses (space separator)', () => {
    assert.strictEqual(parseTime('2025-01-01 00:00:00'), Date.UTC(2025, 0, 1));
  });
  test('a bare date parses to midnight UTC', () => {
    assert.strictEqual(parseTime('2025-01-01'), Date.UTC(2025, 0, 1));
  });
  test('garbage returns null rather than a wrong date', () => {
    assert.strictEqual(parseTime('not-a-date'), null);
    assert.strictEqual(parseTime(''), null);
    assert.strictEqual(parseTime('12'), null);
  });
  test('quoted and BOM-prefixed cells are cleaned', () => {
    assert.strictEqual(parseTime('"\uFEFF1700000000000"'), 1700000000000);
  });
});

// ========================================================== CSV: number parsing
group('csv \u2014 number parsing', () => {
  test('plain, quoted, thousands-separated and scientific all parse', () => {
    assert.strictEqual(parseNumber('1.5'), 1.5);
    assert.strictEqual(parseNumber('"1.5"'), 1.5);
    assert.strictEqual(parseNumber('1,234.5'), 1234.5);
    assert.strictEqual(parseNumber('1.2e-3'), 0.0012);
  });
  test('empty and null-ish cells return null, not 0', () => {
    assert.strictEqual(parseNumber(''), null);
    assert.strictEqual(parseNumber('null'), null);
    assert.strictEqual(parseNumber('abc'), null);
  });
});

// ============================================================ CSV: separators
group('csv \u2014 separator and header detection', () => {
  test('comma, semicolon and tab are detected', () => {
    assert.strictEqual(detectSeparator('a,b,c'), ',');
    assert.strictEqual(detectSeparator('a;b;c'), ';');
    assert.strictEqual(detectSeparator('a\tb\tc'), '\t');
  });
  test('a named header maps regardless of column order', () => {
    const m = mapHeader(['close', 'volume', 'time', 'open', 'high', 'low']);
    assert.strictEqual(m.t, 2);
    assert.strictEqual(m.c, 0);
    assert.strictEqual(m.v, 1);
  });
  test('a header without time or close is not a header', () => {
    assert.strictEqual(mapHeader(['foo', 'bar', 'baz']), null);
  });
});

// ============================================================== CSV: full parse
group('csv \u2014 full parse', () => {
  const bars = synth(50);

  test('header + comma + ms parses every row', () => {
    const { bars: out, report } = parseCsv(toCsv(bars));
    assert.strictEqual(report.accepted, 50);
    assert.strictEqual(report.rejected, 0);
    assert.strictEqual(report.ok, true);
    assert.strictEqual(out[0].t, bars[0].t);
    assert.ok(Math.abs(out[0].c - bars[0].c) < 1e-9);
  });

  test('no header + semicolon + seconds parses', () => {
    const { bars: out, report } = parseCsv(toCsv(bars, { header: false, sep: ';', timeMode: 's' }));
    assert.strictEqual(report.accepted, 50);
    assert.strictEqual(out[0].t, bars[0].t);
  });

  test('ISO timestamps parse', () => {
    const { bars: out, report } = parseCsv(toCsv(bars, { timeMode: 'iso' }));
    assert.strictEqual(report.accepted, 50);
    assert.strictEqual(out[0].t, bars[0].t);
  });

  test('CRLF and blank lines are tolerated', () => {
    const text = toCsv(bars).replace(/\n/g, '\r\n') + '\r\n\r\n';
    const { report } = parseCsv(text);
    assert.strictEqual(report.accepted, 50);
  });

  test('duplicate timestamps are dropped and counted', () => {
    const text = toCsv(bars) + `${bars[10].t},1,2,0.5,1.5,10\n`;
    const { bars: out, report } = parseCsv(text);
    assert.strictEqual(report.duplicates, 1);
    assert.strictEqual(report.accepted, 50);
    assert.ok(report.problems.some((p) => p.code === 'duplicates'));
  });

  test('out-of-order rows are sorted and reported', () => {
    const lines = toCsv(bars).trim().split('\n');
    const header = lines[0];
    const body = lines.slice(1);
    [body[5], body[20]] = [body[20], body[5]];
    const { bars: out, report } = parseCsv([header, ...body].join('\n'));
    // Two swaps create two inversions, not one: each moved row is now after a
    // row it should precede. Counting one would understate how messy the file is.
    assert.ok(report.outOfOrder >= 1, `outOfOrder=${report.outOfOrder}`);
    assert.ok(report.problems.some((p) => p.code === 'out_of_order'));
    for (let i = 1; i < out.length; i++) assert.ok(out[i].t > out[i - 1].t, 'sorted ascending');
  });

  test('a gap in the series is detected and quantified', () => {
    const gapped = bars.filter((_, i) => i < 20 || i > 25); // drop 6 bars
    const { report } = parseCsv(toCsv(gapped));
    assert.ok(report.gaps >= 1, `gaps=${report.gaps}`);
    assert.ok(report.problems.some((p) => p.code === 'gaps'));
  });

  test('bad rows are rejected with a reason, not silently kept', () => {
    const text = toCsv(bars) + 'notatime,1,2,0.5,1.5,10\n';
    const { report } = parseCsv(text);
    assert.strictEqual(report.rejected, 1);
    assert.ok(report.problems.some((p) => p.code === 'rejected_rows'));
  });

  test('high below low is rejected', () => {
    const text = toCsv(bars) + `${bars[0].t + 999999},10,1,5,6,10\n`;
    const { report } = parseCsv(text);
    assert.strictEqual(report.rejected, 1);
  });

  test('close outside the high/low range is rejected', () => {
    const text = toCsv(bars) + `${bars[0].t + 999999},10,12,8,99,10\n`;
    const { report } = parseCsv(text);
    assert.strictEqual(report.rejected, 1);
  });

  test('an empty file fails loudly', () => {
    const { report } = parseCsv('');
    assert.strictEqual(report.ok, false);
    assert.ok(report.problems.some((p) => p.code === 'empty'));
  });

  test('a file with no valid rows fails loudly', () => {
    const { report } = parseCsv('time,open,high,low,close\nx,y,z,w,q\n');
    assert.strictEqual(report.ok, false);
  });

  test('a date range filter narrows the series', () => {
    const from = bars[10].t;
    const to = bars[20].t;
    const { bars: out, report } = parseCsv(toCsv(bars), { from, to });
    assert.strictEqual(report.accepted, 11);
    assert.strictEqual(out[0].t, from);
    assert.strictEqual(out[out.length - 1].t, to);
  });

  test('a range that matches nothing fails loudly', () => {
    const { report } = parseCsv(toCsv(bars), { from: Date.UTC(2030, 0, 1) });
    assert.strictEqual(report.ok, false);
    assert.ok(report.problems.some((p) => p.code === 'empty_range'));
  });

  test('a missing file returns a report, never throws', () => {
    const { bars: out, report } = readCsvFile('/nonexistent/nope.csv');
    assert.strictEqual(out.length, 0);
    assert.strictEqual(report.ok, false);
    assert.ok(report.problems.some((p) => p.code === 'unreadable'));
  });

  test('formatReport renders a readable block', () => {
    const { report } = parseCsv(toCsv(bars));
    const s = formatReport(report);
    assert.ok(s.includes('accepted=50'));
    assert.ok(s.includes('interval=3600000ms'));
  });
});

// ============================================================ fill model
group('backtest \u2014 fill model', () => {
  const cfg = loadConfig({ server: { enabled: false } });
  const bars = synth(10);
  const feed = new CsvFeed('X', bars, { windowBars: 100 });
  feed.seek(5);
  const hub = new CsvHub(new Map([['X', feed]]));
  const broker = new CsvBroker({ cfg, hub, log: quietLog() });

  test('a buy fills above the close by the slippage', () => {
    const f = broker.submit({ symbol: 'X', side: 'buy', qty: 1, type: 'market' });
    assert.strictEqual(f.status, 'filled');
    const slip = cfg.backtest?.slippageBps ?? 1.5;
    assert.ok(f.price > bars[5].c, 'buy pays up');
    assert.ok(Math.abs(f.price - bars[5].c * (1 + slip / 10000)) < 1e-9);
  });

  test('a sell fills below the close by the slippage', () => {
    const f = broker.submit({ symbol: 'X', side: 'sell', qty: 1, type: 'market' });
    assert.ok(f.price < bars[5].c, 'sell receives less');
  });

  test('the taker fee is charged on notional', () => {
    const f = broker.submit({ symbol: 'X', side: 'buy', qty: 2, type: 'market' });
    const expected = (f.notional * cfg.fees.takerBps) / 10000;
    assert.ok(Math.abs(f.fee - expected) < 1e-9);
  });

  test('a zero or negative quantity is rejected', () => {
    assert.strictEqual(broker.submit({ symbol: 'X', side: 'buy', qty: 0 }).status, 'rejected');
    assert.strictEqual(broker.submit({ symbol: 'X', side: 'buy', qty: -1 }).status, 'rejected');
  });

  test('an unknown symbol is rejected, not crashed', () => {
    assert.strictEqual(broker.submit({ symbol: 'NOPE', side: 'buy', qty: 1 }).status, 'rejected');
  });
});

// ============================================ offline vs live: same fill price
group('backtest \u2014 offline and live agree', () => {
  test('CsvBroker and PaperBroker price the same order identically', () => {
    const cfg = loadConfig({ server: { enabled: false } });
    // PaperBroker with zero slippage and a one-level book at the close must
    // produce exactly the CsvBroker price with zero slippage.
    const price = 100;
    const feed = {
      isStale: false,
      depth: { bids: [[price, 1e6]], asks: [[price, 1e6]] },
    };
    const paper = new PaperBroker({
      cfg: { ...cfg, fees: { ...cfg.fees, slippageBpsPer1kNotional: 0 } },
      log: quietLog(),
      getBook: () => ({ bid: price, ask: price }),
      getFeed: () => feed,
    });
    const p = paper.submit({ symbol: 'X', side: 'buy', type: 'market', qty: 3 });

    const bars = synth(5);
    bars[4].c = price;
    const cf = new CsvFeed('X', bars, { windowBars: 10 });
    cf.seek(4);
    const csv = new CsvBroker({
      cfg: { ...cfg, backtest: { slippageBps: 0 } },
      hub: new CsvHub(new Map([['X', cf]])),
      log: quietLog(),
    });
    const c = csv.submit({ symbol: 'X', side: 'buy', qty: 3 });

    assert.strictEqual(p.status, 'filled');
    assert.strictEqual(c.status, 'filled');
    assert.ok(Math.abs(p.price - c.price) < 1e-9, `paper=${p.price} csv=${c.price}`);
    assert.ok(Math.abs(p.fee - c.fee) < 1e-9, `paper=${p.fee} csv=${c.fee}`);
  });

  test('the same Rotator class runs both paths (no second implementation)', () => {
    // If the backtest had its own strategy, this require would not be the
    // production module. Assert the identity explicitly.
    const engineSrc = fs.readFileSync(path.join(SRC, 'backtest/engine.js'), 'utf8');
    assert.ok(engineSrc.includes("require('../strategy/rotator')"), 'uses the production Rotator');
    assert.ok(!/class\s+BacktestRotator/.test(engineSrc), 'no reimplemented strategy');
  });

  test('the backtest engine contains no network call', () => {
    for (const f of ['backtest/engine.js', 'backtest/csv.js', 'backtest/run.js']) {
      const src = fs.readFileSync(path.join(SRC, f), 'utf8');
      assert.ok(!/\bfetch\s*\(/.test(src), `${f} must not call fetch`);
      assert.ok(!/require\(['"]node:https?['"]\)/.test(src), `${f} must not require http`);
      assert.ok(!/require\(['"]node:net['"]\)/.test(src), `${f} must not require net`);
    }
  });
});

// ============================================================ full backtest
group('backtest \u2014 full run', () => {
  const cfg = loadConfig({ server: { enabled: false } });

  test('a rising market produces a positive return and a real trade list', () => {
    // Two constraints, both real:
    //  1. the rotator needs `maxLook + 60` bars before it will trade;
    //  2. with only TWO symbols and `neutral: true` variants, longs and shorts
    //     land on the same two names and cancel exactly -> an empty book. That
    //     is the strategy working correctly ("views cancel -> stay flat"), so a
    //     meaningful test needs a cross-section of at least four names.
    const four = {
      BTCUSDT: synth(900, 0.0004, 11),
      ETHUSDT: synth(900, 0.0014, 12),
      SOLUSDT: synth(900, -0.0002, 13),
      XRPUSDT: synth(900, -0.0010, 14),
    };
    const r = runBacktest({ cfg, barsBySymbol: four });
    assert.strictEqual(r.ok, true);
    assert.ok(r.rotatorStats.ready, 'the window was long enough for the strategy');
    assert.ok(r.summary.trades > 0, 'trades happened');
    assert.ok(r.summary.finalEquity > 0);
    assert.ok(r.equity.length === 900);
    assert.ok(r.returns.length === 899);
  });

  test('a series shorter than the warm-up window trades nothing and says so', () => {
    // Silence here would be a trap: a user who feeds 200 bars and sees a flat
    // equity curve must be told the strategy never became ready.
    const bars = synth(200, 0.002, 17);
    const r = runBacktest({ cfg, barsBySymbol: { A: bars, B: synth(200, 0.001, 18) } });
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.rotatorStats.ready, false);
    assert.strictEqual(r.summary.trades, 0);
    assert.strictEqual(r.summary.fills, 0);
  });

  test('the run is deterministic: same input, same output', () => {
    const bars = { A: synth(300, 0.001, 5), B: synth(300, -0.0005, 6) };
    const a = runBacktest({ cfg, barsBySymbol: bars });
    const b = runBacktest({ cfg, barsBySymbol: bars });
    assert.strictEqual(a.summary.finalEquity, b.summary.finalEquity);
    assert.strictEqual(a.summary.trades, b.summary.trades);
    assert.deepStrictEqual(a.returns, b.returns);
  });

  test('all positions are closed at the end of the data', () => {
    const bars = { A: synth(400, 0.001, 7), B: synth(400, 0.0002, 8) };
    const r = runBacktest({ cfg, barsBySymbol: bars });
    // Every trade in the list is closed; the final equity is realised.
    assert.ok(r.trades.every((t) => t.exit && t.exit.reason));
    assert.ok(r.trades.some((t) => t.exit.reason === 'end_of_data') || r.trades.length === 0);
  });

  test('max drawdown is non-negative and bounded', () => {
    const r = runBacktest({ cfg, barsBySymbol: { A: synth(500, 0.0005, 9), B: synth(500, -0.0008, 10) } });
    assert.ok(r.summary.maxDrawdownPct >= 0);
    assert.ok(r.summary.maxDrawdownPct <= 100);
  });

  test('a flat market does not invent profit', () => {
    const flat = [];
    const t0 = Date.UTC(2025, 0, 1);
    for (let i = 0; i < 400; i++) flat.push({ t: t0 + i * 3600000, o: 100, h: 100.01, l: 99.99, c: 100, v: 10 });
    const r = runBacktest({ cfg, barsBySymbol: { A: flat, B: flat.map((b) => ({ ...b })) } });
    assert.strictEqual(r.ok, true);
    // No edge in a flat market: the return must be ~0 (fees only), never large.
    assert.ok(Math.abs(r.summary.returnPct) < 5, `returnPct=${r.summary.returnPct}`);
  });

  test('empty input returns an error object, never throws', () => {
    const r = runBacktest({ cfg, barsBySymbol: {} });
    assert.strictEqual(r.ok, false);
    assert.ok(r.error);
  });

  test('a single bar is refused', () => {
    const r = runBacktest({ cfg, barsBySymbol: { A: synth(1) } });
    assert.strictEqual(r.ok, false);
  });

  test('sharpe is null on a constant series, not Infinity', () => {
    assert.strictEqual(sharpe([0.01, 0.01, 0.01]), null);
    assert.strictEqual(sharpe([]), null);
    assert.ok(Number.isFinite(sharpe([0.01, -0.005, 0.02, 0.001])));
  });
});

// ==================================================== equity curve hand-off
group('backtest \u2014 equity curve hand-off', () => {
  test('the curve is written where the lawyer reads it, and reloads', () => {
    const dir = tmp('bb-bt-eq-');
    const file = path.join(dir, 'equity.jsonl');
    const cfg = loadConfig({ server: { enabled: false } });
    const r = runBacktest({
      cfg,
      barsBySymbol: { A: synth(200, 0.001, 13), B: synth(200, 0.0003, 14) },
      equityFile: file,
    });
    assert.strictEqual(r.ok, true);
    assert.ok(fs.existsSync(file), 'curve file written');

    // A fresh EquityCurve (as the lawyer would build) must see the samples.
    const curve = new EquityCurve({ file, log: quietLog() });
    const perf = curve.performance();
    assert.ok(perf.samples >= 200, `samples=${perf.samples}`);
    assert.ok(perf.T >= 199, `T=${perf.T}`);
    assert.ok(perf.returns.every((x) => Number.isFinite(x)));
  });

  test('the curve survives a restart (reload from disk)', () => {
    const dir = tmp('bb-bt-eq2-');
    const file = path.join(dir, 'equity.jsonl');
    const cfg = loadConfig({ server: { enabled: false } });
    runBacktest({ cfg, barsBySymbol: { A: synth(120, 0.001, 15) }, equityFile: file });
    const first = new EquityCurve({ file, log: quietLog() }).performance().samples;
    const second = new EquityCurve({ file, log: quietLog() }).performance().samples;
    assert.strictEqual(first, second);
    assert.ok(first > 0);
  });
});

// ============================================================ K registration
group('backtest \u2014 trial registry (K)', () => {
  test('each backtest increments K and persists across a restart', () => {
    const dir = tmp('bb-bt-k-');
    const file = path.join(dir, 'trials.jsonl');

    const reg1 = new TrialRegistry({ file });
    assert.strictEqual(reg1.K, 0);
    reg1.record({ kind: 'backtest', field: 'backtest', note: 'run 1', metrics: { sharpe: 0.4 } });
    assert.strictEqual(reg1.K, 1);

    // A new registry instance (a restart) must see the same K.
    const reg2 = new TrialRegistry({ file });
    assert.strictEqual(reg2.K, 1);
    reg2.record({ kind: 'backtest', field: 'backtest', note: 'run 2', metrics: { sharpe: 0.6 } });
    assert.strictEqual(reg2.K, 2);

    const reg3 = new TrialRegistry({ file });
    assert.strictEqual(reg3.K, 2, 'K survives a restart');
    const sharpes = reg3.trials.filter((t) => t.metrics?.sharpe).map((t) => t.metrics.sharpe);
    assert.deepStrictEqual(sharpes, [0.4, 0.6]);
  });

  test('a backtest record carries the input file and range', () => {
    const dir = tmp('bb-bt-k2-');
    const reg = new TrialRegistry({ file: path.join(dir, 'trials.jsonl') });
    const rec = reg.record({
      kind: 'backtest',
      field: 'backtest',
      to: { files: ['BTCUSDT_1h.csv'], symbols: ['BTCUSDT'], timeframe: '1h', bars: 1441 },
      note: 'offline backtest',
      metrics: { sharpe: 0.12, n: 1440 },
    });
    assert.strictEqual(rec.kind, 'backtest');
    assert.deepStrictEqual(rec.to.files, ['BTCUSDT_1h.csv']);
    assert.strictEqual(rec.to.bars, 1441);
    assert.strictEqual(rec.metrics.sharpe, 0.12);
  });
});

// ======================================================= real data, offline
group('backtest \u2014 real recorded data, no network', () => {
  const fixtureDir = path.join(__dirname, 'fixtures');
  const files = fs.existsSync(fixtureDir)
    ? fs.readdirSync(fixtureDir).filter((f) => f.endsWith('.csv'))
    : [];

  test('the recorded fixtures exist', () => {
    assert.ok(files.length >= 1, 'at least one recorded CSV fixture');
  });

  test('every fixture parses cleanly with no rejected rows', () => {
    for (const f of files) {
      const { bars, report } = readCsvFile(path.join(fixtureDir, f), { symbol: f.split('_')[0] });
      assert.strictEqual(report.ok, true, `${f}: ${JSON.stringify(report.problems)}`);
      assert.strictEqual(report.rejected, 0, `${f} rejected ${report.rejected}`);
      assert.ok(bars.length > 100, `${f} has ${bars.length} bars`);
      assert.strictEqual(report.intervalMs, 3600000, `${f} interval`);
    }
  });

  test('a backtest over the recorded data runs and is deterministic', () => {
    const barsBySymbol = {};
    for (const f of files) {
      const sym = f.split('_')[0];
      const { bars } = readCsvFile(path.join(fixtureDir, f), { symbol: sym });
      if (bars.length) barsBySymbol[sym] = bars;
    }
    if (Object.keys(barsBySymbol).length < 2) return; // needs a cross-section
    const cfg = loadConfig({ server: { enabled: false } });
    const a = runBacktest({ cfg, barsBySymbol });
    const b = runBacktest({ cfg, barsBySymbol });
    assert.strictEqual(a.ok, true);
    assert.strictEqual(a.summary.finalEquity, b.summary.finalEquity);
    assert.ok(a.summary.bars > 1000);
  });
});

// ======================================================= panel hand-off
group('backtest \u2014 panel hand-off (latest.json)', () => {
  const { writeLatest, readLatest, latestPath } = require(path.join(SRC, 'backtest/latest'));

  test('a written summary reads back with the fields the panel needs', () => {
    const dir = tmp('bb-bt-latest-');
    const p = writeLatest(dir, {
      ts: Date.now(),
      symbols: ['BTCUSDT', 'ETHUSDT'],
      timeframe: '1h',
      files: ['BTCUSDT_1h.csv'],
      summary: { returnPct: 1.5, maxDrawdownPct: 3.2, trades: 9, wins: 5, losses: 4, sharpePerPeriod: 0.3, feesPaid: 1.1, bars: 900, returns: 899 },
      trialK: 4,
      warnings: ['BTCUSDT: gaps'],
    });
    assert.ok(p && fs.existsSync(p));
    const r = readLatest(dir);
    assert.strictEqual(r.summary.returnPct, 1.5);
    assert.strictEqual(r.trialK, 4);
    assert.deepStrictEqual(r.symbols, ['BTCUSDT', 'ETHUSDT']);
    assert.strictEqual(r.stale, false);
    assert.strictEqual(r.warnings.length, 1);
  });

  test('no file returns null, never throws', () => {
    const dir = tmp('bb-bt-latest2-');
    assert.strictEqual(readLatest(dir), null);
  });

  test('a corrupt file returns null, never throws', () => {
    const dir = tmp('bb-bt-latest3-');
    const file = latestPath(dir);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, '{ this is not json', 'utf8');
    assert.strictEqual(readLatest(dir), null);
  });

  test('a file without a summary is treated as absent', () => {
    const dir = tmp('bb-bt-latest4-');
    writeLatest(dir, { ts: Date.now(), symbols: [] });
    assert.strictEqual(readLatest(dir), null);
  });

  test('an old summary is flagged stale, not hidden', () => {
    const dir = tmp('bb-bt-latest5-');
    const old = Date.now() - 40 * 24 * 3600 * 1000;
    writeLatest(dir, { ts: old, summary: { returnPct: 0 }, symbols: [] });
    const r = readLatest(dir);
    assert.ok(r);
    assert.strictEqual(r.stale, true);
  });

  test('a read-only data dir does not fail the write path', () => {
    // writeLatest must return null rather than throw when it cannot write.
    const p = writeLatest('/proc/definitely-not-writable', { ts: 1, summary: {} });
    assert.strictEqual(p, null);
  });
});

// ================================================================ summary
console.log(`\n${'\u2500'.repeat(48)}`);
console.log(`  backtest: ${passed} passed, ${failed} failed`);
if (failed) {
  console.log('\nFailures:');
  for (const f of failures) {
    console.log(`  \u2022 ${f.name}`);
    console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
  }
}
console.log(`${'\u2500'.repeat(48)}\n`);
process.exit(failed ? 1 : 0);
