'use strict';
/**
 * Regression tests for the v13 intel feed layer.
 *
 * The bug this suite exists for: the intel module could only read JSON, and
 * GDELT answers HTTP 429 from a shared datacenter IP. With no RSS support and
 * no fallback, every feed failed and the "market intel" card stayed empty —
 * while the code still reported `enabled: true`, which reads as "working".
 *
 * These tests are fully offline: fetch is injected, so no network is touched.
 */
const assert = require('node:assert');
const path = require('node:path');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { Intel, parseRss, decodeEntities } = require(path.join(SRC, 'intel/news'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const RSS_SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
  <title>BBC Business</title>
  <item>
    <title>Fed signals rate hike as inflation surges</title>
    <pubDate>Sat, 22 Nov 2026 08:00:00 GMT</pubDate>
  </item>
  <item>
    <title><![CDATA[Ceasefire deal reached after talks]]></title>
    <pubDate>Sat, 22 Nov 2026 07:30:00 GMT</pubDate>
  </item>
  <item>
    <title>Fed&#39;s Powell warns of &quot;tighter&quot; policy</title>
    <pubDate>Sat, 22 Nov 2026 07:00:00 GMT</pubDate>
  </item>
</channel></rss>`;

const ATOM_SAMPLE = `<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <title>Hurricane warning issued for Gulf coast</title>
    <updated>2026-11-22T06:00:00Z</updated>
  </entry>
</feed>`;

/** A fetch stub that answers per-URL from a map. */
function stubFetch(map) {
  return async (url) => {
    const entry = map[url];
    if (!entry) return { ok: false, status: 404, json: async () => ({}), text: async () => '' };
    if (entry.status && entry.status !== 200) {
      return { ok: false, status: entry.status, json: async () => ({}), text: async () => entry.body || '' };
    }
    return {
      ok: true,
      status: 200,
      json: async () => entry.json,
      text: async () => entry.body || '',
    };
  };
}

(async () => {
  // ---------------------------------------------------------------- parsing
  await t('parseRss: reads RSS 2.0 items with titles and dates', () => {
    const items = parseRss(RSS_SAMPLE);
    assert.strictEqual(items.length, 3);
    assert.match(items[0].title, /rate hike/);
    assert.ok(Number.isFinite(items[0].ts), 'pubDate must parse to a timestamp');
  });

  await t('parseRss: unwraps CDATA and decodes entities', () => {
    const items = parseRss(RSS_SAMPLE);
    assert.strictEqual(items[1].title, 'Ceasefire deal reached after talks');
    assert.strictEqual(items[2].title, 'Fed\'s Powell warns of "tighter" policy');
  });

  await t('parseRss: reads Atom <entry> blocks', () => {
    const items = parseRss(ATOM_SAMPLE);
    assert.strictEqual(items.length, 1);
    assert.match(items[0].title, /Hurricane/);
    assert.ok(Number.isFinite(items[0].ts));
  });

  await t('parseRss: empty or garbage input returns [] and never throws', () => {
    assert.deepStrictEqual(parseRss(''), []);
    assert.deepStrictEqual(parseRss(null), []);
    assert.deepStrictEqual(parseRss('<html><body>429 Too Many Requests</body></html>'), []);
  });

  await t('decodeEntities: strips tags so markup cannot reach the scorer', () => {
    assert.strictEqual(decodeEntities('<b>war</b> &amp; peace'), 'war & peace');
  });

  // ------------------------------------------------------- fallback behaviour
  const GDELT = 'https://gdelt.test/doc?query=inflation';
  const BBC = 'https://bbc.test/business.xml';

  const feedCfg = (over = {}) => ({
    enabled: true,
    timeoutMs: 5000,
    feeds: {
      macro: {
        url: GDELT, path: 'articles', titleField: 'title', timeField: 'seendate',
        weight: 1.0, format: 'json', fallbackUrl: BBC, fallbackFormat: 'rss',
        ...over,
      },
    },
  });

  await t('fallback: GDELT 429 falls through to the RSS mirror', async () => {
    const fetchImpl = stubFetch({
      [GDELT]: { status: 429, body: 'Please limit requests to one every 5 seconds' },
      [BBC]: { body: RSS_SAMPLE },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    const view = await intel.refresh();

    assert.strictEqual(intel.feedStatus.macro.ok, true, 'feed must be reported healthy');
    assert.strictEqual(intel.feedStatus.macro.source, 'fallback', 'source must say fallback, not primary');
    assert.strictEqual(view.items, 3);
    assert.ok(view.items > 0, 'the card must not be empty when a mirror answered');
  });

  await t('fallback: primary success is reported as primary, not fallback', async () => {
    const fetchImpl = stubFetch({
      [GDELT]: { json: { articles: [{ title: 'CPI hotter than expected', seendate: '20261122080000' }] } },
      [BBC]: { body: RSS_SAMPLE },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(intel.feedStatus.macro.source, 'primary');
  });

  await t('fallback: both sources failing is reported as failed, never faked', async () => {
    const fetchImpl = stubFetch({
      [GDELT]: { status: 429, body: 'rate limited' },
      [BBC]: { status: 503, body: 'unavailable' },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    const view = await intel.refresh();

    assert.strictEqual(intel.feedStatus.macro.ok, false);
    assert.strictEqual(view.items, 0);
    assert.match(intel.feedStatus.macro.error, /429/);
    assert.match(intel.feedStatus.macro.error, /fallback/);
  });

  await t('fallback: a timeout on the primary still reaches the mirror', async () => {
    const fetchImpl = async (url) => {
      if (url === GDELT) {
        const e = new Error('aborted');
        e.name = 'AbortError';
        throw e;
      }
      return { ok: true, status: 200, text: async () => RSS_SAMPLE, json: async () => ({}) };
    };
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(intel.feedStatus.macro.source, 'fallback');
  });

  // ------------------------------------------------------------ safety rules
  await t('safety: risk multiplier never exceeds 1 even on a risk-on flood', async () => {
    const fetchImpl = stubFetch({
      [GDELT]: {
        json: {
          articles: [
            { title: 'Ceasefire deal breakthrough peace optimism', seendate: '20261122080000' },
            { title: 'Recovery rebound agreement resolution', seendate: '20261122080000' },
            { title: 'Deal truce breakthrough', seendate: '20261122080000' },
          ],
        },
      },
    });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    const m = intel.riskMultiplier();
    assert.ok(m <= 1, `risk multiplier must never exceed 1, got ${m}`);
    assert.ok(m >= 0.75, `risk multiplier must stay within the floor, got ${m}`);
  });

  await t('safety: snapshot exposes per-feed status for the dashboard', async () => {
    const fetchImpl = stubFetch({ [GDELT]: { status: 429 }, [BBC]: { body: RSS_SAMPLE } });
    const intel = new Intel({ cfg: feedCfg(), log: quietLog(), fetchImpl });
    await intel.refresh();
    const snap = intel.snapshot();
    assert.ok(snap.feeds && snap.feeds.macro, 'snapshot must carry feed status');
    assert.strictEqual(snap.feeds.macro.source, 'fallback');
  });

  await t('safety: enabled is false when no feed URL is configured', () => {
    const intel = new Intel({ cfg: { enabled: true, feeds: { macro: { url: '' } } }, log: quietLog() });
    assert.strictEqual(intel.enabled, false);
  });

  // ------------------------------------------------------------- 429 retry
  await t('retry: a transient 429 is retried once and then succeeds', async () => {
    let calls = 0;
    const fetchImpl = async (url) => {
      if (url !== GDELT) return { ok: false, status: 404, json: async () => ({}), text: async () => '' };
      calls++;
      if (calls === 1) return { ok: false, status: 429, json: async () => ({}), text: async () => 'rate limited' };
      return { ok: true, status: 200, json: async () => ({ articles: [{ title: 'CPI hotter than expected', seendate: '20261122080000' }] }), text: async () => '' };
    };
    const cfg = feedCfg();
    cfg.retry429 = 1;
    cfg.retryDelayMs = 1; // do not actually wait in a test
    const intel = new Intel({ cfg, log: quietLog(), fetchImpl });
    await intel.refresh();

    assert.strictEqual(calls, 2, 'the 429 must be retried exactly once');
    assert.strictEqual(intel.feedStatus.macro.source, 'primary', 'the retry must be credited to the primary');
  });

  await t('retry: retry429=0 disables the retry (no extra request)', async () => {
    let primaryCalls = 0;
    const fetchImpl = async (url) => {
      if (url === GDELT) primaryCalls++;
      return { ok: false, status: 429, json: async () => ({}), text: async () => 'rate limited' };
    };
    const cfg = feedCfg();
    cfg.retry429 = 0;
    cfg.retryDelayMs = 1;
    const intel = new Intel({ cfg, log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(primaryCalls, 1, 'with retry429=0 the primary must be called exactly once');
    assert.strictEqual(intel.feedStatus.macro.ok, false);
  });

  await t('retry: a non-429 error is never retried', async () => {
    let primaryCalls = 0;
    const fetchImpl = async (url) => {
      if (url === GDELT) primaryCalls++;
      return { ok: false, status: 500, json: async () => ({}), text: async () => 'boom' };
    };
    const cfg = feedCfg();
    cfg.retry429 = 1;
    cfg.retryDelayMs = 1;
    const intel = new Intel({ cfg, log: quietLog(), fetchImpl });
    await intel.refresh();
    assert.strictEqual(primaryCalls, 1, 'a 500 must not be retried');
  });

  done('intel-rss');
})();
