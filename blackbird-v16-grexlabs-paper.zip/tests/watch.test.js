#!/usr/bin/env node
'use strict';
/**
 * The watch (دیده‌بان) — discovery, ranking, stagnation, council gate, safety.
 *
 * Pure functions are tested directly; the cycle is tested with a stub exchange
 * and a stub portfolio, so nothing here touches the network.
 */
const assert = require('node:assert');
const { t, done } = require('./harness');
const { Watch, scoreCandidate, isStagnant, realisedVol, sma } = require('../src/agents/watch');

const noop = () => {};
const log = { info: noop, warn: noop, error: noop, debug: noop, child() { return log; } };

/** A synthetic hourly series: `driftPct` per bar, small noise, `n` bars. */
function series(n, driftPct, start = 100) {
  const out = [];
  let px = start;
  for (let i = 0; i < n; i++) {
    px *= 1 + driftPct / 100;
    const wobble = 1 + Math.sin(i / 3) * 0.002;
    out.push({ t: i * 3600000, o: px, h: px * 1.004, l: px * 0.996, c: px * wobble, v: 1000 });
  }
  return out;
}

function makeCfg(over = {}) {
  const { watch: watchOver, ...rest } = over;
  return {
    symbols: ['BTCUSDT', 'ETHUSDT'],
    fees: { makerBps: 2, takerBps: 5, slippageBpsPer1kNotional: 0.6 },
    strategy: { minTpBps: 30, maxSlBps: 250 },
    ...rest,
    watch: {
      enabled: true, intervalMs: 6 * 3600000, universe: [], maxCandidates: 5,
      minQuoteVolumeUsd: 5_000_000, minEdgeBps: 25, stagnantDays: 14,
      stagnantReturnPct: 1.0, autoApply: false, requireCouncil: true, maxSwapsPerCycle: 1,
      ...(watchOver || {}),
    },
  };
}

function makeStore() {
  const rows = [];
  return { append: (type, data) => rows.push({ type, data }), rows };
}

function makeHub(barsBySymbol = {}) {
  return {
    get: (sym) => (barsBySymbol[sym] ? { bars: { toArray: () => barsBySymbol[sym] } } : null),
  };
}

function makePortfolio(positions = []) {
  return { openPositions: () => positions };
}

(async () => {
  console.log('\n▸ watch — scoring is pure and honest');

  await t('a strong, orderly uptrend scores above a flat market', () => {
    const up = scoreCandidate(series(300, 0.05), { costBps: 20 });
    const flat = scoreCandidate(series(300, 0.0), { costBps: 20 });
    assert.ok(up && flat, 'both must score');
    assert.ok(up.score > flat.score, `uptrend ${up.score} should beat flat ${flat.score}`);
    assert.ok(up.expectedEdgeBps > flat.expectedEdgeBps);
  });

  await t('a downtrend does not score as an opportunity', () => {
    const down = scoreCandidate(series(300, -0.05), { costBps: 20 });
    assert.ok(down, 'must still return a score');
    assert.ok(down.expectedEdgeBps < 0, `downtrend edge must be negative, got ${down.expectedEdgeBps}`);
  });

  await t('too little data returns null instead of a guess', () => {
    assert.strictEqual(scoreCandidate(series(10, 0.05)), null);
    assert.strictEqual(scoreCandidate([]), null);
    assert.strictEqual(scoreCandidate(null), null);
  });

  await t('a dead-quiet market is penalised even when it drifts up', () => {
    const quiet = scoreCandidate(series(300, 0.0005), { costBps: 20 });
    assert.ok(quiet.volScore <= 0.3, `quiet volScore should be low, got ${quiet.volScore}`);
  });

  await t('realisedVol and sma behave on known input', () => {
    assert.strictEqual(sma([1, 2, 3, 4], 2), 3.5);
    assert.ok(Number.isNaN(sma([1], 5)));
    const flat = realisedVol(new Array(50).fill(100), 24 * 365);
    assert.strictEqual(flat, 0, 'a flat series has zero volatility');
  });

  console.log('\n▸ watch — stagnation is not the same as losing');

  await t('a flat holding is stagnant, a moving one is not', () => {
    const cfg = { stagnantReturnPct: 1.0 };
    assert.strictEqual(isStagnant({ returnPct: 0.2 }, cfg).stagnant, true);
    assert.strictEqual(isStagnant({ returnPct: -0.3 }, cfg).stagnant, true);
    assert.strictEqual(isStagnant({ returnPct: 8 }, cfg).stagnant, false);
    assert.strictEqual(isStagnant({ returnPct: -12 }, cfg).stagnant, true, 'a big loss is worse than dead');
  });

  await t('a holding with no return data is never called stagnant', () => {
    assert.strictEqual(isStagnant({ returnPct: null }, { stagnantReturnPct: 1 }).stagnant, false);
    assert.strictEqual(isStagnant({}, { stagnantReturnPct: 1 }).stagnant, false);
  });

  console.log('\n▸ watch — discovery never proposes what we already hold');

  await t('held and configured symbols are excluded from discovery', async () => {
    const w = new Watch({
      cfg: makeCfg(), log, store: makeStore(),
      hub: makeHub(), exchange: null,
      portfolio: makePortfolio([{ symbol: 'SOLUSDT', dir: 1, qty: 1, entry: 100, last: 100 }]),
    });
    w.w.universe = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'ADAUSDT', 'DOTUSDT'];
    const found = await w.discover();
    assert.deepStrictEqual(found, ['ADAUSDT', 'DOTUSDT']);
  });

  await t('a failing exchange yields an empty discovery, not a crash', async () => {
    const w = new Watch({
      cfg: makeCfg(), log, store: makeStore(), hub: makeHub(),
      exchange: { tickers: async () => { throw new Error('network down'); } },
      portfolio: makePortfolio([]),
    });
    const found = await w.discover();
    assert.deepStrictEqual(found, []);
    assert.strictEqual(w.stats.errors, 1);
  });

  console.log('\n▸ watch — a swap is a replacement, never an addition');

  await t('a swap carries the incumbent notional, never more', () => {
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null });
    const candidates = [{ symbol: 'ADAUSDT', score: 0.8, expectedEdgeBps: 300, momentumPct: 3 }];
    const holdings = [{ symbol: 'XRPUSDT', dir: 1, notional: 500, returnPct: 0.1 }];
    const swaps = w.buildSwaps(candidates, holdings);
    assert.strictEqual(swaps.length, 1);
    assert.strictEqual(swaps[0].notional, 500, 'the new position may not exceed the old one');
    assert.strictEqual(swaps[0].out.symbol, 'XRPUSDT');
    assert.strictEqual(swaps[0].in.symbol, 'ADAUSDT');
  });

  await t('a candidate that does not beat the incumbent by the edge floor is refused', () => {
    const w = new Watch({ cfg: makeCfg({ watch: { minEdgeBps: 500 } }), log, store: makeStore(), hub: makeHub(), exchange: null });
    const swaps = w.buildSwaps(
      [{ symbol: 'ADAUSDT', score: 0.8, expectedEdgeBps: 100, momentumPct: 1 }],
      [{ symbol: 'XRPUSDT', dir: 1, notional: 500, returnPct: 0.1 }]
    );
    assert.strictEqual(swaps.length, 0);
  });

  await t('maxSwapsPerCycle caps the churn', () => {
    const w = new Watch({ cfg: makeCfg({ watch: { maxSwapsPerCycle: 1 } }), log, store: makeStore(), hub: makeHub(), exchange: null });
    const candidates = [
      { symbol: 'ADAUSDT', score: 0.9, expectedEdgeBps: 400, momentumPct: 4 },
      { symbol: 'DOTUSDT', score: 0.8, expectedEdgeBps: 350, momentumPct: 3 },
    ];
    const holdings = [
      { symbol: 'XRPUSDT', dir: 1, notional: 500, returnPct: 0.1 },
      { symbol: 'LTCUSDT', dir: 1, notional: 400, returnPct: 0.2 },
    ];
    assert.strictEqual(w.buildSwaps(candidates, holdings).length, 1);
  });

  await t('a healthy holding is left alone', () => {
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null });
    const swaps = w.buildSwaps(
      [{ symbol: 'ADAUSDT', score: 0.9, expectedEdgeBps: 400, momentumPct: 4 }],
      [{ symbol: 'XRPUSDT', dir: 1, notional: 500, returnPct: 25 }]
    );
    assert.strictEqual(swaps.length, 0, 'a 25% winner is not stagnant');
  });

  console.log('\n▸ watch — the council gates every swap');

  await t('without council approval nothing is applied', () => {
    const board = { review: () => ({ approved: false, reason: 'veto: risk' }) };
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null, board, portfolio: makePortfolio([]) });
    const r = w.review({ id: 's1', ts: 1, out: { symbol: 'XRPUSDT' }, in: { symbol: 'ADAUSDT', score: 0.8 }, notional: 500, edgeBps: 100 });
    assert.strictEqual(r.approved, false);
    assert.strictEqual(w.stats.approved, 0);
    assert.strictEqual(w.stats.refused, 1);
  });

  await t('an approving council approves, and the swap is still not applied by the watch', () => {
    const board = { review: () => ({ approved: true }) };
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null, board, portfolio: makePortfolio([]) });
    const r = w.review({ id: 's2', ts: 1, out: { symbol: 'XRPUSDT' }, in: { symbol: 'ADAUSDT', score: 0.8 }, notional: 500, edgeBps: 100 });
    assert.strictEqual(r.approved, true);
    assert.strictEqual(w.stats.applied, 0, 'the watch never applies a swap itself');
  });

  await t('a throwing council fails closed', () => {
    const board = { review: () => { throw new Error('board exploded'); } };
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null, board, portfolio: makePortfolio([]) });
    const r = w.review({ id: 's3', ts: 1, out: { symbol: 'XRPUSDT' }, in: { symbol: 'ADAUSDT', score: 0.8 }, notional: 500, edgeBps: 100 });
    assert.strictEqual(r.approved, false);
    assert.strictEqual(r.ok, false);
  });

  console.log('\n▸ watch — a full cycle, and its failure modes');

  await t('a full cycle discovers, ranks and proposes', async () => {
    const store = makeStore();
    const w = new Watch({
      cfg: makeCfg({ watch: { universe: ['ADAUSDT', 'DOTUSDT'], minEdgeBps: 1 } }),
      log, store, hub: makeHub({ ADAUSDT: series(300, 0.06), DOTUSDT: series(300, 0.02) }),
      exchange: null,
      portfolio: makePortfolio([{ symbol: 'XRPUSDT', dir: 1, qty: 5, entry: 100, last: 100.05 }]),
    });
    const r = await w.run();
    assert.strictEqual(r.ok, true);
    assert.ok(r.candidates.length >= 1, 'at least one candidate');
    assert.strictEqual(r.candidates[0].symbol, 'ADAUSDT', 'the stronger trend ranks first');
    assert.ok(store.rows.some((x) => x.type === 'watch_proposal'), 'the proposal is journalled');
  });

  await t('a disabled watch does nothing at all', async () => {
    const w = new Watch({ cfg: makeCfg({ watch: { enabled: false } }), log, store: makeStore(), hub: makeHub(), exchange: null });
    const r = await w.run();
    assert.strictEqual(r.ok, false);
    assert.strictEqual(r.reason, 'disabled');
    assert.strictEqual(w.stats.cycles, 0);
  });

  await t('a cycle with nothing new is a clean no-op', async () => {
    const w = new Watch({
      cfg: makeCfg({ watch: { universe: ['BTCUSDT'] } }), log, store: makeStore(),
      hub: makeHub(), exchange: null, portfolio: makePortfolio([]),
    });
    const r = await w.run();
    assert.strictEqual(r.ok, true);
    assert.deepStrictEqual(r.swaps, []);
    assert.strictEqual(r.note, 'nothing_new');
  });

  await t('snapshot is JSON-safe and reports the counters', () => {
    const w = new Watch({ cfg: makeCfg(), log, store: makeStore(), hub: makeHub(), exchange: null });
    const s = w.snapshot();
    assert.strictEqual(s.enabled, true);
    assert.strictEqual(typeof s.cycles, 'number');
    assert.doesNotThrow(() => JSON.stringify(s));
  });

  done('watch');
})();
