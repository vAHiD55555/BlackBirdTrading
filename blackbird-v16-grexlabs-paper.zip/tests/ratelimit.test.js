#!/usr/bin/env node
'use strict';
/**
 * BlackBird — rate limiter test suite.
 *
 * Zero dependencies, no network, real temp files.
 *
 * What is asserted:
 *   - a fresh provider is allowed
 *   - the daily cap blocks once reached
 *   - the per-minute window blocks and then frees up
 *   - counters survive a restart (persistence)
 *   - a corrupt counter file does not crash the limiter
 *   - when every provider is capped, the panel returns null and the engine
 *     falls back to rules instead of crashing
 *   - a provider that is out of quota is never called
 *
 * Run: node tests/ratelimit.test.js
 */
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const SRC = path.join(__dirname, '..', 'src');
const { RateLimiter, FREE_LIMITS, utcDay, msUntilReset } = require(path.join(SRC, 'jev/rateLimiter'));
const { Consensus } = require(path.join(SRC, 'jev/consensus'));
const { MockProvider } = require(path.join(SRC, 'jev/providers'));

let passed = 0;
let failed = 0;
const failures = [];
const queue = [];

function test(name, fn) { queue.push({ name, fn }); }
function group(name, fn) { console.log(`\n\u25b8 ${name}`); fn(); }

async function runAll() {
  for (const t of queue) {
    try { await t.fn(); passed++; }
    catch (e) {
      failed++;
      failures.push({ name: t.name, error: e });
      console.log(`  \u2717 ${t.name}\n      ${e.message.split('\n')[0]}`);
    }
  }
}

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

function tmpFile() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'bb-rl-')), 'rate-limits.json');
}

function makeLimiter(cfg = {}, opts = {}) {
  return new RateLimiter({
    cfg: { enabled: true, ...cfg },
    log: quietLog(),
    stateFile: opts.stateFile || null,
    clock: opts.clock,
  });
}

// ==================================================================== basics
group('rateLimiter — basics', () => {
  test('a fresh provider is allowed', () => {
    const rl = makeLimiter();
    const g = rl.check('groq');
    assert.strictEqual(g.ok, true);
    assert.ok(g.remaining.day > 0);
  });

  test('consume increments the daily counter', () => {
    const rl = makeLimiter();
    rl.consume('groq');
    rl.consume('groq');
    const g = rl.check('groq');
    assert.strictEqual(g.remaining.day, FREE_LIMITS.groq.perDay - 2);
  });

  test('an unlimited provider is never blocked', () => {
    const rl = makeLimiter();
    for (let i = 0; i < 500; i++) rl.consume('ollama');
    assert.strictEqual(rl.check('ollama').ok, true);
  });

  test('config overrides the published limit', () => {
    const rl = makeLimiter({ limits: { groq: { perDay: 3 } } });
    assert.strictEqual(rl.limitsFor('groq').perDay, 3);
  });
});

// ================================================================= daily cap
group('rateLimiter — daily cap', () => {
  test('the daily cap blocks once reached', () => {
    const rl = makeLimiter({ limits: { groq: { perDay: 2, perMinute: 0 } } });
    rl.consume('groq');
    rl.consume('groq');
    const g = rl.check('groq');
    assert.strictEqual(g.ok, false);
    assert.match(g.reason, /daily quota/);
    assert.ok(g.retryAfterMs > 0);
  });

  test('the reset time is the next UTC midnight', () => {
    const ms = msUntilReset(Date.UTC(2026, 10, 7, 23, 0, 0));
    assert.strictEqual(ms, 3600000);
  });

  test('a new UTC day resets the counter', () => {
    let now = Date.UTC(2026, 10, 7, 12, 0, 0);
    const rl = makeLimiter(
      { limits: { groq: { perDay: 1, perMinute: 0 } } },
      { clock: () => now }
    );
    rl.consume('groq');
    assert.strictEqual(rl.check('groq').ok, false);

    now = Date.UTC(2026, 10, 8, 0, 0, 1); // next day
    assert.strictEqual(rl.check('groq').ok, true);
    assert.ok(rl.stats.resets >= 1);
  });
});

// ============================================================== minute window
group('rateLimiter — per-minute window', () => {
  test('the minute window blocks and then frees up', () => {
    let now = 1000000;
    const rl = makeLimiter(
      { limits: { groq: { perMinute: 2, perDay: 0 } } },
      { clock: () => now }
    );
    rl.consume('groq');
    rl.consume('groq');
    assert.strictEqual(rl.check('groq').ok, false);

    now += 61000; // a minute later
    assert.strictEqual(rl.check('groq').ok, true);
  });

  test('the retry hint points at the oldest call', () => {
    let now = 1000000;
    const rl = makeLimiter(
      { limits: { groq: { perMinute: 1, perDay: 0 } } },
      { clock: () => now }
    );
    rl.consume('groq');
    const g = rl.check('groq');
    assert.strictEqual(g.ok, false);
    assert.ok(g.retryAfterMs > 0 && g.retryAfterMs <= 60000);
  });
});

// =============================================================== persistence
group('rateLimiter — persistence', () => {
  test('counters survive a restart', () => {
    const stateFile = tmpFile();
    const a = makeLimiter({ limits: { groq: { perDay: 5, perMinute: 0 } } }, { stateFile });
    a.consume('groq');
    a.consume('groq');
    a.persist();

    const b = makeLimiter({ limits: { groq: { perDay: 5, perMinute: 0 } } }, { stateFile });
    const g = b.check('groq');
    assert.strictEqual(g.remaining.day, 3, 'the restart must not hand back quota');
  });

  test('a corrupt counter file does not crash the limiter', () => {
    const stateFile = tmpFile();
    fs.writeFileSync(stateFile, '{not json at all');
    const rl = makeLimiter({}, { stateFile });
    assert.doesNotThrow(() => rl.check('groq'));
    assert.strictEqual(rl.check('groq').ok, true);
  });

  test('an unwritable state file does not crash', () => {
    // A regular file used as a parent directory: mkdir fails with ENOTDIR.
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-rl-bad-'));
    const blocker = path.join(dir, 'not-a-dir');
    fs.writeFileSync(blocker, 'x');
    const rl = makeLimiter({}, { stateFile: path.join(blocker, 'state.json') });
    assert.doesNotThrow(() => { rl.consume('groq'); rl.persist(); });
    assert.ok(rl.stats.persistFailures >= 1);
  });

  test('reset clears a provider', () => {
    const rl = makeLimiter({ limits: { groq: { perDay: 1, perMinute: 0 } } });
    rl.consume('groq');
    assert.strictEqual(rl.check('groq').ok, false);
    rl.reset('groq');
    assert.strictEqual(rl.check('groq').ok, true);
  });
});

// ==================================================================== guard
group('rateLimiter — guard', () => {
  test('guard runs the call and consumes on success', async () => {
    const rl = makeLimiter();
    const r = await rl.guard('groq', async () => 'ok');
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.value, 'ok');
    assert.strictEqual(rl.check('groq').remaining.day, FREE_LIMITS.groq.perDay - 1);
  });

  test('guard refuses without calling when the quota is gone', async () => {
    const rl = makeLimiter({ limits: { groq: { perDay: 1, perMinute: 0 } } });
    rl.consume('groq');
    let called = false;
    const r = await rl.guard('groq', async () => { called = true; return 'x'; });
    assert.strictEqual(r.ok, false);
    assert.strictEqual(called, false, 'the request must never be made');
  });

  test('a timeout does not burn quota', async () => {
    const rl = makeLimiter();
    const before = rl.check('groq').remaining.day;
    await rl.guard('groq', async () => { throw new Error('timeout after 10ms'); });
    assert.strictEqual(rl.check('groq').remaining.day, before);
  });
});

// ======================================================== consensus fallback
group('rateLimiter — consensus falls back to rules', () => {
  test('a capped provider is skipped, not called', async () => {
    const rl = makeLimiter({ limits: { mock: { perDay: 1, perMinute: 0 } } });
    rl.consume('mock'); // exhaust it

    let calls = 0;
    const provider = new MockProvider({ script: [{ reply: '{}' }] });
    const orig = provider.complete.bind(provider);
    provider.complete = async (a) => { calls++; return orig(a); };

    const c = new Consensus({
      cfg: { enabled: true, quorum: 1, timeoutMs: 50 },
      log: quietLog(),
      providers: [{ provider, model: 'm', weight: 1 }],
      rateLimiter: rl,
    });

    const r = await c.decide({ market: [{ symbol: 'BTC', price: 1 }] });
    assert.strictEqual(r, null, 'no quota means no verdict');
    assert.strictEqual(calls, 0, 'the provider must not be called');
    assert.ok(c.stats.quotaSkipped >= 1);
  });

  test('when every model is capped the cycle returns null and does not crash', async () => {
    const rl = makeLimiter({ limits: { mock: { perDay: 1, perMinute: 0 } } });
    rl.consume('mock');

    const c = new Consensus({
      cfg: { enabled: true, quorum: 2, timeoutMs: 50 },
      log: quietLog(),
      providers: [
        { provider: new MockProvider({ script: [{ reply: '{}' }] }), model: 'a', weight: 1 },
        { provider: new MockProvider({ script: [{ reply: '{}' }] }), model: 'b', weight: 1 },
      ],
      rateLimiter: rl,
    });

    const r = await c.decide({ market: [{ symbol: 'BTC', price: 1 }] });
    assert.strictEqual(r, null);
    assert.match(c.lastError, /quorum not met/);
  });

  test('one capped model does not stop the others', async () => {
    const rl = makeLimiter({ limits: { mock: { perDay: 100, perMinute: 0 } } });
    const vote = JSON.stringify({
      regime: 'muddy', confidence: 0.7, bias: 'neutral',
      riskMultiplier: 0.6, reasoning: 'ok', veto: false,
    });

    const c = new Consensus({
      cfg: { enabled: true, quorum: 1, timeoutMs: 50 },
      log: quietLog(),
      providers: [
        { provider: new MockProvider({ script: [{ reply: vote }] }), model: 'a', weight: 1 },
        { provider: new MockProvider({ script: [{ reply: vote }] }), model: 'b', weight: 1 },
      ],
      rateLimiter: rl,
    });

    const r = await c.decide({ market: [{ symbol: 'BTC', price: 1 }] });
    assert.ok(r, 'the panel should still reach a verdict');
    assert.strictEqual(r.consensus.votes, 2);
  });
});

// ==================================================================== snapshot
group('rateLimiter — snapshot', () => {
  test('the snapshot reports usage, ceiling and reset', () => {
    const rl = makeLimiter();
    rl.consume('groq');
    const s = rl.snapshot();
    const groq = s.providers.find((p) => p.provider === 'groq');
    assert.ok(groq);
    assert.strictEqual(groq.usedToday, 1);
    assert.strictEqual(groq.limitToday, FREE_LIMITS.groq.perDay);
    assert.ok(groq.resetsInMs > 0);
    assert.ok(groq.pctUsed >= 0);
  });

  test('an unlimited provider reports a null ceiling', () => {
    const rl = makeLimiter();
    const s = rl.snapshot();
    const ollama = s.providers.find((p) => p.provider === 'ollama');
    assert.strictEqual(ollama.limitToday, null);
    assert.strictEqual(ollama.pctUsed, null);
  });
});

// ==================================================================== summary
runAll().then(() => {
  console.log(`\n${'\u2500'.repeat(48)}`);
  console.log(`  ratelimit: ${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  \u2022 ${f.name}`);
      console.log(`    ${f.error.stack?.split('\n').slice(0, 3).join('\n    ')}`);
    }
  }
  console.log(`${'\u2500'.repeat(48)}\n`);
  process.exit(failed ? 1 : 0);
});
