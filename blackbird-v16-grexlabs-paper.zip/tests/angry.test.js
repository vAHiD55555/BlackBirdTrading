'use strict';
/**
 * AngryBird — the $100 scenario and its "muddy water" activation window.
 * Offline: the market context is a plain object, no feed, no network.
 */
const path = require('node:path');
const assert = require('node:assert');
const { t, done } = require('./harness');

const SRC = path.join(__dirname, '..', 'src');
const { angryActivation, angryLockout } = require(path.join(SRC, 'risk/angry-limits'));
const { AngryReporter } = require(path.join(SRC, 'notify/angry-report'));
const { applyProfile, ANGRYBIRD_OVERLAY } = require(path.join(SRC, 'profiles'));
const { loadConfig } = require(path.join(SRC, 'config'));
const { RiskManager } = require(path.join(SRC, 'risk/risk'));
const { Portfolio } = require(path.join(SRC, 'exec/portfolio'));

const quietLog = () => {
  const noop = () => {};
  const l = { info: noop, warn: noop, error: noop, debug: noop };
  l.child = () => l;
  return l;
};

const ACT = { enabled: true, minAtrPercentile: 0.75, minExodusBreadth: 0.6, minRecoveryScore: 0.5 };
const muddy = { atrPercentile: 0.9, exodusBreadth: 0.8, recoveryScore: 0.7, spreadOk: true, depthOk: true };

function memStore(cfg) {
  return {
    state: {
      equity: cfg.risk.startEquity,
      dayStartEquity: cfg.risk.startEquity,
      peakEquity: cfg.risk.startEquity,
      counters: { day: '2026-01-01', tradesToday: 0, wins: 0, losses: 0, trades: 0, grossProfit: 0, grossLoss: 0, lossesStreak: 0 },
      cooldowns: {},
      learned: {},
      positions: [],
    },
    append: () => {},
    readJournal: () => [],
    verifyChain: () => ({ ok: true, count: 0 }),
    saveState: () => {},
    rollDay: () => false,
  };
}

(async () => {
  await t('the gate opens only in turbulent water with capitulation and recovery', async () => {
    const r = angryActivation(ACT, muddy);
    assert(r.active === true, JSON.stringify(r));
    assert(r.score > 0.7 && r.score <= 1, `score=${r.score}`);
  });

  await t('a calm market keeps the gate shut', async () => {
    const r = angryActivation(ACT, { ...muddy, atrPercentile: 0.3 });
    assert(r.active === false);
    assert(r.reasons.some((x) => x.startsWith('calm_market')), JSON.stringify(r.reasons));
  });

  await t('a sell-off nobody is leaving keeps the gate shut', async () => {
    const r = angryActivation(ACT, { ...muddy, exodusBreadth: 0.2 });
    assert(r.active === false);
    assert(r.reasons.some((x) => x.startsWith('no_capitulation')), JSON.stringify(r.reasons));
  });

  await t('fear without positive evidence keeps the gate shut', async () => {
    const r = angryActivation(ACT, { ...muddy, recoveryScore: 0.1 });
    assert(r.active === false);
    assert(r.reasons.some((x) => x.startsWith('no_recovery_evidence')), JSON.stringify(r.reasons));
  });

  await t('an illiquid book keeps the gate shut', async () => {
    const bad = angryActivation(ACT, { ...muddy, spreadOk: false });
    assert(bad.active === false && bad.reasons.includes('spread_too_wide'));
    const thin = angryActivation(ACT, { ...muddy, depthOk: false });
    assert(thin.active === false && thin.reasons.includes('book_too_thin'));
  });

  await t('missing measurements fail closed', async () => {
    const r = angryActivation(ACT, { atrPercentile: 0.9 });
    assert(r.active === false);
    assert.deepStrictEqual(r.reasons, ['missing_context']);
  });

  await t('a disabled gate does not block the profile', async () => {
    const r = angryActivation({ enabled: false }, {});
    assert(r.active === true);
  });

  await t('the profile starts at $100 with a $25 hard ceiling', async () => {
    const cfg = applyProfile(
      loadConfig({ server: { enabled: false } }),
      { env: { BB_PROFILE: 'angrybird' }, defaults: { runtime: { dataDir: path.join(require('node:os').tmpdir(), 'bb-angry') } }, pkgVersion: '4.0.0', root: require('node:os').tmpdir() },
    );
    assert.strictEqual(cfg.risk.startEquity, 100, `equity=${cfg.risk.startEquity}`);
    assert.strictEqual(cfg.risk.angry.maxTradeNotionalUsd, 25, `cap=${cfg.risk.angry.maxTradeNotionalUsd}`);
    assert.strictEqual(cfg.risk.angry.activation.enabled, true);
    assert.strictEqual(cfg.strategy.timeStopMs, 6 * 3600 * 1000, 'short-term horizon');
    assert.strictEqual(cfg.strategy.rotator.rebalanceHours, 24, 'daily rotation, not weekly');
  });

  await t('the risk manager refuses entries while the gate is shut', async () => {
    const cfg = loadConfig({ server: { enabled: false } });
    cfg.risk.startEquity = 100;
    cfg.risk.angry = JSON.parse(JSON.stringify(ANGRYBIRD_OVERLAY.risk.angry));
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    risk.marketContext = () => ({ atrPercentile: 0.2, exodusBreadth: 0.3, recoveryScore: 0.9, spreadOk: true, depthOk: true });
    const r = risk.check({ symbol: 'BTCUSDT', notional: 10 }, new Portfolio(quietLog()));
    assert.strictEqual(r.ok, false, JSON.stringify(r));
    assert.match(r.reason, /angry_gate_closed/, r.reason);
    assert.match(r.reason, /calm_market/, r.reason);
  });

  await t('a dead feed cannot open the gate', async () => {
    const cfg = loadConfig({ server: { enabled: false } });
    cfg.risk.startEquity = 100;
    cfg.risk.angry = JSON.parse(JSON.stringify(ANGRYBIRD_OVERLAY.risk.angry));
    const risk = new RiskManager({ cfg, store: memStore(cfg), log: quietLog() });
    risk.marketContext = () => ({ atrPercentile: null, exodusBreadth: null, recoveryScore: null });
    const r = risk.check({ symbol: 'BTCUSDT', notional: 10 }, new Portfolio(quietLog()));
    assert.match(r.reason, /missing_context/, r.reason);
  });

  await t('an open gate stops vetoing on that rule', async () => {
    const cfg = loadConfig({ server: { enabled: false } });
    cfg.risk.startEquity = 100;
    cfg.risk.angry = JSON.parse(JSON.stringify(ANGRYBIRD_OVERLAY.risk.angry));
    const risk = new RiskManager({ cfg, store: memStore(cfg), log: quietLog() });
    risk.marketContext = () => ({ ...muddy });
    const r = risk.check({ symbol: 'BTCUSDT', notional: 10 }, new Portfolio(quietLog()));
    assert.doesNotMatch(String(r.reason || ''), /angry_gate_closed/, String(r.reason));
    assert.ok(r.checks.some((c) => c.rule === 'angry_gate_open'), JSON.stringify(r.checks));
  });

  // ---------------------------------------------------------------- lockout
  const LOCK = { enabled: true, maxConsecutiveLosses: 2, minLockMs: 12 * 3600 * 1000, requireFreshSetup: true };

  await t('two consecutive losses engage the lockout', async () => {
    const r = angryLockout(LOCK, { lossStreak: 2, now: 1000, lock: null });
    assert.strictEqual(r.locked, true, JSON.stringify(r));
    assert.match(r.reasons[0], /2_consecutive_losses/);
  });

  await t('one loss does not engage the lockout', async () => {
    assert.strictEqual(angryLockout(LOCK, { lossStreak: 1, now: 1000, lock: null }).locked, false);
  });

  await t('time alone does not lift the lock: a fresh window is required', async () => {
    const rec = { at: 0, losses: 2, gateClosedSince: false };
    const r = angryLockout(LOCK, { lossStreak: 2, now: 10 * 3600 * 1000, lock: rec });
    assert.strictEqual(r.locked, true, JSON.stringify(r));
    assert.ok(r.reasons.includes('no_fresh_setup'), JSON.stringify(r.reasons));
  });

  await t('the lock lifts after the cooling period and a fresh setup', async () => {
    const rec = { at: 0, losses: 2, gateClosedSince: true };
    assert.strictEqual(angryLockout(LOCK, { lossStreak: 2, now: 20 * 3600 * 1000, lock: rec }).locked, false);
  });

  await t('the risk manager blocks re-entry after two losses', async () => {
    const cfg = loadConfig({ server: { enabled: false } });
    cfg.profile = { name: 'angrybird' };
    cfg.risk.startEquity = 100;
    cfg.risk.angry = JSON.parse(JSON.stringify(ANGRYBIRD_OVERLAY.risk.angry));
    cfg.risk.angry.lockout.minLockMs = 0;
    const store = memStore(cfg);
    const risk = new RiskManager({ cfg, store, log: quietLog() });
    risk.marketContext = () => ({ ...muddy });
    const pf = new Portfolio(quietLog());
    risk.settle({ tradeId: 'a', symbol: 'X', pnl: -1, fee: 0, win: false });
    risk.settle({ tradeId: 'b', symbol: 'X', pnl: -1, fee: 0, win: false });
    assert.ok(store.state.angryLock, 'lock should be recorded in state');
    const r = risk.check({ symbol: 'BTCUSDT', notional: 10 }, pf);
    assert.match(r.reason, /angry_lockout/, r.reason);

    // The gate closing marks the old setup as over; the next check lifts the lock.
    risk.marketContext = () => ({ atrPercentile: 0.1, exodusBreadth: 0.1, recoveryScore: 0.1, spreadOk: true, depthOk: true });
    risk.check({ symbol: 'BTCUSDT', notional: 10 }, pf);
    assert.strictEqual(store.state.angryLock, undefined, 'lock should clear on a fresh window');
  });

  // -------------------------------------------------------- Telegram report
  const makeReporter = () => {
    const sent = [];
    const cfg = {
      profile: { name: 'angrybird' },
      strategy: { entryType: 'maker' },
      risk: { angry: { maxTradeNotionalUsd: 25, activation: ACT } },
      notifications: { telegram: { enabled: true, botToken: 'x', angryChatId: '-100123' } },
    };
    let t0 = 1000;
    const rec = new AngryReporter({
      cfg,
      log: quietLog(),
      store: null,
      clock: () => t0,
      checkEveryMs: 0,
      send: (text) => { sent.push(text); },
    });
    return { rec, sent, cfg, advance: (ms) => { t0 += ms; } };
  };

  await t('the start report says why it started, how it entered and with what size', async () => {
    const { rec, sent } = makeReporter();
    const positions = [
      { symbol: 'BTCUSDT', side: 'buy', notional: 25, dir: 1 },
      { symbol: 'ETHUSDT', side: 'sell', notional: 25, dir: -1 },
    ];
    rec.tick({ context: muddy, positions, equity: 100 });
    assert.strictEqual(sent.length, 1, JSON.stringify(sent));
    const m = sent[0];
    assert.match(m, /شروع فعالیت/);
    assert.match(m, /علت شروع/);
    assert.match(m, /نوع ورود: maker/);
    assert.match(m, /BTCUSDT/);
    assert.match(m, /25\.00 دلار/);
  });

  await t('each closed trade produces its own result message', async () => {
    const { rec, sent } = makeReporter();
    rec.tick({ context: muddy, positions: [{ symbol: 'BTCUSDT', notional: 25, dir: 1 }], equity: 100 });
    rec.onTradeClosed({ symbol: 'BTCUSDT', pnl: 0.28, pnlPct: 1.12, win: true, exit: { reason: 'take_profit' } });
    assert.strictEqual(sent.length, 2);
    assert.match(sent[1], /نتیجه معامله/);
    assert.match(sent[1], /take_profit/);
    assert.match(sent[1], /جمع این دور/);
  });

  await t('the session summary closes the episode', async () => {
    const { rec, sent } = makeReporter();
    rec.tick({ context: muddy, positions: [{ symbol: 'BTCUSDT', notional: 25, dir: 1 }], equity: 100 });
    rec.onTradeClosed({ symbol: 'BTCUSDT', pnl: 0.28, pnlPct: 1.12, win: true, exit: { reason: 'take_profit' } });
    rec.tick({ context: muddy, positions: [], equity: 100.28 });
    assert.strictEqual(sent.length, 3);
    assert.match(sent[2], /پایان دور/);
    assert.match(sent[2], /نرخ برد 100/);
    assert.strictEqual(rec.session, null);
  });

  await t('nothing is sent for the BlackBird profile', async () => {
    const { rec, cfg, sent } = makeReporter();
    cfg.profile.name = 'blackbird';
    rec.enabled = false; // mirrors the constructor check for the new name
    rec.tick({ context: muddy, positions: [{ symbol: 'BTCUSDT', notional: 25 }], equity: 100 });
    assert.strictEqual(sent.length, 0);
  });

  done('angry');
})();
